CREATE DATABASE IF NOT EXISTS `test_sitedb`;
GRANT ALL ON `test_sitedb`.* TO 'sitedb_user'@'%';
FLUSH PRIVILEGES;