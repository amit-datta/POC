docker exec -i "sitedb_mysql" mysql -uroot -ppass < ./create_test_sitedb.sql
docker exec -i "sitedb_mysql" mysql -usitedb_user -ppass test_sitedb < ./sitedb_schema.sql
docker exec -i "sitedb_mysql" mysql -usitedb_user -ppass test_sitedb < ./batch-schema-mysql.sql
docker exec -i "sitedb_mysql" mysql -usitedb_user -ppass sitedb < ./sitedb_schema.sql
docker exec -i "sitedb_mysql" mysql -usitedb_user -ppass sitedb < ./batch-schema-mysql.sql