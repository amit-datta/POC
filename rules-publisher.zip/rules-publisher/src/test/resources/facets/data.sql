DROP TABLE IF EXISTS PUBLIC.attribute;
CREATE TABLE IF NOT EXISTS PUBLIC.attribute
(
    ATTR_NAME          varchar(30)      not null primary key,
    FACET_DISPLAY_NAME varchar(100)     null,
    FACET_ATTRIBUTE    char default 'N' not null
);

INSERT INTO PUBLIC.attribute(ATTR_NAME, FACET_DISPLAY_NAME, FACET_ATTRIBUTE)
VALUES ('AGE', 'Age', 'Y'),
       ('ACCESSORIES_TYPE', 'ACCESSORIES_TYPE', 'Y'),
       ('ACTIVE_BRA', 'YES OR NO', 'N');