DROP TABLE IF EXISTS PUBLIC.MERCH_ACTION_PARAMETER;
DROP TABLE IF EXISTS PUBLIC.MERCH_ACTION;

CREATE TABLE IF NOT EXISTS PUBLIC.MERCH_ACTION
(
    `ACTION_ID`        int                                 not null,
    `ACTION_TYPE`      varchar(25)                         not null,
    `CREATED`          timestamp default CURRENT_TIMESTAMP not null,
    `CREATED_BY`       varchar(64)                         not null,
    `LAST_MODIFIED`    timestamp default CURRENT_TIMESTAMP not null,
    `LAST_MODIFIED_BY` varchar(64)                         not null
);

CREATE TABLE IF NOT EXISTS PUBLIC.MERCH_ACTION_PARAMETER
(
    `ACTION_ID`           int(11)                   not null,
    `PARAM_GROUP`         varchar(30)               not null,
    `PARAM_NAME`          varchar(30)               not null,
    `PARAM_VALUE`         varchar(300)              not null,
    `PARAM_SEQ_NBR`       int                       null,
    `PARAM_GROUP_SEQ_NBR` int                       null,
    `EFFECTIVE_DATE`      date default '0001-01-01' not null,
    `EXPIRATION_DATE`     date default '9999-12-31' not null
);
