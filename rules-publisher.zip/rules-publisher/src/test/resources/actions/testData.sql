INSERT INTO PUBLIC.MERCH_ACTION (ACTION_ID, ACTION_TYPE, CREATED, CREATED_BY, LAST_MODIFIED_BY)
VALUES (1, 'ModifySearchResults', '2013-06-12 18:06:22', 'p139tnb', 'p139tnb'),
       (2, 'CategoryRedirect', '2013-04-19 11:04:47', 'A050869', 'A050869');

INSERT INTO PUBLIC.MERCH_ACTION_PARAMETER(ACTION_ID, PARAM_GROUP, PARAM_NAME, PARAM_VALUE, PARAM_SEQ_NBR,
                                          PARAM_GROUP_SEQ_NBR)
VALUES (1, 'Operations', 'Operation', 'BOOST', null, null),
       (1, 'Pool', 'PoolId', '1', null, null),
       (2, 'Category', 'CategoryId', '64761', null, null),
       (2, 'Context', 'NAVIGATION_TYPE', 'SEARCH', null, null);
