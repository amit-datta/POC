DROP TABLE IF EXISTS PUBLIC.MERCH_RULE;
DROP TABLE IF EXISTS PUBLIC.ACTION_TO_RULE_MAPPING;
CREATE TABLE IF NOT EXISTS PUBLIC.MERCH_RULE
(
    `RULE_ID`          int                                 not null primary key,
    `RULE_NAME`        varchar(50)                         not null,
    `RULE_DESCRIPTION` varchar(200)                        null,
    `EFFECTIVE_DATE`   date      default '0001-01-01'      not null,
    `EXPIRATION_DATE`  date      default '9999-12-31'      not null,
    `CREATED`          timestamp default CURRENT_TIMESTAMP not null,
    `CREATED_BY`       varchar(64)                         not null,
    `LAST_MODIFIED`    timestamp default CURRENT_TIMESTAMP not null,
    `LAST_MODIFIED_BY` varchar(64)                         not null,
    `RULE_STATE_CODE`  smallint  default 0                 not null,
    `RULE_PRIORITY`    int       default 9999              not null,
    `TRIGGER_EXP_ID`   int                                 null,
    `RULE_TYPE`        varchar(10)                         null
);

INSERT INTO PUBLIC.MERCH_RULE (RULE_ID, RULE_NAME, RULE_DESCRIPTION, EFFECTIVE_DATE, EXPIRATION_DATE, CREATED,
                               CREATED_BY, LAST_MODIFIED, LAST_MODIFIED_BY, RULE_STATE_CODE, RULE_PRIORITY,
                               TRIGGER_EXP_ID, RULE_TYPE)
VALUES (1, 'CatRedirect: Panty', '', '2013-04-18',
        '2016-03-21', '2013-04-19 02:04:44', 'test',
        '2016-03-18 15:03:04', 'test', 1, 85,
        1, 'MERCH'),
       (2, 'URL Redirect: Beauty Blog', '', '2013-08-25',
        '2020-08-25', '2013-04-22 13:04:18', 'p139mma',
        '2020-08-25 13:08:12', 'M412138', 1, 70,
        2, 'MERCH'),

       (3, 'Facet Metadata - 50684 - 12/03/2020 09:48-111', 'Brand - YNQ Denim -',
        '2013-12-03', '2037-12-31', '2013-12-03 09:12:28',
        'A231310', '2020-12-03 09:12:28', 'A231310',
        1, 10, 3, 'SEO');

CREATE TABLE IF NOT EXISTS PUBLIC.ACTION_TO_RULE_MAPPING
(
    RULE_ID   int not null,
    ACTION_ID int not null,
    primary key (RULE_ID, ACTION_ID)
);

INSERT INTO ACTION_TO_RULE_MAPPING(RULE_ID, ACTION_ID)
VALUES (1, 1);
VALUES (2, 2);
VALUES (3, 3);