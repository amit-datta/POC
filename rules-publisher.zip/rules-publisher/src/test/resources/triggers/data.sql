DROP TABLE IF EXISTS PUBLIC.MERCH_TRIGGER;
CREATE TABLE IF NOT EXISTS PUBLIC.MERCH_TRIGGER
(
    TRIGGER_ID             int                                 not null
        primary key,
    TRIGGER_TYPE           varchar(30)                         not null,
    IS_SEARCHABLE          char                                not null,
    IS_RESULT_SET_REQUIRED char                                not null,
    CREATED                timestamp default CURRENT_TIMESTAMP not null,
    CREATED_BY             varchar(64)                         not null,
    LAST_MODIFIED          timestamp default CURRENT_TIMESTAMP not null,
    LAST_MODIFIED_BY       varchar(64)                         not null
);

INSERT INTO PUBLIC.MERCH_TRIGGER (TRIGGER_ID, TRIGGER_TYPE, IS_SEARCHABLE, IS_RESULT_SET_REQUIRED, CREATED, CREATED_BY,
                                  LAST_MODIFIED, LAST_MODIFIED_BY)
VALUES (1, 'KeywordPattern', 'Y', 'N',
        '2013-04-19 10:04:19', 'test', '2013-04-19 10:04:19', 'test'),
       (2, 'FacetRefinement', 'N', 'N',
        '2014-04-03 17:04:40', 'y124123', '2014-04-03 17:04:40', 'y124123'),
       (3, 'HierarchicalRefinement', 'Y', 'N',
        '2014-05-10 00:05:00', 'UN_Phase0_Migration', '2014-05-10 00:05:00', 'UN_Phase0_Migration');

DROP TABLE IF EXISTS PUBLIC.MERCH_TRIGGER_PARAMETER;
CREATE TABLE IF NOT EXISTS PUBLIC.MERCH_TRIGGER_PARAMETER
(
    `TRIGGER_ID`  int          not null,
    `PARAM_GROUP` varchar(30)  not null,
    `PARAM_NAME`  varchar(30)  not null,
    `PARAM_VALUE` varchar(300) not null
);
