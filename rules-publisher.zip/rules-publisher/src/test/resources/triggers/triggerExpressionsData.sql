DROP TABLE IF EXISTS PUBLIC.MERCH_TRIGGER_EXPRESSION;
CREATE TABLE IF NOT EXISTS PUBLIC.MERCH_TRIGGER_EXPRESSION
(
    TRIGGER_EXP_ID     int                                 not null
        primary key,
    PARENT_TRIG_EXP_ID int                                 null,
    RULE_ID            int                                 null,
    TRIGGER_ID         int                                 null,
    OPERATOR           varchar(3)                          null,
    CREATED            timestamp default CURRENT_TIMESTAMP not null,
    CREATED_BY         varchar(64)                         not null,
    LAST_MODIFIED      timestamp default CURRENT_TIMESTAMP not null,
    LAST_MODIFIED_BY   varchar(64)                         not null,
    CHILD_TRIG_EXP_ID  int                                 null,
    TRIGGER_GROUP_NM   varchar(50)                         null
);

INSERT INTO PUBLIC.MERCH_TRIGGER_EXPRESSION(TRIGGER_EXP_ID, PARENT_TRIG_EXP_ID, RULE_ID, TRIGGER_ID, OPERATOR, CREATED,
                                            CREATED_BY, LAST_MODIFIED, LAST_MODIFIED_BY, CHILD_TRIG_EXP_ID,
                                            TRIGGER_GROUP_NM)
VALUES (1, null, null, null, 'AND',
        '2013-04-19 02:04:16', 'test', '2020-05-14 14:05:45',
        'test', 2, ''),
       (2, 1, null, 1, 'AND',
        '2013-05-29 21:05:21', 'm448728', '2015-01-28 16:01:02',
        'm076491', null, ''),
       (3, null, null, null, 'AND',
        '2013-06-12 14:06:11', 'y964432', '2015-01-28 16:01:02',
        'm076491', null, '');