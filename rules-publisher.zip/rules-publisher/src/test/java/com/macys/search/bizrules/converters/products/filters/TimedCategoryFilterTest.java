package com.macys.search.bizrules.converters.products.filters;

import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import com.macys.search.bizrules.model.product.Product;
import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TimedCategoryFilterTest {

    private final TimedCategoryFilter filter = new TimedCategoryFilter();

    @Test
    void thereIsNoTimedAttributeInCategory() {
        Category category = Category.builder().attributes(Map.of()).build();
        Product product = Product.builder().build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void timedAttributeHasSeveralValues() {
        Category category = Category.builder()
                .attributes(Map.of(CategoryAttributeName.TIMED_FILTER,
                        CategoryAttribute.builder()
                                .values(Set.of("1", "2"))
                                .build()))
                .build();
        Product product = Product.builder().build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void timedAttributeHasUnexpectedValues() {
        Category category = Category.builder()
                .attributes(Map.of(CategoryAttributeName.TIMED_FILTER,
                        CategoryAttribute.builder()
                                .values(Set.of("Unexpected"))
                                .build()))
                .build();
        Product product = Product.builder().build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void testNewArrivalsPassed() {
        Category category = Category.builder()
                .attributes(Map.of(CategoryAttributeName.TIMED_FILTER,
                        CategoryAttribute.builder()
                                .values(Set.of("New Arrivals"))
                                .build()))
                .build();
        Product product = Product.builder()
                .isNew(true)
                .newMarkdown(false)
                .build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void testNewArrivalsFailed() {
        Category category = Category.builder()
                .attributes(Map.of(CategoryAttributeName.TIMED_FILTER,
                        CategoryAttribute.builder()
                                .values(Set.of("New Arrivals"))
                                .build()))
                .build();
        Product product = Product.builder()
                .isNew(false)
                .newMarkdown(true)
                .build();
        assertFalse(filter.pass(category, product));
    }

    @Test
    void testNewMarkdownsPassed() {
        Category category = Category.builder()
                .attributes(Map.of(CategoryAttributeName.TIMED_FILTER,
                        CategoryAttribute.builder()
                                .values(Set.of("New Markdowns"))
                                .build()))
                .build();
        Product product = Product.builder()
                .isNew(false)
                .newMarkdown(true)
                .build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void testNewMarkdownsFailed() {
        Category category = Category.builder()
                .attributes(Map.of(CategoryAttributeName.TIMED_FILTER,
                        CategoryAttribute.builder()
                                .values(Set.of("New Markdowns"))
                                .build()))
                .build();
        Product product = Product.builder()
                .isNew(true)
                .newMarkdown(false)
                .build();
        assertFalse(filter.pass(category, product));
    }

}