package com.macys.search.bizrules.converters.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.FacetRefinementMatchType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.FacetRefinementTriggerParams;
import com.macys.search.bizrules.services.merch.TriggersService;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FacetRefinementTriggerConverterTest extends BaseTest {

    @Autowired
    private FacetRefinementTriggerConverter converter;
    @Autowired
    private TriggersService triggersService;

    @Test
    void applicableFor() {
        assertEquals(TriggerType.FacetRefinement, converter.applicableFor());
    }

    @Test
    void conversionTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee & Espresso");
        TestUtils.triggerAddParam(trigger, "FURNITURE_CATEGORY", "AttributeValue", "Couches & Sofas");
        TestUtils.triggerAddParam(trigger, "BED_SIZE", "AttributeValue", "Queen");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setTriggers(Map.of(17223, ProcessingTrigger.from(trigger)));

        ProcessingTrigger processingTrigger = triggersService.getProcessedTrigger(17223, ctx);

        FacetRefinementTriggerParams actualParams = (FacetRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        FacetRefinementTriggerParams expectedParams = FacetRefinementTriggerParams.builder()
                .triggerId(17223)
                .matchType(FacetRefinementMatchType.contains_and)
                .refinements(Map.of(
                        "refinement_electrics_type", Set.of("Coffee & Espresso"),
                        "refinement_furniture_category", Set.of("Couches & Sofas"),
                        "refinement_bed_size", Set.of("Queen")
                ))
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void severalValuesTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Sofas");
        TestUtils.triggerAddParam(trigger, "BED_SIZE", "AttributeValue", "Queen");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setTriggers(Map.of(17223, ProcessingTrigger.from(trigger)));

        ProcessingTrigger processingTrigger = triggersService.getProcessedTrigger(17223, ctx);

        FacetRefinementTriggerParams actualParams = (FacetRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        FacetRefinementTriggerParams expectedParams = FacetRefinementTriggerParams.builder()
                .triggerId(17223)
                .matchType(FacetRefinementMatchType.contains_and)
                .refinements(Map.of(
                        "refinement_electrics_type", Set.of("Coffee", "Sofas"),
                        "refinement_bed_size", Set.of("Queen")
                ))
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void optionalMapTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Exact");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setTriggers(Map.of(17223, ProcessingTrigger.from(trigger)));

        ProcessingTrigger processingTrigger = triggersService.getProcessedTrigger(17223, ctx);

        FacetRefinementTriggerParams actualParams = (FacetRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        FacetRefinementTriggerParams expectedParams = FacetRefinementTriggerParams.builder()
                .triggerId(17223)
                .matchType(FacetRefinementMatchType.exact_and)
                .refinements(Map.of())
                .build();

        assertEquals(expectedParams, actualParams);
    }
}