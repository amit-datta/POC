package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AbstractActionConverterTest {

    final AbstractActionConverter underTest = new AbstractActionConverter() {
        @Override
        public ActionType applicableFor() {
            return null;
        }

        @Override
        void enrichWithTypeSpecificProperties(Action action, ESAction result, ProcessingContext context) {
        }
    };

    @Test
    void convert() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.ProductRedirect);
        action.setCreatedDate(LocalDate.of(2021, 2, 4));
        action.setLastModified(LocalDate.of(2021, 2, 3));
        action.setLastModifiedByName("LMBY");

        ESAction esAction = underTest.convert(action, null);

        Map<String, Object> expected = new HashMap<>();
        expected.put("action_id", 1);
        expected.put("action_type_priority", 3);
        Map<String, ?> actual = esAction.getSource();
        assertEquals(expected, actual);
    }

    @Test
    void actionTypePriority0() {
        Action action = new Action();
        action.setId(222);
        action.setMerchActionType(ActionType.ShowMedia);

        ESAction esAction = underTest.convert(action, null);
        assertEquals(0, esAction.getSource().get("action_type_priority"));
    }

    @Test
    void actionTypePriority1() {
        Action action = new Action();
        action.setId(222);
        action.setMerchActionType(ActionType.URLRedirect);

        ESAction esAction = underTest.convert(action, null);
        assertEquals(1, esAction.getSource().get("action_type_priority"));
    }

    @Test
    void actionTypePriority2() {
        Action action = new Action();
        action.setId(222);
        action.setMerchActionType(ActionType.CategoryRedirect);

        ESAction esAction = underTest.convert(action, null);
        assertEquals(2, esAction.getSource().get("action_type_priority"));
    }

    @Test
    void actionTypePriority3OrMax() {
        Action action = new Action();
        action.setId(222);
        action.setMerchActionType(ActionType.ProductRedirect);

        ESAction esAction = underTest.convert(action, null);
        assertEquals(3, esAction.getSource().get("action_type_priority"));
    }
}