package com.macys.search.bizrules.repository.mrf;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.time.Month;

class CustomDateReaderTest extends BaseTest {
    @Autowired
    private CustomDateReader customDateReader;

    @Test
    @Sql({"classpath:customDate/data.sql"})
    void testGetCustomDate() {
        LocalDate actual = customDateReader.getCustomDate(SiteName.MCOM);
        Assertions.assertEquals(LocalDate.of(2021, Month.FEBRUARY, 25), actual);
    }
}
