package com.macys.search.bizrules.repository.mrf;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.ContextUtils;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.tasklets.JobParams.SITE_NAME_JOB_PARAM;

public class RulesReaderTest extends BaseTest {

    private static final ProcessingContext context = ContextUtils.createProcessingContext(Map.of(
            SITE_NAME_JOB_PARAM, new JobParameter("MCOM")
    ));

    @Autowired
    private RulesReader rulesReader;

    @Test
    @Sql({"classpath:rules/data.sql"})
    public void testReadRules() {
        Map<Integer, ProcessingRule> actualRulesMap = new HashMap<>();
        Map<Integer, Integer> actualExpressionToRuleMapping = new HashMap<>();
        rulesReader.readRules(context, LocalDate.of(2014, Month.APRIL, 26), actualRulesMap, actualExpressionToRuleMapping);

        Rule expected = createRule(1, "CatRedirect: Panty", "", LocalDate.of(2013, Month.APRIL, 18),
                LocalDate.of(2016, Month.MARCH, 21), 85,
                LocalDateTime.of(2016, Month.MARCH, 18, 15, 3, 4),
                LocalDateTime.of(2013, Month.APRIL, 19, 2, 4, 44), "test",
                "test", RuleType.MERCH, List.of(1));

        Rule expected1 = createRule(2, "URL Redirect: Beauty Blog", "",
                LocalDate.of(2013, Month.AUGUST, 25),
                LocalDate.of(2020, Month.AUGUST, 25),
                70, LocalDateTime.of(2020, Month.AUGUST, 25, 13, 8, 12),
                LocalDateTime.of(2013, Month.APRIL, 22, 13, 4, 18),
                "p139mma", "M412138", RuleType.MERCH, List.of());

        Rule expected2 = createRule(3, "Facet Metadata - 50684 - 12/03/2020 09:48-111",
                "Brand - YNQ Denim -", LocalDate.of(2013, Month.DECEMBER, 3),
                LocalDate.of(2037, Month.DECEMBER, 31), 10,
                LocalDateTime.of(2020, Month.DECEMBER, 3, 9, 12, 28),
                LocalDateTime.of(2013, Month.DECEMBER, 3, 9, 12, 28),
                "A231310", "A231310", RuleType.SEO, List.of());

        Assertions.assertEquals(3, actualRulesMap.size());
        ProcessingRule actualRule = actualRulesMap.get(1);
        ProcessingRule actualRule1 = actualRulesMap.get(2);
        ProcessingRule actualRule2 = actualRulesMap.get(3);

        Assertions.assertEquals(expected, actualRule.getRule());
        Assertions.assertEquals(expected1, actualRule1.getRule());
        Assertions.assertEquals(expected2, actualRule2.getRule());
    }

    @Test
    @Sql({"classpath:rules/data.sql"})
    public void testGetRuleById() {
        Rule actual = rulesReader.getRuleById(SiteName.MCOM, 1);
        Rule expected = createRule(1, "CatRedirect: Panty", "",
                LocalDate.of(2013, Month.APRIL, 18),
                LocalDate.of(2016, Month.MARCH, 21), 85,
                LocalDateTime.of(2016, Month.MARCH, 18, 15, 3, 4),
                LocalDateTime.of(2013, Month.APRIL, 19, 2, 4, 44),
                "test", "test", RuleType.MERCH, List.of(1));
        Assertions.assertEquals(expected, actual);
    }

    private Rule createRule(int id, String name, String description, LocalDate effectiveDate, LocalDate expirationDate,
                            int priority, LocalDateTime lastModified, LocalDateTime createdDate,
                            String authorName, String lastModifiedByName, RuleType ruleType, List<Integer> actionIds) {
        Rule rule = new Rule();
        rule.setId(id);
        rule.setName(name);
        rule.setDescription(description);
        rule.setEffectiveDate(effectiveDate);
        rule.setExpirationDate(expirationDate);
        rule.setPriority(priority);
        rule.setStateCode(1);
        rule.setLastModified(lastModified);
        rule.setCreatedDate(createdDate);
        rule.setAuthorName(authorName);
        rule.setLastModifiedByName(lastModifiedByName);
        rule.setMerchRuleType(ruleType);
        rule.setActionsIds(actionIds);
        return rule;
    }
}