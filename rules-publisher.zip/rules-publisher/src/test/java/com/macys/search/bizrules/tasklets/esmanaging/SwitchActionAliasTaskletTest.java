package com.macys.search.bizrules.tasklets.esmanaging;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;

class SwitchActionAliasTaskletTest extends AbstractTaskletTest {

    private final String mcomKwpTriggersIndexAliasName = "kwp_triggers";
    private final String bcomKwpTriggersIndexAliasName = "kwp_triggers";
    private final String mcomActionsIndexAliasName = "mcom_actions";
    private final String bcomActionsIndexAliasName = "bcom_actions";
    private final String mcomRulesIndexAliasName = "mcom_rules";
    private final String bcomRulesIndexAliasName = "bcom_rules";
    private final String mcomTriggersIndexAliasName = "mcom_triggers";
    private final String bcomTriggersIndexAliasName = "bcom_triggers";
    private final String mcomProductsIndexAliasName = "mcom_products";
    private final String bcomProductsIndexAliasName = "bcom_products";
    private final String mcomCategoriesIndexAliasName = "mcom_categories";
    private final String bcomCategoriesIndexAliasName = "bcom_categories";
    private final String mcomBizControlsDbIndexAliasName = "mcom_biz_controls_db";
    private final String bcomBizControlsDbIndexAliasName = "bcom_biz_controls_db";


    private final Integer mcomIndicesToKeep = 2;
    private final Integer bcomIndicesToKeep = 2;
    private final String mcomKwpTriggersIndexName = "mcom_kwp_triggers_index";
    private final String bcomKwpTriggersIndexName = "bcom_kwp_triggers_index";
    private final String mcomBizControlsDbIndexName = "mcom_biz_controls_db_index";
    private final String bcomBizControlsDbIndexName = "bcom_biz_controls_db_index";

    private final String mcomActionsIndexName = "mcom_actions_index";
    private final String bcomActionsIndexName = "bcom_actions_index";
    private final String mcomRulesIndexName = "mcom_rules_index";
    private final String bcomRulesIndexName = "bcom_rules_index";

    private final String mcomTriggersIndexName = "mcom_triggers_index";
    private final String bcomTriggersIndexName = "bcom_triggers_index";

    private final String mcomCategoriesIndexName = "mcom_categories_index";
    private final String bcomCategoriesIndexName = "bcom_categories_index";

    private final String mcomProductsIndexName = "mcom_products_index";
    private final String bcomProductsIndexName = "bcom_products_index";

    @Mock
    private ElasticSearchFacade facade;
    @Autowired
    private ElasticSearchIndexerFactory factory;

    private SwitchAliasTasklet create(ESIndex index, SiteName siteName, String aliasName) {
        SwitchAliasProperties mcomProperties = SwitchAliasProperties.of(
                index,
                aliasName,
                null,
                "",
                1);
        SwitchAliasProperties bcomProperties = SwitchAliasProperties.of(
                index,
                null,
                aliasName,
                "",
                1
        );
        List<SwitchAliasProperties> properties = List.of(siteName == SiteName.MCOM ? mcomProperties : bcomProperties);
        CommonIndexProperties common = new CommonIndexProperties(2, "unfinished");
        return new SwitchAliasTasklet(facade, properties, common, common, new ObjectMapper());
    }

    @Test
    void switchBizControlsDbAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.BIZ_CONTROLS_DB, mcomBizControlsDbIndexName, mcomBizControlsDbIndexAliasName);
    }

    @Test
    void switchBizControlsDbAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.BIZ_CONTROLS_DB, bcomBizControlsDbIndexName, mcomBizControlsDbIndexAliasName);
    }

    @Test
    void switchKwpTriggersAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.KWP_TRIGGERS, mcomKwpTriggersIndexName, mcomKwpTriggersIndexAliasName);
    }

    @Test
    void switchKwpTriggersAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.KWP_TRIGGERS, bcomKwpTriggersIndexName, bcomKwpTriggersIndexAliasName);
    }

    @Test
    void switchActionsAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.ACTIONS, mcomActionsIndexName, mcomActionsIndexAliasName);
    }

    @Test
    void switchActionsAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.ACTIONS, bcomActionsIndexName, bcomActionsIndexAliasName);
    }

    @Test
    void switchRulesAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.RULES, mcomRulesIndexName, mcomRulesIndexAliasName);
    }

    @Test
    void switchRulesAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.RULES, bcomRulesIndexName, bcomRulesIndexAliasName);
    }

    @Test
    void switchTriggersAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.TRIGGERS, mcomTriggersIndexName, mcomTriggersIndexAliasName);
    }

    @Test
    void switchTriggersAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.TRIGGERS, bcomTriggersIndexName, bcomTriggersIndexAliasName);
    }

    @Test
    void switchProductsAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.PRODUCTS, mcomProductsIndexName, mcomProductsIndexAliasName);
    }

    @Test
    void switchProductsAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.PRODUCTS, bcomProductsIndexName, bcomProductsIndexAliasName);
    }

    @Test
    void switchCategoriesAliasForMCOM() throws Exception {
        switchForSingleIndexTest(SiteName.MCOM, ESIndex.CATEGORIES, mcomCategoriesIndexName, mcomCategoriesIndexAliasName);
    }

    @Test
    void switchCategoriesAliasForBCOM() throws Exception {
        switchForSingleIndexTest(SiteName.BCOM, ESIndex.CATEGORIES, bcomCategoriesIndexName, bcomCategoriesIndexAliasName);
    }

    void switchForSingleIndexTest(SiteName siteName, ESIndex index, String indexName, String aliasName) throws Exception {
        SwitchAliasTasklet underTestTasklet = create(index, siteName, aliasName);
        changeSiteName(siteName);

        ctx.setupIndex(ESIndex.KWP_TRIGGERS, indexName, factory.createIndexer(indexName));
        ctx.setupIndex(ESIndex.BIZ_CONTROLS_DB, indexName, factory.createIndexer(indexName));
        ctx.setupIndex(ESIndex.RULES, indexName, factory.createIndexer(indexName));
        ctx.setupIndex(ESIndex.ACTIONS, indexName, factory.createIndexer(indexName));
        ctx.setupIndex(ESIndex.TRIGGERS, indexName, factory.createIndexer(indexName));
        ctx.setupIndex(ESIndex.PRODUCTS, indexName, factory.createIndexer(indexName));
        ctx.setupIndex(ESIndex.CATEGORIES, indexName, factory.createIndexer(indexName));

        Mockito.doNothing().when(facade).merge(indexName, 1);
        Mockito.doNothing().when(facade).switchAlias(any(), any());
        Mockito.when(facade.getIndicesStartingWith(aliasName)).thenReturn(
                List.of("INDEX_0", "INDEX_1", "INDEX_2", "INDEX_3", "INDEX_4")
        );
        Mockito.doNothing().when(facade).deleteIndices("INDEX_2", "INDEX_3", "INDEX_4");
        execute(underTestTasklet);
        Mockito.verify(facade).merge(indexName, 1);
        Mockito.verify(facade).switchAlias(any(), any());
        Mockito.verify(facade).deleteIndices("INDEX_2", "INDEX_3", "INDEX_4");
    }
}