package com.macys.search.bizrules.model.category;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static java.util.Collections.emptyList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CategoryTreeTest {

    @Test
    void emptyCategoryTree() {
        CategoryTree tree = CategoryTree.from(emptyList());
        assertTrue(tree.getChildren(1, emptyList()).isEmpty());
        assertTrue(tree.getChildren(1, Set.of(2, 3, 4)).isEmpty());
        assertTrue(tree.getParents(1).isEmpty());
    }

    @Test
    void oneNodeTree() {
        CategoryTree tree = CategoryTree.from(List.of(cat(1)));
        assertTrue(tree.getChildren(1, emptyList()).isEmpty());
        assertTrue(tree.getChildren(1, Set.of(2, 3, 4)).isEmpty());
        assertTrue(tree.getParents(1).isEmpty());
    }

    @Test
    void twoNodeTree() {
        Category c1 = cat(1);
        Category c2 = cat(2, 1);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2));

        assertEquals(List.of(2), tree.getChildren(1, emptyList()));
        assertEquals(List.of(2), tree.getChildren(1, Set.of(3, 4)));
        assertTrue(tree.getChildren(1, Set.of(2, 3, 4)).isEmpty());
        assertTrue(tree.getParents(1).isEmpty());

        assertTrue(tree.getChildren(2, emptyList()).isEmpty());
        assertTrue(tree.getChildren(2, Set.of(3, 4)).isEmpty());
        assertEquals(List.of(1), tree.getParents(2));
    }


    @Test
    void twoTree() {
        Category c1 = cat(1);
        Category c2 = cat(2, 1);
        Category c3 = cat(3, 2);

        Category c4 = cat(4);
        Category c5 = cat(5, 4);
        Category c6 = cat(6, 5);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2, c3, c4, c5, c6));

        assertEquals(List.of(2, 3), tree.getChildren(1, emptyList()));
        assertEquals(List.of(3), tree.getChildren(2, emptyList()));
        assertEquals(List.of(), tree.getChildren(3, emptyList()));
        assertEquals(List.of(5, 6), tree.getChildren(4, emptyList()));
        assertEquals(List.of(6), tree.getChildren(5, emptyList()));
        assertEquals(List.of(), tree.getChildren(6, emptyList()));

        assertEquals(List.of(), tree.getParents(1));
        assertEquals(List.of(1), tree.getParents(2));
        assertEquals(List.of(1, 2), tree.getParents(3));
        assertEquals(List.of(), tree.getParents(4));
        assertEquals(List.of(4), tree.getParents(5));
        assertEquals(List.of(4, 5), tree.getParents(6));
    }

    @Test
    void simpleCycleInTree() {
        Category c1 = cat(1, 2);
        Category c2 = cat(2, 1);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2));

        assertEquals(List.of(), tree.getChildren(1, emptyList()));
        assertEquals(List.of(), tree.getChildren(2, emptyList()));
        assertEquals(List.of(), tree.getParents(1));
        assertEquals(List.of(), tree.getParents(2));
    }

    @Test
    void cycleInTree() {
        Category c1 = cat(1, 3);
        Category c2 = cat(2, 1);
        Category c3 = cat(3, 2);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2, c3));

        assertEquals(List.of(), tree.getChildren(1, emptyList()));
        assertEquals(List.of(), tree.getChildren(2, emptyList()));
        assertEquals(List.of(), tree.getChildren(3, emptyList()));
        assertEquals(List.of(), tree.getParents(1));
        assertEquals(List.of(), tree.getParents(2));
        assertEquals(List.of(), tree.getParents(3));
    }

    @Test
    void cycleIn2Tree() {
        Category c1 = cat(1, null);
        Category c2 = cat(2, 1);
        Category c3 = cat(3, 2);

        Category c4 = cat(4, 6);
        Category c5 = cat(5, 4);
        Category c6 = cat(6, 5);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2, c3, c4, c5, c6));

        assertEquals(List.of(2, 3), tree.getChildren(1, emptyList()));
        assertEquals(List.of(3), tree.getChildren(2, emptyList()));
        assertEquals(List.of(), tree.getChildren(3, emptyList()));

        assertEquals(List.of(), tree.getChildren(4, emptyList()));
        assertEquals(List.of(), tree.getChildren(5, emptyList()));
        assertEquals(List.of(), tree.getChildren(6, emptyList()));

        assertEquals(List.of(), tree.getParents(1));
        assertEquals(List.of(1), tree.getParents(2));
        assertEquals(List.of(1, 2), tree.getParents(3));

        assertEquals(List.of(), tree.getParents(4));
        assertEquals(List.of(), tree.getParents(5));
        assertEquals(List.of(), tree.getParents(6));
    }

    @Test
    void cycleInOneElementTree() {
        Category c1 = cat(1, 1);
        CategoryTree tree = CategoryTree.from(List.of(c1));
        assertEquals(List.of(), tree.getChildren(1, emptyList()));
        assertEquals(List.of(), tree.getParents(1));
    }

    @Test
    void emptyHierarchyTest() {
        Category c1 = cat(1);
        Category c2 = cat(2, 1);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2));

        assertTrue(tree.getHierarchy(3).isEmpty());
    }

    @Test
    void hierarchyTest() {
        Category c1 = cat(1);
        Category c2 = cat(2, 1);
        Category c3 = cat(3, 2);
        CategoryTree tree = CategoryTree.from(List.of(c1, c2, c3));

        assertEquals(List.of(1, 2, 3), tree.getHierarchy(3));
    }

    private Category cat(Integer id, String name, Integer parentId) {
        return Category.builder()
                .id(id)
                .name(name)
                .parentCategoryId(parentId)
                .build();
    }

    private Category cat(Integer id, Integer parentId) {
        return cat(id, "Name " + id.toString(), parentId);
    }

    private Category cat(Integer id) {
        return cat(id, null);
    }

}