package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static com.macys.search.bizrules.model.mrf.action.ActionType.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ActionConverterServiceTest {

    @Test
    void notImplementedConverterException() {
        ActionConverter urlRedirect = mock(ActionConverter.class);
        when(urlRedirect.applicableFor()).thenReturn(URLRedirect);
        ActionConverter categoryRedirect = mock(ActionConverter.class);
        when(categoryRedirect.applicableFor()).thenReturn(CategoryRedirect);

        Exception exception = assertThrows(RuntimeException.class, () ->
                new ActionConverterService(
                        List.of(categoryRedirect, urlRedirect),
                        List.of(ProductRedirect, URLRedirect, CategoryRedirect)
                ));

        String expectedMessage = "Some of action converters have not implemented yet. Enabled action types=[ProductRedirect, URLRedirect, CategoryRedirect] Implemented converters types=[CategoryRedirect, URLRedirect]";
        String actualMessage = exception.getMessage();

        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void chooseCorrectImplementation() {
        ActionConverter productRedirect = mock(ActionConverter.class);
        when(productRedirect.applicableFor()).thenReturn(ProductRedirect);
        ActionConverter urlRedirect = mock(ActionConverter.class);
        when(urlRedirect.applicableFor()).thenReturn(URLRedirect);
        ActionConverter categoryRedirect = mock(ActionConverter.class);
        when(categoryRedirect.applicableFor()).thenReturn(CategoryRedirect);

        ActionConverterService service = new ActionConverterService(
                List.of(productRedirect, categoryRedirect, urlRedirect),
                List.of(ProductRedirect, URLRedirect, CategoryRedirect)
        );

        Action action = new Action();
        action.setMerchActionType(ProductRedirect);
        when(productRedirect.convert(any(), any())).thenReturn(new ESAction());
        service.convert(action, null);

        Mockito.verify(productRedirect, times(1)).convert(action, null);
    }

    @Test
    void NPWWhenTryToConvertDisabledActionType() {
        ActionConverter productRedirect = mock(ActionConverter.class);
        when(productRedirect.applicableFor()).thenReturn(ProductRedirect);
        ActionConverter urlRedirect = mock(ActionConverter.class);
        when(urlRedirect.applicableFor()).thenReturn(URLRedirect);
        ActionConverter categoryRedirect = mock(ActionConverter.class);
        when(categoryRedirect.applicableFor()).thenReturn(CategoryRedirect);

        ActionConverterService service = new ActionConverterService(
                List.of(productRedirect, categoryRedirect, urlRedirect),
                List.of(ProductRedirect, URLRedirect, CategoryRedirect)
        );

        Action action = new Action();
        action.setMerchActionType(ShowMedia);

        assertThrows(NullPointerException.class, () ->
                service.convert(action, null)
        );
    }

}