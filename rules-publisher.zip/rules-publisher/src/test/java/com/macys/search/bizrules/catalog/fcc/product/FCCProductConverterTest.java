package com.macys.search.bizrules.catalog.fcc.product;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.catalog.fcc.product.bindings.MetricBinding;
import com.macys.search.bizrules.catalog.fcc.product.bindings.ProductBinding;
import com.macys.search.bizrules.catalog.fcc.product.bindings.ReviewStatisticBinding;
import com.macys.search.bizrules.model.product.*;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FCCProductConverterTest {

    FCCProductConverterTest() throws JsonProcessingException {
    }

    ObjectMapper mapper = new ObjectMapper();
    ProductBinding binding = mapper.readValue(
            "     {\n" +
                    "                    \"id\": 10223082,\n" +
                    "                    \"price\": {\n" +
                    "                        \"retailPrice\": 37.99,\n" +
                    "                        \"priceType\": 3,\n" +
                    "                        \"newMarkdown\": true\n" +
                    "                    },\n" +
                    "                    \"isNew\": true,\n" +
                    "                    \"categories\": [\n" +
                    "                        {\n" +
                    "                            \"id\": 73162\n" +
                    "                        },\n" +
                    "                        {\n" +
                    "                            \"id\": 75512\n" +
                    "                        },\n" +
                    "                        {\n" +
                    "                            \"id\": 199967\n" +
                    "                        }\n" +
                    "                    ],\n" +
                    "                    \"pools\": [\n" +
                    "                        {\n" +
                    "                            \"id\": 1449949\n" +
                    "                      },\n" +
                    "                      {\n" +
                    "                          \"id\": 3294690\n" +
                    "                      },\n" +
                    "                      {\n" +
                    "                          \"id\": 3348292\n" +
                    "                      }" +
                    "                    ],\n" +
                    "                    \"upcs\": [\n" +
                    "                        {\n" +
                    "                            \"id\": 42647361,\n" +
                    "                            \"productId\": 10223082,\n" +
                    "                            \"price\": {\n" +
                    "                                \"retailPrice\": 37.99,\n" +
                    "                                \"priceType\": 3,\n" +
                    "                                \"newMarkdown\": false\n" +
                    "                            },\n" +
                    "                            \"availability\": {\n" +
                    "                                \"available\": true\n" +
                    "                            },\n" +
                    "                            \"active\": true,\n" +
                    "                            \"link\": []\n" +
                    "                        }\n" +
                    "                    ],\n" +
                    "                    \"memberProducts\": [\n" +
                    "                       {\n" +
                    "                            \"id\": 10565301" +
                    "                        }\n" +
                    "                    ]\n" +
                    "                }",
            ProductBinding.class
    );

    @Test
    void convert() {
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullId() {
        binding.setId(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(-1)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullIsNewAndNewMarkDown() {
        binding.setIsNew(null);
        binding.getPrice().setNewMarkdown(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(false)
                .newMarkdown(false)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullCategories() {
        binding.setCategories(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(List.of())
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullUpcs() {
        binding.setUpcs(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of()
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullUpcFields() {
        binding.getUpcs().iterator().next().setId(null);
        binding.getUpcs().iterator().next().setPrice(null);
        binding.getUpcs().iterator().next().setAvailability(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(-1)
                                        .price(null)
                                        .available(false)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void filterDisabledUpcs() {
        binding.getUpcs().iterator().next().setActive(false);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of()
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullPoolsId() {
        binding.setPools(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(List.of())
                .members(List.of(
                                Product.builder()
                                        .productId(10565301)
                                        .members(List.of())
                                        .parentCategories(List.of())
                                        .pools(List.of())
                                        .upcs(List.of())
                                        .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullMembers() {
        binding.setMemberProducts(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of())
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void reviewStatisticsNull() {
        binding.setReviewStatistics(null);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                        Product.builder()
                                .productId(10565301)
                                .members(List.of())
                                .parentCategories(List.of())
                                .pools(List.of())
                                .upcs(List.of())
                                .build()
                        )
                )
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .recentlyReviewTimestamp(null)
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void reviewStatistics() {
        ReviewStatisticBinding reviewStatisticBinding = new ReviewStatisticBinding();
        reviewStatisticBinding.setRecentlyReviewTimestamp(12345L);
        reviewStatisticBinding.setReviewCount(100);
        reviewStatisticBinding.setProductId(1000);
        reviewStatisticBinding.setAverageRating(54.0f);
        reviewStatisticBinding.setAverageRating(60.0f);
        binding.setReviewStatistics(reviewStatisticBinding);
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                        Product.builder()
                                .productId(10565301)
                                .members(List.of())
                                .parentCategories(List.of())
                                .pools(List.of())
                                .upcs(List.of())
                                .build()
                ))
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .recentlyReviewTimestamp(12345L)
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void metricsTest() {
        MetricBinding metricBinding1 = new MetricBinding();
        metricBinding1.setName("MetricBinding1");
        metricBinding1.setValue(123);
        metricBinding1.setRawValue("MetricBindingRawValue");

        MetricBinding metricBinding2 = new MetricBinding();
        metricBinding2.setName("MetricBinding2");
        metricBinding2.setValue(222);

        MetricBinding metricBinding3 = new MetricBinding();
        metricBinding3.setName("MetricBinding3");
        metricBinding3.setRawValue("MetricBindingRawValue3");

        MetricBinding metricBinding4 = new MetricBinding();
        metricBinding4.setValue(444);
        metricBinding4.setRawValue("MetricBindingRawValue4");

        binding.setMetrics(List.of(metricBinding1, metricBinding2, metricBinding3, metricBinding4));
        Product actual = FCCProductConverter.convert(binding);
        Product expected = Product.builder()
                .productId(10223082)
                .isNew(true)
                .newMarkdown(true)
                .parentCategories(createProductToCatetory(List.of(73162, 75512, 199967)))
                .pools(createProductToPool(List.of(1449949, 3294690, 3348292)))
                .members(List.of(
                        Product.builder()
                                .productId(10565301)
                                .members(List.of())
                                .parentCategories(List.of())
                                .pools(List.of())
                                .upcs(List.of())
                                .build()
                ))
                .upcs(
                        List.of(
                                Upc.builder()
                                        .upcId(42647361)
                                        .price(
                                                Price.builder()
                                                        .priceType(3)
                                                        .retailPrice(37.99)
                                                        .originalPrice(0)
                                                        .intermediatePrice(0)
                                                        .saleValue(0)
                                                        .intermediateSaleValue(0)
                                                        .basePriceType(-1)
                                                        .onSale(false)
                                                        .build()
                                        )
                                        .available(true)
                                        .build()
                        )
                )
                .productMetrics(Map.of("MetricBinding1", 123, "MetricBinding2", 222))
                .productRawMetrics(Map.of("MetricBinding1", "MetricBindingRawValue", "MetricBinding3", "MetricBindingRawValue3"))
                .build();
        assertEquals(expected, actual);
    }

    private List<ProductToCategory> createProductToCatetory(List<Integer> ids) {
        return ids.stream()
                .map(id -> ProductToCategory.builder().categoryId(id).build())
                .collect(Collectors.toList());
    }

    private List<ProductToPool> createProductToPool(List<Integer> ids) {
        return ids.stream()
                .map(id -> ProductToPool.builder().poolId(id).build())
                .collect(Collectors.toList());
    }

}