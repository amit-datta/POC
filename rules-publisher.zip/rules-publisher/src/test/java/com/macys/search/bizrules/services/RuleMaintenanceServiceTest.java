package com.macys.search.bizrules.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.macys.search.bizrules.dto.GetJobStatusResponse;
import com.macys.search.bizrules.dto.IndexingMessage;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.repository.batch.BatchRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.*;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static com.macys.search.bizrules.enums.PubSubProcessType.START_INDEXING;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class RuleMaintenanceServiceTest {

    @Mock
    private Job ruleFullReindex;
    @Mock
    private JobExplorer jobExplorer;
    @Mock
    private JobRepository jobRepository;
    @Mock
    private BatchRepository batchRepository;
    @Mock
    private JobOperator jobOperator;
    @Mock
    private RulesPubSubIndexingPublisher publisher;
    @InjectMocks
    private RuleMaintenanceService ruleMaintenanceService;

    private final ObjectMapper mapper = new ObjectMapper();

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetAllJobsForLastNDays() {
        ReflectionTestUtils.setField(ruleMaintenanceService, "batchRepository", batchRepository);
        when(batchRepository.getBatchJobIdsStartingFromDate(any())).thenReturn(List.of(1L));
        when(jobExplorer.getJobExecution(1L)).thenReturn(
                new JobExecution(new JobInstance(1L, "job-test"), 1L, new JobParameters(), "configuration-test"));
        List<GetJobStatusResponse> result = ruleMaintenanceService.getAllJobsForLastNDays(1);

        assertEquals(1L, result.get(0).getExecutionId());
        assertEquals("job-test", result.get(0).getName());
        assertEquals("STARTING", result.get(0).getStatus());
        assertEquals("N/A", result.get(0).getDuration());
    }

    @Test
    public void shouldReturnEmptyListWhenDaysCountIsNull() {
        List<GetJobStatusResponse> result = ruleMaintenanceService.getAllJobsForLastNDays(null);
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void abandonStuckJobsTest() {
        ReflectionTestUtils.setField(ruleMaintenanceService, "terminateKilledJobsKillSwitch", true);

        when(ruleFullReindex.getName()).thenReturn("test-name");

        JobExecution job = new JobExecution(1L);
        StepExecution step1 = new StepExecution("step1", job);
        StepExecution step2 = new StepExecution("step2", job);
        job.addStepExecutions(List.of(step1, step2));

        when(jobExplorer.findRunningJobExecutions(any())).thenReturn(Set.of(job));

        ruleMaintenanceService.abandonStuckJobs();

        assertEquals(BatchStatus.ABANDONED, job.getStatus());
        assertEquals(ExitStatus.STOPPED, job.getExitStatus());
        assertNotNull(job.getEndTime());
        verify(jobRepository, times(1)).update(any(JobExecution.class));
        verify(jobRepository, times(2)).update(any(StepExecution.class));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void testStopJob() throws NoSuchJobException, NoSuchJobExecutionException, JobExecutionNotRunningException {
        when(jobExplorer.getJobExecution(1L)).thenReturn(null);
        assertEquals(ResponseEntity.status(HttpStatus.NOT_FOUND).build(), ruleMaintenanceService.stopJob(1L));

        JobExecution job = new JobExecution(2L);
        job.setStatus(BatchStatus.STOPPED);
        when(jobExplorer.getJobExecution(2L)).thenReturn(job);
        assertEquals(ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body("Job with id = " + job.getJobId() + " is not running."), ruleMaintenanceService.stopJob(2L));
        verify(jobExplorer, times(2)).getJobExecution(any(Long.class));

        JobExecution job1 = new JobExecution(3L);
        job1.setStatus(BatchStatus.STARTED);
        when(jobExplorer.getJobExecution(3L)).thenReturn(job1);
        when(jobOperator.stop(3L)).thenThrow(new NoSuchJobExecutionException("There is no such job."));
        ReflectionTestUtils.setField(ruleMaintenanceService, "stoppedJobsCache", new StoppedJobsCache());
        Throwable exception = assertThrows(NoSuchJobExecutionException.class, () -> ruleMaintenanceService.stopJob(3L));
        StoppedJobsCache stoppedJobsCache = (StoppedJobsCache) ReflectionTestUtils.getField(ruleMaintenanceService, "stoppedJobsCache");
        assertNotNull(stoppedJobsCache);
        Set<Long> stoppedJobs = (Set<Long>) ReflectionTestUtils.getField(stoppedJobsCache, "stoppedJobs");
        assertNotNull(stoppedJobs);
        assertEquals(Set.of(3L), stoppedJobs);
        assertEquals("There is no such job.", exception.getMessage());
        verify(jobExplorer, times(3)).getJobExecution(any(Long.class));
    }

    @Test
    public void startIndexingTest() {
        String sessionId = UUID.randomUUID().toString();
        ReflectionTestUtils.setField(ruleMaintenanceService, "gson", new Gson());
        ruleMaintenanceService.publishMessage(SiteName.MCOM, sessionId, START_INDEXING);
        verify(publisher).publishMessage(argThat(arg -> {
            IndexingMessage msg = new IndexingMessage();
            try {
                msg = mapper.readValue(arg, IndexingMessage.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            return START_INDEXING.equals(msg.getProcessType()) &&
                    sessionId.equals(msg.getSessionId()) &&
                    SiteName.MCOM.name().equals(msg.getSiteName());
        }));
    }
}
