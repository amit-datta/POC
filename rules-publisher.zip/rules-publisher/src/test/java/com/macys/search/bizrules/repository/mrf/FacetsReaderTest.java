package com.macys.search.bizrules.repository.mrf;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.Facet;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.ContextUtils;
import org.junit.Test;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.tasklets.JobParams.SITE_NAME_JOB_PARAM;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class FacetsReaderTest extends BaseTest {

    private static final ProcessingContext context = ContextUtils.createProcessingContext(Map.of(
            SITE_NAME_JOB_PARAM, new JobParameter("MCOM")
    ));

    @Autowired
    private FacetsReader facetsReader;

    @Test
    @Sql({"classpath:facets/data.sql"})
    public void testGetFacets() {
        String attributeName = "AGE";
        String facetDisplayName = "Age";
        String attributeName2 = "ACCESSORIES_TYPE";
        String facetDisplayName2 = "ACCESSORIES_TYPE";
        List<Facet> actual = facetsReader.getFacets(context);
        Facet facet = actual.get(0);
        Facet facet1 = actual.get(1);
        assertEquals(2, actual.size());
        assertEquals(facetDisplayName, facet.getFacetDisplayName());
        assertEquals(attributeName, facet.getAttributeName());
        assertEquals(facetDisplayName2, facet1.getFacetDisplayName());
        assertEquals(attributeName2, facet1.getAttributeName());
    }
}
