package com.macys.search.bizrules.statistics;

import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TimeStatisticsTest {

    public static Stream<List<Long>> testCases() {
        return Stream.of(
                List.of(2L, 3L, 7L),
                List.of(10L, 3L, 0L, 7L),
                List.of(0L, 0L, 0L, 0L),
                List.of(2L, 6L, 5L, 19L),
                List.of(2L, 3L, 3L, 5L),
                List.of(8L, 3L, 6L, 0L)
        );
    }

    @ParameterizedTest
    @MethodSource("testCases")
    void testMaxTime(List<Long> numbers) {
        TimeStatistics timeStatistics = new TimeStatistics();
        numbers.forEach(timeStatistics::computeTime);
        Long expected = numbers.stream()
                .max(Long::compare)
                .orElse(null);
        Long actual = timeStatistics.getMaxTime();
        assertEquals(expected, actual);
    }

    @ParameterizedTest
    @MethodSource("testCases")
    void testAvgTime(List<Long> numbers) {
        TimeStatistics timeStatistics = new TimeStatistics();
        numbers.forEach(timeStatistics::computeTime);
        Long expected = numbers.stream().reduce(Long::sum).orElse(0L) / numbers.size();
        Long actual = timeStatistics.getAvgTime();
        assertEquals(expected, actual);
    }
}
