package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.validation.ValidationResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;


class ContextParamsValidatorTest extends BaseTest {

    @Autowired
    private ContextParamsValidator validator;

    private final Action action = getAction();

    private Action getAction() {
        Action action = new Action();
        action.setId(1);
        return action;
    }

    @Test
    void invalidRegionCode() {
        action.setContextAttributes(Map.of(
                "REGION_CODE", List.of("JAPAN")
        ));
        ValidationResult validationResult = validator.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Action with id=1 has invalid context params. REGION_CODE attr value must be two-character string or INTL. But was=JAPAN";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void onlyOneRegionCode() {
        action.setContextAttributes(Map.of(
                "REGION_CODE", List.of("JP", "FR")
        ));
        ValidationResult validationResult = validator.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Action with id=1 has invalid context params. REGION_CODE attr must contain one value but contains[JP, FR]";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validRegionCode() {
        action.setContextAttributes(Map.of(
                "REGION_CODE", List.of("RU")
        ));
        assertTrue(validator.validate(action).isValid());
    }

    @Test
    void validInternationalRegionCode() {
        action.setContextAttributes(Map.of(
                "REGION_CODE", List.of("INTL")
        ));
        assertTrue(validator.validate(action).isValid());
    }

    @Test
    void invalidCtxAttr() {
        action.setContextAttributes(Map.of(
                "DEVICE_TYPE", List.of("UNKNOWN_PARAM")
        ));
        ValidationResult validationResult = validator.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Action with id=1 has invalid context params. DEVICE_TYPE attribute can contains only=[POS, DESKTOP, PHONE, TABLET] but contains=[UNKNOWN_PARAM]";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void invalidCtxKey() {
        action.setContextAttributes(Map.of(
                "SOMEWHAT", List.of("UNKNOWN_PARAM")
        ));
        ValidationResult validationResult = validator.validate(action);
        assertFalse(validationResult.isValid());
        String messagePrefix = "Action with id=1 has invalid context params. SOMEWHAT is not possible attribute name. Possible names=[";
        assertTrue(validationResult.getWarning().startsWith(messagePrefix));
    }

    @Test
    void validCtxAttr() {
        action.setContextAttributes(Map.of(
                "DEVICE_TYPE", List.of("PHONE", "TABLET")
        ));
        assertTrue(validator.validate(action).isValid());
    }

}