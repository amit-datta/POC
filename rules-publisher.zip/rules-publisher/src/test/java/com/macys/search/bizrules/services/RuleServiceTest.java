package com.macys.search.bizrules.services;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionConstants;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.services.merch.RuleService;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class RuleServiceTest extends BaseTest {

    private final ProcessingContext ctx;
    @Autowired
    private RuleService ruleService;

    public RuleServiceTest() {
        ctx = new ProcessingContext();
        ctx.setRules(Collections.emptyMap());
        ctx.setActions(Collections.emptyMap());
        ctx.setTriggers(Collections.emptyMap());
        ctx.setCustomDate(LocalDate.of(2022, 1, 1));
    }

    @Test
    void noRuleNoEffectiveDate() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().addAll(List.of(2, 3));
        rule1.setExpirationDate(LocalDate.of(2021, 3, 5));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule id=1 invalid because of effectiveDate parameter is null";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void noRuleNoExpirationDate() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().addAll(List.of(2, 3));
        rule1.setEffectiveDate(LocalDate.of(2021, 3, 5));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule id=1 invalid because of expirationDate parameter is null";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void noValidActionsForRule() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().addAll(List.of(2, 3));
        rule1.setEffectiveDate(LocalDate.of(2021, 12, 1));
        rule1.setExpirationDate(LocalDate.of(2022, 12, 1));
        Action action2 = new Action();
        Action action3 = new Action();

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ctx.setActions(Map.of(2, ProcessingAction.from(action2), 3, ProcessingAction.from(action3)));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule with id=1 invalid due empty valid action list";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void noTriggerExpressionQuery() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().add(2);
        rule1.setEffectiveDate(LocalDate.of(2021, 12, 1));
        rule1.setExpirationDate(LocalDate.of(2022, 12, 1));

        Action action2 = TestUtils.createAction(2, ActionType.ProductRedirect);
        TestUtils.actionAddParam(action2, ActionConstants.PDP_PRODUCT, ActionConstants.PDP_PRODUCT_ID, "12", 0, 0);

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ctx.setActions(Map.of(2, ProcessingAction.from(action2)));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "No trigger ids for rule id=1";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void noTriggerQuery() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().add(2);
        rule1.setEffectiveDate(LocalDate.of(2021, 12, 1));
        rule1.setExpirationDate(LocalDate.of(2022, 12, 1));
        rule1.getTriggerIds().add(123);

        Action action2 = TestUtils.createAction(2, ActionType.ProductRedirect);
        TestUtils.actionAddParam(action2, ActionConstants.PDP_PRODUCT, ActionConstants.PDP_PRODUCT_ID, "12", 0, 0);

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ctx.setActions(Map.of(2, ProcessingAction.from(action2)));

        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule with id=1 skipped because there are no valid trigger queries. Trigger with id=123 was not found. Maybe it has disabled type";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void expirationDateBeforeEffectiveDate() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().addAll(List.of(2, 3));
        rule1.setEffectiveDate(LocalDate.of(2021, 3, 5));
        rule1.setExpirationDate(LocalDate.of(2021, 2, 5));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));

        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule id=1 has wrong parameters. ExpirationDate=2021-02-05 before effectiveDate=2021-03-05";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void setExpirationDateForRuleWithSpecialRestrictionAnd() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().add(2);
        rule1.setExpirationDate(LocalDate.of(3333, 3, 5));
        rule1.setEffectiveDate(LocalDate.of(2021, 3, 5));
        rule1.setAuthorName("owner");
        rule1.setDescription("description");
        rule1.setCreatedDate(LocalDateTime.of(2020, 1, 1, 1, 1));
        rule1.setTriggerIds(List.of(12));
        Action action2 = TestUtils.createAction(2, ActionType.ProductRedirect);
        TestUtils.actionAddParam(action2, ActionConstants.PDP_PRODUCT, ActionConstants.PDP_PRODUCT_ID, "12", 0, 0);

        Trigger trigger12 = TestUtils.createTrigger(12, TriggerType.Always);

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));
        ctx.setActions(Map.of(2, ProcessingAction.from(action2)));
        ctx.setTriggers(Map.of(12, ProcessingTrigger.from(trigger12)));

        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertTrue(processedRule.isValid());
        assertEquals(LocalDate.of(2021, 6, 3), processedRule.getRuleExpirationDate());
        assertEquals(processedRule.getRuleOwner(), "owner");
        assertEquals(processedRule.getRuleDescription(), "description");
        assertEquals(processedRule.getRuleCreatedDate(), LocalDateTime.of(2020, 1, 1, 1, 1));
    }

    @Test
    void expirationDateBeforeCustomDate() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().addAll(List.of(2, 3));
        rule1.setEffectiveDate(LocalDate.of(2021, 12, 1));
        rule1.setExpirationDate(LocalDate.of(2021, 12, 5));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));

        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule id=1 has already expired. ExpirationDate=2021-12-05 "
                + "CustomDate=2022-01-01 ExpirationDateShiftThreshold=0";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void effectiveDateAfterThreshold() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setLastModifiedByName("YH00111");
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.getActionsIds().addAll(List.of(2, 3));
        rule1.setEffectiveDate(LocalDate.of(2022, 2, 2));
        rule1.setExpirationDate(LocalDate.of(2022, 12, 1));

        ctx.setRules(Map.of(1, ProcessingRule.from(rule1)));

        ProcessingRule processedRule = ruleService.getProcessedRule(1, ctx);
        assertFalse(processedRule.isValid());
        ValidationResult validationResult = processedRule.getValidationResult();

        String expectedMessage = "Rule id=1 is out of allowed range for effective date. ExpirationDate=2022-12-01 "
                + "CustomDate=2022-01-01 EffectiveDateShiftThreshold=31";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

}
