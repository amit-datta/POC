package com.macys.search.bizrules.tasklets.action;

import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.ActionValidationService;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.action.ActionValidationStrategy;
import com.macys.search.bizrules.validation.action.ContextParamsValidator;
import org.junit.jupiter.api.Test;

import java.util.List;

import static com.macys.search.bizrules.model.mrf.action.ActionType.*;
import static com.macys.search.util.TestUtils.createAction;
import static org.junit.jupiter.api.Assertions.*;

class ActionValidationServiceTest {

    private final ActionValidationStrategy categoryRedirectFalse = new ActionValidationStrategy() {
        @Override
        public ActionType applicableFor() {
            return CategoryRedirect;
        }

        @Override
        public ValidationResult validate(Action action) {
            return ValidationResult.failResult("");
        }
    };
    private final ActionValidationStrategy productRedirectTrue = new ActionValidationStrategy() {
        @Override
        public ActionType applicableFor() {
            return ActionType.ProductRedirect;
        }

        @Override
        public ValidationResult validate(Action action) {
            return ValidationResult.validResult();
        }
    };
    private final ActionValidationStrategy urlRedirectTrue = new ActionValidationStrategy() {
        @Override
        public ActionType applicableFor() {
            return ActionType.URLRedirect;
        }

        @Override
        public ValidationResult validate(Action action) {
            return ValidationResult.validResult();
        }
    };

    @Test
    public void happyPassTest() {
        ActionValidationService validationService = new ActionValidationService(new ContextParamsValidator(),
                List.of(
                        categoryRedirectFalse,
                        productRedirectTrue,
                        urlRedirectTrue),
                List.of(
                        CategoryRedirect,
                        ProductRedirect
                ));

        assertFalse(validationService.validate(createAction(1, CategoryRedirect), null).isValid());
        assertTrue(validationService.validate(createAction(2, ProductRedirect), null).isValid());
        assertFalse(validationService.validate(createAction(3, URLRedirect), null).isValid());
    }

    @Test
    public void contextFailWhenUnsupportedActionTypeTest() {
        Exception exception = assertThrows(RuntimeException.class, () ->
                new ActionValidationService(
                        null,
                        List.of(
                                categoryRedirectFalse
                        ),
                        List.of(
                                CategoryRedirect,
                                ProductRedirect
                        )
                )
        );

        String expectedMessage = "Some of action validators have not implemented yet. Enabled action types=[CategoryRedirect, ProductRedirect] Implemented validators types=[CategoryRedirect]";
        assertEquals(expectedMessage, exception.getMessage());
    }

}