package com.macys.search.bizrules.tasklets.category;

import com.macys.search.bizrules.converters.category.CategoryConverter;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESCategory;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.macys.search.bizrules.model.category.CategoryAttributeName.SEARCH_PHRASE;
import static org.junit.jupiter.api.Assertions.assertEquals;

class CategoryConverterTest {

    private final CategoryConverter converter = new CategoryConverter();

    @Test
    void simpleCategoryTest() {
        Category c1 = cat(1, null);
        Category c2 = cat(2, 1);
        Category c3 = cat(3, 2);

        CategoryTree tree = CategoryTree.from(List.of(c1, c2, c3));

        ESCategory esCategory = converter.convert(c2, tree);

        Map<String, Object> expected = Map.of(
                "category_id", 2,
                "ids_path", "1 > 2",
                "titles_path", "1 > 2"
        );
        Map<String, ?> actual = esCategory.getSource();
        assertEquals(expected, actual);
    }

    @Test
    void simpleCategoryTestWithNames() {
        Category c1 = cat(1, null, "Women");
        Category c2 = cat(2, 1, "Women's Clothing");
        Category c3 = cat(3, 2, "Leggings");

        CategoryTree tree = CategoryTree.from(List.of(c1, c2, c3));

        ESCategory esCategory = converter.convert(c3, tree);

        Map<String, Object> expected = Map.of(
                "category_id", 3,
                "ids_path", "1 > 2 > 3",
                "titles_path", "Women > Women's Clothing > Leggings"
        );
        Map<String, ?> actual = esCategory.getSource();
        assertEquals(expected, actual);
    }

    @Test
    void simpleCategoryTestWithAttr() {
        Category c1 = catAttr(1, null, SEARCH_PHRASE,
                CategoryAttribute.builder().name(SEARCH_PHRASE).values(Set.of("stocking stuffers")).build());

        CategoryTree tree = CategoryTree.from(List.of(c1));

        ESCategory esCategory = converter.convert(c1, tree);

        Map<String, Object> expected = Map.of(
                "category_id", 1,
                "ids_path", "1",
                "titles_path", "1",
                "search_phrase", "stocking stuffers"
        );
        Map<String, ?> actual = esCategory.getSource();
        assertEquals(expected, actual);
    }

    private Category cat(Integer id, Integer parentId) {
        return Category.builder()
                .id(id)
                .name(id.toString())
                .parentCategoryId(parentId)
                .attributes(Collections.emptyMap())
                .build();
    }

    private Category cat(Integer id, Integer parentId, String name) {
        return Category.builder()
                .id(id)
                .name(name)
                .parentCategoryId(parentId)
                .attributes(Collections.emptyMap())
                .build();
    }

    private Category catAttr(Integer id, Integer parentId, CategoryAttributeName categoryAttributeName, CategoryAttribute categoryAttribute) {
        return Category.builder()
                .id(id)
                .name(id.toString())
                .parentCategoryId(parentId)
                .attributes(Map.of(categoryAttributeName, categoryAttribute))
                .build();
    }
}
