package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class URLRedirectConverterTest {

    private final URLRedirectConverter converter = new URLRedirectConverter();

    @Test
    void convert() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.URLRedirect);
        Criteria criteria = new Criteria();
        action.setCriteriaMap(Map.of(
                "URL", criteria
        ));
        criteria.setCriteriaAttributes(
                Map.of(
                        "URLType", List.of("abs"),
                        "URLValue", List.of("macys.com")
                )
        );
        ESAction actual = converter.convert(action, null);
        assertEquals("abs", actual.getSource().get("url_redirect_type"));
        assertEquals("macys.com", actual.getSource().get("url_redirect_value"));
    }

}