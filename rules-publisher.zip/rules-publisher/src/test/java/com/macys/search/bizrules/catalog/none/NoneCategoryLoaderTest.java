package com.macys.search.bizrules.catalog.none;

import com.macys.search.bizrules.model.SiteName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class NoneCategoryLoaderTest {

    NoneCategoryLoader loader = new NoneCategoryLoader();

    @Test
    void loadAll() {
        assertEquals(List.of(), loader.loadAll(SiteName.MCOM, null));
        assertEquals(List.of(), loader.loadAll(SiteName.BCOM, null));
    }

    @Test
    void iterator() {
        assertFalse(loader.iterator(SiteName.MCOM, null).hasNext());
        assertFalse(loader.iterator(SiteName.BCOM, null).hasNext());
    }

}