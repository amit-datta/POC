package com.macys.search.util.templatetests;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.validation.trigger.TriggerValidationStrategy;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@RequiredArgsConstructor
public class TriggerTemplateTestContext extends AbstractTemplateTestContext {

    final TriggerValidationStrategy strategy;
    Trigger trigger;

    @Override
    void createNew() {
        trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(strategy.applicableFor());
        setFlags(strategy.applicableFor());
    }

    private void setFlags(TriggerType type) {
        switch (type) {
            case KeywordPattern:
                trigger.setSearchable(true);
                return;
            case Always:
                return;
            default:
                throw new AssertionError("Trigger type=" + type + " was not implemented");
        }
    }

    @Override
    void setCriteriaMap(Map<String, Criteria> map) {
        trigger.setCriteriaMap(map);
        mergeCriteriaMap(trigger.getCriteriaMap(), additionalCriteria);
    }

    @Override
    boolean validate() {
        return strategy.validate(trigger, null).isValid();
    }
}
