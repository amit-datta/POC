package com.macys.search;

import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

import java.lang.annotation.*;

/**
 * Annotation marks test units which require external systems like Elastic Search
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@EnabledIfSystemProperty(named = "it", matches = "true")
@Inherited
public @interface OnlyIntegrationMode {
}
