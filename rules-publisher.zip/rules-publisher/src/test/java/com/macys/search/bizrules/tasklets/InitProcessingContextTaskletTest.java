package com.macys.search.bizrules.tasklets;

import com.macys.search.bizrules.services.StoppedJobsCache;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InitProcessingContextTaskletTest {

    private final InitProcessingContextTasklet tasklet = new InitProcessingContextTasklet(new StoppedJobsCache());

    @Test
    void happyPassTest() {
        ExecutionContext executionContext = new ExecutionContext();
        JobExecution jobExecution = new JobExecution(1L, new JobParameters(Map.of(
                "site-name", new JobParameter("BCOM"),
                "indexing-session-id", new JobParameter("InitProcessingContextTaskletTest")
        )));
        jobExecution.setExecutionContext(executionContext);
        StepContribution contribution = new StepContribution(new StepExecution("stepName", jobExecution));
        ChunkContext chunkContext = new ChunkContext(new StepContext(contribution.getStepExecution()));

        assertTrue(executionContext.isEmpty());
        tasklet.execute(contribution, chunkContext);
        assertEquals(1, executionContext.size());
        assertTrue(executionContext.containsKey("PROCESSING_CONTEXT"));
        assertTrue(executionContext.get("PROCESSING_CONTEXT") instanceof ProcessingContext);
    }

}