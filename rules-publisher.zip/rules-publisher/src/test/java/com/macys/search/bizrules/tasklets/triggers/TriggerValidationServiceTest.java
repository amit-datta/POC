package com.macys.search.bizrules.tasklets.triggers;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.TriggerValidationService;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.trigger.TriggerValidationStrategy;
import org.junit.jupiter.api.Test;

import java.util.List;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.Always;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.KeywordPattern;
import static com.macys.search.util.TestUtils.createTrigger;
import static org.junit.jupiter.api.Assertions.*;

class TriggerValidationServiceTest {

    private TriggerValidationStrategy alwaysTrue = new TriggerValidationStrategy() {
        @Override
        public TriggerType applicableFor() {
            return Always;
        }

        @Override
        public ValidationResult validate(Trigger trigger, ProcessingContext context) {
            return ValidationResult.validResult();
        }
    };
    private TriggerValidationStrategy keywordFalse = new TriggerValidationStrategy() {
        @Override
        public TriggerType applicableFor() {
            return KeywordPattern;
        }

        @Override
        public ValidationResult validate(Trigger trigger, ProcessingContext context) {
            return ValidationResult.failResult("");
        }
    };

    @Test
    public void happyPassTest() {
        TriggerValidationService service = new TriggerValidationService(List.of(alwaysTrue, keywordFalse),
                List.of(Always, KeywordPattern));

        assertTrue(service.validate(createTrigger(1, Always), null).isValid());
        assertFalse(service.validate(createTrigger(2, KeywordPattern), null).isValid());
        assertTrue(service.validate(createTrigger(3, Always), null).isValid());
    }

    @Test
    public void filterByEnabledListTest() {
        TriggerValidationService service = new TriggerValidationService(List.of(alwaysTrue, keywordFalse),
                List.of(KeywordPattern));

        assertFalse(service.validate(createTrigger(1, Always), null).isValid());
        assertFalse(service.validate(createTrigger(2, KeywordPattern), null).isValid());
        assertFalse(service.validate(createTrigger(3, Always), null).isValid());
    }

    @Test
    public void contextFailWhenUnsupportedActionTypeTest() {
        Exception exception = assertThrows(RuntimeException.class, () ->
                new TriggerValidationService(
                        List.of(
                                keywordFalse
                        ),
                        List.of(
                                KeywordPattern,
                                TriggerType.NumResults
                        )
                )
        );

        String expectedMessage = "Some of trigger validators have not implemented yet. Enabled trigger types=[KeywordPattern, NumResults] Implemented validators types=[KeywordPattern]";
        assertEquals(expectedMessage, exception.getMessage());
    }

}