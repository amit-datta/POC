package com.macys.search.bizrules.catalog.fcc;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConversionUtilsTest {

    @Test
    void unboxInteger() {
        assertEquals(5, UnboxingHelper.unbox(5));
        assertEquals(-1, UnboxingHelper.unbox((Integer) null));
    }

    @Test
    void unboxBool() {
        assertTrue(UnboxingHelper.unbox(Boolean.TRUE));
        assertFalse(UnboxingHelper.unbox(Boolean.FALSE));
        assertFalse(UnboxingHelper.unbox((Boolean) null));
    }
}