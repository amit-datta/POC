package com.macys.search.bizrules.validation.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.templatetests.TemplateTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static com.macys.search.util.TestUtils.*;
import static java.util.List.of;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class KeywordPatternTriggerValidatorTest extends BaseTest {

    @Autowired
    KeywordPatternTriggerValidatorStrategy strategy;

    Trigger trigger = new Trigger();

    @BeforeEach
    public void reset() {
        trigger = new Trigger();
        trigger.setId(1718);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        trigger.setSearchable(true);
    }

    @Test
    void applicableFor() {
        assertEquals(TriggerType.KeywordPattern, strategy.applicableFor());
    }

    @Test
    void validateSearchableFlag() {
        trigger.setSearchable(false);
        ValidationResult validationResult = strategy.validate(trigger, null);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Flags isSearchable and isResultSetRequired set incorrectly";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateResultSetRequiredFlag() {
        trigger.setResultSetRequired(true);
        ValidationResult validationResult = strategy.validate(trigger, null);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Flags isSearchable and isResultSetRequired set incorrectly";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void configTemplateTest() {
        TemplateTest.uniqPossibleValuesTemplateCompositeTest(
                strategy,
                toMap(of(
                        criteria("MatchConfig", attr("MatchOperator", "AND")),
                        criteria("MISCELLANEOUS", attr("KeywordValue", "any"))
                )),
                "MatchConfig",
                "MatchType",
                List.of("Exact", "Contains", "Literal")
        );
        TemplateTest.uniqPossibleValuesTemplateCompositeTest(
                strategy,
                toMap(of(
                        criteria("MatchConfig", attr("MatchType", "Contains")),
                        criteria("MISCELLANEOUS", attr("KeywordValue", "any"))
                )),
                "MatchConfig",
                "MatchOperator",
                List.of("AND", "OR")
        );
    }

    @Test
    void configAttributeTest() {
        TemplateTest.nonBlankStringTemplateCompositeTest(
                strategy,
                toMap(of(
                        criteria("MatchConfig",
                                attr("MatchOperator", "AND"),
                                attr("MatchType", "Exact")
                        ))
                ),
                "ANY_NAME",
                "KeywordValue"
        );
    }

}