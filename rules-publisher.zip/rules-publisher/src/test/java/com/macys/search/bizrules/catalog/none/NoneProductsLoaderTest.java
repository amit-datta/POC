package com.macys.search.bizrules.catalog.none;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class NoneProductsLoaderTest {

    NoneProductsLoader loader = new NoneProductsLoader();

    @Test
    void loadAll() {
        assertEquals(List.of(), loader.loadAll(SiteName.MCOM, null, null));
        assertEquals(List.of(), loader.loadAll(SiteName.BCOM, LocalDate.now(), null));
    }

    @Test
    void iterator() {
        assertFalse(loader.iterator(SiteName.MCOM, null, new TimeStatistics()).hasNext());
        assertFalse(loader.iterator(SiteName.BCOM, LocalDate.now(), new TimeStatistics()).hasNext());
    }

}