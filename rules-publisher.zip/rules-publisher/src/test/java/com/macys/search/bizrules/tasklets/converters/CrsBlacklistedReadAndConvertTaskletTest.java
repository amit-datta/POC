package com.macys.search.bizrules.tasklets.converters;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.macys.search.analysis.PhraseAnalyzerFactory;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.ESEntry;
import com.macys.search.bizrules.model.mrf.action.ActionConstants;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.elasticsearch.index.query.QueryBuilders;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.mrf.action.ESActionType.SPECIAL_INSTRUCTION;
import static org.elasticsearch.index.query.QueryBuilders.matchPhraseQuery;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CrsBlacklistedReadAndConvertTaskletTest extends AbstractTaskletTest {

    @Mock
    private Storage storage;
    @Autowired
    private PhraseAnalyzerFactory phraseAnalyzerFactory;
    @Captor
    private ArgumentCaptor<ESEntry> rulesCaptor;
    @Captor
    private ArgumentCaptor<ESEntry> actionsCaptor;
    @Captor
    private ArgumentCaptor<ESEntry> triggersCaptor;

    @BeforeEach
    void setUp() {
        ctx = ProcessingContext.getContext(contribution);

        ElasticSearchIndexer rulesIndexer = createIndexerMock(rulesCaptor);
        ElasticSearchIndexer actionsIndexer = createIndexerMock(actionsCaptor);
        ElasticSearchIndexer triggersIndexer = createIndexerMock(triggersCaptor);

        ctx.setupIndex(ESIndex.RULES, "rules-index", rulesIndexer);
        ctx.setupIndex(ESIndex.ACTIONS, "actions-index", actionsIndexer);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, "triggers-index", triggersIndexer);
    }

    private ElasticSearchIndexer createIndexerMock(ArgumentCaptor<ESEntry> argumentCaptor) {
        ElasticSearchIndexer indexer = Mockito.mock(ElasticSearchIndexer.class);
        Mockito.doNothing().when(indexer).add(argumentCaptor.capture());
        Mockito.when(indexer.flush()).thenReturn(true);
        return indexer;
    }

    @Test
    void readCrsForMCOM() throws Exception {
        readCrsTest(SiteName.MCOM, "mcom_phrases.txt");
    }

    @Test
    void readCrsForBCOM() throws Exception {
        readCrsTest(SiteName.BCOM, "bcom_phrases.txt");
    }

    private void readCrsTest(SiteName siteName, String bucketName) throws Exception {
        changeSiteName(siteName);

        Blob blobMock = Mockito.mock(Blob.class);
        Mockito.when(storage.get(BlobId.of("bucket_name", bucketName))).thenReturn(blobMock);
        Mockito.when(blobMock.getContent()).thenReturn(
                "Phrase 1,\nPhrase 2,\nPhrase3".getBytes(StandardCharsets.UTF_8)
        );

        ctx.setRules(new HashMap<>());
        ctx.setActions(new HashMap<>());
        ctx.setTriggers(new HashMap<>());

        execute(createTasklet());

        List<ESEntry> allCapturedRules = rulesCaptor.getAllValues();
        assertEquals(1, allCapturedRules.size());
        Map<String, Object> expectedRuleSource = Map.of(
                "rule_id", 0,
                "rule_enabled", true,
                "rule_type", RuleType.SEO,
                "rule_name", "CrsBlacklisted",
                "rule_effective_date", ActionConstants.MIN_DATE,
                "rule_natural_id", 0,
                "rule_last_modification_date", ActionConstants.MIN_DATE_TIME,
                "rule_expiration_date", ActionConstants.MAX_DATE,
                "rule_priority", 0
        );
        assertEquals(expectedRuleSource, allCapturedRules.get(0).getSource());

        List<ESEntry> capturedTriggers = triggersCaptor.getAllValues();
        assertEquals(3, capturedTriggers.size());
        Set<Map<String, ?>> actualTriggers = capturedTriggers.stream().map(ESEntry::getSource)
                .collect(Collectors.toSet());

        Set<Map<String, Object>> expectedTriggers = Set.of(
                Map.of("trigger_query", QueryBuilders.constantScoreQuery(matchPhraseQuery("phrase_literal", "phrase 1")).boost(2),
                        "trigger_id", 0,
                        "trigger_type", "KeywordPattern",
                        "match_type", "Literal",
                        "percolator_filter", Set.of("phrase 1")
                ),
                Map.of("trigger_query", QueryBuilders.constantScoreQuery(matchPhraseQuery("phrase_literal", "phrase 2")).boost(2),
                        "trigger_id", 0,
                        "trigger_type", "KeywordPattern",
                        "match_type", "Literal",
                        "percolator_filter", Set.of("phrase 2")
                ),
                Map.of("trigger_query", QueryBuilders.constantScoreQuery(matchPhraseQuery("phrase_literal", "phrase3")).boost(1),
                        "trigger_id", 0,
                        "trigger_type", "KeywordPattern",
                        "match_type", "Literal",
                        "percolator_filter", Set.of("phrase3")
                )
        );
        assertEquals(expectedTriggers, actualTriggers);

        List<ESEntry> capturedActions = actionsCaptor.getAllValues();
        assertEquals(1, capturedActions.size());
        Map<String, Object> expectedActionSource = Map.of(
                "action_id", 0,
                "action_type", SPECIAL_INSTRUCTION,
                "crs_blacklisted", true
        );
        assertEquals(expectedActionSource, capturedActions.get(0).getSource());
    }

    @Test
    void fileNotFoundTest() {
        changeSiteName(SiteName.MCOM);
        Mockito.when(storage.get(BlobId.of("bucket_name", "mcom_phrases.txt"))).thenReturn(null);

        Exception exception = assertThrows(RuntimeException.class, () -> execute(createTasklet()));
        assertEquals("Couldn't find " + "mcom_phrases.txt" + " in Google storage", exception.getMessage());
    }

    @Test
    void findFreeIdTest() throws Exception {
        changeSiteName(SiteName.BCOM);

        Blob blobMock = Mockito.mock(Blob.class);
        Mockito.when(storage.get(BlobId.of("bucket_name", "bcom_phrases.txt"))).thenReturn(blobMock);
        Mockito.when(blobMock.getContent()).thenReturn("Phrase 1".getBytes(StandardCharsets.UTF_8));

        ctx.setRules(new HashMap<>());
        ctx.setActions(new HashMap<>());
        ctx.setTriggers(new HashMap<>());

        for (int i = 0; i < 5; i++) {
            ctx.getRules().put(i, null);
        }
        for (int i = 0; i < 6; i++) {
            ctx.getActions().put(i, null);
        }
        for (int i = 0; i < 7; i++) {
            ctx.getTriggers().put(i, null);
        }

        execute(createTasklet());

        List<ESEntry> allCapturedRules = rulesCaptor.getAllValues();
        assertEquals(1, allCapturedRules.size());
        assertEquals(5, allCapturedRules.get(0).getSource().get("rule_id"));

        List<ESEntry> capturedTriggers = triggersCaptor.getAllValues();
        assertEquals(1, capturedTriggers.size());
        assertEquals(7, capturedTriggers.get(0).getSource().get("trigger_id"));

        List<ESEntry> capturedActions = actionsCaptor.getAllValues();
        assertEquals(1, capturedActions.size());
        assertEquals(6, capturedActions.get(0).getSource().get("action_id"));
    }

    private CrsBlacklistedReadAndConvertTasklet createTasklet() {
        CrsBlacklistedReadAndConvertTasklet result = new CrsBlacklistedReadAndConvertTasklet(phraseAnalyzerFactory, storage);
        ReflectionTestUtils.setField(result, "mcomBlacklistPhrasesObject", "mcom_phrases.txt");
        ReflectionTestUtils.setField(result, "bcomBlacklistPhrasesObject", "bcom_phrases.txt");
        ReflectionTestUtils.setField(result, "bucketName", "bucket_name");
        return result;
    }

}