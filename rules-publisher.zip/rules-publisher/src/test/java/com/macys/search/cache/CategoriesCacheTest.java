package com.macys.search.cache;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.catalog.fcc.category.CategoryLoaderImpl;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class CategoriesCacheTest extends BaseTest {

    @Autowired
    private CategoriesCache mcomCategoriesCache;

    @Test
    public void shouldReturnCategoryTree() {
        List<Category> categories = List.of(
                Category.builder().id(1).parentCategoryId(null).build(),
                Category.builder().id(2).parentCategoryId(1).build(),
                Category.builder().id(4).parentCategoryId(1).build());
        CategoryTree categoryTree = CategoryTree.from(categories);
        ReflectionTestUtils.setField(mcomCategoriesCache, "updateOnStartup", true);
        ReflectionTestUtils.setField(mcomCategoriesCache, "categoryTree", categoryTree);
        CategoryTree result = mcomCategoriesCache.getCategoryTree();
        assertEquals(categoryTree, result);
    }

    @Test
    public void loadCache() {
        CategoryLoader mock = Mockito.mock(CategoryLoader.class);
        CategoryLoaderImpl mock1 = Mockito.mock(CategoryLoaderImpl.class);
        List<Category> categories = List.of(
                Category.builder().id(1).parentCategoryId(null).build(),
                Category.builder().id(2).parentCategoryId(1).build(),
                Category.builder().id(4).parentCategoryId(1).build());
        CategoryTree categoryTree = CategoryTree.from(categories);
        ReflectionTestUtils.setField(mcomCategoriesCache, "updateOnStartup", true);
        ReflectionTestUtils.setField(mcomCategoriesCache, "categoryTree", categoryTree);
        Mockito.when(mock.loadAll(any(), any())).thenReturn(categories);
        Mockito.when(mock1.loadAll(any(), any())).thenReturn(categories);
        mcomCategoriesCache.loadCache();
    }

}
