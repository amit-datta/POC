package com.macys.search.bizrules.tasklets.action;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.DateAwareAttribute;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.services.merch.ActionsService;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ActionsExtractionTest extends AbstractTaskletTest {

    @Autowired
    private ActionsService actionsService;

    @Test
    void happyPassExtractValues() {
        Action action1 = TestUtils.createAction(1, ActionType.SeoControl);
        TestUtils.actionAddParam(action1, "group1", "name1", "value1", 1, 11);

        Action action2 = TestUtils.createAction(2, ActionType.SeoControl);
        TestUtils.actionAddParam(action2, "group2", "name2", "value2", 2, 22);

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        ctx.setActions(
                Map.of(
                        1, ProcessingAction.from(action1),
                        2, ProcessingAction.from(action2)
                )
        );
        actionsService.getProcessedAction(1, ctx);
        actionsService.getProcessedAction(2, ctx);

        Criteria criteria1 = new Criteria();
        criteria1.setCriteriaName("group1");
        criteria1.setSequenceGroupNumber(11);
        criteria1.setCriteriaAttributes(Map.of("name1", List.of("value1")));
        criteria1.setAttributeToSeqNumbersMap(Map.of("name1", List.of(1)));
        DateAwareAttribute daw1 = new DateAwareAttribute();
        daw1.setValue("value1");
        criteria1.setCriteriaDateAwareAttributes(Map.of("name1", List.of(daw1)));

        assertEquals(Map.of("group1", criteria1), action1.getCriteriaMap());

        Criteria criteria2 = new Criteria();
        criteria2.setCriteriaName("group2");
        criteria2.setSequenceGroupNumber(22);
        criteria2.setCriteriaAttributes(Map.of("name2", List.of("value2")));
        criteria2.setAttributeToSeqNumbersMap(Map.of("name2", List.of(2)));
        DateAwareAttribute daw2 = new DateAwareAttribute();
        daw2.setValue("value2");
        criteria2.setCriteriaDateAwareAttributes(Map.of("name2", List.of(daw2)));

        assertEquals(Map.of("group2", criteria2), action2.getCriteriaMap());
    }

    @Test
    void extractContextValues() {
        Action action = TestUtils.createAction(1, ActionType.SeoControl);
        TestUtils.actionAddParam(action, "group1", "name1", "value1", 1, 11);
        TestUtils.actionAddParam(action, "group1", "name5", "value5", 5, 55);
        TestUtils.actionAddParam(action, "Context", "name2", "value2", null, null);
        TestUtils.actionAddParam(action, "Context", "name4", "value4", null, null);

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        ctx.setActions(Map.of(1, ProcessingAction.from(action)));
        actionsService.getProcessedAction(1, ctx);

        Criteria criteria1 = new Criteria();
        criteria1.setCriteriaName("group1");
        criteria1.setSequenceGroupNumber(null);
        criteria1.setCriteriaAttributes(Map.of("name1", List.of("value1"), "name5", List.of("value5")));
        criteria1.setAttributeToSeqNumbersMap(Map.of("name1", List.of(1), "name5", List.of(5)));
        DateAwareAttribute daw1 = new DateAwareAttribute();
        DateAwareAttribute daw5 = new DateAwareAttribute();
        daw1.setValue("value1");
        daw5.setValue("value5");
        criteria1.setCriteriaDateAwareAttributes(Map.of("name1", List.of(daw1), "name5", List.of(daw5)));

        assertEquals(Map.of("group1", criteria1), action.getCriteriaMap());
        assertEquals(Map.of("name2", Set.of("value2"), "name4", Set.of("value4")), action.getContextAttributes());
    }

}