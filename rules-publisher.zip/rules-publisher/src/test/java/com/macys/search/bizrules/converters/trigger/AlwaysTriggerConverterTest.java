package com.macys.search.bizrules.converters.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.model.processing.trigger.params.AlwaysTriggerParams;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AlwaysTriggerConverterTest extends BaseTest {

    @Autowired
    private AlwaysTriggerConverter converter;

    @Test
    void applicableFor() {
        assertEquals(TriggerType.Always, converter.applicableFor());
    }

    @Test
    void converterTest() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.Always);

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);
        AbstractTriggerParams abstractTriggerParams = converter.convert(processingTrigger, null);

        AlwaysTriggerParams actualParams = (AlwaysTriggerParams) abstractTriggerParams;

        AlwaysTriggerParams expectedParams = new AlwaysTriggerParams(1);
        assertEquals(expectedParams, actualParams);
    }
}