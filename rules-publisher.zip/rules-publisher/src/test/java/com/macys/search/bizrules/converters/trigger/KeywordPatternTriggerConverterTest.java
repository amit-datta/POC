package com.macys.search.bizrules.converters.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.KeywordPatternTriggerParams;
import com.macys.search.util.TestUtils;
import org.elasticsearch.index.query.QueryBuilders;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Set;

import static com.macys.search.bizrules.model.mrf.BooleanOperation.AND;
import static com.macys.search.bizrules.model.mrf.BooleanOperation.OR;
import static com.macys.search.bizrules.model.mrf.trigger.KWPMatchType.*;
import static org.elasticsearch.index.query.QueryBuilders.constantScoreQuery;
import static org.elasticsearch.index.query.QueryBuilders.matchPhraseQuery;
import static org.junit.jupiter.api.Assertions.assertEquals;

class KeywordPatternTriggerConverterTest extends BaseTest {

    @Autowired
    private KeywordPatternTriggerConverter converter;

    @Test
    void applicableFor() {
        assertEquals(TriggerType.KeywordPattern, converter.applicableFor());
    }

    @Test
    void convertOneExactTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "n/a 1", "KeywordValue", "blue jeans");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Exact)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_exact", "blue jeans")).boost(2),
                                        Set.of("blue jeans")
                                )
                        )
                )
                .keywordPatternPreview("n/a 1 = blue jeans\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertTwoORedExactTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "OR");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "blue jeans");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "red dress");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(OR)
                .matchType(Exact)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_exact", "blue jeans")).boost(2),
                                        Set.of("blue jeans")
                                ),
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_exact", "red dress")).boost(2),
                                        Set.of("red dress")
                                )
                        )
                )
                .keywordPatternPreview("field name = blue jeans, red dress\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertThreeANDedExactTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "blue jeans");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "red dress");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "pants");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Exact)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_exact", "blue jeans")).boost(2),
                                        Set.of("blue jeans")
                                ),
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_exact", "red dress")).boost(2),
                                        Set.of("red dress")
                                ),
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_exact", "pants")).boost(1),
                                        Set.of("pants")
                                )
                        )
                )
                .keywordPatternPreview("field name = blue jeans, pants, red dress\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertOneContainsTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Contains");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "n/a 1", "KeywordValue", "blue jeans");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Contains)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_contains", "blue jeans")).boost(256),
                                        Set.of("blue jeans")
                                )
                        )
                )
                .keywordPatternPreview("n/a 1 = blue jeans\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertOneLiteralTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Literal");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "n/a 1", "KeywordValue", "blue jeans");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Literal)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        constantScoreQuery(matchPhraseQuery("phrase_literal", "blue jeans")).boost(2),
                                        Set.of("blue jeans")
                                )
                        )
                )
                .keywordPatternPreview("n/a 1 = blue jeans\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void dismaxQueryForOneKeywordAttrTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field1", "KeywordValue", "jeans");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field1", "KeywordValue", "pants");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "color", "KeywordValue", "red");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "color", "KeywordValue", "blue");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Exact)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        QueryBuilders.boolQuery()
                                                .must(
                                                        QueryBuilders.disMaxQuery()
                                                                .add(constantScoreQuery(matchPhraseQuery("phrase_exact", "jeans")).boost(1))
                                                                .add(constantScoreQuery(matchPhraseQuery("phrase_exact", "pants").boost(1)))
                                                )
                                                .must(
                                                        QueryBuilders.disMaxQuery()
                                                                .add(constantScoreQuery(matchPhraseQuery("phrase_exact", "red")).boost(1))
                                                                .add(constantScoreQuery(matchPhraseQuery("phrase_exact", "blue")).boost(1))
                                                ),
                                        Set.of("pants", "jeans", "blue", "red")
                                )
                        )
                )
                .keywordPatternPreview("color = blue, red\nfield1 = jeans, pants\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void relaxingDismaxQueryForOneKeywordAttrTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field1", "KeywordValue", "jeans");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "color", "KeywordValue", "red");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "color", "KeywordValue", "blue");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Exact)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        QueryBuilders.boolQuery()
                                                .must(constantScoreQuery(matchPhraseQuery("phrase_exact", "jeans")).boost(1))
                                                .must(
                                                        QueryBuilders.disMaxQuery()
                                                                .add(constantScoreQuery(matchPhraseQuery("phrase_exact", "red")).boost(1))
                                                                .add(constantScoreQuery(matchPhraseQuery("phrase_exact", "blue")).boost(1))
                                                ),
                                        Set.of("jeans", "red", "blue")
                                )
                        )
                )
                .keywordPatternPreview("color = blue, red\nfield1 = jeans\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

    @Test
    void relaxing2DismaxQueryForOneKeywordAttrTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "AND");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field1", "KeywordValue", "jeans");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "color", "KeywordValue", "red");

        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);

        KeywordPatternTriggerParams actualParams = (KeywordPatternTriggerParams) converter.convert(processingTrigger, null);
        KeywordPatternTriggerParams expectedParams = KeywordPatternTriggerParams.builder()
                .triggerId(1)
                .operationType(AND)
                .matchType(Exact)
                .nodes(
                        List.of(
                                new KeywordPatternTriggerParams.KWPNode(
                                        QueryBuilders.boolQuery()
                                                .must(constantScoreQuery(matchPhraseQuery("phrase_exact", "jeans")).boost(1))
                                                .must(constantScoreQuery(matchPhraseQuery("phrase_exact", "red")).boost(1)),
                                        Set.of("jeans", "red")
                                )
                        )
                )
                .keywordPatternPreview("color = red\nfield1 = jeans\n")
                .build();
        assertEquals(expectedParams, actualParams);
    }

}