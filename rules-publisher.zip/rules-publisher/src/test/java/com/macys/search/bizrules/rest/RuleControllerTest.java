package com.macys.search.bizrules.rest;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.dto.RuleDto;
import com.macys.search.bizrules.services.merch.PreviewService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class RuleControllerTest {

    @Test
    public void happyPass() {
        PreviewService previewService = Mockito.mock(PreviewService.class);
        Mockito.when(previewService.getRuleById(SiteName.MCOM, 5, 200)).thenReturn(
                RuleDto.builder()
                        .ruleId(100)
                        .ruleEnabled(true)
                        .ruleName("ruleName")
                        .build()
        );
        RuleController ruleController = new RuleController(previewService);
        RuleDto rule = ruleController.getRuleById(5, SiteName.MCOM, 200);
        assertEquals(rule.getRuleId(), 100);
        assertEquals(rule.getRuleEnabled(), true);
    }
}
