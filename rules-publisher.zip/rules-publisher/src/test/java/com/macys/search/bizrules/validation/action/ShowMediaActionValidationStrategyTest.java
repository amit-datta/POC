package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.templatetests.TemplateTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Collections;

import static com.macys.search.bizrules.model.mrf.action.ActionType.ShowMedia;
import static com.macys.search.util.TestUtils.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class ShowMediaActionValidationStrategyTest extends BaseTest {

    @Autowired
    ShowMediaActionValidationStrategy strategy;

    Action action = new Action();

    @BeforeEach
    public void reset() {
        action = new Action();
        action.setId(1636);
        action.setMerchActionType(ShowMedia);
    }

    @Test
    void applicableFor() {
        assertEquals(ShowMedia, strategy.applicableFor());
    }

    @Test
    void canvasShouldBeOnlyOneCriteria() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Canvas"),
                criteria("Pool")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Canvas criteria should be single criteria in map. Criteria=[Canvas, Pool]";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void canvasTemplate() {
        TemplateTest.uniqPositiveIntegerTemplateCompositeTest(strategy, Collections.emptyMap(), "Canvas", "CanvasId");
    }

    @Test
    void noCriteria() {
        action.setCriteriaMap(Collections.emptyMap());
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Show media action should contains at least one criteria";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void oneIncorrectShowMedia() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("SM1",
                        attr("MediaIdType", "MediaPool"),
                        attr("MediaId", "124")
                ),
                criteria("SM2",
                        attr("MediaIdType", "MediaPool"),
                        attr("MediaId", "non parsable")
                )
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Only show canvas id actions available.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

}