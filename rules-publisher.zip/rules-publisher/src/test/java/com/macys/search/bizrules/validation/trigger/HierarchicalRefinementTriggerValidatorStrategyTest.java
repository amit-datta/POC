package com.macys.search.bizrules.validation.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.mrf.trigger.HRTFiringStrategy;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

class HierarchicalRefinementTriggerValidatorStrategyTest extends BaseTest {
    private final static String CRITERIA_CAT_ID = "CAT_ID";
    private final static String FIRING_STRATEGY = "FiringStrategy";
    private final static String ATTRIBUTE_VALUE = "AttributeValue";

    @Autowired
    private HierarchicalRefinementTriggerValidatorStrategy validator;

    @Test
    void applicableFor() {
        assertThat(validator.applicableFor()).isEqualTo(TriggerType.HierarchicalRefinement);
    }

    @Test
    void validateNotSearchableFlag() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(false);

        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        String expectedMessage = "Flags isSearchable and isResultSetRequired set incorrectly";
        assertThat(validationResult.getWarning()).isEqualTo(expectedMessage);
    }

    @Test
    void validateResultSetRequiredFlag() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setResultSetRequired(true);

        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        String expectedMessage = "Flags isSearchable and isResultSetRequired set incorrectly";
        assertThat(validationResult.getWarning()).isEqualTo(expectedMessage);
    }

    @Test
    void validateNotAllowedFiringStrategy() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, "NOT_ALLOWED");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");

        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        String expectedMessage = "Criteria with name=CAT_ID validation failed. In criteria CAT_ID attribute FiringStrategy " +
                "contains unexpected values. Possible values=[Exact, Descendants], real values=[NOT_ALLOWED].";
        assertThat(validationResult.getWarning()).isEqualTo(expectedMessage);
    }

    @Test
    void validateSeveralFiringStrategies() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Exact.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");

        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        String expectedMessage = "Criteria with name=CAT_ID validation failed. In Criteria CAT_ID attribute FiringStrategy " +
                "must contain only one value. But its values=[Descendants, Exact].";
        assertThat(validationResult.getWarning()).isEqualTo(expectedMessage);
    }

    @Test
    void validateMissingCriteria() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);

        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        String expectedMessage = "Missing criteria with name=CAT_ID.";
        assertThat(validationResult.getWarning()).isEqualTo(expectedMessage);
    }

    @Test
    void validateMissingAttributeValue() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());

        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        String expectedMessage = "Criteria with name=CAT_ID validation failed. Criteria=CAT_ID has missing attribute with name=AttributeValue.";
        assertThat(validationResult.getWarning()).isEqualTo(expectedMessage);
    }

    @Test
    void validateEmptyLiveCategoriesList() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");
        ValidationResult validationResult = validator.validate(trigger, getProcessingContext());
        assertThat(validationResult.isValid()).isFalse();
        assertThat(validationResult.getWarning())
                .isEqualTo("HRT trigger doesn't have live categories. not live categories = [10]");
    }

    @Test
    void validateCorrectTriggerSimpleCase() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");

        assertThat(validator.validate(trigger, getProcessingContext(List.of(Category.builder().id(10).build()))).isValid()).isTrue();
    }

    @Test
    void validateCorrectTriggerWithOnlyOneLiveCategory() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        trigger.setSearchable(true);
        trigger.setResultSetRequired(false);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "20");

        assertThat(validator.validate(trigger, getProcessingContext(List.of(Category.builder().id(20).build()))).isValid()).isTrue();
    }

    private ProcessingContext getProcessingContext() {
        return getProcessingContext(List.of());
    }

    private ProcessingContext getProcessingContext(Collection<Category> categories) {
        ProcessingContext context = new ProcessingContext();
        context.setCategoryTree(CategoryTree.from(categories));
        return context;
    }
}