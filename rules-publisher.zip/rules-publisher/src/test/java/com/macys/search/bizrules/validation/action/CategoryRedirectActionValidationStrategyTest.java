package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.util.templatetests.TemplateTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CategoryRedirectActionValidationStrategyTest extends BaseTest {

    @Autowired
    CategoryRedirectActionValidationStrategy strategy;

    @Test
    void templateLoaded() {
        assertNotNull(strategy.getTemplate());
    }

    @Test
    void applicableFor() {
        assertEquals(ActionType.CategoryRedirect, strategy.applicableFor());
    }

    @Test
    void templateTest() {
        TemplateTest.uniqPositiveIntegerTemplateCompositeTest(strategy, Collections.emptyMap(), "Category", "CategoryId");
    }

}