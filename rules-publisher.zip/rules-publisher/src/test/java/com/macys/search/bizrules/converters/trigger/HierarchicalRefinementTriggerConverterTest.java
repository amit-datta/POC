package com.macys.search.bizrules.converters.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.mrf.trigger.HRTFiringStrategy;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.HierarchicalRefinementTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.AssertionsForClassTypes.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;

class HierarchicalRefinementTriggerConverterTest extends BaseTest {
    private final static String CRITERIA_CAT_ID = "CAT_ID";
    private final static String FIRING_STRATEGY = "FiringStrategy";
    private final static String ATTRIBUTE_VALUE = "AttributeValue";
    private final static String EXCLUDED_VALUE = "ExcludedValue";

    Collection<Category> categoryList = List.of(
            from(11, null),
            from(21, 11),
            from(22, 11),
            from(311, 21),
            from(312, 21),
            from(321, 22),
            from(4121, 312),
            from(4122, 312),
            from(4123, 312),

            from(1, null),
            from(2, 1),
            from(4, 1),
            from(3, 2),
            from(5, 4),
            from(6, 4)
    );

    private static Category from(Integer id, Integer parentId) {
        return Category.builder()
                .id(id)
                .name(id.toString())
                .parentCategoryId(parentId)
                .build();
    }

    @Autowired
    private HierarchicalRefinementTriggerConverter converter;

    @Test
    void applicableForReturnsCorrectValue() {
        assertEquals(TriggerType.HierarchicalRefinement, converter.applicableFor());
    }

    @Test
    void convertExactTriggerTest() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Exact.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setCategoryTree(CategoryTree.from(categoryList));
        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);
        ctx.setTriggers(Map.of(1, processingTrigger));

        HierarchicalRefinementTriggerParams actualParams = (HierarchicalRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        HierarchicalRefinementTriggerParams expectedParams = HierarchicalRefinementTriggerParams.builder()
                .triggerId(1)
                .catIds(Set.of(10))
                .strategy(HRTFiringStrategy.Exact)
                .excludedCatIds(Set.of())
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertExactTriggerWithTwoValues() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Exact.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "20");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setCategoryTree(CategoryTree.from(categoryList));
        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);
        ctx.setTriggers(Map.of(1, processingTrigger));

        HierarchicalRefinementTriggerParams actualParams = (HierarchicalRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        HierarchicalRefinementTriggerParams expectedParams = HierarchicalRefinementTriggerParams.builder()
                .triggerId(1)
                .catIds(Set.of(10, 20))
                .strategy(HRTFiringStrategy.Exact)
                .excludedCatIds(Set.of())
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertExactTriggerShouldNotIncludeExcludedValues() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Exact.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "20");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, EXCLUDED_VALUE, "10");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setCategoryTree(CategoryTree.from(categoryList));
        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);
        ctx.setTriggers(Map.of(1, processingTrigger));

        HierarchicalRefinementTriggerParams actualParams = (HierarchicalRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        HierarchicalRefinementTriggerParams expectedParams = HierarchicalRefinementTriggerParams.builder()
                .triggerId(1)
                .catIds(Set.of(20))
                .strategy(HRTFiringStrategy.Exact)
                .excludedCatIds(Set.of(10))
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertDescendantTrigger() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "11");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "22");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "2");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "6");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setCategoryTree(CategoryTree.from(categoryList));
        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);
        ctx.setTriggers(Map.of(1, processingTrigger));

        HierarchicalRefinementTriggerParams actualParams = (HierarchicalRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        HierarchicalRefinementTriggerParams expectedParams = HierarchicalRefinementTriggerParams.builder()
                .triggerId(1)
                .catIds(Set.of(11, 21, 22, 311, 312, 321, 4121, 4122, 4123, 2, 3, 6))
                .strategy(HRTFiringStrategy.Descendants)
                .excludedCatIds(Set.of())
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertDescendantTriggerWithExcludedValue() {
        Trigger trigger = new Trigger();
        trigger.setId(1);
        trigger.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, HRTFiringStrategy.Descendants.name());
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "11");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "312");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, EXCLUDED_VALUE, "21");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, EXCLUDED_VALUE, "4123");

        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "4");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, EXCLUDED_VALUE, "6");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setCategoryTree(CategoryTree.from(categoryList));
        ProcessingTrigger processingTrigger = ProcessingTrigger.from(trigger);
        ctx.setTriggers(Map.of(1, processingTrigger));

        HierarchicalRefinementTriggerParams actualParams = (HierarchicalRefinementTriggerParams) converter.convert(processingTrigger, ctx);
        HierarchicalRefinementTriggerParams expectedParams = HierarchicalRefinementTriggerParams.builder()
                .triggerId(1)
                .catIds(Set.of(11, 22, 321, 312, 4121, 4122, 4, 5))
                .strategy(HRTFiringStrategy.Descendants)
                .excludedCatIds(Set.of(6, 21, 4123))
                .build();

        assertEquals(expectedParams, actualParams);
    }

    @Test
    void convertThrowsExceptionNonExistingStrategy() {
        Trigger trigger = new Trigger();
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, FIRING_STRATEGY, "Ancestors");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), CRITERIA_CAT_ID, ATTRIBUTE_VALUE, "10");

        ProcessingContext ctx = new ProcessingContext();
        ctx.setCategoryTree(CategoryTree.from(categoryList));
        assertThatThrownBy(() -> converter.convert(ProcessingTrigger.from(trigger), ctx)).isInstanceOf(IllegalArgumentException.class);
    }
}