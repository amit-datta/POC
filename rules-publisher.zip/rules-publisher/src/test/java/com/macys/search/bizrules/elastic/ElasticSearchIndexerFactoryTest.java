package com.macys.search.bizrules.elastic;

import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactoryImpl;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import java.util.concurrent.ExecutorService;

import static org.junit.jupiter.api.Assertions.assertNotNull;

class ElasticSearchIndexerFactoryTest {

    private final Integer sendBulkAttemptsCount = 7;
    private final Integer maxBulkSize = 10;
    @Mock
    private RestHighLevelClient client;
    @Mock
    private ExecutorService indexingExecutorService;

    private ElasticSearchIndexerFactory getFactory() {
        return new ElasticSearchIndexerFactoryImpl(client, indexingExecutorService, maxBulkSize, sendBulkAttemptsCount,
                RequestOptions.DEFAULT, 10);
    }

    @Test
    public void testCreateIndexer() {
        ElasticSearchIndexerFactory factory = getFactory();
        String indexName = "index123";
        ElasticSearchIndexer indexer = factory.createIndexer(indexName);
        assertNotNull(indexer);
    }
}
