package com.macys.search.bizrules.converters.actions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.Facet;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.junit.jupiter.api.Test;

import java.util.*;

import static com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields.MSR_PREVIEW;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ModifySearchResultsConverterTest {
    private final ObjectMapper mapper = new ObjectMapper();
    private final ModifySearchResultsConverter converter = new ModifySearchResultsConverter();

    @Test
    void convertReplaceTest() {
        Action action = new Action();
        action.setId(12345);
        action.setMerchActionType(ActionType.ModifySearchResults);
        action.setLastModifiedByName("YH00555");

        Criteria operationsCriteria = new Criteria();
        action.setCriteriaMap(Map.of("Operations", operationsCriteria));
        operationsCriteria.setCriteriaName("Operation");
        operationsCriteria.setCriteriaAttributes(Map.of("Operation", List.of("REPLACE")));

        ESAction actual = converter.convert(action, null);
        Object actualActionType = actual.getSource().get(ActionsIndexFields.ACTION_TYPE.getFieldName());
        assertEquals(ESActionType.MSR_REPLACE, actualActionType);
    }

    // TODO: this test is invalid, fix it in scope of ticket - SRP-3155
    @Test
    void attributesTest() throws JsonProcessingException {
        Action action = new Action();
        action.setId(12345);
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria attr0 = new Criteria();
        Criteria attr1 = new Criteria();
        Criteria attr2 = new Criteria();
        LinkedHashMap<String, Criteria> criteriaMap = new LinkedHashMap<>();
        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of("Operation", List.of("BOOST")));
        criteriaMap.put("Operations", operation);

        criteriaMap.put("AttributesGroup0", attr0);
        criteriaMap.put("AttributesGroup1", attr1);
        criteriaMap.put("AttributesGroup2", attr2);
        action.setCriteriaMap(criteriaMap);

        attr0.setCriteriaName("BOOST");
        attr0.setCriteriaAttributes(
                Map.of(
                        "F1", List.of("#1", "#2", "#3"),
                        "F2", List.of("#4"),
                        "F3", List.of("#3", "#4")
                )
        );
        attr0.setSequenceGroupNumber(1);
        attr1.setCriteriaName("BOOST");
        attr1.setCriteriaAttributes(
                Map.of(
                        "F1", List.of("#1", "#2", "#3", "#4"),
                        "F2", List.of("#6"),
                        "F4", List.of("#6", "#7")
                )
        );
        attr1.setSequenceGroupNumber(1);
        attr2.setCriteriaName("BOOST");
        attr2.setCriteriaAttributes(
                Map.of(
                        "F2", List.of("#6"),
                        "F4", List.of("#8")
                )
        );
        attr2.setSequenceGroupNumber(2);
        ProcessingContext processingContext = new ProcessingContext();
        processingContext.setFacets(Map.of(
                "F1", Facet.of("F1", "Facet_F1"),
                "F2", Facet.of("F2", "Facet_F2"),
                "F3", Facet.of("F3", "Facet_F3"),
                "F4", Facet.of("F4", "Facet_F4")
        ));
        ESAction esAction = converter.convert(action, processingContext);

        String actual = (String) esAction.getSource().get("boost_by_attribute");

        TypeReference<Set<MsrBavAttribute>> typeRef = new TypeReference<>() {
        };
        Set<MsrBavAttribute> actualSet = mapper.readValue(actual, typeRef);
        Set<MsrBavAttribute> expected = new HashSet<>();
        MsrBavAttribute msrBavAttribute = new MsrBavAttribute(1,
                Map.of(
                        "F1", List.of("#3", "#1", "#2"),
                        "F2", List.of("#4"),
                        "F3", List.of("#3", "#4"))
        );
        MsrBavAttribute msrBavAttribute1 = new MsrBavAttribute(1,
                Map.of(
                        "F1", List.of("#3", "#4", "#1", "#2"),
                        "F2", List.of("#6"),
                        "F4", List.of("#6", "#7"))
        );
        MsrBavAttribute msrBavAttribute2 = new MsrBavAttribute(2,
                Map.of(
                        "F2", List.of("#6"),
                        "F4", List.of("#8"))
        );
        expected.add(msrBavAttribute1);
        expected.add(msrBavAttribute);
        expected.add(msrBavAttribute2);
        assertEquals(expected, actualSet);
        List<String> resultValuesForPreview = (List<String>) esAction.getSource().get("msr_preview");
        List<String> expectedValuesForPreview = List.of("BOOST", "Sequence 1:", "F1 (Facet_F1) = #1, #2, #3", "F2 (Facet_F2) = #4",
                "F3 (Facet_F3) = #3, #4", "F4 (Facet_F4) = #6, #7", "Sequence 1:",
                "F1 (Facet_F1) = #1, #2, #3", "F2 (Facet_F2) = #4", "F3 (Facet_F3) = #3, #4", "F4 (Facet_F4) = #6, #7",
                "Sequence 2:", "F2 (Facet_F2) = #6", "F4 (Facet_F4) = #8");
        assertEquals(resultValuesForPreview, expectedValuesForPreview);
    }

    @Test
    void attributesTestWithDifferentAttributesGroup() throws JsonProcessingException {
        Action action1 = new Action();
        action1.setId(123456);
        action1.setMerchActionType(ActionType.ModifySearchResults);
        Map<String, Criteria> criteriaMap1 = new LinkedHashMap<>();

        Map<String, Criteria> criteriaMap = new LinkedHashMap<>();
        Criteria operation1 = new Criteria();
        operation1.setCriteriaAttributes(Map.of("Operation", List.of("BOOST")));
        Criteria attr3 = new Criteria();
        criteriaMap.put("Operations", operation1);

        criteriaMap.put("AttributesGroup2", attr3);

        attr3.setCriteriaName("AttributesGroup3");
        attr3.setCriteriaAttributes(
                Map.of(
                        "COLOR", List.of("Purple"),
                        "BRAND", List.of("U ZINY")
                )
        );
        attr3.setSequenceGroupNumber(1);
        attr3.setCriteriaName("AttributesGroup3");
        criteriaMap1.put("AttributesGroup3", attr3);
        action1.setCriteriaMap(criteriaMap1);

        Criteria attr1 = new Criteria();
        operation1.setCriteriaAttributes(Map.of("Operation", List.of("BOOST")));
        criteriaMap1.put("Operations", operation1);
        Action action = new Action();
        action.setId(12345);
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria attr0 = new Criteria();
        criteriaMap1.put("AttributesGroup3", attr3);
        criteriaMap1.put("AttributesGroup1", attr1);

        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of("Operation", List.of("BOOST")));
        criteriaMap.put("Operations", operation);

        criteriaMap.put("AttributesGroup0", attr0);

        attr0.setCriteriaName("AttributesGroup0");
        attr0.setCriteriaAttributes(
                Map.of(
                        "COLOR", List.of("RED", "YELLOW"),
                        "BRAND", List.of("CK", "Michael Cors")
                )
        );
        attr0.setSequenceGroupNumber(1);
        attr1.setSequenceGroupNumber(1);
        attr1.setCriteriaName("AttributesGroup1");
        attr1.setCriteriaAttributes(
                Map.of(
                        "COLOR", List.of("GREEN"),
                        "BRAND", List.of("ADIDAS")
                ));
        action.setCriteriaMap(criteriaMap);
        ProcessingContext processingContext = new ProcessingContext();
        processingContext.setFacets(Map.of(
                "F1", Facet.of("F1", "Facet_F1"),
                "F2", Facet.of("F2", "Facet_F2"),
                "F3", Facet.of("F3", "Facet_F3"),
                "F4", Facet.of("F4", "Facet_F4")
        ));
        ESAction esAction = converter.convert(action, processingContext);

        String actual = (String) esAction.getSource().get("boost_by_attribute");

        TypeReference<Set<MsrBavAttribute>> typeRef = new TypeReference<>() {
        };
        Set<MsrBavAttribute> actualSet = mapper.readValue(actual, typeRef);
        Set<MsrBavAttribute> expected = new LinkedHashSet<>();
        MsrBavAttribute msrBavAttribute = new MsrBavAttribute(1,
                Map.of(
                        "COLOR", List.of("Purple"),
                        "BRAND", List.of("U ZINY"))
        );
        MsrBavAttribute msrBavAttribute1 = new MsrBavAttribute(1,
                Map.of(
                        "COLOR", List.of("RED", "YELLOW"),
                        "BRAND", List.of("Michael Cors", "CK"))
        );
        expected.add(msrBavAttribute1);
        expected.add(msrBavAttribute);

        assertEquals(expected, actualSet);
    }

    @Test
    void differentAttributesTest() throws JsonProcessingException {
        Action action = new Action();
        action.setId(12345);
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria attr0 = new Criteria();
        Criteria attr1 = new Criteria();
        Criteria attr2 = new Criteria();
        LinkedHashMap<String, Criteria> criteriaMap = new LinkedHashMap<>();
        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of("Operation", List.of("BOOST")));
        criteriaMap.put("Operations", operation);

        criteriaMap.put("AttributesGroup0", attr0);
        criteriaMap.put("AttributesGroup1", attr1);
        criteriaMap.put("AttributesGroup2", attr2);
        action.setCriteriaMap(criteriaMap);

        attr0.setCriteriaName("BOOST");
        attr0.setCriteriaAttributes(
                Map.of(
                        "A1", List.of("#1", "#2", "#3"),
                        "A2", List.of("#4"),
                        "A3", List.of("#3", "#4")
                )
        );
        attr0.setSequenceGroupNumber(1);
        attr1.setCriteriaName("BOOST");
        attr1.setCriteriaAttributes(
                Map.of(
                        "B1", List.of("#1", "#2", "#3", "#4"),
                        "B2", List.of("#6"),
                        "B4", List.of("#6", "#7")
                )
        );
        attr1.setSequenceGroupNumber(2);
        attr2.setCriteriaName("BOOST");
        attr2.setCriteriaAttributes(
                Map.of(
                        "C2", List.of("#6"),
                        "C3", List.of("#3"),
                        "C4", List.of("#8")
                )
        );
        attr2.setSequenceGroupNumber(3);
        ProcessingContext processingContext = new ProcessingContext();
        processingContext.setFacets(Map.of(
                "A1", Facet.of("A1", "Facet_A1"),
                "A2", Facet.of("A2", "Facet_A2"),
                "A3", Facet.of("A3", "Facet_A3"),
                "B1", Facet.of("B1", "Facet_B1"),
                "B2", Facet.of("B2", "Facet_B2"),
                "B4", Facet.of("B4", "Facet_B4"),
                "C2", Facet.of("C2", "Facet_C2"),
                "C3", Facet.of("C3", "Facet_C3"),
                "C4", Facet.of("C4", "Facet_C4")
        ));
        ESAction esAction = converter.convert(action, processingContext);

        String actual = (String) esAction.getSource().get("boost_by_attribute");

        TypeReference<Set<MsrBavAttribute>> typeRef = new TypeReference<>() {
        };
        Set<MsrBavAttribute> actualSet = mapper.readValue(actual, typeRef);
        Set<MsrBavAttribute> expected = new HashSet<>();
        MsrBavAttribute msrBavAttribute = new MsrBavAttribute(1,
                Map.of(
                        "A3", List.of("#3", "#4"),
                        "A1", List.of("#3", "#1", "#2"),
                        "A2", List.of("#4"))
        );
        MsrBavAttribute msrBavAttribute1 = new MsrBavAttribute(3,
                Map.of(
                        "C4", List.of("#8"),
                        "C3", List.of("#3"),
                        "C2", List.of("#6"))
        );
        MsrBavAttribute msrBavAttribute2 = new MsrBavAttribute(2,
                Map.of(
                        "B1", List.of("#3", "#1", "#4", "#2"),
                        "B4", List.of("#6", "#7"),
                        "B2", List.of("#6")));

        expected.add(msrBavAttribute1);
        expected.add(msrBavAttribute);
        expected.add(msrBavAttribute2);

        assertEquals(expected, actualSet);
        List<String> resultValuesForPreview = (List<String>) esAction.getSource().get("msr_preview");
        List<String> expectedValuesForPreview = List.of("BOOST", "Sequence 1:", "A1 (Facet_A1) = #1, #2, #3", "A2 (Facet_A2) = #4",
                "A3 (Facet_A3) = #3, #4", "Sequence 2:",
                "B1 (Facet_B1) = #1, #2, #3, #4", "B2 (Facet_B2) = #6", "B4 (Facet_B4) = #6, #7",
                "Sequence 3:", "C2 (Facet_C2) = #6", "C3 (Facet_C3) = #3", "C4 (Facet_C4) = #8");
        assertEquals(resultValuesForPreview, expectedValuesForPreview);
    }

    @Test
    void convertBoostTest() {
        Action action = new Action();
        action.setId(12345);
        action.setMerchActionType(ActionType.ModifySearchResults);
        action.setLastModifiedByName("YH00555");
        action.setCriteriaMap(new HashMap<>());
        Criteria operationsCriteria = new Criteria();
        action.getCriteriaMap().put("Operations", operationsCriteria);
        operationsCriteria.setCriteriaName("Operation");
        operationsCriteria.setCriteriaAttributes(Map.of("Operation", List.of("BOOST")));

        Criteria poolCriteria = new Criteria();
        action.getCriteriaMap().put("Pool", poolCriteria);
        poolCriteria.setCriteriaName("Pool");
        poolCriteria.setCriteriaAttributes(Map.of("PoolId", new ArrayList<>(Arrays.asList("3", "2", "1"))));

        Criteria productCriteria = new Criteria();
        action.getCriteriaMap().put("Product", productCriteria);
        productCriteria.setCriteriaName("Product");
        productCriteria.setCriteriaAttributes(Map.of("ProductId", new ArrayList<>(Arrays.asList("22", "33", "11"))));


        ESAction actual = converter.convert(action, null);
        Object actualActionType = actual.getSource().get(ActionsIndexFields.ACTION_TYPE.getFieldName());
        assertEquals(ESActionType.MSR_BOOST, actualActionType);
        List<String> preview = (List<String>) actual.getSource().get(MSR_PREVIEW.getFieldName());
        assertEquals(preview.size(), 3);
        assertEquals(preview.get(0), "BOOST");
        assertEquals(preview.get(1), "Prod ID = 11, 22, 33");
        assertEquals(preview.get(2), "Saved Set / Query ID = 1, 2, 3");
    }

}