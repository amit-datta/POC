package com.macys.search.bizrules.tasklets.product;

import com.macys.search.bizrules.catalog.ProductsLoader;
import com.macys.search.bizrules.converters.products.CategoryPathConverter;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.ESProduct;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.services.StoppedJobsCache;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

class ProcessProductsTaskletTest extends AbstractTaskletTest {

    @Mock
    private ElasticSearchIndexerFactory factory;
    @Mock
    private ElasticSearchIndexer indexer;
    @Captor
    private ArgumentCaptor<ESProduct> captor;

    private ProductsProcessingTasklet tasklet;

    @Test
    void execute() throws Exception {
        tasklet = createTasklet(
                List.of(
                        product(1).build(),
                        product(3).build(),
                        product(5).build()
                )
        );

        Mockito.when(factory.createIndexer(any())).thenReturn(indexer);
        Mockito.when(indexer.flush()).thenReturn(true);

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        StoppedJobsCache jobsCache = new StoppedJobsCache();
        ctx.setStoppedJobsCache(jobsCache);
        ctx.setupIndex(ESIndex.PRODUCTS, "products", indexer);
        ctx.setIndexedMsrAction(Map.of());

        execute(tasklet);

        Mockito.verify(indexer, Mockito.times(3)).add(captor.capture());
        List<ESProduct> actual = captor.getAllValues();

        assertEquals(Set.of(1, 3, 5), getIds(actual));
    }

    @Test
    void masterMemberLogic() throws Exception {
        tasklet = createTasklet(
                List.of(
                        product(1).members(List.of(product(2).build(), product(3).build())).build(),
                        product(4).members(List.of(product(5).build())).build(),
                        product(6).build(),
                        product(7).build()
                )
        );

        Mockito.when(factory.createIndexer(any())).thenReturn(indexer);
        Mockito.when(indexer.flush()).thenReturn(true);

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        StoppedJobsCache jobsCache = new StoppedJobsCache();
        ctx.setStoppedJobsCache(jobsCache);
        ctx.setupIndex(ESIndex.PRODUCTS, "products", indexer);
        ctx.setIndexedMsrAction(Map.of());

        execute(tasklet);

        Mockito.verify(indexer, Mockito.times(4)).add(captor.capture());
        List<ESProduct> actual = captor.getAllValues();

        assertEquals(Set.of(1, 4, 6, 7), getIds(actual));
    }

    @Test
    void failOnFlush() {
        tasklet = createTasklet(List.of(product(6).build()));

        Mockito.when(factory.createIndexer(any())).thenReturn(indexer);
        Mockito.when(indexer.flush()).thenReturn(false);

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        StoppedJobsCache jobsCache = new StoppedJobsCache();
        ctx.setStoppedJobsCache(jobsCache);
        ctx.setupIndex(ESIndex.PRODUCTS, "products", indexer);
        ctx.setIndexedMsrAction(Map.of());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> execute(tasklet));
        assertTrue(exception.getMessage().contains("Some exception occurred during send products to Elastic search"));
    }

    private static Set<Integer> getIds(List<ESProduct> list) {
        return list.stream()
                .map(ESProduct::getSource)
                .map(m -> m.get("product_id"))
                .map(Integer.class::cast)
                .collect(Collectors.toSet());
    }

    private ProductsProcessingTasklet createTasklet(List<Product> products) {
        return new ProductsProcessingTasklet(
                new ProductsLoader() {
                    @Override
                    public Collection<Product> loadAll(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics) {
                        return products;
                    }

                    @Override
                    public Iterator<Product> iterator(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics) {
                        return products.iterator();
                    }
                },
                factory,
                new CategoryPathConverter(List.of())
        );
    }

    private static Product.ProductBuilder product(Integer id) {
        return Product.builder().productId(id).parentCategories(List.of()).pools(List.of()).members(List.of());
    }
}