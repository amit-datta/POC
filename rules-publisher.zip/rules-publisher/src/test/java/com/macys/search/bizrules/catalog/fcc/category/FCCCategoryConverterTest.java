package com.macys.search.bizrules.catalog.fcc.category;

import com.macys.search.bizrules.catalog.fcc.category.bindings.*;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import com.macys.search.bizrules.model.category.ContextOverride;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.category.CategoryAttributeName.PRICE_FILTER;
import static com.macys.search.bizrules.model.category.CategoryAttributeName.TIMED_FILTER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class FCCCategoryConverterTest {

    CategoryBinding binding;

    public FCCCategoryConverterTest() {
        binding = new CategoryBinding();
        binding.setId(2);
        binding.setName("Category name");
        binding.setParentCategoryId(1);
        binding.setAttributes(List.of(
                attrBinding(PRICE_FILTER, "val1")
        ));
    }

    @Test
    void convert() {
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(
                        Map.of(PRICE_FILTER, CategoryAttribute.builder()
                                .name(PRICE_FILTER)
                                .values(
                                        Set.of(
                                                "val1"
                                        )
                                ).build()
                        )
                )
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullId() {
        binding.setId(null);
        binding.setParentCategoryId(null);
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(null)
                .parentCategoryId(null)
                .name("Category name")
                .attributes(
                        Map.of(PRICE_FILTER, CategoryAttribute.builder()
                                .name(PRICE_FILTER)
                                .values(
                                        Set.of(
                                                "val1"
                                        )
                                ).build()
                        )
                )
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullAttributes() {
        binding.setAttributes(null);
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(Map.of())
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullAttributeName() {
        binding.getAttributes().iterator().next().setName(null);
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(
                        Map.of()
                )
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void nullAttrValue() {
        binding.getAttributes().iterator().next()
                .getAttributeValues().iterator().next()
                .setValue(null);
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(
                        Map.of(PRICE_FILTER, CategoryAttribute.builder()
                                .name(PRICE_FILTER)
                                .values(
                                        Set.of()
                                ).build()
                        )
                )
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void severalAttrs() {
        binding.setAttributes(
                List.of(binding.getAttributes().iterator().next(),
                        attrBinding(TIMED_FILTER, "v1", "v2", "v2", "v3")
                )
        );
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(
                        Map.of(PRICE_FILTER, CategoryAttribute.builder()
                                        .name(PRICE_FILTER)
                                        .values(
                                                Set.of("val1")
                                        ).build(),
                                TIMED_FILTER, CategoryAttribute.builder()
                                        .name(TIMED_FILTER)
                                        .values(
                                                Set.of("v1", "v2", "v3")
                                        ).build()
                        )
                )
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void duplicatedAttrNames() {
        binding.setAttributes(
                List.of(binding.getAttributes().iterator().next(),
                        attrBinding(PRICE_FILTER, "v1", "v2", "v2", "v3")
                )
        );
        Category actual = FCCCategoryConverter.convert(binding);
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(
                        Map.of(PRICE_FILTER, CategoryAttribute.builder()
                                .name(PRICE_FILTER)
                                .values(
                                        Set.of("val1")
                                ).build()
                        )
                )
                .contextOverrides(List.of())
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void contextOverridesBinding() {
        ContextOverridesBinding contextOverridesBinding = new ContextOverridesBinding();
        ContextOverrideBinding contextOverrideBinding = new ContextOverrideBinding();
        contextOverrideBinding.setSuppressed(false);
        contextOverrideBinding.setName("contextOverrideBinding");
        contextOverrideBinding.setSequenceNumber(100);
        contextOverridesBinding.setContextOverride(List.of(contextOverrideBinding));
        ContextBinding contextBinding = new ContextBinding();
        contextOverrideBinding.setContext(contextBinding);
        contextBinding.setId(1000);

        ContextAttributesBinding contextAttributesBinding = new ContextAttributesBinding();
        ContextAttributeBinding contextAttributeBinding1 = new ContextAttributeBinding();
        contextAttributeBinding1.setName("attr1");
        contextAttributeBinding1.setValue(List.of("value1"));
        contextAttributesBinding.setAttribute(List.of(contextAttributeBinding1));
        contextBinding.setContextAttributes(contextAttributesBinding);

        binding.setContextOverrides(contextOverridesBinding);
        Category actual = FCCCategoryConverter.convert(binding);
        ContextOverride contextOverride = new ContextOverride();
        contextOverride.setName("contextOverrideBinding");
        contextOverride.setSequenceNumber(100);
        contextOverride.setId(1000);
        contextOverride.addAttribute("attr1", List.of("value1"));
        Category expected = Category.builder()
                .id(2)
                .parentCategoryId(1)
                .name("Category name")
                .attributes(
                        Map.of(PRICE_FILTER, CategoryAttribute.builder()
                                .name(PRICE_FILTER)
                                .values(
                                        Set.of("val1")
                                ).build()
                        )
                )
                .contextOverrides(List.of(contextOverride))
                .build();
        assertEquals(expected, actual);
    }

    @Test
    void contextOverridesBindingEmptyAttributesBinding() {
        ContextOverridesBinding contextOverridesBinding = new ContextOverridesBinding();
        ContextOverrideBinding contextOverrideBinding = new ContextOverrideBinding();
        contextOverrideBinding.setSuppressed(false);
        contextOverrideBinding.setName("contextOverrideBinding");
        contextOverrideBinding.setSequenceNumber(100);
        contextOverridesBinding.setContextOverride(List.of(contextOverrideBinding));
        ContextBinding contextBinding = new ContextBinding();
        contextOverrideBinding.setContext(contextBinding);
        contextBinding.setId(1000);

        binding.setContextOverrides(contextOverridesBinding);
        assertThrows(IllegalArgumentException.class, () -> FCCCategoryConverter.convert(binding));
    }

    @Test
    void contextOverridesBindingMissedContextBinding() {
        ContextOverridesBinding contextOverridesBinding = new ContextOverridesBinding();
        ContextOverrideBinding contextOverrideBinding = new ContextOverrideBinding();
        contextOverrideBinding.setSuppressed(false);
        contextOverrideBinding.setName("contextOverrideBinding");
        contextOverrideBinding.setSequenceNumber(100);
        contextOverridesBinding.setContextOverride(List.of(contextOverrideBinding));

        binding.setContextOverrides(contextOverridesBinding);
        assertThrows(IllegalArgumentException.class, () -> FCCCategoryConverter.convert(binding));
    }

    private static AttributeBinding attrBinding(CategoryAttributeName name, String... values) {
        AttributeBinding binding = new AttributeBinding();
        binding.setName(name.toString());
        binding.setAttributeValues(
                Arrays.stream(values)
                        .map(FCCCategoryConverterTest::attrValueBinding)
                        .collect(Collectors.toList())
        );
        return binding;
    }

    private static AttributeValueBinding attrValueBinding(String value) {
        AttributeValueBinding binding = new AttributeValueBinding();
        binding.setValue(value);
        return binding;
    }

}