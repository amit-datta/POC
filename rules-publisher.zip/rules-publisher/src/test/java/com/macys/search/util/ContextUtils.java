package com.macys.search.util;

import com.macys.search.bizrules.services.StoppedJobsCache;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;

import java.util.Map;

public class ContextUtils {

    public static ProcessingContext createProcessingContext(Map<String, JobParameter> params) {
        ExecutionContext executionContext = new ExecutionContext();
        JobExecution jobExecution = new JobExecution(new JobInstance(1L, "job-test"), new JobParameters(params));
        jobExecution.setExecutionContext(executionContext);
        var contribution = new StepContribution(new StepExecution("stepName", jobExecution));
        var chunkContext = new ChunkContext(new StepContext(contribution.getStepExecution()));
        ProcessingContext.initContext(contribution, chunkContext);
        var context = ProcessingContext.getContext(contribution);
        context.setStoppedJobsCache(new StoppedJobsCache());
        return context;
    }
}
