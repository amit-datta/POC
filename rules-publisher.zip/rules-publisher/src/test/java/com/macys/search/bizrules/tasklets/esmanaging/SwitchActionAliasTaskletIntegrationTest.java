package com.macys.search.bizrules.tasklets.esmanaging;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.BaseIntegrationESTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.elasticsearch.cluster.metadata.AliasMetadata;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

//todo move it to test framework
class SwitchActionAliasTaskletIntegrationTest extends BaseIntegrationESTest {
    private final String mcomKWPIndexAliasName = "mcom_kwp_triggers__test";
    private final String bcomKWPIndexAliasName = "bcom_kwp_triggers_test";
    public static final String MCOM_KWP_TRIGGERS_ALIAS_V_1 = "mcom_kwp_triggers__test";
    public static final String MCOM_KWP_TRIGGERS_ALIAS_V_2 = "mcom_kwp_triggers__test_V_2__V_2";
    private final String mcomActionsIndexAliasName_V_1 = "mcom_kwp_triggers__test_V_1__V_1";

    private final String indexVersionV1 = "_V_1";
    private final String indexVersionV2 = "_V_2";

    private final Integer mcomIndicesToKeep = 2;
    private final Integer bcomIndicesToKeep = 2;
    private final String mcomKWPTriggersIndexNameV1 = "mcom_kwp_triggers";
    private final String mcomKWPTriggersNameV2 = "mcom_kwp_triggers_v2";
    @Autowired
    private SwitchAliasTasklet switchAliasTasklet;
    @Autowired
    private ElasticSearchIndexerFactory factory;

    @Test
    void shouldSwitchActionAliasIndexAndRemoveOldIndexVersionMCOM() throws IOException {
        setSiteNameForTheJob(SiteName.MCOM);
        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, indexNameSearchMCOM, factory.createIndexer(indexNameSearchMCOM));
        ctx.setupIndex(ESIndex.TRIGGERS, indexNameBrowseMCOM, factory.createIndexer(indexNameBrowseMCOM));
        ctx.setupIndex(ESIndex.CATEGORIES, indexNameCategoriesMCOM, factory.createIndexer(indexNameCategoriesMCOM));
        ctx.setupIndex(ESIndex.PRODUCTS, indexNameProductsMCOM, factory.createIndexer(indexNameProductsMCOM));
        ctx.setupIndex(ESIndex.BIZ_CONTROLS_DB, indexNameSearchBCOM, factory.createIndexer(indexNameSearchBCOM));
        ctx.setupIndex(ESIndex.ACTIONS, indexNameActionsBCOM, factory.createIndexer(indexNameActionsBCOM));
        ctx.setupIndex(ESIndex.RULES, indexNameRulesMCOM, factory.createIndexer(indexNameRulesMCOM));

        switchAliasTasklet.execute(ctx);

        GetIndexRequest request = new GetIndexRequest(indexNameSearchMCOM);
        GetIndexResponse response = client.indices().get(request, RequestOptions.DEFAULT);

        String[] actualIndices = response.getIndices();
        String[] expectedIndicesV0 = new String[]{indexNameSearchMCOM};

        List<String> expectedAliases = List.of(mcomKWPIndexAliasName);
        List<String> actualAliases = response.getAliases().values()
                .stream()
                .flatMap(Collection::stream)
                .map(AliasMetadata::getAlias)
                .sorted()
                .collect(Collectors.toList());

        compareResults(expectedAliases, actualAliases, expectedIndicesV0, actualIndices);

        String indexNameV1 = facade.createIndex(new IndexCreationProperties(mcomKWPTriggersIndexNameV1,
                1, 0, ActionsIndexFields.class, null), mcomCommonIndexProperties);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, indexNameV1, factory.createIndexer(indexNameV1));
        SwitchAliasTasklet switchAliasTaskletV1 = create(indexVersionV1);
        switchAliasTaskletV1.execute(ctx);

        GetIndexRequest indexRequestV1 = new GetIndexRequest(indexNameSearchMCOM, indexNameV1);
        GetIndexResponse indexResponseV1 = client.indices().get(indexRequestV1, RequestOptions.DEFAULT);

        String[] actualIndicesV1 = indexResponseV1.getIndices();
        String[] expectedIndicesV1 = new String[]{indexNameSearchMCOM, indexNameV1};

        List<String> expectedAliasesV1 = List.of(MCOM_KWP_TRIGGERS_ALIAS_V_1, mcomActionsIndexAliasName_V_1);
        List<String> actualAliasesV1 = indexResponseV1.getAliases().values()
                .stream()
                .flatMap(Collection::stream)
                .map(AliasMetadata::getAlias)
                .sorted()
                .collect(Collectors.toList());

        compareResults(expectedAliasesV1, actualAliasesV1, expectedIndicesV1, actualIndicesV1);

        String indexNameV2 = facade.createIndex(new IndexCreationProperties(mcomKWPTriggersNameV2, 1, 0,
                ActionsIndexFields.class, null), mcomCommonIndexProperties);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, indexNameV2, factory.createIndexer(indexNameV2));
        SwitchAliasTasklet switchAliasTaskletV2 = create(indexVersionV2);
        switchAliasTaskletV2.execute(ctx);
        GetIndexRequest indexRequestV2 = new GetIndexRequest(indexNameV1, indexNameV2);
        GetIndexResponse indexResponseV2 = client.indices().get(indexRequestV2, RequestOptions.DEFAULT);
        String[] expectedIndicesV2 = new String[]{indexNameV1, indexNameV2};
        String[] actualIndicesV2 = indexResponseV2.getIndices();

        List<String> expectedAliasesV2 = List.of(mcomActionsIndexAliasName_V_1, MCOM_KWP_TRIGGERS_ALIAS_V_2);
        List<String> actualAliasesV2 = indexResponseV2.getAliases().values()
                .stream()
                .flatMap(Collection::stream)
                .map(AliasMetadata::getAlias)
                .sorted()
                .collect(Collectors.toList());

        compareResults(expectedAliasesV2, actualAliasesV2, expectedIndicesV2, actualIndicesV2);
        removeESIndex(indexNameV1);
        removeESIndex(indexNameV2);
    }

    private void compareResults(List<String> expectedAliases, List<String> actualAliases, String[] expectedIndices, String[] actualIndices) {
        assertArrayEquals(expectedIndices, actualIndices);
        assertEquals(expectedAliases.size(), actualAliases.size());
        assertEquals(expectedAliases, actualAliases);
    }

    void removeESIndex(String actionsIndexName) throws IOException {
        DeleteIndexRequest request = new DeleteIndexRequest(actionsIndexName);
        AcknowledgedResponse response = client.indices().delete(request, RequestOptions.DEFAULT);
        assertTrue(response.isAcknowledged());
    }


    private SwitchAliasTasklet create(String indexVersion) {
        SwitchAliasProperties actionsProperties = SwitchAliasProperties.of(
                ESIndex.KWP_TRIGGERS,
                mcomKWPIndexAliasName + indexVersion,
                bcomKWPIndexAliasName + indexVersion,
                indexVersion,
                1);
        List<SwitchAliasProperties> properties = List.of(actionsProperties);
        return new SwitchAliasTasklet(facade, properties, mcomCommonIndexProperties, bcomCommonIndexProperties,
                new ObjectMapper());
    }
}
