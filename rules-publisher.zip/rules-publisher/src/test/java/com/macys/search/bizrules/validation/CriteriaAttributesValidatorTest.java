package com.macys.search.bizrules.validation;

import com.macys.search.bizrules.validation.model.ConfigTemplate;
import com.macys.search.bizrules.validation.model.CriteriaTemplate;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CriteriaAttributesValidatorTest {

    @Test
    void validateCriteriaMap() {
        ValidationResult result = CriteriaAttributesValidator.validateCriteriaMap(null, new ConfigTemplate());
        assertEquals("Criteria map is null.", result.getWarning());
    }

    @Test
    void validateCriteriaAttributes() {
        ValidationResult result = CriteriaAttributesValidator.validateCriteriaAttributes(null, new CriteriaTemplate());
        assertEquals("Criteria is null.", result.getWarning());
    }
}