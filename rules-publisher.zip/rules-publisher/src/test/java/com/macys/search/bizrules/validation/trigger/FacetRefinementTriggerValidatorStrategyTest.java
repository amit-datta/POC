package com.macys.search.bizrules.validation.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.services.merch.TriggersService;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

class FacetRefinementTriggerValidatorStrategyTest extends BaseTest {

    @Autowired
    private FacetRefinementTriggerValidatorStrategy strategy;

    @Test
    void applicableForTest() {
        assertEquals(TriggerType.FacetRefinement, strategy.applicableFor());
    }

    @Test
    void oneParameterTriggerTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee & Espresso");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertTrue(result.isValid());
    }

    @Test
    void validTriggerTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee & Espresso");
        TestUtils.triggerAddParam(trigger, "FURNITURE_CATEGORY", "AttributeValue", "Couches & Sofas");
        TestUtils.triggerAddParam(trigger, "BED_SIZE", "AttributeValue", "Queen");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertTrue(result.isValid());
    }

    @Test
    void exactWithOptionTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Exact");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertTrue(result.isValid());
    }

    @Test
    void containsWithOptionTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. Refinements is optional only for 'exact' 'and' trigger type. " +
                "Match config=Criteria(criteriaName=MatchConfig, criteriaAttributes={MatchType=[Contains], MatchOperator=[AND]}, " +
                "criteriaDateAwareAttributes={}, attributeToSeqNumbersMap={}, sequenceGroupNumber=null)";
        assertEquals(expectedMsg, result.getWarning());
    }

    @Test
    void orWithOptionTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "OR");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Exact");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertTrue(result.isValid());
    }

    @Test
    void orContainsOptionTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "OR");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. Refinements is optional only for 'exact' 'and' trigger type. " +
                "Match config=Criteria(criteriaName=MatchConfig, criteriaAttributes={MatchType=[Contains], MatchOperator=[OR]}, " +
                "criteriaDateAwareAttributes={}, attributeToSeqNumbersMap={}, sequenceGroupNumber=null)";
        assertEquals(expectedMsg, result.getWarning());
    }

    @Test
    void absentMatchTypeTriggerTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee & Espresso");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. Criteria with name=MatchConfig validation failed. " +
                "Criteria=MatchConfig has missing attribute with name=MatchType.";
        assertEquals(expectedMsg, result.getWarning());
    }

    @Test
    void absentMatchOperatorTriggerTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee & Espresso");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. Criteria with name=MatchConfig validation failed. " +
                "Criteria=MatchConfig has missing attribute with name=MatchOperator.";
        assertEquals(expectedMsg, result.getWarning());
    }

    @Test
    void absentParamsTriggerTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. Missing criteria with name=MatchConfig.";
        assertEquals(expectedMsg, result.getWarning());
    }


    @Test
    void attributeHasTwoValuesTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee & Espresso");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Couches & Sofas");
        TestUtils.triggerAddParam(trigger, "BED_SIZE", "AttributeValue", "Queen");
        TestUtils.triggerAddParam(trigger, "BED_SIZE", "AttributeValue", "Overweight");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertTrue(result.isValid());
    }

    @Test
    void attributeHasInvalidNameTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue1", "Coffee & Espresso");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. Criteria=ELECTRICS_TYPE has missing attribute with name=AttributeValue.";
        assertEquals(expectedMsg, result.getWarning());
    }

    @Test
    void emptyAttributeTest() {
        Trigger trigger = TestUtils.createTrigger(17223, TriggerType.FacetRefinement);
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchOperator", "AND");
        TestUtils.triggerAddParam(trigger, "MatchConfig", "MatchType", "Contains");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "");
        TestUtils.triggerAddParam(trigger, "ELECTRICS_TYPE", "AttributeValue", "Coffee");

        TriggersService.parseAttributes(trigger);

        ValidationResult result = strategy.validate(trigger, null);
        assertFalse(result.isValid());
        String expectedMsg = "Trigger with id=17223 invalid. In criteria ELECTRICS_TYPE attribute " +
                "AttributeValue contains wrong value=. Values=[, Coffee] should match the type=NonBlankString.";
        assertEquals(expectedMsg, result.getWarning());
    }
}