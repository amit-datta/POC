package com.macys.search.bizrules.tasklets.category;

import com.macys.search.bizrules.converters.category.CategoryConverter;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESCategory;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.tasklets.ProcessingContext.initContext;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

class CategoryIndexingTaskletTest extends AbstractTaskletTest {

    @Mock
    private ElasticSearchIndexerFactory factory;
    @Mock
    private ElasticSearchIndexer indexer;
    @Captor
    private ArgumentCaptor<ESCategory> captor;

    private CategoryIndexingTasklet tasklet;
    @Autowired
    private CategoryConverter categoryConverter;

    @Test
    void execute() throws Exception {
        Mockito.when(factory.createIndexer(any())).thenReturn(indexer);
        Mockito.when(indexer.flush()).thenReturn(true);
        tasklet = new CategoryIndexingTasklet(factory, categoryConverter);

        ProcessingContext ctx = initContext(contribution, chunkContext);
        ctx.setCategoryTree(
                CategoryTree.from(List.of(
                        Category.builder().id(1).name("first").attributes(Map.of()).build(),
                        Category.builder().id(2).parentCategoryId(1).name("second").attributes(Map.of()).build(),
                        Category.builder().id(3).parentCategoryId(2).name("third").attributes(Map.of()).build(),
                        Category.builder().id(5).parentCategoryId(3).name("fifth").attributes(Map.of()).build()
                ))
        );

        execute(tasklet);

        Mockito.verify(indexer, Mockito.times(4)).add(captor.capture());
        List<ESCategory> actual = captor.getAllValues();

        assertEquals(Set.of(1, 2, 3, 5), getIds(actual));
    }

    @Test
    void failOnFlush() {
        Mockito.when(factory.createIndexer(any())).thenReturn(indexer);
        Mockito.when(indexer.flush()).thenReturn(false);
        tasklet = new CategoryIndexingTasklet(factory, new CategoryConverter());

        ProcessingContext ctx = initContext(contribution, chunkContext);
        ctx.setCategoryTree(
                CategoryTree.from(List.of(
                        Category.builder().id(1).name("first").attributes(Map.of()).build()
                ))
        );
        RuntimeException exception = assertThrows(RuntimeException.class, () -> execute(tasklet));
        assertTrue(exception.getMessage().contains("Some exception occurred during send categories to Elastic search"));
    }

    private static Set<Integer> getIds(List<ESCategory> list) {
        return list.stream()
                .map(ESCategory::getSource)
                .map(m -> m.get("category_id"))
                .map(Integer.class::cast)
                .collect(Collectors.toSet());
    }
}