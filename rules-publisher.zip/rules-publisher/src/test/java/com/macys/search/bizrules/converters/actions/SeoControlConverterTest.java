package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SeoControlConverterTest {

    private final SeoControlConverter converter = new SeoControlConverter();

    @Test
    void convertTrue() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.SeoControl);
        Criteria criteria = new Criteria();
        action.setCriteriaMap(Map.of(
                "SeoParameters", criteria
        ));
        criteria.setCriteriaAttributes(
                Map.of(
                        "IndexFollow", List.of("Y")
                )
        );
        ESAction actual = converter.convert(action, null);
        assertEquals(true, actual.getSource().get("index_follow"));
    }

    @Test
    void convertFalse() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.SeoControl);
        Criteria criteria = new Criteria();
        action.setCriteriaMap(Map.of(
                "SeoParameters", criteria
        ));
        criteria.setCriteriaAttributes(
                Map.of(
                        "IndexFollow", List.of("N")
                )
        );
        ESAction actual = converter.convert(action, null);
        assertEquals(false, actual.getSource().get("index_follow"));
    }

}