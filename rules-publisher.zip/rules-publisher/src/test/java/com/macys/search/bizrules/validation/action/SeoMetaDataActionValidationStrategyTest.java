package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.macys.search.bizrules.model.mrf.action.ActionType.SeoMetaData;
import static com.macys.search.util.TestUtils.*;
import static org.junit.jupiter.api.Assertions.*;

class SeoMetaDataActionValidationStrategyTest extends BaseTest {

    @Autowired
    private SeoMetaDataActionValidationStrategy strategy;
    private Action action = TestUtils.createAction(1452, SeoMetaData);

    @Test
    void templateLoaded() {
        assertNotNull(strategy.getTemplate());
    }

    @Test
    void applicableFor() {
        assertEquals(ActionType.SeoMetaData, strategy.applicableFor());
    }

    @Test
    void missingAttribute() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("ANY_NAME_0", attr("AttributeValue", "val")),
                criteria("ANY_NAME_1")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria=ANY_NAME_1 has missing attribute with name=AttributeValue.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void multipleAttribute() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("ANY_NAME_1", attr("AttributeValue", "val")),
                criteria("ANY_NAME_2", attr("AttributeValue", "val1", "val2"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "In Criteria ANY_NAME_2 attribute AttributeValue must contain only one value. But its values=[val1, val2].";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void blankAttribute() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("ANY_NAME_1", attr("AttributeValue", " "))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "In criteria ANY_NAME_1 attribute AttributeValue has blank value.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void noCriteria() {
        action.setCriteriaMap(Collections.emptyMap());
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Seo metadata action should contains at least one criteria";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validAction() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("ANY_NAME_1", attr("AttributeValue", "val"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

    @Test
    void validMultiParamAction() {
        action.setCriteriaMap(toMap(List.of(
                criteria("ANY_NAME_1", attr("AttributeValue", "val")),
                criteria("ANY_NAME_2", attr("AttributeValue", "val")),
                criteria("ANY_NAME_3", attr("AttributeValue", "val"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

}