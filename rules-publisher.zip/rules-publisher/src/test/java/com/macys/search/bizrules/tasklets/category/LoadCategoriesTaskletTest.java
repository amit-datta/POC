package com.macys.search.bizrules.tasklets.category;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LoadCategoriesTaskletTest extends AbstractTaskletTest {

    List<Category> categories = List.of(
            Category.builder().id(1).parentCategoryId(null).build(),
            Category.builder().id(2).parentCategoryId(1).build(),
            Category.builder().id(4).parentCategoryId(1).build()
    );

    CategoryLoader categoryLoader = new CategoryLoader() {
        @Override
        public Collection<Category> loadAll(SiteName siteName, TimeStatistics timeStatistics) {
            return categories;
        }

        @Override
        public Iterator<Category> iterator(SiteName siteName, TimeStatistics timeStatistics) {
            return categories.iterator();
        }
    };

    LoadCategoriesTasklet tasklet = new LoadCategoriesTasklet(categoryLoader);

    @Test
    void loadCategories() {
        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        tasklet.execute(ctx);
        assertEquals(List.of(2, 4), ctx.getCategoryTree().getChildren(1, Set.of()));
    }

}