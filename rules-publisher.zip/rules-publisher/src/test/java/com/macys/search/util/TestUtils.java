package com.macys.search.util;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionParameter;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerParameter;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestUtils {

    public static String getUniqLogMessage(InmemoryAppender inmemoryAppender) {
        List<ILoggingEvent> events = inmemoryAppender.getLoggedEvents();
        assertEquals(1, events.size());
        return events.get(0).getFormattedMessage();
    }

    public static void noWarns(InmemoryAppender inmemoryAppender) {
        List<ILoggingEvent> events = inmemoryAppender.getLoggedEvents();
        assertTrue(events.isEmpty());
    }

    public static void addAppender(Object bean, InmemoryAppender appender) {
        addAppender(appender, (Logger) ReflectionTestUtils.getField(bean, "log"));
    }

    public static void addAppender(Class staticClass, InmemoryAppender appender) {
        addAppender(appender, (Logger) ReflectionTestUtils.getField(staticClass, "log"));
    }

    private static void addAppender(final InmemoryAppender appender, final Logger logger) {
        appender.setContext((LoggerContext) LoggerFactory.getILoggerFactory());
        logger.setLevel(Level.WARN);
        logger.addAppender(appender);
    }

    public static Map<String, List<String>> attr(String name, String... values) {
        Map<String, List<String>> result = new HashMap<>();
        result.put(name, values == null ? Collections.emptyList() : Arrays.asList(values));
        return result;
    }

    public static Criteria criteria(String criteriaName, Map<String, List<String>>... attrs) {
        Criteria criteria = new Criteria();
        criteria.setCriteriaName(criteriaName);
        criteria.setCriteriaAttributes(new HashMap<>());
        if (attrs != null) {
            Arrays.stream(attrs).forEach(attr -> criteria.getCriteriaAttributes().putAll(attr));
        }
        return criteria;
    }

    public static Map<String, Criteria> toMap(List<Criteria> list) {
        return list.stream().collect(Collectors.toMap(
                Criteria::getCriteriaName, c -> c
        ));
    }

    public static Action createAction(int id, ActionType type) {
        Action action = new Action();
        action.setId(id);
        action.setMerchActionType(type);
        action.setParams(new ArrayList<>());
        action.setLastModifiedByName("YH00111");
        return action;
    }

    public static void actionAddParam(Action action,
                                      String group,
                                      String name,
                                      String value) {
        actionAddParam(action, group, name, value, null, null);
    }

    public static void actionAddParam(Action action,
                                      String group,
                                      String name,
                                      String value,
                                      Integer sequenceNumber,
                                      Integer groupSequenceNumber) {
        ActionParameter param = new ActionParameter();
        param.setName(name);
        param.setGroup(group);
        param.setValue(value);
        param.setSequenceNumber(sequenceNumber);
        param.setGroupSequenceNumber(groupSequenceNumber);
        if (action.getParams() == null) {
            action.setParams(new ArrayList<>());
        }
        action.getParams().add(param);
    }

    public static Trigger createTrigger(int id, TriggerType type) {
        Trigger trigger = new Trigger();
        trigger.setId(id);
        trigger.setMerchTriggerType(type);
        trigger.setParams(new ArrayList<>());
        return trigger;
    }

    public static void triggerAddParam(Trigger trigger,
                                       String group,
                                       String name,
                                       String value) {
        TriggerParameter param = new TriggerParameter();
        param.setName(name);
        param.setGroup(group);
        param.setValue(value);
        trigger.getParams().add(param);
    }

    public static void addCriteriaParam(Map<String, Criteria> map,
                                        String criteriaName,
                                        String paramName,
                                        String value) {
        Criteria criteria = map.computeIfAbsent(criteriaName, k -> new Criteria());
        criteria.setCriteriaName(criteriaName);
        Map<String, List<String>> attr = criteria.getCriteriaAttributes();
        List<String> attrParams = attr.computeIfAbsent(paramName, k -> new ArrayList<>());
        attrParams.add(value);
    }

}
