package com.macys.search.util.templatetests;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.validation.action.ActionValidationStrategy;
import lombok.RequiredArgsConstructor;

import java.util.Map;

@RequiredArgsConstructor
public class ActionTemplateTestContext extends AbstractTemplateTestContext {

    private final ActionValidationStrategy strategy;
    private Action action;

    @Override
    void createNew() {
        action = new Action();
        action.setId(1);
        action.setMerchActionType(strategy.applicableFor());
    }

    @Override
    void setCriteriaMap(Map<String, Criteria> map) {
        action.setCriteriaMap(map);
        mergeCriteriaMap(action.getCriteriaMap(), additionalCriteria);
    }

    @Override
    boolean validate() {
        return strategy.validate(action).isValid();
    }

}
