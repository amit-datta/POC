package com.macys.search.util.templatetests;

import com.macys.search.bizrules.model.mrf.Criteria;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import static com.macys.search.util.TestUtils.attr;
import static com.macys.search.util.TestUtils.criteria;
import static com.macys.search.util.TestUtils.toMap;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TemplateTest {

    private static final List<Consumer<AbstractTemplateTestContext>> uniqPositiveIntegerChain = Arrays.asList(
            TemplateTest::noCriteriaTest,
            TemplateTest::noAttrTest,
            TemplateTest::emptyAttrTest,
            TemplateTest::uniqAttrTest,
            TemplateTest::positiveAttrTest,
            TemplateTest::zeroValueAttrTest,
            TemplateTest::allPositiveTest
    );

    private static final List<Consumer<AbstractTemplateTestContext>> positiveIntegerChain = Arrays.asList(
            TemplateTest::noCriteriaTest,
            TemplateTest::noAttrTest,
            TemplateTest::emptyAttrTest,
            TemplateTest::positiveAttrTest,
            TemplateTest::zeroValueAttrTest,
            TemplateTest::allPositiveTest
    );

    private static final List<Consumer<AbstractTemplateTestContext>> uniqWithPossibleValues = Arrays.asList(
            TemplateTest::noCriteriaTest,
            TemplateTest::noAttrTest,
            TemplateTest::emptyAttrTest,
            TemplateTest::uniqAttrTest,
            TemplateTest::checkAllPossibleValues
    );

    private static final List<Consumer<AbstractTemplateTestContext>> nonBlankString = Arrays.asList(
            TemplateTest::noCriteriaTest,
            TemplateTest::noAttrTest,
            TemplateTest::emptyAttrTest,
            TemplateTest::checkNonBlank
    );

    private static final List<Consumer<AbstractTemplateTestContext>> uniqNonBlankString = Arrays.asList(
            TemplateTest::noCriteriaTest,
            TemplateTest::noAttrTest,
            TemplateTest::emptyAttrTest,
            TemplateTest::uniqAttrTest,
            TemplateTest::checkNonBlank
    );

    public static void uniqPositiveIntegerTemplateCompositeTest(
            Object strategy,
            Map<String, Criteria> additionalCriteria,
            String criteriaName,
            String attrName) {
        AbstractTemplateTestContext ctx = ContextFactory.createContext(strategy);
        ctx.additionalCriteria = additionalCriteria;
        ctx.criteriaName = criteriaName;
        ctx.attrName = attrName;
        ctx.possibleValues = Arrays.asList("1", "2", "3");

        uniqPositiveIntegerChain.forEach(step -> step.accept(ctx));
    }

    public static void positiveIntegerTemplateCompositeTest(
            Object strategy,
            Map<String, Criteria> additionalCriteria,
            String criteriaName,
            String attrName) {
        AbstractTemplateTestContext ctx = ContextFactory.createContext(strategy);
        ctx.additionalCriteria = additionalCriteria;
        ctx.criteriaName = criteriaName;
        ctx.attrName = attrName;
        ctx.possibleValues = Arrays.asList("1", "2", "3");

        positiveIntegerChain.forEach(step -> step.accept(ctx));
    }

    public static void uniqPossibleValuesTemplateCompositeTest(
            Object strategy,
            Map<String, Criteria> additionalCriteria,
            String criteriaName,
            String attrName,
            List<String> possibleValues) {
        AbstractTemplateTestContext ctx = ContextFactory.createContext(strategy);
        ctx.additionalCriteria = additionalCriteria;
        ctx.criteriaName = criteriaName;
        ctx.attrName = attrName;
        ctx.possibleValues = possibleValues;

        uniqWithPossibleValues.forEach(step -> step.accept(ctx));
    }

    public static void nonBlankStringTemplateCompositeTest(
            Object strategy,
            Map<String, Criteria> additionalCriteria,
            String criteriaName,
            String attrName) {
        AbstractTemplateTestContext ctx = ContextFactory.createContext(strategy);
        ctx.additionalCriteria = additionalCriteria;
        ctx.criteriaName = criteriaName;
        ctx.attrName = attrName;
        ctx.possibleValues = Arrays.asList("aba", "caba");

        nonBlankString.forEach(step -> step.accept(ctx));
    }

    public static void uniqNonBlankStringTemplateCompositeTest(
            Object strategy,
            Map<String, Criteria> additionalCriteria,
            String criteriaName,
            String attrName) {
        AbstractTemplateTestContext ctx = ContextFactory.createContext(strategy);
        ctx.additionalCriteria = additionalCriteria;
        ctx.criteriaName = criteriaName;
        ctx.attrName = attrName;
        ctx.possibleValues = Arrays.asList("aba", "caba");

        uniqNonBlankString.forEach(step -> step.accept(ctx));
    }


    private static void noCriteriaTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria("DOES NOR MATTER")
        )));
        assertFalse(ctx.validate());
    }

    private static void noAttrTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName)
        )));
        assertFalse(ctx.validate());
    }

    private static void emptyAttrTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName, attr(ctx.attrName))
        )));
        assertFalse(ctx.validate());
    }

    private static void uniqAttrTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName,
                        attr(ctx.attrName, ctx.possibleValues.toArray(new String[0]))
                )
        )));
        assertFalse(ctx.validate());
    }

    private static void positiveAttrTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName, attr(ctx.attrName, "-2"))
        )));
        assertFalse(ctx.validate());
    }

    private static void zeroValueAttrTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName, attr(ctx.attrName, "0"))
        )));
        assertFalse(ctx.validate());
    }

    private static void allPositiveTest(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName, attr(ctx.attrName, "100"))
        )));
        assertTrue(ctx.validate());
    }

    private static void checkAllPossibleValues(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        for (String value : ctx.possibleValues) {
            ctx.setCriteriaMap(toMap(Arrays.asList(
                    criteria(ctx.criteriaName, attr(ctx.attrName, value))
            )));
            assertTrue(ctx.validate(), "Check all possible values:" + ctx.possibleValues);
        }

        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName, attr(ctx.attrName, "NOT IN LIST VALUE"))
        )));
        assertFalse(ctx.validate());
    }

    private static void checkNonBlank(AbstractTemplateTestContext ctx) {
        ctx.createNew();
        ctx.setCriteriaMap(toMap(Arrays.asList(
                criteria(ctx.criteriaName, attr(ctx.attrName, "aba caba"))
        )));
        assertTrue(ctx.validate());

        List<String> sampleOfBlankString = Arrays.asList("", " ", "  ");
        for (String blank : sampleOfBlankString) {
            ctx.setCriteriaMap(toMap(Arrays.asList(
                    criteria(ctx.criteriaName, attr(ctx.attrName, blank))
            )));
            assertFalse(ctx.validate());
        }
    }

}
