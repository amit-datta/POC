package com.macys.search.bizrules.tasklets.triggers;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.services.merch.TriggersService;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TriggersExtractorTaskletTest extends AbstractTaskletTest {

    @Autowired
    private TriggersService triggersService;

    @Test
    void happyPassExtractValues() {
        Trigger trigger = TestUtils.createTrigger(1, TriggerType.KeywordPattern);
        TestUtils.triggerAddParam(trigger, "group1", "name1", "value1");
        TestUtils.triggerAddParam(trigger, "group2", "name1", "value4");
        TestUtils.triggerAddParam(trigger, "group1", "name3", "value3");

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        ctx.setTriggers(Map.of(1, ProcessingTrigger.from(trigger)));

        triggersService.getProcessedTrigger(1, ctx);

        Criteria criteria1 = new Criteria();
        criteria1.setCriteriaName("group1");
        criteria1.setCriteriaAttributes(Map.of("name1", List.of("value1"), "name3", List.of("value3")));

        Criteria criteria2 = new Criteria();
        criteria2.setCriteriaName("group2");
        criteria2.setCriteriaAttributes(Map.of("name1", List.of("value4")));

        assertEquals(Map.of("group1", criteria1, "group2", criteria2), trigger.getCriteriaMap());
    }

}