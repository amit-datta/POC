package com.macys.search.bizrules.services;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.dto.RuleDto;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionParameter;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.repository.mrf.*;
import com.macys.search.bizrules.services.merch.PreviewService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.util.ReflectionTestUtils;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.util.List;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.Always;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@DirtiesContext
class PreviewServiceTest extends BaseTest {

    @Autowired
    private PreviewService previewService;
    @Value("${rules.publisher.enabled.trigger-types}")
    private List<TriggerType> enabledTriggerTypes;
    @Value("${rules.publisher.enabled.action-types}")
    private List<ActionType> enabledActionTypes;

    private final RulesReader rulesReader = Mockito.mock(RulesReader.class);
    private final TriggerExpressionReader triggerExpressionReader = Mockito.mock(TriggerExpressionReader.class);
    private final ActionsReader actionsReader = Mockito.mock(ActionsReader.class);
    private final TriggersReader triggersReader = Mockito.mock(TriggersReader.class);
    private final CustomDateReader customDateReader = Mockito.mock(CustomDateReader.class);

    @PostConstruct
    void init() {
        ReflectionTestUtils.setField(previewService, "rulesReader", rulesReader);
        ReflectionTestUtils.setField(previewService, "actionsReader", actionsReader);
        ReflectionTestUtils.setField(previewService, "triggersReader", triggersReader);
        ReflectionTestUtils.setField(previewService, "triggerExpressionReader", triggerExpressionReader);
        ReflectionTestUtils.setField(previewService, "customDateReader", customDateReader);
    }

    @Test
    void invalidRuleTest() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.setActionsIds(List.of(2, 3));
        rule1.setExpirationDate(LocalDate.of(2021, 3, 5));

        Mockito.when(rulesReader.getRuleById(SiteName.MCOM,1)).thenReturn(rule1);
        Mockito.doNothing().when(triggerExpressionReader).readTriggerExpressionForRule(SiteName.MCOM,rule1);
        Mockito.when(actionsReader.getActionsById(any(), any(), any())).thenReturn(null);
        Mockito.when(triggersReader.getTriggerById(any(), any(), any())).thenReturn(null);

        RuleDto result = previewService.getRuleById(SiteName.MCOM, 1, 200);

        Assertions.assertFalse(result.getValidationResult().isValid());
    }

    @Test
    void getRuleByIdTest() {
        Rule rule1 = new Rule();
        rule1.setId(1);
        rule1.setMerchRuleType(RuleType.MERCH);
        rule1.setActionsIds(List.of(2, 3));
        rule1.setEffectiveDate(LocalDate.of(2021, 3, 5));
        rule1.setExpirationDate(LocalDate.of(3022, 3, 5));
        rule1.setLastModifiedByName("YH00471");
        rule1.setActionsIds(List.of(3));
        rule1.setTriggerIds(List.of(4, 6));
        rule1.setTriggerOperation(BooleanOperation.OR);

        Action action = new Action();
        action.setId(3);
        action.setMerchActionType(ActionType.CategoryRedirect);
        ActionParameter actionParameter = new ActionParameter();
        actionParameter.setGroup("Category");
        actionParameter.setName("CategoryId");
        actionParameter.setValue("123");
        action.setParams(List.of(actionParameter));
        action.setLastModifiedByName("YH00555");

        Trigger trigger4 = new Trigger();
        trigger4.setId(4);
        trigger4.setMerchTriggerType(Always);
        trigger4.setValid(true);
        trigger4.setParams(List.of());

        Mockito.when(rulesReader.getRuleById(SiteName.MCOM, 1)).thenReturn(rule1);
        Mockito.when(actionsReader.getActionsById(SiteName.MCOM, 3, enabledActionTypes)).thenReturn(action);
        Mockito.when(triggersReader.getTriggerById(SiteName.MCOM,4, enabledTriggerTypes)).thenReturn(trigger4);
        Mockito.when(triggersReader.getTriggerById(SiteName.MCOM,6, enabledTriggerTypes)).thenReturn(null);
        Mockito.when(customDateReader.getCustomDate(SiteName.MCOM)).thenReturn(LocalDate.now());

        RuleDto actual = previewService.getRuleById(SiteName.MCOM, 1, 200);

        assertTrue(actual.getValidationResult().isValid());
        assertEquals(actual.getTriggers().size(), 1);
        assertEquals(actual.getActions().size(), 1);

        assertEquals(1, actual.getActions().size());
        assertEquals(1, actual.getTriggers().size());
    }

}
