package com.macys.search.bizrules.converters.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.model.processing.trigger.params.AlwaysTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.InmemoryAppender;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.annotation.PostConstruct;
import java.util.List;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.*;
import static com.macys.search.util.TestUtils.addAppender;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class TriggerConverterServiceTest extends BaseTest {

    private static InmemoryAppender inmemoryAppender;

    @AfterAll
    public static void tearDown() {
        inmemoryAppender.stop();
    }

    @PostConstruct
    public void init() {
        inmemoryAppender = new InmemoryAppender();
        addAppender(new TriggerConverterService(List.of(), List.of()), inmemoryAppender);
        inmemoryAppender.start();
    }

    @BeforeEach
    public void reset() {
        inmemoryAppender.reset();
    }

    @Test
    void notImplementedConverterException() {
        TriggerConverter always = mock(TriggerConverter.class);
        when(always.applicableFor()).thenReturn(Always);
        TriggerConverter keyword = mock(TriggerConverter.class);
        when(keyword.applicableFor()).thenReturn(KeywordPattern);

        Exception exception = assertThrows(RuntimeException.class, () ->
                new TriggerConverterService(
                        List.of(always, keyword),
                        List.of(Always, KeywordPattern, HierarchicalRefinement)
                ));

        String expectedMessage = "Some of trigger converter have not implemented yet. Enabled trigger types=[Always, KeywordPattern, HierarchicalRefinement] Implemented converter types=[Always, KeywordPattern]";
        String actualMessage = exception.getMessage();

        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    void chooseRightTriggerConverter() {
        TriggerConverter always = mock(TriggerConverter.class);
        when(always.applicableFor()).thenReturn(Always);
        Mockito.when(always.convert(any(), any())).thenReturn(new AlwaysTriggerParams(1));

        TriggerConverter keyword = mock(TriggerConverter.class);
        when(keyword.applicableFor()).thenReturn(KeywordPattern);
        Mockito.when(keyword.convert(any(), any())).thenReturn(new AlwaysTriggerParams(2));

        TriggerConverter resultSet = mock(TriggerConverter.class);
        when(resultSet.applicableFor()).thenReturn(ResultSet);
        Mockito.when(resultSet.convert(any(), any())).thenReturn(new AlwaysTriggerParams(3));

        TriggerConverterService triggerConverterService = new TriggerConverterService(
                List.of(always, keyword, resultSet),
                List.of(Always, KeywordPattern, ResultSet)
        );

        Trigger trigger = new Trigger();
        trigger.setMerchTriggerType(KeywordPattern);
        triggerConverterService.convertTrigger(ProcessingTrigger.from(trigger), new ProcessingContext());
        verify(always, times(0)).convert(any(), any());
        verify(keyword, times(1)).convert(any(), any());
        verify(resultSet, times(0)).convert(any(), any());
    }

    @Test
    void triggerConverterWasNotFoundTest() {
        TriggerConverter always = mock(TriggerConverter.class);
        when(always.applicableFor()).thenReturn(Always);
        Mockito.when(always.convert(any(), any())).thenReturn(new AlwaysTriggerParams(1));

        TriggerConverterService triggerConverterService = new TriggerConverterService(
                List.of(always),
                List.of(Always)
        );

        Trigger trigger = new Trigger();
        trigger.setMerchTriggerType(KeywordPattern);
        AbstractTriggerParams actualTriggerParams = triggerConverterService.convertTrigger(ProcessingTrigger.from(trigger),
                new ProcessingContext());
        Assertions.assertNull(actualTriggerParams);
    }

}