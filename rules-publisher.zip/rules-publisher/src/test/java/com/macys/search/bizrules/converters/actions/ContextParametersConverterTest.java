package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.context.*;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ContextParametersConverterTest {

    private final ContextParametersConverter converter = new ContextParametersConverter();

    @Test
    void testCorrectConvert() {
        Action action = new Action();
        ESAction esAction = new ESAction();

        action.setContextAttributes(Map.of(
                "REGION_CODE", List.of("RU"),
                "APPLICATION", List.of(ApplicationType.ASSOCIATE.name(), ApplicationType.MOBILE.name()),
                "CUSTOMER_EXPERIMENT", List.of(CustomerExperiment.A.name(), CustomerExperiment.B.name()),
                "DEVICE_TYPE", List.of(DeviceType.PHONE.name(), DeviceType.DESKTOP.name()),
                "NAVIGATION_TYPE", List.of(NavigationType.BROWSE.name(), NavigationType.LANDING.name()),
                "SHOPPING_MODE", List.of(ShoppingMode.SITE.name(), ShoppingMode.STORE.name())
        ));
        converter.convert(action, esAction);

        assertEquals("RU", esAction.getSource().get("region_code_ctx_attr"));
        assertEquals(List.of(ApplicationType.ASSOCIATE, ApplicationType.MOBILE), esAction.getSource().get("application_type_ctx_attr"));
        assertEquals(List.of(CustomerExperiment.A, CustomerExperiment.B), esAction.getSource().get("customer_experiment_ctx_attr"));
        assertEquals(List.of(DeviceType.PHONE, DeviceType.DESKTOP), esAction.getSource().get("device_type_ctx_attr"));
        assertEquals(List.of(NavigationType.BROWSE, NavigationType.LANDING), esAction.getSource().get("navigation_type_ctx_attr"));
        assertEquals(List.of(ShoppingMode.SITE, ShoppingMode.STORE), esAction.getSource().get("shopping_mode_ctx_attr"));
    }

}