package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.util.templatetests.TemplateTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;

import static com.macys.search.util.TestUtils.attr;
import static com.macys.search.util.TestUtils.criteria;
import static com.macys.search.util.TestUtils.toMap;
import static java.util.List.of;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class URLRedirectActionValidationStrategyTest extends BaseTest {

    @Autowired
    URLRedirectActionValidationStrategy strategy;

    @Test
    void templateLoaded() {
        assertNotNull(strategy.getTemplate());
    }

    @Test
    void applicableFor() {
        assertEquals(ActionType.URLRedirect, strategy.applicableFor());
    }

    @Test
    void templateTest() {
        TemplateTest.uniqPossibleValuesTemplateCompositeTest(strategy,
                toMap(of(criteria("URL", attr("URLValue", "value")))),
                "URL",
                "URLType",
                Arrays.asList("Relative", "Absolute")
        );
        TemplateTest.uniqNonBlankStringTemplateCompositeTest(strategy,
                toMap(of(criteria("URL", attr("URLType", "Absolute")))),
                "URL",
                "URLValue"
        );
    }

}