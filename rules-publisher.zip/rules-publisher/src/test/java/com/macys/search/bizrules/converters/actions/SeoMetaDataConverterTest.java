package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.services.merch.ActionsService;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static com.macys.search.bizrules.model.mrf.action.ESActionType.SEO_META_DATA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SeoMetaDataConverterTest {

    private final SeoMetaDataConverter converter = new SeoMetaDataConverter();

    @Test
    void applicableForTest() {
        assertEquals(ActionType.SeoMetaData, converter.applicableFor());
    }

    @Test
    void conversionTest() {
        Action action = TestUtils.createAction(1, ActionType.SeoMetaData);
        TestUtils.actionAddParam(action, "Context", "APPLICATION", "MSA");
        TestUtils.actionAddParam(action, "Context", "APPLICATION", "SEO_LINK_MODULE");
        TestUtils.actionAddParam(action, "Context", "APPLICATION", "SITE");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "DESKTOP");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "PHONE");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "TABLET");
        TestUtils.actionAddParam(action, "noIndex", "AttributeValue", "Y");

        ValidationResult validationResult = ActionsService.parseAttributes(action);
        assertTrue(validationResult.isValid());

        ESAction actual = converter.convert(action, null);

        assertEquals(Map.of(
                "seo_metadata", "{\"noIndex\":\"Y\"}",
                "action_id", 1,
                "action_type", SEO_META_DATA,
                "action_type_priority", 0
        ), actual.getSource());
    }

    @Test
    void severalParamsConversionTest() {
        Action action = TestUtils.createAction(1, ActionType.SeoMetaData);
        TestUtils.actionAddParam(action, "Context", "APPLICATION", "MSA");
        TestUtils.actionAddParam(action, "Context", "APPLICATION", "SEO_LINK_MODULE");
        TestUtils.actionAddParam(action, "Context", "APPLICATION", "SITE");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "DESKTOP");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "PHONE");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "TABLET");
        TestUtils.actionAddParam(action, "canonical", "AttributeValue", "https://www.macys.com/shop/furniture/bedroom-furniture-sets/Furniture_category/Bedroom%20Collections?id=35420");
        TestUtils.actionAddParam(action, "description", "AttributeValue", "Buy Accent Table Sets at Macys.com! Browse our great prices & discounts on the best Accent Table Sets. FREE SHIPPING AVAILABLE!");
        TestUtils.actionAddParam(action, "title", "AttributeValue", "Accent Table Sets You'll Want to Buy - Macy's");
        TestUtils.actionAddParam(action, "noIndex", "AttributeValue", "Y");

        ValidationResult validationResult = ActionsService.parseAttributes(action);
        assertTrue(validationResult.isValid());

        ESAction actual = converter.convert(action, null);

        assertEquals(Map.of(
                "seo_metadata", "{\"description\":\"Buy Accent Table Sets at Macys.com! " +
                        "Browse our great prices & discounts on the best Accent Table Sets. " +
                        "FREE SHIPPING AVAILABLE!\",\"canonical\":\"https://www.macys.com/shop/furn" +
                        "iture/bedroom-furniture-sets/Furniture_category/Bedroom%20Collections?id=35420\"," +
                        "\"title\":\"Accent Table Sets You'll Want to Buy - Macy's\",\"noIndex\":\"Y\"}",
                "action_id", 1,
                "action_type", SEO_META_DATA,
                "action_type_priority", 0
        ), actual.getSource());
    }

    @Test
    void emptyParamsTest() {
        Action action = TestUtils.createAction(1, ActionType.SeoMetaData);
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "DESKTOP");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "PHONE");
        TestUtils.actionAddParam(action, "Context", "DEVICE_TYPE", "TABLET");

        ValidationResult validationResult = ActionsService.parseAttributes(action);
        assertTrue(validationResult.isValid());

        ESAction actual = converter.convert(action, null);

        assertEquals(Map.of(
                "seo_metadata", "{}",
                "action_id", 1,
                "action_type", SEO_META_DATA,
                "action_type_priority", 0
        ), actual.getSource());
    }

}