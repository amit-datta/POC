package com.macys.search.bizrules.tasklets.converters;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.ESIndex.BIZ_CONTROLS_DB;
import static org.mockito.ArgumentMatchers.any;

class CreateActionsIndexTaskletTest extends AbstractTaskletTest {

    @Mock
    private ElasticSearchFacade facade;
    @Mock
    private ElasticSearchIndexerFactory factory;

    private void creationTest(final SiteName siteName, final String expectedIndexName) {
        changeSiteName(siteName);

        Mockito.when(facade.createIndex(any(), any())).thenAnswer((Answer<String>) invocation -> {
            IndexCreationProperties props = (IndexCreationProperties) invocation.getArguments()[0];
            return props.getIndexNamePrefix() + "TIMESTAMP";
        });

        IndexCreationProperties mcomProps = new IndexCreationProperties("MCOM_TEST_PREFIX_", 1, 1, ActionsIndexFields.class, null);
        IndexCreationProperties bcomProps = new IndexCreationProperties("BCOM_TEST_PREFIX_", 1, 1, ActionsIndexFields.class, null);
        CommonIndexProperties common = new CommonIndexProperties(2, "unfinished");

        CreateIndexTasklet underTest = new CreateIndexTasklet(facade, mcomProps, bcomProps, common, common, factory,
                ESIndex.ACTIONS);

        underTest.execute(ctx);
        String createdIndexName = ctx.getIndexName(ESIndex.ACTIONS);
        Assertions.assertEquals(expectedIndexName, createdIndexName);

        Map<ESIndex, String> indices = ctx.getIndexNames();
        Assertions.assertEquals(1, indices.size());
        String bizControlsDbIndexName = ctx.getIndexName(BIZ_CONTROLS_DB);
        Assertions.assertNull(bizControlsDbIndexName);
    }

    @Test
    void mcomIndexCreation() {
        creationTest(SiteName.MCOM, "MCOM_TEST_PREFIX_TIMESTAMP");
    }

    @Test
    void bcomIndexCreation() {
        creationTest(SiteName.BCOM, "BCOM_TEST_PREFIX_TIMESTAMP");
    }
}