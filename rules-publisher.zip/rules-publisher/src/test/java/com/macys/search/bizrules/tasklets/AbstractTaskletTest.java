package com.macys.search.bizrules.tasklets;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

public abstract class AbstractTaskletTest extends BaseTest {

    protected JobExecution jobExecution;
    protected StepContribution contribution;
    protected ExecutionContext executionContext;
    protected ChunkContext chunkContext;
    protected ProcessingContext ctx;

    public AbstractTaskletTest() {
        executionContext = new ExecutionContext();
        jobExecution = new JobExecution(1L, new JobParameters(Map.of(
                "site-name", new JobParameter("BCOM"),
                "indexing-session-id", new JobParameter("unit-test-session-id")
        )));
        jobExecution.setExecutionContext(executionContext);
        contribution = new StepContribution(new StepExecution("stepName", jobExecution));
        chunkContext = new ChunkContext(new StepContext(contribution.getStepExecution()));
        ctx = ProcessingContext.initContext(contribution, chunkContext);
    }

    protected void changeSiteName(SiteName siteName) {
        ProcessingContext context = ProcessingContext.getContext(contribution);
        ReflectionTestUtils.setField(context, "siteName", siteName);
    }

    protected void execute(Tasklet tasklet) throws Exception {
        tasklet.execute(contribution, chunkContext);
    }

}
