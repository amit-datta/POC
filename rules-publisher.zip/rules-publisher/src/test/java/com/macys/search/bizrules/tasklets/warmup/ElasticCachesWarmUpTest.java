package com.macys.search.bizrules.tasklets.warmup;

import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.TriggerValidationService;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.TestUtils;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;
import java.util.Map;

import static org.mockito.Mockito.*;

class ElasticCachesWarmUpTest extends AbstractTaskletTest {
    @Mock
    private TriggerValidationService triggerValidationService;

    @Test
    void testCachesDisabled() {
        WarmUpQueryBuilder builder = Mockito.mock(WarmUpQueryBuilder.class);
        WarmUpSearchClient client = Mockito.mock(WarmUpSearchClient.class);
        ElasticCachesWarmUp tasklet = createElasticCachesWarmUp(client, 5, false, triggerValidationService);
        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        Trigger trigger = TestUtils.createTrigger(1, TriggerType.KeywordPattern);
        TestUtils.triggerAddParam(trigger, "group1", "name1", "value1");
        TestUtils.triggerAddParam(trigger, "group2", "name1", "value4");
        TestUtils.triggerAddParam(trigger, "group1", "name3", "value3");
        ctx.setTriggers(Map.of(1, ProcessingTrigger.from(trigger)));
        tasklet.execute(ctx);
        verifyNoInteractions(client);
        verifyNoInteractions(builder);
    }

    @Test
    void testCollectingUniqueData() {
        WarmUpSearchClient client = Mockito.mock(WarmUpSearchClient.class);
        when(client.search(Mockito.any(WarmUpRequest.class), Mockito.anyString())).thenReturn(null);
        ElasticCachesWarmUp tasklet = createElasticCachesWarmUp(client, 10, true, triggerValidationService);
        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, "mcom_kwp_triggers", null);
        ProcessingContext.getContext(contribution).setCustomDate(LocalDate.now());
        Trigger trigger = TestUtils.createTrigger(1, TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "MatchConfig", "MatchOperator", "OR");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "blue jeans");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "field name", "KeywordValue", "red dress");

        Trigger trigger2 = TestUtils.createTrigger(2, TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger2.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger2.getCriteriaMap(), "MatchConfig", "MatchOperator", "OR");
        TestUtils.addCriteriaParam(trigger2.getCriteriaMap(), "field name", "KeywordValue", "blue jeans");
        TestUtils.addCriteriaParam(trigger2.getCriteriaMap(), "field name", "KeywordValue", "green dress");

        Trigger trigger3 = TestUtils.createTrigger(3, TriggerType.KeywordPattern);
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "MatchConfig", "MatchType", "Exact");
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "MatchConfig", "MatchOperator", "OR");
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "field name", "KeywordValue", "blue jeans");
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "field name", "KeywordValue", "green dress");
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "field name", "KeywordValue", "summer dress");

        ctx.setTriggers(Map.of(1, ProcessingTrigger.from(trigger), 2, ProcessingTrigger.from(trigger2),
                3, ProcessingTrigger.from(trigger3)));
        when(triggerValidationService.validate(any(), any())).thenReturn(ValidationResult.validResult());
        tasklet.execute(ctx);
        verify(client, Mockito.times(4)).search(Mockito.any(WarmUpRequest.class), Mockito.anyString());
    }

    @Test
    void testCategoriesRequests() {
        WarmUpSearchClient client = Mockito.mock(WarmUpSearchClient.class);
        when(client.search(Mockito.any(WarmUpRequest.class), Mockito.anyString())).thenReturn(null);
        ElasticCachesWarmUp tasklet = createElasticCachesWarmUp(client, 10, true, triggerValidationService);
        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);

        ctx.setupIndex(ESIndex.KWP_TRIGGERS, "search", null);
        ctx.setupIndex(ESIndex.TRIGGERS, "browse", null);
        ctx.setCustomDate(LocalDate.now());
        Trigger trigger = TestUtils.createTrigger(1, TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "CAT_ID", "FiringStrategy", "Exact");
        TestUtils.addCriteriaParam(trigger.getCriteriaMap(), "CAT_ID", "AttributeValue", "1");

        Trigger trigger2 = TestUtils.createTrigger(2, TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger2.getCriteriaMap(), "CAT_ID", "FiringStrategy", "Exact");
        TestUtils.addCriteriaParam(trigger2.getCriteriaMap(), "CAT_ID", "AttributeValue", "2");

        Trigger trigger3 = TestUtils.createTrigger(3, TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "CAT_ID", "FiringStrategy", "Exact");
        TestUtils.addCriteriaParam(trigger3.getCriteriaMap(), "CAT_ID", "AttributeValue", "3");

        Trigger trigger4 = TestUtils.createTrigger(3, TriggerType.HierarchicalRefinement);
        TestUtils.addCriteriaParam(trigger4.getCriteriaMap(), "CAT_ID", "FiringStrategy", "Exact");
        TestUtils.addCriteriaParam(trigger4.getCriteriaMap(), "CAT_ID", "AttributeValue", "3");

        ctx.setTriggers(Map.of(1, ProcessingTrigger.from(trigger), 2, ProcessingTrigger.from(trigger2),
                3, ProcessingTrigger.from(trigger3), 4, ProcessingTrigger.from(trigger4)));
        when(triggerValidationService.validate(any(), any())).thenReturn(ValidationResult.validResult());
        tasklet.execute(ctx);
        verify(client, Mockito.times(3)).search(Mockito.any(WarmUpRequest.class), Mockito.anyString());
    }

    private ElasticCachesWarmUp createElasticCachesWarmUp(WarmUpSearchClient client, int warmupRequestsCount, boolean cachesWarmupEnabled, TriggerValidationService validationService) {
        ElasticCachesWarmUp tasklet = new ElasticCachesWarmUp(client, validationService);
        ReflectionTestUtils.setField(tasklet, "warmupRequestsCount", warmupRequestsCount);
        ReflectionTestUtils.setField(tasklet, "cachesWarmupEnabled", cachesWarmupEnabled);
        return tasklet;
    }
}
