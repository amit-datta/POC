package com.macys.search;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.mappings.*;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.client.RestHighLevelClient;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

@Slf4j
@SpringBootTest
@ActiveProfiles("it")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@OnlyIntegrationMode
public class BaseIntegrationESTest {
    @Autowired
    protected CommonIndexProperties mcomCommonIndexProperties;
    @Autowired
    protected CommonIndexProperties bcomCommonIndexProperties;

    @Value("${rules.publisher.mcom.kwp.triggers.alias.name}")
    protected String kwpIndexNamePrefixMCOM;
    @Value("${rules.publisher.bcom.kwp.triggers.alias.name}")
    protected String kwpIndexNamePrefixBCOM;

    @Value("${rules.publisher.mcom.triggers.alias.name}")
    protected String triggersIndexNamePrefixMCOM;
    @Value("${rules.publisher.bcom.triggers.alias.name}")
    protected String triggersIndexNamePrefixBCOM;

    @Value("${rules.publisher.mcom.categories.alias.name}")
    protected String categoriesIndexNamePrefixMCOM;
    @Value("${rules.publisher.bcom.categories.alias.name}")
    protected String categoriesIndexNamePrefixBCOM;

    @Value("${rules.publisher.mcom.products.alias.name}")
    protected String productsIndexNamePrefixMCOM;
    @Value("${rules.publisher.bcom.products.alias.name}")
    protected String productsIndexNamePrefixBCOM;

    @Value("${rules.publisher.bcom.rules.alias.name}")
    protected String rulesIndexNamePrefixBCOM;
    @Value("${rules.publisher.mcom.rules.alias.name}")
    protected String rulesIndexNamePrefixMCOM;

    @Value("${rules.publisher.mcom.actions.alias.name}")
    protected String actionsIndexNamePrefixMCOM;
    @Value("${rules.publisher.bcom.actions.alias.name}")
    protected String actionsIndexNamePrefixBCOM;

    @Value("${rules.publisher.mcom.biz_controls_db.alias.index.name}")
    protected String dbAliasIndexNameMCOM;
    @Value("${rules.publisher.bcom.biz_controls_db.alias.index.name}")
    protected String dbAliasIndexNameBCOM;

    protected String indexNameSearchMCOM;
    protected String indexNameSearchBCOM;

    protected String indexNameBrowseMCOM;
    protected String indexNameBrowseBCOM;
    protected String indexNameCategoriesMCOM;
    protected String indexNameCategoriesBCOM;

    protected String indexNameProductsMCOM;
    protected String indexNameProductsBCOM;

    protected String indexNameActionsMCOM;
    protected String indexNameActionsBCOM;

    protected String indexNameRulesMCOM;
    protected String indexNameRulesBCOM;

    @Autowired
    protected RestHighLevelClient client;
    protected IndexCreationProperties mcomSearchIndexCreationProperties;
    protected IndexCreationProperties bcomSearchIndexCreationProperties;

    protected IndexCreationProperties mcomBrowseIndexCreationProperties;
    protected IndexCreationProperties bcomBrowseIndexCreationProperties;

    protected IndexCreationProperties mcomCategoriesIndexCreationProperties;
    protected IndexCreationProperties bcomCategoriesIndexCreationProperties;

    protected IndexCreationProperties mcomProductsIndexCreationProperties;
    protected IndexCreationProperties bcomProductsIndexCreationProperties;

    protected IndexCreationProperties dbIndexCreationPropertiesMCOM;
    protected IndexCreationProperties dbIndexCreationPropertiesBCOM;

    protected IndexCreationProperties mcomRulesIndexCreationProperties;
    protected IndexCreationProperties bcomRulesIndexCreationProperties;

    protected IndexCreationProperties mcomActionsIndexCreationProperties;
    protected IndexCreationProperties bcomActionsIndexCreationProperties;

    @Autowired
    protected ElasticSearchFacade facade;

    protected JobExecution jobExecution;
    protected StepContribution contribution;
    protected ExecutionContext executionContext;
    protected ChunkContext chunkContext;

    {
        setJobExecutionParams(
                Map.of(
                        "site-name", new JobParameter("BCOM"),
                        "indexing-session-id", new JobParameter("sss")
                )
        );
    }

    protected void setJobExecutionParams(Map<String, JobParameter> params) {
        executionContext = new ExecutionContext();
        jobExecution = new JobExecution(1L, new JobParameters(params));
        jobExecution.setExecutionContext(executionContext);
        contribution = new StepContribution(new StepExecution("stepName", jobExecution));
        chunkContext = new ChunkContext(new StepContext(contribution.getStepExecution()));
    }

    protected void setSiteNameForTheJob(SiteName siteName) {
        setJobExecutionParams(Map.of(
                        "site-name", new JobParameter(siteName.name()),
                        "indexing-session-id", new JobParameter("sss")
                )
        );
    }

    @BeforeAll
    public void createESIndex() {
        IndexCreationProperties indexCreationPropertiesMCOM = createIndexCreationPropertiesSearchActions(SiteName.MCOM);
        IndexCreationProperties indexCreationPropertiesBCOM = createIndexCreationPropertiesSearchActions(SiteName.BCOM);
        IndexCreationProperties browseIndexCreationPropertiesMCOM = createIndexCreationPropertiesBrowseAction(SiteName.MCOM);
        IndexCreationProperties browseIndexCreationPropertiesBCOM = createIndexCreationPropertiesBrowseAction(SiteName.BCOM);
        IndexCreationProperties categoriesIndexCreationPropertiesMCOM = createIndexCreationPropertiesCategories(SiteName.MCOM);
        IndexCreationProperties categoriesIndexCreationPropertiesBCOM = createIndexCreationPropertiesCategories(SiteName.BCOM);
        IndexCreationProperties productsIndexCreationPropertiesMCOM = createIndexCreationPropertiesProducts(SiteName.MCOM);
        IndexCreationProperties productsIndexCreationPropertiesBCOM = createIndexCreationPropertiesProducts(SiteName.BCOM);

        IndexCreationProperties rulesIndexCreationPropertiesMCOM = createIndexCreationPropertiesRules(SiteName.MCOM);
        IndexCreationProperties rulesIndexCreationPropertiesBCOM = createIndexCreationPropertiesRules(SiteName.BCOM);
        IndexCreationProperties actionsIndexCreationPropertiesMCOM = createIndexCreationPropertiesActions(SiteName.MCOM);
        IndexCreationProperties actionsIndexCreationPropertiesBCOM = createIndexCreationPropertiesActions(SiteName.BCOM);

        indexNameSearchMCOM = facade.createIndex(indexCreationPropertiesMCOM, mcomCommonIndexProperties);
        indexNameSearchBCOM = facade.createIndex(indexCreationPropertiesBCOM, bcomCommonIndexProperties);
        indexNameBrowseMCOM = facade.createIndex(browseIndexCreationPropertiesMCOM, mcomCommonIndexProperties);
        indexNameBrowseBCOM = facade.createIndex(browseIndexCreationPropertiesBCOM, bcomCommonIndexProperties);
        indexNameCategoriesMCOM = facade.createIndex(categoriesIndexCreationPropertiesMCOM, mcomCommonIndexProperties);
        indexNameCategoriesBCOM = facade.createIndex(categoriesIndexCreationPropertiesBCOM, bcomCommonIndexProperties);
        indexNameProductsMCOM = facade.createIndex(productsIndexCreationPropertiesMCOM, mcomCommonIndexProperties);
        indexNameProductsBCOM = facade.createIndex(productsIndexCreationPropertiesBCOM, bcomCommonIndexProperties);
        indexNameRulesMCOM = facade.createIndex(rulesIndexCreationPropertiesMCOM, mcomCommonIndexProperties);
        indexNameRulesBCOM = facade.createIndex(rulesIndexCreationPropertiesBCOM, bcomCommonIndexProperties);
        indexNameActionsMCOM = facade.createIndex(actionsIndexCreationPropertiesMCOM, mcomCommonIndexProperties);
        indexNameActionsBCOM = facade.createIndex(actionsIndexCreationPropertiesBCOM, bcomCommonIndexProperties);

    }

    private IndexCreationProperties createIndexCreationPropertiesActions(SiteName siteName) {
        mcomActionsIndexCreationProperties = new IndexCreationProperties(actionsIndexNamePrefixMCOM, 1, 0, ActionsIndexFields.class, null);
        bcomActionsIndexCreationProperties = new IndexCreationProperties(actionsIndexNamePrefixBCOM, 1, 0, ActionsIndexFields.class, null);
        return siteName == SiteName.MCOM ? mcomActionsIndexCreationProperties : bcomActionsIndexCreationProperties;

    }

    private IndexCreationProperties createIndexCreationPropertiesRules(SiteName siteName) {
        mcomRulesIndexCreationProperties = new IndexCreationProperties(rulesIndexNamePrefixMCOM, 1, 0, RulesIndexFields.class, null);
        bcomRulesIndexCreationProperties = new IndexCreationProperties(rulesIndexNamePrefixBCOM, 1, 0, RulesIndexFields.class, null);
        return siteName == SiteName.MCOM ? mcomRulesIndexCreationProperties : bcomRulesIndexCreationProperties;
    }

    private IndexCreationProperties createIndexCreationPropertiesProducts(SiteName siteName) {
        mcomProductsIndexCreationProperties = new IndexCreationProperties(productsIndexNamePrefixMCOM, 1, 0, ProductIndexFields.class, null);
        bcomProductsIndexCreationProperties = new IndexCreationProperties(productsIndexNamePrefixBCOM, 1, 0, ProductIndexFields.class, null);
        return siteName == SiteName.MCOM ? mcomProductsIndexCreationProperties : bcomProductsIndexCreationProperties;
    }


    protected IndexCreationProperties createIndexCreationPropertiesSearchActions(SiteName siteName) {
        mcomSearchIndexCreationProperties = new IndexCreationProperties(kwpIndexNamePrefixMCOM, 1, 0, TriggerIndexFields.class, null);
        bcomSearchIndexCreationProperties = new IndexCreationProperties(kwpIndexNamePrefixBCOM, 1, 0, TriggerIndexFields.class, null);
        dbIndexCreationPropertiesMCOM = new IndexCreationProperties(dbAliasIndexNameBCOM, 1, 0, BizControlIndexFields.class, null);
        dbIndexCreationPropertiesBCOM = new IndexCreationProperties(dbAliasIndexNameBCOM, 1, 0, BizControlIndexFields.class, null);
        return siteName == SiteName.MCOM ? mcomSearchIndexCreationProperties : bcomSearchIndexCreationProperties;
    }

    protected IndexCreationProperties createIndexCreationPropertiesBrowseAction(SiteName siteName) {
        mcomBrowseIndexCreationProperties = new IndexCreationProperties(triggersIndexNamePrefixMCOM, 1, 0, TriggerIndexFields.class, null);
        bcomBrowseIndexCreationProperties = new IndexCreationProperties(triggersIndexNamePrefixBCOM, 1, 0, TriggerIndexFields.class, null);
        return siteName == SiteName.MCOM ? mcomBrowseIndexCreationProperties : bcomBrowseIndexCreationProperties;
    }

    protected IndexCreationProperties createIndexCreationPropertiesCategories(SiteName siteName) {
        mcomCategoriesIndexCreationProperties = new IndexCreationProperties(categoriesIndexNamePrefixMCOM, 1, 0, CategoryFieldMapping.class, null);
        bcomCategoriesIndexCreationProperties = new IndexCreationProperties(categoriesIndexNamePrefixBCOM, 1, 0, CategoryFieldMapping.class, null);
        return siteName == SiteName.MCOM ? mcomCategoriesIndexCreationProperties : bcomCategoriesIndexCreationProperties;
    }

    @AfterAll
    void remove() {
        facade.deleteIndices(indexNameSearchBCOM);
        facade.deleteIndices(indexNameSearchMCOM);
        facade.deleteIndices(indexNameBrowseMCOM);
        facade.deleteIndices(indexNameBrowseBCOM);
        facade.deleteIndices(indexNameCategoriesMCOM);
        facade.deleteIndices(indexNameCategoriesBCOM);
        facade.deleteIndices(indexNameProductsMCOM);
        facade.deleteIndices(indexNameProductsBCOM);
        facade.deleteIndices(indexNameRulesMCOM);
        facade.deleteIndices(indexNameRulesBCOM);
        facade.deleteIndices(indexNameActionsMCOM);
        facade.deleteIndices(indexNameActionsBCOM);
    }
}
