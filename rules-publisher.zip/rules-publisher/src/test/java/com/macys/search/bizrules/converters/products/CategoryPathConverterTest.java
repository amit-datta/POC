package com.macys.search.bizrules.converters.products;

import com.macys.search.bizrules.converters.products.filters.CategoryFilter;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESProduct;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.model.product.ProductToCategory;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CategoryPathConverterTest {

    @Test
    void oneCategoryConvert() {
        Product product = Product.builder()
                .parentCategories(List.of(ProductToCategory.builder().categoryId(1).build()))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null)
        ));
        CategoryPathConverter converter = passedCategoryIds(1);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1),
                "cat_paths", Set.of("1")
        );
        assertEquals(expected, actual);
    }

    @Test
    void oneHierarchyConvert() {
        Product product = Product.builder()
                .parentCategories(List.of(ProductToCategory.builder().categoryId(3).build()))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1),
                cat(3, 2)
        ));
        CategoryPathConverter converter = passedCategoryIds(1, 2, 3);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1, 2, 3),
                "cat_paths", Set.of("1 > 2 > 3")
        );
        assertEquals(expected, actual);
    }

    @Test
    void testMissingTailAndHeadInHierarchy() {
        Product product = Product.builder()
                .parentCategories(List.of(ProductToCategory.builder().categoryId(3).build()))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1),
                cat(3, 2)
        ));
        CategoryPathConverter converter = passedCategoryIds(2);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1, 2),
                "cat_paths", Set.of("1 > 2")
        );
        assertEquals(expected, actual);
    }

    @Test
    void testOnlyTailInHierarchy() {
        Product product = Product.builder()
                .parentCategories(List.of(ProductToCategory.builder().categoryId(3).build()))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1),
                cat(3, 2)
        ));
        CategoryPathConverter converter = passedCategoryIds(3);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1, 2, 3),
                "cat_paths", Set.of("1 > 2 > 3")
        );
        assertEquals(expected, actual);
    }

    @Test
    void testMissingCategoryInTail() {
        Product product = Product.builder()
                .parentCategories(List.of(ProductToCategory.builder().categoryId(3).build()))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1)
        ));
        CategoryPathConverter converter = passedCategoryIds(1, 2);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123
        );
        assertEquals(expected, actual);
    }

    @Test
    void removeDuplicates() {
        Product product = Product.builder()
                .parentCategories(List.of(
                        ProductToCategory.builder().categoryId(1).build(),
                        ProductToCategory.builder().categoryId(2).build(),
                        ProductToCategory.builder().categoryId(3).build(),
                        ProductToCategory.builder().categoryId(4).build()
                ))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1),
                cat(3, 2),
                cat(4, 3)
        ));
        CategoryPathConverter converter = passedCategoryIds(1, 2);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1, 2),
                "cat_paths", Set.of("1", "1 > 2")
        );
        assertEquals(expected, actual);
    }

    @Test
    void twoHierarchies() {
        Product product = Product.builder()
                .parentCategories(List.of(
                        ProductToCategory.builder().categoryId(3).build(),
                        ProductToCategory.builder().categoryId(5).build()
                ))
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1),
                cat(3, 2),

                cat(4, null),
                cat(5, 4)
        ));
        CategoryPathConverter converter = passedCategoryIds(1, 2, 3, 4, 5);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1, 2, 3, 4, 5),
                "cat_paths", Set.of("1 > 2 > 3", "4 > 5")
        );
        assertEquals(expected, actual);
    }

    @Test
    void masterMemberTest() {
        Product product = Product.builder()
                .parentCategories(List.of(
                        ProductToCategory.builder().categoryId(1).build(),
                        ProductToCategory.builder().categoryId(3).build()
                ))
                .members(
                        List.of(
                                Product.builder()
                                        .productId(124)
                                        .parentCategories(List.of(
                                                ProductToCategory.builder().categoryId(1).build(),
                                                ProductToCategory.builder().categoryId(2).build()
                                        ))
                                        .build()
                        )
                )
                .build();
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(123);
        CategoryTree categoryTree = CategoryTree.from(List.of(
                cat(1, null),
                cat(2, 1),
                cat(3, 2)
        ));
        CategoryPathConverter converter = passedCategoryIds(2, 3);
        converter.convert(product, esProduct, categoryTree);

        Map<String, ?> actual = esProduct.getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", Set.of(1, 2, 3),
                "cat_paths", Set.of("1 > 2 > 3")
        );
        assertEquals(expected, actual);
    }

    private static CategoryPathConverter passedCategoryIds(Integer... ids) {
        final List<Integer> catIds = Arrays.asList(ids);
        return new CategoryPathConverter(
                List.of(
                        new CategoryFilter() {
                            @Override
                            public boolean pass(Category category, Product product) {
                                return catIds.contains(category.getId());
                            }

                            @Override
                            public boolean isSelfBased() {
                                return false;
                            }
                        }
                )
        );
    }

    private Category cat(Integer id, Integer parentId) {
        return Category.builder()
                .id(id)
                .parentCategoryId(parentId)
                .name(id.toString())
                .build();
    }

}