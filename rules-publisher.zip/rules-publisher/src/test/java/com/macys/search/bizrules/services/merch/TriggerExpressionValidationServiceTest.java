package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

class TriggerExpressionValidationServiceTest {

    private final TriggerExpressionValidationService service;
    private final TriggersService triggersService;
    private final ProcessingContext ctx;
    private final ProcessingTrigger validProcessingTrigger;
    private final ProcessingTrigger invalidProcessingTrigger;

    public TriggerExpressionValidationServiceTest() {
        triggersService = Mockito.mock(TriggersService.class);
        service = new TriggerExpressionValidationService(triggersService);
        ctx = new ProcessingContext();

        validProcessingTrigger = ProcessingTrigger.from(new Trigger());
        validProcessingTrigger.setValidationResult(ValidationResult.validResult());

        invalidProcessingTrigger = ProcessingTrigger.from(new Trigger());
        invalidProcessingTrigger.setValidationResult(ValidationResult.failResult("Trigger warning"));
    }

    @Test
    void noChildrenExpressionTest() {
        Rule rule = new Rule();
        rule.setId(1);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(0, validTriggers.size());
        ValidationResult expected = ValidationResult.failResult("No trigger ids for rule id=1");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void noOperationForSeveralChildTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));
        ProcessingRule processingRule = ProcessingRule.from(rule);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(0, validTriggers.size());
        ValidationResult expected = ValidationResult.failResult("Trigger expression operation is null for rule id=1");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void noOperationForOneTriggerTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2));
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(validProcessingTrigger);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(1, validTriggers.size());
        ValidationResult expected = ValidationResult.validResult();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void nullTriggerQueriesTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2));
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(invalidProcessingTrigger);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(0, validTriggers.size());
        ValidationResult expected = ValidationResult.failResult("Rule with id=1 skipped because there are no valid trigger queries. Trigger with id=2 is invalid. Msg=Trigger warning");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void missingQueryWithAndOperatorTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));
        rule.setTriggerOperation(BooleanOperation.AND);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(validProcessingTrigger);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(invalidProcessingTrigger);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(1, validTriggers.size());
        ValidationResult expected = ValidationResult.failResult("Rule with id=1 skipped because there are no valid trigger queries. Trigger with id=3 is invalid. Msg=Trigger warning");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void missingQueryWithOrOperatorTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));
        rule.setTriggerOperation(BooleanOperation.OR);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(validProcessingTrigger);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(invalidProcessingTrigger);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(1, validTriggers.size());
        ValidationResult expected = ValidationResult.validResult();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void emptyQueryWithOrOperatorTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));
        rule.setTriggerOperation(BooleanOperation.OR);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(invalidProcessingTrigger);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(invalidProcessingTrigger);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(0, validTriggers.size());
        ValidationResult expected = ValidationResult.failResult("Rule with id=1 skipped because there are no valid trigger queries. ");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void unsupportedTriggerWithAndOperatorError() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));
        rule.setTriggerOperation(BooleanOperation.AND);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(validProcessingTrigger);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(null);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(1, validTriggers.size());
        ValidationResult expected = ValidationResult.failResult("Rule with id=1 skipped because there are no valid trigger queries." +
                " Trigger with id=3 was not found. Maybe it has disabled type");
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void doNotFailIfOneTriggerIsDisabled() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3, 4));
        rule.setTriggerOperation(BooleanOperation.OR);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(validProcessingTrigger);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(null);
        Mockito.when(triggersService.getProcessedTrigger(4, ctx)).thenReturn(invalidProcessingTrigger);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(1, validTriggers.size());
        ValidationResult expected = ValidationResult.validResult();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void onlyHRTTriggerTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2));
        rule.setTriggerOperation(BooleanOperation.OR);
        ProcessingRule processingRule = ProcessingRule.from(rule);


        Trigger trigger1 = new Trigger();
        trigger1.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        ProcessingTrigger processingTrigger1 = ProcessingTrigger.from(trigger1);
        processingTrigger1.setValidationResult(ValidationResult.validResult());

        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(processingTrigger1);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(1, validTriggers.size());
        ValidationResult expected = ValidationResult.validResult();
        Assertions.assertEquals(expected, actual);
    }

    @Test
    void oneHRTTriggerAndOneFRTTriggerTest() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));

        rule.setTriggerOperation(BooleanOperation.AND);
        ProcessingRule processingRule = ProcessingRule.from(rule);


        Trigger trigger1 = new Trigger();
        trigger1.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        ProcessingTrigger processingTrigger1 = ProcessingTrigger.from(trigger1);
        processingTrigger1.setValidationResult(ValidationResult.validResult());

        Trigger trigger2 = new Trigger();
        trigger2.setMerchTriggerType(TriggerType.FacetRefinement);
        ProcessingTrigger processingTrigger2 = ProcessingTrigger.from(trigger2);
        processingTrigger2.setValidationResult(ValidationResult.validResult());

        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(processingTrigger1);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(processingTrigger2);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        Assertions.assertEquals(2, validTriggers.size());
        ValidationResult expected = ValidationResult.validResult();
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(2, validTriggers.size());
    }

    @Test
    void oneHRTTriggerAndNOther() {
        Rule rule = new Rule();
        rule.setId(1);
        rule.setTriggerIds(List.of(2, 3));

        rule.setTriggerOperation(BooleanOperation.AND);
        ProcessingRule processingRule = ProcessingRule.from(rule);


        Trigger trigger1 = new Trigger();
        trigger1.setMerchTriggerType(TriggerType.HierarchicalRefinement);
        ProcessingTrigger processingTrigger1 = ProcessingTrigger.from(trigger1);
        processingTrigger1.setValidationResult(ValidationResult.validResult());

        Trigger trigger2 = new Trigger();
        trigger2.setMerchTriggerType(TriggerType.KeywordPattern);
        ProcessingTrigger processingTrigger2 = ProcessingTrigger.from(trigger2);
        processingTrigger2.setValidationResult(ValidationResult.validResult());

        Mockito.when(triggersService.getProcessedTrigger(2, ctx)).thenReturn(processingTrigger1);
        Mockito.when(triggersService.getProcessedTrigger(3, ctx)).thenReturn(processingTrigger2);
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        ValidationResult actual = service.validate(processingRule, ctx, validTriggers);
        ValidationResult expected = ValidationResult.failResult("There should be either only 1 HRT trigger or 1 HRT and N FRT triggers " +
                "when operation is AND.");
        Assertions.assertEquals(expected, actual);
        Assertions.assertEquals(0, validTriggers.size());
    }
}