package com.macys.search.bizrules.repository.mrf;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.ContextUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.tasklets.JobParams.SITE_NAME_JOB_PARAM;

class TriggerExpressionReaderTest extends BaseTest {

    private static final ProcessingContext context = ContextUtils.createProcessingContext(Map.of(
            SITE_NAME_JOB_PARAM, new JobParameter("MCOM")
    ));

    @Autowired
    private TriggerExpressionReader triggerExpressionReader;

    @Test
    @Sql({"classpath:triggers/triggerExpressionsData.sql", "classpath:rules/data.sql"})
    void readTriggerExpression() {
        Rule expected = createRule(1, "CatRedirect: Panty", "",
                LocalDate.of(2013, Month.APRIL, 18),
                LocalDate.of(2016, Month.MARCH, 21), 85,
                LocalDateTime.of(2016, Month.MARCH, 18, 15, 3, 4),
                LocalDateTime.of(2013, Month.APRIL, 19, 2, 4, 44),
                "test", "test", RuleType.MERCH, List.of(1));

        Rule expected1 = createRule(2, "URL Redirect: Beauty Blog", "",
                LocalDate.of(2013, Month.AUGUST, 25),
                LocalDate.of(2020, Month.AUGUST, 25),
                70, LocalDateTime.of(2020, Month.AUGUST, 25, 13, 8, 12),
                LocalDateTime.of(2013, Month.APRIL, 22, 13, 4, 18),
                "p139mma", "M412138", RuleType.MERCH, List.of());

        Rule expected2 = createRule(3, "Facet Metadata - 50684 - 12/03/2020 09:48-111",
                "Brand - YNQ Denim -", LocalDate.of(2013, Month.DECEMBER, 3),
                LocalDate.of(2037, Month.DECEMBER, 31), 10,
                LocalDateTime.of(2020, Month.DECEMBER, 3, 9, 12, 28),
                LocalDateTime.of(2013, Month.DECEMBER, 3, 9, 12, 28),
                "A231310", "A231310", RuleType.SEO, List.of());
        Map<Integer, ProcessingRule> rulesMap = Map.of(1, ProcessingRule.from(expected),
                2, ProcessingRule.from(expected1), 3, ProcessingRule.from(expected2));
        Map<Integer, Integer> expressionToRuleMapping = Map.of(1, 1, 2, 2, 3, 3);

        Assertions.assertTrue(expected.getTriggerIds().isEmpty());

        triggerExpressionReader.readTriggerExpression(context, rulesMap, expressionToRuleMapping);

        Assertions.assertEquals(expected.getTriggerIds(), List.of(1));
    }

    @Test
    @Sql({"classpath:triggers/triggerExpressionsData.sql", "classpath:rules/data.sql"})
    void testReadTriggerExpressionForRule() {
        Rule expected = new Rule();
        Rule actual = new Rule();
        actual.setId(1);
        triggerExpressionReader.readTriggerExpressionForRule(SiteName.MCOM, actual);
        expected.setId(1);
        expected.setTriggerOperation(BooleanOperation.AND);
        expected.setTriggerIds(List.of(1));
        Assertions.assertEquals(expected, actual);
    }

    private Rule createRule(int id, String name, String description, LocalDate effectiveDate, LocalDate expirationDate,
                            int priority, LocalDateTime lastModified, LocalDateTime createdDate,
                            String authorName, String lastModifiedByName, RuleType ruleType, List<Integer> actionIds) {
        Rule rule = new Rule();
        rule.setId(id);
        rule.setName(name);
        rule.setDescription(description);
        rule.setEffectiveDate(effectiveDate);
        rule.setExpirationDate(expirationDate);
        rule.setPriority(priority);
        rule.setStateCode(1);
        rule.setLastModified(lastModified);
        rule.setCreatedDate(createdDate);
        rule.setAuthorName(authorName);
        rule.setLastModifiedByName(lastModifiedByName);
        rule.setMerchRuleType(ruleType);
        rule.setActionsIds(actionIds);
        return rule;
    }
}