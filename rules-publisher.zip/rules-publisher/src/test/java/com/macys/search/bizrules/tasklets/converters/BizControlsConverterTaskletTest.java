package com.macys.search.bizrules.tasklets.converters;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.elastic.ESBizControlType;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.AbstractESEntry;
import com.macys.search.bizrules.model.elastic.entries.ESBizControl;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.mrf.CustomDateReader;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.utils.CustomDateUtils;
import com.macys.search.util.InmemoryAppender;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.time.Month;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.util.TestUtils.addAppender;
import static com.macys.search.util.TestUtils.getUniqLogMessage;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;

class BizControlsConverterTaskletTest extends AbstractTaskletTest {

    private final LocalDate date = LocalDate.of(2021, Month.FEBRUARY, 25);
    @Mock
    private ElasticSearchIndexerFactory factory;
    @Mock
    private ElasticSearchIndexer indexer;
    @Mock
    private CustomDateReader mcomCustomDateReader;
    private static InmemoryAppender inmemoryAppender;
    private BizControlsConverterTasklet tasklet;
    private ProcessingContext ctx;

    @PostConstruct
    public void init() {
        tasklet = createTasklet();
        inmemoryAppender = new InmemoryAppender();
        addAppender(CustomDateUtils.class, inmemoryAppender);
        inmemoryAppender.start();
    }

    @AfterAll
    public static void tearDown() {
        inmemoryAppender.stop();
    }

    @Test
    void controlsDbWhenCustomDateIsNullTest() throws Exception {
        Mockito.when(mcomCustomDateReader.getCustomDate(any())).thenReturn(null);
        ctx = ProcessingContext.initContext(contribution, chunkContext);
        CustomDateUtils.getCustomDate(ctx, mcomCustomDateReader);
        Mockito.when(factory.createIndexer("TEST_INDEX_NAME")).thenReturn(indexer);

        ArgumentCaptor<ESBizControl> valueCapture = ArgumentCaptor.forClass(ESBizControl.class);
        Mockito.doNothing().when(indexer).add(valueCapture.capture());
        Mockito.when(indexer.flush()).thenReturn(true);

        changeSiteName(SiteName.MCOM);

        ctx.setupIndex(ESIndex.BIZ_CONTROLS_DB, "TEST_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.ACTIONS, "TEST_ACTIONS_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.RULES, "TEST_RULES_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.TRIGGERS, "TEST_TRIGGERS_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, "TEST_KWP_TRIGGERS_INDEX_NAME", indexer);

        execute(tasklet);

        Set<Map<String, Object>> expected = Set.of(
                ESBizControl.of(ESBizControlType.CUSTOM_DATE, LocalDate.now().toString()).getSource(),
                ESBizControl.of(ESBizControlType.ACTIONS_INDEX, "TEST_ACTIONS_INDEX_NAME").getSource(),
                ESBizControl.of(ESBizControlType.RULES_INDEX, "TEST_RULES_INDEX_NAME").getSource(),
                ESBizControl.of(ESBizControlType.TRIGGERS_INDEX, "TEST_TRIGGERS_INDEX_NAME").getSource(),
                ESBizControl.of(ESBizControlType.KWP_TRIGGERS_INDEX, "TEST_KWP_TRIGGERS_INDEX_NAME").getSource()
        );
        Set<Map<String, Object>> actual = valueCapture.getAllValues()
                .stream()
                .map(AbstractESEntry::getSource)
                .collect(Collectors.toSet());
        assertEquals(expected, actual);
        Mockito.verify(indexer, Mockito.times(1)).flush();
        String expectedMessage = "Custom date is null. Continue indexing using current date";
        assertEquals(expectedMessage, getUniqLogMessage(inmemoryAppender));
    }

    @Test
    void bizControlsTest() throws Exception {
        Mockito.when(mcomCustomDateReader.getCustomDate(any())).thenReturn(date);
        ctx = ProcessingContext.initContext(contribution, chunkContext);
        CustomDateUtils.getCustomDate(ctx, mcomCustomDateReader);

        BizControlsConverterTasklet tasklet = createTasklet();
        changeSiteName(SiteName.MCOM);

        Mockito.when(factory.createIndexer("TEST_INDEX_NAME")).thenReturn(indexer);

        ArgumentCaptor<ESBizControl> valueCapture = ArgumentCaptor.forClass(ESBizControl.class);
        Mockito.doNothing().when(indexer).add(valueCapture.capture());
        Mockito.when(indexer.flush()).thenReturn(true);

        ctx.setupIndex(ESIndex.BIZ_CONTROLS_DB, "TEST_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.BIZ_CONTROLS_DB, "TEST_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.ACTIONS, "TEST_ACTIONS_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.RULES, "TEST_RULES_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.TRIGGERS, "TEST_TRIGGERS_INDEX_NAME", indexer);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, "TEST_KWP_TRIGGERS_INDEX_NAME", indexer);

        execute(tasklet);

        Set<Map<String, Object>> expected = Set.of(
                ESBizControl.of(ESBizControlType.CUSTOM_DATE, date.toString()).getSource(),
                ESBizControl.of(ESBizControlType.ACTIONS_INDEX, "TEST_ACTIONS_INDEX_NAME").getSource(),
                ESBizControl.of(ESBizControlType.RULES_INDEX, "TEST_RULES_INDEX_NAME").getSource(),
                ESBizControl.of(ESBizControlType.TRIGGERS_INDEX, "TEST_TRIGGERS_INDEX_NAME").getSource(),
                ESBizControl.of(ESBizControlType.KWP_TRIGGERS_INDEX, "TEST_KWP_TRIGGERS_INDEX_NAME").getSource()
        );
        Set<Map<String, Object>> actual = valueCapture.getAllValues()
                .stream()
                .map(AbstractESEntry::getSource)
                .collect(Collectors.toSet());
        assertEquals(expected, actual);
        Mockito.verify(indexer, Mockito.times(1)).flush();
    }

    private BizControlsConverterTasklet createTasklet() {
        return new BizControlsConverterTasklet(factory);
    }

}
