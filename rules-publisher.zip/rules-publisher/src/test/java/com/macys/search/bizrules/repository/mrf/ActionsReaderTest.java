package com.macys.search.bizrules.repository.mrf;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionParameter;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.ContextUtils;
import org.junit.Test;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.model.mrf.action.ActionType.CategoryRedirect;
import static com.macys.search.bizrules.model.mrf.action.ActionType.ModifySearchResults;
import static com.macys.search.bizrules.tasklets.JobParams.SITE_NAME_JOB_PARAM;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ActionsReaderTest extends BaseTest {

    private static final ProcessingContext context = ContextUtils.createProcessingContext(Map.of(
            SITE_NAME_JOB_PARAM, new JobParameter("MCOM")
    ));

    @Autowired
    private ActionsReader actionsReader;
    @Value("${rules.publisher.enabled.action-types}")
    private List<ActionType> enabledActionTypes;

    @Test
    @Sql({"classpath:actions/schema.sql", "classpath:actions/testData.sql"})
    public void testReadActions() {
        Map<Integer, ProcessingAction> actual = new HashMap<>();
        Action expectedMSRAction = new Action();
        expectedMSRAction.setId(1);
        expectedMSRAction.setLastModified(LocalDate.now());
        expectedMSRAction.setCreatedDate(LocalDate.of(2013, Month.JUNE, 12));
        expectedMSRAction.setLastModifiedByName("p139tnb");
        expectedMSRAction.setMerchActionType(ModifySearchResults);
        expectedMSRAction.setCriteriaMap(Map.of());
        expectedMSRAction.setContextAttributes(Map.of());
        expectedMSRAction.setNonEqualSeqNumberInSomeCriteria(false);

        ActionParameter actionParam = new ActionParameter();
        actionParam.setGroup("Operations");
        actionParam.setName("Operation");
        actionParam.setValue("BOOST");
        actionParam.setSequenceNumber(0);
        actionParam.setGroupSequenceNumber(0);
        actionParam.setEffectiveDate(LocalDate.of(1, Month.JANUARY, 3));
        actionParam.setExpirationDate(LocalDate.of(9999, Month.DECEMBER, 31));
        ActionParameter actionParam2 = new ActionParameter();
        actionParam2.setGroup("Pool");
        actionParam2.setName("PoolId");
        actionParam2.setValue("1");
        actionParam2.setSequenceNumber(0);
        actionParam2.setGroupSequenceNumber(0);
        actionParam2.setEffectiveDate(LocalDate.of(1, Month.JANUARY, 3));
        actionParam2.setExpirationDate(LocalDate.of(9999, Month.DECEMBER, 31));

        Action expectedCatRedirectAction = new Action();
        expectedCatRedirectAction.setId(2);
        expectedCatRedirectAction.setLastModified(LocalDate.now());
        expectedCatRedirectAction.setCreatedDate(LocalDate.of(2013, Month.APRIL, 19));
        expectedCatRedirectAction.setLastModifiedByName("A050869");
        expectedCatRedirectAction.setMerchActionType(CategoryRedirect);
        expectedCatRedirectAction.setCriteriaMap(Map.of());
        expectedCatRedirectAction.setContextAttributes(Map.of());
        expectedCatRedirectAction.setNonEqualSeqNumberInSomeCriteria(false);

        List<ActionParameter> params2 = new ArrayList<>();
        ActionParameter actionParam3 = new ActionParameter();
        actionParam3.setGroup("Category");
        actionParam3.setName("CategoryId");
        actionParam3.setValue("64761");
        actionParam3.setSequenceNumber(0);
        actionParam3.setGroupSequenceNumber(0);
        actionParam3.setEffectiveDate(LocalDate.of(1, Month.JANUARY, 3));
        actionParam3.setExpirationDate(LocalDate.of(9999, Month.DECEMBER, 31));
        ActionParameter actionParam4 = new ActionParameter();
        actionParam4.setGroup("Context");
        actionParam4.setName("NAVIGATION_TYPE");
        actionParam4.setValue("SEARCH");
        actionParam4.setSequenceNumber(0);
        actionParam4.setGroupSequenceNumber(0);
        actionParam4.setEffectiveDate(LocalDate.of(1, Month.JANUARY, 3));
        actionParam4.setExpirationDate(LocalDate.of(9999, Month.DECEMBER, 31));
        params2.add(actionParam3);
        params2.add(actionParam4);
        expectedCatRedirectAction.setParams(params2);

        actionsReader.readActions(context, enabledActionTypes, actual);
        assertEquals(2, actual.size());
        Action actualAction = actual.values().iterator().next().getAction();
        ProcessingAction actualCatRedirectAction = actual.get(2);

        assertEquals(expectedMSRAction.getId(), actualAction.getId());
        assertEquals(expectedMSRAction.getLastModified(), actualAction.getLastModified());
        assertEquals(expectedMSRAction.getLastModifiedByName(), actualAction.getLastModifiedByName());
        assertEquals(expectedMSRAction.getMerchActionType(), actualAction.getMerchActionType());
        assertEquals(expectedMSRAction.getCreatedDate(), actualAction.getCreatedDate());
        List<ActionParameter> msrParams = actualAction.getParams();
        assertEquals(actionParam.getName(), msrParams.get(0).getName());
        assertEquals(actionParam.getValue(), msrParams.get(0).getValue());
        assertEquals(actionParam.getGroup(), msrParams.get(0).getGroup());
        assertEquals(actionParam.getGroupSequenceNumber(), msrParams.get(0).getGroupSequenceNumber());


        assertEquals(actionParam2.getName(), msrParams.get(1).getName());
        assertEquals(actionParam2.getValue(), msrParams.get(1).getValue());
        assertEquals(actionParam2.getGroup(), msrParams.get(1).getGroup());
        assertEquals(actionParam2.getGroupSequenceNumber(), msrParams.get(1).getGroupSequenceNumber());

        assertEquals(expectedCatRedirectAction.getId(), actualCatRedirectAction.getAction().getId());
        assertEquals(expectedCatRedirectAction.getLastModified(), actualCatRedirectAction.getAction().getLastModified());
        assertEquals(expectedCatRedirectAction.getLastModifiedByName(), actualCatRedirectAction.getAction().getLastModifiedByName());
        assertEquals(expectedCatRedirectAction.getMerchActionType(), actualCatRedirectAction.getAction().getMerchActionType());
        assertEquals(expectedCatRedirectAction.getCreatedDate(), actualCatRedirectAction.getAction().getCreatedDate());
    }

    @Test
    @Sql({"classpath:actions/schema.sql", "classpath:actions/testData.sql"})
    public void testGetActionsById() {
        Action expected = new Action();
        expected.setId(1);
        expected.setLastModified(LocalDate.now());
        expected.setCreatedDate(LocalDate.of(2013, Month.JUNE, 12));
        expected.setLastModifiedByName("p139tnb");
        expected.setMerchActionType(ModifySearchResults);
        expected.setCriteriaMap(Map.of());
        expected.setContextAttributes(Map.of());
        expected.setNonEqualSeqNumberInSomeCriteria(false);
        List<ActionParameter> params = new ArrayList<>();
        ActionParameter actionParam = new ActionParameter();
        actionParam.setGroup("Operations");
        actionParam.setName("Operation");
        actionParam.setValue("BOOST");
        actionParam.setSequenceNumber(0);
        actionParam.setGroupSequenceNumber(0);
        actionParam.setEffectiveDate(LocalDate.of(1, Month.JANUARY, 3));
        actionParam.setExpirationDate(LocalDate.of(9999, Month.DECEMBER, 31));
        ActionParameter actionParam2 = new ActionParameter();
        actionParam2.setGroup("Pool");
        actionParam2.setName("PoolId");
        actionParam2.setValue("1");
        actionParam2.setSequenceNumber(0);
        actionParam2.setGroupSequenceNumber(0);
        actionParam2.setEffectiveDate(LocalDate.of(1, Month.JANUARY, 3));
        actionParam2.setExpirationDate(LocalDate.of(9999, Month.DECEMBER, 31));
        params.add(actionParam);
        params.add(actionParam2);
        expected.setParams(params);
        Action actual = actionsReader.getActionsById(SiteName.MCOM, 1, enabledActionTypes);

        assertEquals(expected.getId(), actual.getId());
        assertEquals(expected.getLastModified(), actual.getLastModified());
        assertEquals(expected.getLastModifiedByName(), actual.getLastModifiedByName());
        assertEquals(expected.getMerchActionType(), actual.getMerchActionType());
        assertEquals(expected.getCreatedDate(), actual.getCreatedDate());
        List<ActionParameter> msrParams = actual.getParams();
        assertEquals(actionParam.getName(), msrParams.get(0).getName());
        assertEquals(actionParam.getValue(), msrParams.get(0).getValue());
        assertEquals(actionParam.getGroup(), msrParams.get(0).getGroup());
        assertEquals(actionParam.getGroupSequenceNumber(), msrParams.get(0).getGroupSequenceNumber());
    }
}