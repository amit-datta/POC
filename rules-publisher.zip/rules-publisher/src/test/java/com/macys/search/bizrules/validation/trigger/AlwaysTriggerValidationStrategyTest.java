package com.macys.search.bizrules.validation.trigger;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AlwaysTriggerValidationStrategyTest extends BaseTest {

    @Autowired
    AlwaysTriggerValidationStrategy strategy;

    @Test
    void applicableFor() {
        assertEquals(TriggerType.Always, strategy.applicableFor());
    }

    @Test
    void validate() {
        assertTrue(strategy.validate(null, null).isValid());
    }
}