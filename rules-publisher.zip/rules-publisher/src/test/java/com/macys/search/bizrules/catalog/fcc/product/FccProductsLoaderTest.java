package com.macys.search.bizrules.catalog.fcc.product;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.catalog.fcc.FccField;
import com.macys.search.bizrules.catalog.fcc.product.bindings.ProductBinding;
import com.macys.search.bizrules.catalog.fcc.product.bindings.ProductsBinding;
import com.macys.search.bizrules.catalog.fcc.product.bindings.ProductsRootBinding;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FccProductsLoaderTest extends BaseTest {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Collection<FccField> fccProductFields;

    @Autowired
    private Collection<FccField> fccLightProductFields;

    @Test
    void testGetPathWithParams() {
        ProductsLoaderImpl fccProductsLoader = getFccProductsLoader();
        assertNotNull(fccProductsLoader.getPathWithParams());
    }

    @Test
    void testIterator() {
        ProductsLoaderImpl fccProductsLoader = getFccProductsLoader();
        assertNotNull(fccProductsLoader.iterator(SiteName.MCOM, LocalDate.MAX, new TimeStatistics()));
    }

    @Test
    void testIsBatchEmpty() {
        ProductsLoaderImpl fccProductsLoader = getFccProductsLoader();
        assertTrue(fccProductsLoader.isBatchEmpty(new ProductsRootBinding()));
    }

    @Test
    void testIsBatchNonEmpty() {
        ProductsLoaderImpl fccProductsLoader = getFccProductsLoader();
        ProductsRootBinding productsRootBinding = new ProductsRootBinding();
        ProductsBinding productsBinding = new ProductsBinding();
        productsBinding.setProduct(List.of(new ProductBinding()));
        productsRootBinding.setProducts(productsBinding);
        assertFalse(fccProductsLoader.isBatchEmpty(productsRootBinding));
    }

    @Test
    void testConvert() {
        ProductsLoaderImpl fccProductsLoader = getFccProductsLoader();
        ProductsBinding productsBinding = new ProductsBinding();
        ProductsRootBinding productsRootBinding = new ProductsRootBinding();
        productsBinding.setProduct(List.of());
        productsRootBinding.setProducts(productsBinding);
        assertTrue(fccProductsLoader.convert(productsRootBinding).isEmpty());
    }

    private ProductsLoaderImpl getFccProductsLoader() {
        return new ProductsLoaderImpl(restTemplate, "http://mcom:8080/endpoint", "http://bcom:8080/endpoint",
                5, 3, 3, 1, 1, fccProductFields);
    }
}