package com.macys.search.bizrules.catalog.fcc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.client.ResponseActions;
import org.springframework.test.web.client.match.MockRestRequestMatchers;
import org.springframework.test.web.client.response.DefaultResponseCreator;
import org.springframework.web.client.RestTemplate;

import java.util.*;

import static com.macys.search.bizrules.catalog.fcc.AbstractFCCLoader.URIParams.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

class AbstractFCCLoaderTest extends BaseTest {

    private static final int PARTITIONS_COUNT = 2;

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private ObjectMapper mapper;
    private MockRestServiceServer mockServer;

    static class TestFccLoader extends AbstractFCCLoader<Integer, String> {
        final int partitionsCount;

        public TestFccLoader(RestTemplate restTemplate,
                             int batchSize,
                             int retryCount,
                             int partitionsCount) {
            super(restTemplate, "http://mcom:8080/endpoint", "http://bcom:8080/endpoint",
                    batchSize, retryCount, partitionsCount, Integer.class);
            this.partitionsCount = partitionsCount;
        }

        @Override
        protected boolean isBatchEmpty(Integer batch) {
            return batch == 0;
        }

        @Override
        protected String getPathWithParams() {
            return "?filter=ACTIVE" +
                    "&_offset={" + OFFSET + "}" +
                    "&_limit={" + LIMIT + "}" +
                    "&partition={" + PARTITION + "}" +
                    "&partitions={" + PARTITIONS + "}" +
                    "&custom1={CUSTOM_ATTR1}" +
                    "&custom2={CUSTOM_ATTR2}";
        }

        @Override
        protected Collection<String> convert(Integer batch) {
            Collection<String> result = new ArrayList<>();
            while (batch > 0) {
                result.add(String.valueOf(batch % 100));
                batch /= 100;
            }
            return result;
        }

        protected Iterator<String> iterator(SiteName siteName) {
            return new FCCIterator<>(siteName, Map.of("CUSTOM_ATTR1", "attr1", "CUSTOM_ATTR2", "attr2"),
                    "Test entry", partitionsCount, this, new TimeStatistics());
        }
    }

    @BeforeEach
    void init() {
        mockServer = MockRestServiceServer.bindTo(restTemplate).ignoreExpectOrder(true).build();
    }

    @AfterEach
    void verify() {
        mockServer.verify();
    }

    static String uri(Integer offset, Integer partition, Integer partitions) {
        return String.format("http://mcom:8080/endpoint?filter=ACTIVE&_offset=%d&_limit=5&partition=%d&partitions=%d&custom1=attr1&custom2=attr2",
                offset, partition, partitions);
    }

    void build(Integer offset, Integer nextOffset, Integer partition, Integer batch) throws Exception {
        HttpHeaders responseHeaders = new HttpHeaders();
        if (nextOffset != null) {
            responseHeaders.put(HttpHeaders.LINK, List.of("http://mcom:8080/endpoint?filter=ACTIVE&_offset=" + nextOffset));
        }
        ResponseActions action = mockServer.expect(ExpectedCount.once(), requestTo(uri(offset, partition, PARTITIONS_COUNT)));
        action.andExpect(MockRestRequestMatchers.header("X-Macys-ClientId", "RulesPublisher"));
        action.andExpect(MockRestRequestMatchers.method(HttpMethod.GET));
        DefaultResponseCreator response = withStatus(HttpStatus.OK)
                .contentType(MediaType.APPLICATION_JSON)
                .body(mapper.writeValueAsString(batch))
                .headers(responseHeaders);
        action.andRespond(response);
    }

    @Test
    void loadTwoBatchesInTwoThreads() throws Exception {
        build(0, -1, 1, 3453542);
        build(0, -1, 2, 89853432);

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, PARTITIONS_COUNT);
        Iterator<String> it = loader.iterator(SiteName.MCOM);
        assertTrue(it.hasNext());
        List<String> actual = new ArrayList<>();
        while (it.hasNext()) {
            actual.add(it.next());
        }
        List<String> expected = List.of("3", "45", "35", "42",
                "89", "85", "34", "32");

        assertEquals(sort(expected), sort(actual));
    }

    @Test
    void loadOneBatchInTwoThreads() throws Exception {
        build(0, -1, 1, 3453542);
        build(0, -1, 2, 0);

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, PARTITIONS_COUNT);
        Iterator<String> it = loader.iterator(SiteName.MCOM);
        assertTrue(it.hasNext());
        List<String> actual = new ArrayList<>();
        while (it.hasNext()) {
            actual.add(it.next());
        }
        List<String> expected = List.of("3", "45", "35", "42");

        assertEquals(sort(expected), sort(actual));
    }

    @Test
    void loadNone() throws Exception {
        build(0, -1, 1, 0);
        build(0, -1, 2, 0);

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, PARTITIONS_COUNT);
        Iterator<String> it = loader.iterator(SiteName.MCOM);
        assertFalse(it.hasNext());
    }

    @RepeatedTest(12)
    void loadSeveralBatchesInTwoThreads() throws Exception {
        build(0, 1, 1, 4327842);
        build(1, 2, 1, 234321);
        build(2, 3, 1, 3565121);
        build(3, -1, 1, 8975231);

        build(0, 50, 2, 2141404);
        build(50, null, 2, 2345329);

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, PARTITIONS_COUNT);
        Iterator<String> it = loader.iterator(SiteName.MCOM);
        assertTrue(it.hasNext());
        List<String> actual = new ArrayList<>();
        while (it.hasNext()) {
            actual.add(it.next());
        }
        List<String> expected = List.of("4", "32", "78", "42",
                "23", "43", "21",
                "3", "56", "51", "21",
                "8", "97", "52", "31",
                "2", "14", "14", "4",
                "2", "34", "53", "29"
        );

        assertEquals(sort(expected), sort(actual));
    }

    @RepeatedTest(12)
    void loadAllBatchesInTwoThreads() throws Exception {
        build(0, 1, 1, 4327842);
        build(1, 2, 1, 234321);
        build(2, 3, 1, 3565121);
        build(3, -1, 1, 8975231);

        build(0, 50, 2, 2141404);
        build(50, null, 2, 2345329);

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, PARTITIONS_COUNT);
        Collection<String> actual = loader.loadAll(SiteName.MCOM,
                Map.of("CUSTOM_ATTR1", "attr1", "CUSTOM_ATTR2", "attr2"),
                "Load all entry", new TimeStatistics());

        List<String> expected = List.of("4", "32", "78", "42",
                "23", "43", "21",
                "3", "56", "51", "21",
                "8", "97", "52", "31",
                "2", "14", "14", "4",
                "2", "34", "53", "29"
        );
        assertEquals(sort(expected), sort(actual));
    }

    @Test
    void exceptionIfLinkHeaderHasMultiplyValue() {
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.put(HttpHeaders.LINK, List.of("ONE VALUE", "NEXT VALUE"));
        ResponseActions action = mockServer.expect(ExpectedCount.manyTimes(), requestTo(uri(0, 1, 1)));
        action.andExpect(MockRestRequestMatchers.header("X-Macys-ClientId", "RulesPublisher"));
        action.andExpect(MockRestRequestMatchers.method(HttpMethod.GET));
        action.andRespond(
                withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body("12345")
                        .headers(responseHeaders)
        );

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, 1);
        Iterator<String> it = loader.iterator(SiteName.MCOM);

        RuntimeException exception = assertThrows(RuntimeException.class, it::hasNext);
        assertTrue(exception.getMessage().contains("Count not parse Link header from FCC. Headers=[Content-Type:\"application/json\", Link:\"ONE VALUE\", \"NEXT VALUE\"]"));
    }

    @Test
    void testLinkDoesNotContainOffset() {
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.put(HttpHeaders.LINK, List.of("http://mcom:8080/endpoint?filter=ACTIVE&_limit=2"));
        ResponseActions action = mockServer.expect(ExpectedCount.manyTimes(), requestTo(uri(0, 1, 1)));
        action.andExpect(MockRestRequestMatchers.header("X-Macys-ClientId", "RulesPublisher"));
        action.andExpect(MockRestRequestMatchers.method(HttpMethod.GET));
        action.andRespond(
                withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body("12345")
                        .headers(responseHeaders)
        );

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, 1);
        Iterator<String> it = loader.iterator(SiteName.MCOM);

        RuntimeException exception = assertThrows(RuntimeException.class, it::hasNext);
        assertTrue(exception.getMessage().contains("Could not parse next offset from Link header=http://mcom:8080/endpoint?filter=ACTIVE&_limit=2"));
    }

    @Test
    void testMissingValueInAdditionalParams() {
        TestFccLoader loader = new TestFccLoader(restTemplate, 5, 3, PARTITIONS_COUNT);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> loader.loadAll(SiteName.MCOM, Map.of(), "Load all entry", new TimeStatistics())
        );
        assertTrue(exception.getMessage().contains("Map has no value for 'CUSTOM_ATTR1'"));
    }

    @Test
    void retryCountTest() {
        final int RETRY_COUNT = 3;
        ResponseActions action = mockServer.expect(ExpectedCount.times(RETRY_COUNT), requestTo(uri(0, 1, 1)));
        action.andRespond(withStatus(HttpStatus.INTERNAL_SERVER_ERROR));

        TestFccLoader loader = new TestFccLoader(restTemplate, 5, RETRY_COUNT, 1);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> loader.iterator(SiteName.MCOM).hasNext());
        assertTrue(exception.getMessage().contains("500 Internal Server Error: [no body]"));
    }

    private static List<String> sort(Collection<String> input) {
        List<String> list = new ArrayList<>(input);
        list.sort(Comparator.comparing(s -> s));
        return list;
    }

}