package com.macys.search.bizrules.catalog.fcc.product.bindings;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProductsRootBindingTest {

    ObjectMapper mapper = new ObjectMapper();

    String body = "{\n" +
            "    \"products\": {\n" +
            "        \"product\": [\n" +
            "            {\n" +
            "                \"id\": 1934215,\n" +
            "                \"isNew\": false,\n" +
            "                \"categories\": [\n" +
            "                    {\n" +
            "                        \"id\": 54698\n" +
            "                    }\n" +
            "                ]\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}";

    @Test
    void checkRootCategory() throws JsonProcessingException {
        ProductsRootBinding actual = mapper.readValue(body, ProductsRootBinding.class);
        assertNotNull(actual.getProducts());
        assertEquals(1, actual.getProducts().getProduct().size());
    }

}