package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ShowMediaConverterTest {

    private final ShowMediaConverter converter = new ShowMediaConverter();

    @Test
    void convert() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.ShowMedia);
        Criteria criteria = new Criteria();
        action.setCriteriaMap(Map.of(
                "Canvas", criteria
        ));
        criteria.setCriteriaAttributes(
                Map.of(
                        "CanvasId", List.of("14")
                )
        );
        ESAction actual = converter.convert(action, null);
        assertEquals(14, actual.getSource().get("canvas_id"));
    }

}