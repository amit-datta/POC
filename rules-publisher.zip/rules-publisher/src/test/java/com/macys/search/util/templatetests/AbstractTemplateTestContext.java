package com.macys.search.util.templatetests;

import com.macys.search.bizrules.model.mrf.Criteria;

import java.util.List;
import java.util.Map;

abstract class AbstractTemplateTestContext {

    Map<String, Criteria> additionalCriteria;
    String criteriaName;
    String attrName;
    List<String> possibleValues;

    abstract void createNew();

    abstract void setCriteriaMap(Map<String, Criteria> map);

    abstract boolean validate();

    static void mergeCriteriaMap(Map<String, Criteria> target, Map<String, Criteria> additional) {
        if (additional == null) return;
        for (Map.Entry<String, Criteria> entry : additional.entrySet()) {
            String criteriaName = entry.getKey();
            if (target.containsKey(criteriaName)) {
                Criteria targetCriteria = target.get(criteriaName);
                targetCriteria.getCriteriaAttributes().putAll(
                        entry.getValue().getCriteriaAttributes()
                );
            } else {
                target.put(criteriaName, entry.getValue());
            }
        }
    }

}
