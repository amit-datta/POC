package com.macys.search.util.templatetests;

import com.macys.search.bizrules.validation.action.ActionValidationStrategy;
import com.macys.search.bizrules.validation.trigger.TriggerValidationStrategy;

public class ContextFactory {

    static AbstractTemplateTestContext createContext(Object strategy) {
        AbstractTemplateTestContext ctx = null;
        if (strategy instanceof ActionValidationStrategy) {
            ctx = new ActionTemplateTestContext((ActionValidationStrategy) strategy);
        } else if (strategy instanceof TriggerValidationStrategy) {
            ctx = new TriggerTemplateTestContext((TriggerValidationStrategy) strategy);
        }
        return ctx;
    }

}
