package com.macys.search.bizrules.converters.products;

import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESProduct;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.model.product.ProductToPool;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ProductConverterTest {

    private static final Map<Integer, ProcessingAction> actionMap = Map.of(
            101, createProcessingAction(101, "BOOST", List.of("1", "2"), List.of("1", "2")),
            102, createProcessingAction(102, "BOOST", List.of("3", "4"), List.of("3")),
            103, createProcessingAction(103, "BOOST", List.of(), List.of("4", "5")),

            104, createProcessingAction(104, "ADD", List.of("1", "2"), List.of()),
            105, createProcessingAction(105, "ADD", List.of("3", "4"), List.of("6", "7")),
            106, createProcessingAction(106, "ADD", List.of(), List.of()),

            107, createProcessingAction(107, "REPLACE", List.of("1", "2"), List.of()),
            108, createProcessingAction(108, "REPLACE", List.of("3", "4"), List.of("8")),

            109, createProcessingAction(109, "REMOVE", List.of("1", "2"), List.of()),
            110, createProcessingAction(110, "REMOVE", List.of("3", "4"), List.of("9", "10"))
    );

    private static final ProductConverter converter = new ProductConverter(
            new CategoryPathConverter(List.of()),
            actionMap,
            CategoryTree.from(List.of()),
            false
    );

    private static ProcessingAction createProcessingAction(Integer id, String type, List<String> pools, List<String> products) {
        Map<String, Criteria> criteriaMap = new HashMap<>();
        {
            Criteria operation = new Criteria();
            operation.setCriteriaAttributes(Map.of("Operation", List.of(type)));
            criteriaMap.put("Operations", operation);
        }
        if (!CollectionUtils.isEmpty(pools)) {
            Criteria poolsCriteria = new Criteria();
            criteriaMap.put("Pool", poolsCriteria);
            poolsCriteria.setCriteriaAttributes(Map.of("PoolId", pools));
        }
        if (!CollectionUtils.isEmpty(products)) {
            Criteria productCriteria = new Criteria();
            criteriaMap.put("Product", productCriteria);
            productCriteria.setCriteriaAttributes(Map.of("ProductId", products));
        }

        Action action = new Action();
        action.setId(id);
        action.setCriteriaMap(criteriaMap);
        return ProcessingAction.from(action);
    }

    @Test
    void testBoost() {
        Product product = Product.builder()
                .productId(1)
                .members(List.of())
                .pools(List.of(ProductToPool.builder().poolId(3).build()))
                .parentCategories(List.of())
                .build();

        Map<String, ?> actual = converter.convert(product).getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 1,
                "msr_boost", Set.of(102, 101),
                "msr_add", Set.of(105),
                "msr_replace", Set.of(108),
                "msr_remove", Set.of(110)
        );
        assertEquals(expected, actual);
    }

    @Test
    void doNotDuplicateIds() {
        Product product = Product.builder()
                .productId(1)
                .members(List.of())
                .pools(List.of(
                        ProductToPool.builder().poolId(1).build(),
                        ProductToPool.builder().poolId(3).build()
                ))
                .parentCategories(List.of())
                .build();

        Map<String, ?> actual = converter.convert(product).getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 1,
                "msr_boost", Set.of(102, 101),
                "msr_add", Set.of(104, 105),
                "msr_replace", Set.of(107, 108),
                "msr_remove", Set.of(109, 110)
        );
        assertEquals(expected, actual);
    }

    @Test
    void onlyProductBy() {
        Product product = Product.builder()
                .productId(8)
                .members(List.of())
                .pools(List.of())
                .parentCategories(List.of())
                .build();

        Map<String, ?> actual = converter.convert(product).getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 8,
                "msr_replace", Set.of(108)
        );
        assertEquals(expected, actual);
    }

    @Test
    void noMsr() {
        Product product = Product.builder()
                .productId(11)
                .members(List.of())
                .pools(List.of())
                .parentCategories(List.of())
                .build();

        Map<String, ?> actual = converter.convert(product).getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 11
        );
        assertEquals(expected, actual);
    }

    @Test
    void allPools() {
        Product product = Product.builder()
                .productId(4)
                .members(List.of())
                .pools(List.of(
                        ProductToPool.builder().poolId(1).build(),
                        ProductToPool.builder().poolId(2).build(),
                        ProductToPool.builder().poolId(3).build(),
                        ProductToPool.builder().poolId(4).build(),
                        ProductToPool.builder().poolId(5).build(),
                        ProductToPool.builder().poolId(6).build()
                ))
                .parentCategories(List.of())
                .build();

        Map<String, ?> actual = converter.convert(product).getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 4,
                "msr_boost", Set.of(101, 102, 103),
                "msr_add", Set.of(104, 105),
                "msr_replace", Set.of(107, 108),
                "msr_remove", Set.of(109, 110)
        );
        assertEquals(expected, actual);
    }

    @Test
    void testProductIdAndCategoryFields() {
        ProductConverter productIdConverter = new ProductConverter(
                new CategoryPathConverter(List.of()) {
                    @Override
                    public void convert(Product product, ESProduct esProduct, CategoryTree categoryTree) {
                        esProduct.setCatIds(List.of(1, 3, 6));
                        esProduct.setCatPaths(List.of("1", "1 > 2"));
                    }
                }, Map.of(), CategoryTree.from(List.of()),
                false
        );

        Product product = Product.builder()
                .productId(123)
                .members(List.of())
                .pools(List.of())
                .build();

        Map<String, ?> actual = productIdConverter.convert(product).getSource();
        Map<String, ?> expected = Map.of(
                "product_id", 123,
                "cat_ids", List.of(1, 3, 6),
                "cat_paths", List.of("1", "1 > 2")

        );
        assertEquals(expected, actual);
    }

}