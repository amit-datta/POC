package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ProductRedirectConverterTest {

    private final ProductRedirectConverter converter = new ProductRedirectConverter();

    @Test
    void convert() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.ProductRedirect);
        Criteria criteria = new Criteria();
        action.setCriteriaMap(Map.of(
                "Product", criteria
        ));
        criteria.setCriteriaAttributes(
                Map.of(
                        "ProductId", List.of("32")
                )
        );
        ESAction actual = converter.convert(action, null);
        assertEquals("32", actual.getSource().get("product_redirect_id"));
    }

}