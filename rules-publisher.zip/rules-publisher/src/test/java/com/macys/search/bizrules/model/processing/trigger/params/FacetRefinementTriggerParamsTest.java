package com.macys.search.bizrules.model.processing.trigger.params;

import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.macys.search.bizrules.model.mrf.trigger.FacetRefinementMatchType.exact_and;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FacetRefinementTriggerParamsTest {

    @Test
    void generateTriggers() {
        FacetRefinementTriggerParams params = FacetRefinementTriggerParams.builder()
                .triggerId(123)
                .refinements(Map.of(
                        "odd", Set.of("1", "3"),
                        "colors", Set.of("red")
                ))
                .matchType(exact_and)
                .build();
        List<ESTrigger> actualTriggers = params.generateTriggers();
        assertEquals(1, actualTriggers.size());
        assertEquals(Map.of(
                "trigger_id", 123,
                "trigger_type", "FacetRefinement",
                "frt_match_type", exact_and,
                "colors", Set.of("red"),
                "odd", Set.of("1", "3"),
                "frt_ref_count", 2
        ), actualTriggers.get(0).getSource());
    }
}