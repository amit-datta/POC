package com.macys.search.analysis;

import com.macys.search.BaseTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;

class KeywordPhraseAnalyzerTest extends BaseTest {

    @Autowired
    PhraseAnalyzerFactory factory;

    @Test
    void lowerCase() {
        assertEquals("jaba", factory.createExactPhraseAnalyzer().analise("JaBa"));
    }

    @Test
    void spaceTrimming() {
        assertEquals("brew beer", factory.createExactPhraseAnalyzer().analise("   brew    beer  "));
    }

    @Test
    void asciFolding() {
        assertEquals("jeans", factory.createExactPhraseAnalyzer().analise("jeáns"));
    }

    @Test
    void specSymbolReplacing() {
        assertEquals("jeans", factory.createExactPhraseAnalyzer().analise("! !#@ @j@e#a!n@s! @!# #"));
    }

    @Test
    void multipleUsageTest() {
        assertEquals("java is the best language", factory.createExactPhraseAnalyzer().analise("Java is The Best Language"));
        assertEquals("best language", factory.createExactPhraseAnalyzer().analise("Best Language"));
    }
}