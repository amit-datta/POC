package com.macys.search.bizrules.tasklets.esmanaging;

import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.tasklets.AbstractTaskletTest;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

class RemoveIndicesTaskletTest extends AbstractTaskletTest {

    @Mock
    private ElasticSearchFacade facade;

    @Test
    void removeESIndexTest() {
        final String indexName = "UNDER_removeESIndexTest";
        Mockito.doNothing().when(facade).deleteIndices(indexName);

        ProcessingContext ctx = ProcessingContext.initContext(contribution, chunkContext);
        ctx.setupIndex(ESIndex.KWP_TRIGGERS, indexName, null);

        RemoveIndicesTasklet underTestTasklet = new RemoveIndicesTasklet(facade);
        Assertions.assertThrows(RuntimeException.class, () -> underTestTasklet.execute(contribution, chunkContext));

        Mockito.verify(facade, Mockito.times(1)).deleteIndices(indexName);
    }

}