package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.util.templatetests.TemplateTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class SeoControlValidationStrategyTest extends BaseTest {

    @Autowired
    SeoControlValidationStrategy strategy;

    @Test
    void templateLoaded() {
        assertNotNull(strategy.getTemplate());
    }

    @Test
    void applicableFor() {
        assertEquals(ActionType.SeoControl, strategy.applicableFor());
    }

    @Test
    void templateTest() {
        TemplateTest.uniqPossibleValuesTemplateCompositeTest(strategy,
                Collections.emptyMap(),
                "SeoParameters",
                "IndexFollow",
                Arrays.asList("N", "Y"));
    }

}