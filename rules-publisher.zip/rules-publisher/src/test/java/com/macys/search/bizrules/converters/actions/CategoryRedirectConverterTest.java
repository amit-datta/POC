package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CategoryRedirectConverterTest {

    private final CategoryRedirectConverter converter = new CategoryRedirectConverter();

    @Test
    void convert() {
        Action action = new Action();
        action.setId(1);
        action.setMerchActionType(ActionType.CategoryRedirect);
        Criteria criteria = new Criteria();
        action.setCriteriaMap(Map.of(
                "Category", criteria
        ));
        criteria.setCriteriaAttributes(
                Map.of(
                        "CategoryId", List.of("57")
                )
        );
        ESAction actual = converter.convert(action, null);
        assertEquals("57", actual.getSource().get("category_redirect_id"));
    }

}