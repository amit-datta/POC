package com.macys.search.bizrules.validation.action;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.util.templatetests.TemplateTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Map;

import static com.macys.search.bizrules.model.mrf.action.ActionType.ModifySearchResults;
import static com.macys.search.util.TestUtils.*;
import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.*;

class ModifySearchResultActionValidationStrategyTest extends BaseTest {
    @Autowired
    ModifySearchResultActionValidationStrategy strategy;

    Action action = new Action();

    @BeforeEach
    public void reset() {
        action = new Action();
        action.setId(1235);
        action.setMerchActionType(ModifySearchResults);
    }

    @Test
    void applicableFor() {
        assertEquals(ModifySearchResults, strategy.applicableFor());
    }

    @Test
    void validateAttrGrpWithoutOperation() {
        action.setCriteriaMap(toMap(singletonList(criteria("AttributesGroup777"))));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Missing criteria with name=Operations.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpProhibitPoolCriteria() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Pool")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria map contains AttributesGroup and group of Pool or Product.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpProhibitProductCriteria() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Product")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria map contains AttributesGroup and group of Pool or Product.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpOperationsWithoutOperation() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Operations")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. Criteria=Operations has missing attribute with name=Operation.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpOperationWithoutValues() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Operations", attr("Operation"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. In Criteria Operations attribute Operation must contain value but it is empty.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpOperationWithMultipleValues() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Operations", attr("Operation", "1", "2"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. In Criteria Operations attribute Operation must contain only one value. But its values=[1, 2].";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpOperationWithValueNotInPossibleList() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Operations", attr("Operation", "wrong"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. In criteria Operations attribute Operation contains unexpected values. Possible values=[BOOST], real values=[wrong].";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpNotMatchPattern() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("AttributesGroup7-7"),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "AttributesGroup7-7 does not follow AttributesGroup[0-9] pattern.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpWithoutAttributes() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777"),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria AttributesGroup777 does not have any attributes";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpWithAttributes() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777",
                        attr("SECOND_ATTR", "value"),
                        attr("FIRST_ATTR")),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Attribute name is blank or values is empty in criteria name=AttributesGroup777 attribute=FIRST_ATTR=[]";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpBlankAttrName() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("AttributesGroup777",
                        attr("FIRST_ATTR", "value"),
                        attr("    ", "value_0")
                ),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Attribute name is blank or values is empty in criteria name=AttributesGroup777 attribute=    =[value_0]";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpValid() {
        Criteria attrCriteria = criteria("AttributesGroup777",
                attr("ATTR_ONE", "value_0"),
                attr("ATTR_TWO", "value_0", "value_2")
        );
        attrCriteria.setSequenceGroupNumber(100);
        action.setCriteriaMap(toMap(Arrays.asList(
                attrCriteria,
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

    @Test
    void validateAttrGrpNonValidSeqGroup() {
        Criteria attrCriteria = criteria("AttributesGroup777",
                attr("ATTR_ONE", "value_0"),
                attr("ATTR_TWO", "value_0", "value_2")
        );
        action.setCriteriaMap(toMap(Arrays.asList(
                attrCriteria,
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Sequence group number should be positive integer. Criteria name=AttributesGroup777, sequence number=null";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateAttrGrpNegativeSeqGroup() {
        Criteria attrCriteria = criteria("AttributesGroup777",
                attr("ATTR_ONE", "value_0"),
                attr("ATTR_TWO", "value_0", "value_2")
        );
        attrCriteria.setSequenceGroupNumber(-100);
        action.setCriteriaMap(toMap(Arrays.asList(
                attrCriteria,
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Sequence group number should be positive integer. Criteria name=AttributesGroup777, sequence number=-100";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupTypesContainsExtra() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Operations"),
                criteria("Pool"),
                criteria("Product"),
                criteria("ANY_OTHER")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Invalid groups exist in [Product, Pool, Operations, ANY_OTHER] compare to possible ones [Operations, Pool, Product]";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupTypesMissingMandatoryOperations() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool"),
                criteria("Product")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Missing criteria with name=Operations.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupTypesMissingMandatoryOperationAttribute() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool"),
                criteria("Product"),
                criteria("Operations")
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. Criteria=Operations has missing attribute with name=Operation.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupTypesEmptyOperation() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool"),
                criteria("Product"),
                criteria("Operations", attr("Operation"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. In Criteria Operations attribute Operation must contain value but it is empty.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupTypesUniqOperation() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool"),
                criteria("Product"),
                criteria("Operations", attr("Operation", "BOOST", "ADD"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. In Criteria Operations attribute Operation must contain only one value. But its values=[BOOST, ADD].";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupTypesPossibleValueOperation() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool"),
                criteria("Product"),
                criteria("Operations", attr("Operation", "WRONG"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "Criteria with name=Operations validation failed. In criteria Operations attribute Operation contains unexpected values. Possible values=[BOOST, ADD, REPLACE, REMOVE], real values=[WRONG].";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

    @Test
    void validateGroupValidProduct() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Product", attr("ProductId", "1")),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

    @Test
    void validateGroupValidProductInvalidPool() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Product", attr("ProductId", "1")),
                criteria("Pool"),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

    @Test
    void validateGroupValidPool() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool", attr("PoolId", "2")),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

    @Test
    void validateGroupValidPoolInvalidProduct() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Product", attr("PoolId", "2")),
                criteria("Pool", attr("PoolId", "2")),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        assertTrue(strategy.validate(action).isValid());
    }

    @Test
    void innerValidateProduct() {
        Map<String, Criteria> additionalMap = toMap(singletonList(
                criteria("Operations", attr("Operation", "BOOST"))
        ));
        TemplateTest.positiveIntegerTemplateCompositeTest(strategy, additionalMap, "Product", "ProductId");
    }

    @Test
    void innerValidatePool() {
        Map<String, Criteria> additionalMap = toMap(singletonList(
                criteria("Operations", attr("Operation", "BOOST"))
        ));
        TemplateTest.positiveIntegerTemplateCompositeTest(strategy, additionalMap, "Pool", "PoolId");
    }

    @Test
    void validateGroupProductAndPoolAreBothInvalid() {
        action.setCriteriaMap(toMap(Arrays.asList(
                criteria("Pool", attr("PoolId", "aba")),
                criteria("Product", attr("ProductId", "caba")),
                criteria("Operations", attr("Operation", "BOOST"))
        )));
        ValidationResult validationResult = strategy.validate(action);
        assertFalse(validationResult.isValid());
        String expectedMessage = "At least one of groups: Product, Pool should be valid.";
        assertEquals(expectedMessage, validationResult.getWarning());
    }

}