package com.macys.search.bizrules.repository.mrf;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.util.ContextUtils;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.springframework.batch.core.JobParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.jdbc.Sql;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.tasklets.JobParams.SITE_NAME_JOB_PARAM;

public class TriggersReaderTest extends BaseTest {

    private static final ProcessingContext context = ContextUtils.createProcessingContext(Map.of(
            SITE_NAME_JOB_PARAM, new JobParameter("MCOM")
    ));

    @Value("${rules.publisher.enabled.trigger-types}")
    private List<TriggerType> enabledTriggerTypes;
    @Autowired
    private TriggersReader triggersReader;

    @Test
    @Sql({"classpath:triggers/data.sql"})
    public void testReadTriggers() {
        Map<Integer, ProcessingTrigger> actual = new HashMap<>();
        Trigger expectedTrigger = createTrigger(1, TriggerType.KeywordPattern, "test",
                true, false, (LocalDate.of(2013, Month.APRIL, 19)));
        Trigger expectedTrigger1 = createTrigger(2, TriggerType.FacetRefinement, "y124123",
                false, false, LocalDate.of(2014, Month.APRIL, 3));
        Trigger expectedTrigger2 = createTrigger(3, TriggerType.HierarchicalRefinement, "UN_Phase0_Migration",
                true, false, LocalDate.of(2014, Month.MAY, 10));
        triggersReader.readTriggers(context, enabledTriggerTypes, actual);
        Assertions.assertEquals(3, actual.size());
        ProcessingTrigger actualProcessingTrigger = actual.get(1);
        ProcessingTrigger actualProcessingTrigger1 = actual.get(2);
        ProcessingTrigger actualProcessingTrigger2 = actual.get(3);

        Assertions.assertEquals(expectedTrigger, actualProcessingTrigger.getTrigger());
        Assertions.assertEquals(expectedTrigger1, actualProcessingTrigger1.getTrigger());
        Assertions.assertEquals(expectedTrigger2, actualProcessingTrigger2.getTrigger());
    }

    @Test
    @Sql({"classpath:triggers/data.sql"})
    public void testGetTriggerById() {
        Trigger expected = createTrigger(1, TriggerType.KeywordPattern, "test", true,
                false, (LocalDate.of(2013, Month.APRIL, 19)));
        Trigger actual = triggersReader.getTriggerById(SiteName.MCOM, 1, enabledTriggerTypes);

        Assertions.assertEquals(expected, actual);
    }

    private Trigger createTrigger(Integer id, TriggerType triggerType, String name, boolean isSearchable,
                                  boolean isResSetReq, LocalDate date) {
        Trigger expected = new Trigger();
        expected.setId(id);
        expected.setMerchTriggerType(triggerType);
        expected.setParams(List.of());
        expected.setAuthorName(name);
        expected.setLastModifiedByName(name);
        expected.setSearchable(isSearchable);
        expected.setResultSetRequired(isResSetReq);
        expected.setLastModified(date);
        expected.setCreatedDate(date);
        return expected;
    }
}