package com.macys.search.bizrules.converters.products.filters;

import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import com.macys.search.bizrules.model.product.Price;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.model.product.Upc;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ColorwayPriceCategoryFilterTest {

    private final ColorwayPriceCategoryFilter filter = new ColorwayPriceCategoryFilter();

    @Test
    void categoryDoesNotContainPriceFilter() {
        Category category = Category.builder().attributes(Map.of()).build();
        Product product = Product.builder().build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void testPriceType() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1", "2"))
                        .build()
        )).build();
        Product product = Product.builder()
                .members(List.of())
                .upcs(List.of(
                        upc(2, null, true),
                        upc(3, null, true)
                ))
                .build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void testNoAvailableUpc() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1", "2"))
                        .build()
        )).build();
        Product product = Product.builder()
                .members(List.of())
                .upcs(List.of(
                        upc(2, null, false),
                        upc(3, null, true)
                ))
                .build();
        assertFalse(filter.pass(category, product));
    }

    @Test
    void noUpc() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1", "2"))
                        .build()
        )).build();
        Product product = Product.builder()
                .members(List.of())
                .upcs(List.of())
                .build();
        assertFalse(filter.pass(category, product));
    }

    @Test
    void masterProduct() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1", "2"))
                        .build()
        )).build();
        Product product = Product.builder().members(List.of())
                .upcs(List.of(upc(2, null, true))).build();
        assertTrue(filter.pass(category, product));
    }

    @Test
    void masterProductFail() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1", "2"))
                        .build()
        )).build();
        Product product = Product.builder().members(List.of())
                .upcs(List.of(upc(3, null, true))).build();
        assertFalse(filter.pass(category, product));
    }

    @Test
    void testNoRetailPrice() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MIN,
                CategoryAttribute.builder()
                        .values(Set.of("1"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MAX,
                CategoryAttribute.builder()
                        .values(Set.of("10"))
                        .build()
        )).build();
        Product product = Product.builder()
                .members(List.of())
                .upcs(List.of(
                        upc(1, null, true)
                ))
                .build();
        assertFalse(filter.pass(category, product));
    }

    @Test
    void testRetailPrice1_10() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MIN,
                CategoryAttribute.builder()
                        .values(Set.of("1"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MAX,
                CategoryAttribute.builder()
                        .values(Set.of("10"))
                        .build()
        )).build();
        assertTrue(filter.pass(category, product(upc(1, 5d, true))));
        assertTrue(filter.pass(category, product(upc(1, 8d, true))));
        assertFalse(filter.pass(category, product(upc(1, 8d, false))));
        assertTrue(filter.pass(category, product(upc(1, 10d, true))));
        assertTrue(filter.pass(category, product(upc(1, 1d, true))));

        assertFalse(filter.pass(category, product(upc(1, 10.5d, true))));
        assertFalse(filter.pass(category, product(upc(1, 0.5d, true))));
    }

    @Test
    void testRetailPriceMin5() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MIN,
                CategoryAttribute.builder()
                        .values(Set.of("5"))
                        .build()
        )).build();
        assertTrue(filter.pass(category, product(upc(1, 5d, true))));
        assertTrue(filter.pass(category, product(upc(1, 8d, true))));
        assertFalse(filter.pass(category, product(upc(1, 8d, false))));
        assertFalse(filter.pass(category, product(upc(1, 4d, true))));
    }

    @Test
    void testRetailPriceWithoutTypeFilter() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_RANGE_MIN,
                CategoryAttribute.builder()
                        .values(Set.of("50"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MAX,
                CategoryAttribute.builder()
                        .values(Set.of("99.99"))
                        .build()
        )).build();
        assertTrue(filter.pass(category, product(upc(1, 51d, true))));
        assertTrue(filter.pass(category, product(upc(1, 80d, true))));
        assertFalse(filter.pass(category, product(upc(1, 80d, false))));
        assertFalse(filter.pass(category, product(upc(1, 44.99d, true))));
    }

    @Test
    void testRetailPriceMax5() {
        Category category = Category.builder().attributes(Map.of(
                CategoryAttributeName.PRICE_FILTER,
                CategoryAttribute.builder()
                        .values(Set.of("1"))
                        .build(),
                CategoryAttributeName.PRICE_RANGE_MAX,
                CategoryAttribute.builder()
                        .values(Set.of("5"))
                        .build()
        )).build();
        assertTrue(filter.pass(category, product(upc(1, 5d, true))));
        assertFalse(filter.pass(category, product(upc(1, 8d, true))));
        assertFalse(filter.pass(category, product(upc(1, 4d, false))));
        assertTrue(filter.pass(category, product(upc(1, 4d, true))));
    }

    private static Product product(Upc... upcs) {
        return Product.builder()
                .members(List.of())
                .upcs(Arrays.asList(upcs))
                .build();
    }

    private static Upc upc(Integer priceType, Double retailPrice, Boolean available) {
        Upc.UpcBuilder builder = Upc.builder();
        if (priceType != null) {
            Price price = Price.builder()
                    .priceType(priceType)
                    .retailPrice(retailPrice)
                    .build();
            builder.price(price);
        }
        if (available != null) {
            builder.available(available);
        }
        return builder.build();
    }

}