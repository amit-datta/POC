package com.macys.search.bizrules.services;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.services.merch.ActionsService;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MerchPermissionsCheckerServiceTest extends BaseTest {

    @Autowired
    private ActionsService actionsService;
    private final ProcessingContext ctx = new ProcessingContext();

    @Test
    void emptyRuleIdsTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(Set.of(), Set.of("A", "B", "C"));
        assertTrue(service.redirectRulesValidation(1, ActionType.URLRedirect));
    }

    @Test
    void redirectNotInWhiteListTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(Set.of(2, 3), Set.of("A", "B", "C"));
        assertFalse(service.redirectRulesValidation(1, ActionType.URLRedirect));
    }

    @Test
    void nonRedirectNotInWhiteListTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(Set.of(2, 3), Set.of("A", "B", "C"));
        assertTrue(service.redirectRulesValidation(1, ActionType.ModifySearchResults));
    }

    @Test
    void redirectInWhiteListTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(Set.of(2, 3), Set.of("A", "B", "C"));
        assertTrue(service.redirectRulesValidation(2, ActionType.ModifySearchResults));
    }

    @Test
    void msrReplaceTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(null, Set.of("A", "B", "C"));
        Rule ruleD = new Rule();
        ruleD.setLastModifiedByName("D");
        Rule ruleA = new Rule();
        ruleA.setLastModifiedByName("A");
        Action action = new Action();
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of(MSR_OPERATION, List.of("REPLACE")));
        Criteria pool = new Criteria();
        pool.setCriteriaAttributes(Map.of(MSR_POOL_ID, List.of("1")));
        action.setCriteriaMap(Map.of(
                MSR_OPERATIONS, operation,
                MSR_POOL, pool
        ));
        ctx.setActions(Map.of(1, ProcessingAction.from(action)));
        assertTrue(service.checkExtendedPermission(ruleA, actionsService.getProcessedAction(1, ctx)));
        assertFalse(service.checkExtendedPermission(ruleD, actionsService.getProcessedAction(1, ctx)));
    }

    @Test
    void msrRemoveTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(null, Set.of("A", "B", "C"));
        Rule ruleD = new Rule();
        ruleD.setLastModifiedByName("D");
        Rule ruleA = new Rule();
        ruleA.setLastModifiedByName("A");
        Action action = new Action();
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of(MSR_OPERATION, List.of("REMOVE")));
        Criteria pool = new Criteria();
        pool.setCriteriaAttributes(Map.of(MSR_POOL_ID, List.of("1")));
        action.setCriteriaMap(Map.of(
                MSR_OPERATIONS, operation,
                MSR_POOL, pool
        ));
        ctx.setActions(Map.of(1, ProcessingAction.from(action)));
        assertTrue(service.checkExtendedPermission(ruleA, actionsService.getProcessedAction(1, ctx)));
        assertFalse(service.checkExtendedPermission(ruleD, actionsService.getProcessedAction(1, ctx)));
    }

    @Test
    void msrBoostTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(null, Set.of("A", "B", "C"));
        Rule ruleD = new Rule();
        ruleD.setLastModifiedByName("D");
        Rule ruleA = new Rule();
        ruleA.setLastModifiedByName("A");
        Action action = new Action();
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of(MSR_OPERATION, List.of("BOOST")));
        Criteria pool = new Criteria();
        pool.setCriteriaAttributes(Map.of(MSR_POOL_ID, List.of("1")));
        action.setCriteriaMap(Map.of(
                MSR_OPERATIONS, operation,
                MSR_POOL, pool
        ));
        ctx.setActions(Map.of(1, ProcessingAction.from(action)));
        assertTrue(service.checkExtendedPermission(ruleA, actionsService.getProcessedAction(1, ctx)));
        assertTrue(service.checkExtendedPermission(ruleD, actionsService.getProcessedAction(1, ctx)));
    }

    @Test
    void msrAddTest() {
        MerchPermissionsCheckerService service = new MerchPermissionsCheckerService(null, Set.of("A", "B", "C"));
        Rule ruleD = new Rule();
        ruleD.setLastModifiedByName("D");
        Rule ruleA = new Rule();
        ruleA.setLastModifiedByName("A");
        Action action = new Action();
        action.setMerchActionType(ActionType.ModifySearchResults);
        Criteria operation = new Criteria();
        operation.setCriteriaAttributes(Map.of(MSR_OPERATION, List.of("BOOST")));
        Criteria pool = new Criteria();
        pool.setCriteriaAttributes(Map.of(MSR_POOL_ID, List.of("1")));
        action.setCriteriaMap(Map.of(
                MSR_OPERATIONS, operation,
                MSR_POOL, pool
        ));
        ctx.setActions(Map.of(1, ProcessingAction.from(action)));
        assertTrue(service.checkExtendedPermission(ruleA, actionsService.getProcessedAction(1, ctx)));
        assertTrue(service.checkExtendedPermission(ruleD, actionsService.getProcessedAction(1, ctx)));
    }

}