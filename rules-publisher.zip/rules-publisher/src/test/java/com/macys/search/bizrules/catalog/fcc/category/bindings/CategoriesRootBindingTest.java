package com.macys.search.bizrules.catalog.fcc.category.bindings;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CategoriesRootBindingTest {

    String body = "{\n" +
            "    \"categories\": {\n" +
            "        \"category\": [\n" +
            "            {\n" +
            "                \"id\": 1,\n" +
            "                \"name\": \"Men\",\n" +
            "                \"link\": []\n" +
            "            }\n" +
            "        ]\n" +
            "    }\n" +
            "}";

    ObjectMapper mapper = new ObjectMapper();

    @Test
    void getCategories() throws JsonProcessingException {
        CategoriesRootBinding actual = mapper.readValue(body, CategoriesRootBinding.class);
        assertNotNull(actual.getCategories());
        assertEquals(1, actual.getCategories().getCategory().size());
    }
}