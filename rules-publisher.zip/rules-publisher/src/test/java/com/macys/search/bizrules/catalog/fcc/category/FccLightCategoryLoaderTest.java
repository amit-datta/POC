package com.macys.search.bizrules.catalog.fcc.category;

import com.macys.search.BaseTest;
import com.macys.search.bizrules.catalog.fcc.FccField;
import com.macys.search.bizrules.catalog.fcc.category.bindings.CategoriesBinding;
import com.macys.search.bizrules.catalog.fcc.category.bindings.CategoriesRootBinding;
import com.macys.search.bizrules.catalog.fcc.category.bindings.CategoryBinding;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FccLightCategoryLoaderTest extends BaseTest {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private Collection<FccField> fccLightCategoryFields;

    @Test
    void testGetPathWithParams() {
        CategoryLoaderImpl fccCategoryLoader = getFCCLightCategoryLoader();
        assertNotNull(fccCategoryLoader.getPathWithParams());
    }

    @Test
    void testIterator() {
        CategoryLoaderImpl fccCategoryLoader = getFCCLightCategoryLoader();
        assertNotNull(fccCategoryLoader.iterator(SiteName.MCOM, new TimeStatistics()));
    }

    @Test
    void testIsBatchEmpty() {
        CategoryLoaderImpl fccCategoryLoader = getFCCLightCategoryLoader();
        assertTrue(fccCategoryLoader.isBatchEmpty(new CategoriesRootBinding()));
    }

    @Test
    void testIsBatchNonEmpty() {
        CategoryLoaderImpl fccCategoryLoader = getFCCLightCategoryLoader();
        CategoriesRootBinding categoriesRootBinding = new CategoriesRootBinding();
        CategoriesBinding categoriesBinding = new CategoriesBinding();
        categoriesBinding.setCategory(List.of(new CategoryBinding()));
        categoriesRootBinding.setCategories(categoriesBinding);
        assertFalse(fccCategoryLoader.isBatchEmpty(categoriesRootBinding));
    }

    @Test
    void testConvert() {
        CategoryLoaderImpl fccCategoryLoader = getFCCLightCategoryLoader();
        CategoriesRootBinding categoriesRootBinding = new CategoriesRootBinding();
        CategoriesBinding categoriesBinding = new CategoriesBinding();
        categoriesBinding.setCategory(List.of());
        categoriesRootBinding.setCategories(categoriesBinding);
        assertTrue(fccCategoryLoader.convert(categoriesRootBinding).isEmpty());
    }

    private CategoryLoaderImpl getFCCLightCategoryLoader() {
        return new CategoryLoaderImpl(restTemplate, "http://mcom:8080/endpoint", "http://bcom:8080/endpoint",
                5, 3, 3, fccLightCategoryFields);
    }
}
