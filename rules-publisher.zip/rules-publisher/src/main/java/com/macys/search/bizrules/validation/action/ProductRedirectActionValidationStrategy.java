package com.macys.search.bizrules.validation.action;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import lombok.AccessLevel;
import lombok.Getter;
import org.springframework.stereotype.Component;

/**
 * Implementation of validation strategy for action {@link com.macys.search.bizrules.model.mrf.action.ActionType#ProductRedirect}
 * validates that given actionConfig {@link Action} contains unary attribute ProductId and it's value
 * is positive integer value.
 */
@Component
public class ProductRedirectActionValidationStrategy extends AbstractActionCriteriaValidationStrategy {

    @Getter(AccessLevel.PACKAGE)
    @ResourceMapping("classpath:merch-validation-template/action/ProductRedirect.json")
    private ConfigTemplate template;

    @Override
    public ActionType applicableFor() {
        return ActionType.ProductRedirect;
    }

}
