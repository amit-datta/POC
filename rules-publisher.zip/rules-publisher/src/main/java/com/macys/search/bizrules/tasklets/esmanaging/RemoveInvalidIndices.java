package com.macys.search.bizrules.tasklets.esmanaging;

import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;

@Slf4j
@Component
@RequiredArgsConstructor
public class RemoveInvalidIndices implements RulesPublisherTasklet {

    private final ElasticSearchFacade elasticSearchFacade;
    private final CommonIndexProperties mcomCommonIndexProperties;
    private final CommonIndexProperties bcomCommonIndexProperties;

    public void execute(ProcessingContext ctx) {
        String alias = ctx.isMCOM() ? mcomCommonIndexProperties.getUnfinishedIndicesAliasName() :
                bcomCommonIndexProperties.getUnfinishedIndicesAliasName();
        Collection<String> indicesWithAlias = elasticSearchFacade.getIndicesWithAlias(Collections.singletonList(alias));
        if (indicesWithAlias.isEmpty()) {
            return;
        }
        elasticSearchFacade.deleteIndices(indicesWithAlias.toArray(String[]::new));
        log.info("Removed next invalid indices {} ", indicesWithAlias);
    }
}
