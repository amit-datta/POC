package com.macys.search.bizrules.services;

import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

import static org.springframework.util.CollectionUtils.isEmpty;

/**
 * Set of functions to check permissions for special cases.
 * <ul>
 *     <li>Extended permissions required for - MSR replace and remove</li>
 *     <li>Extended permissions required for - long redirect rules</li>
 *     <li>Redirect action enabled either ids white list is empty or rule id in white list</li>
 * </ul>
 */
@Component
public class MerchPermissionsCheckerService {

    private final Set<Integer> redirectRuleIdsWhitelist;
    private final Set<String> longRulesUsernamesWhitelist;

    public MerchPermissionsCheckerService(
            @Value("${rules.publisher.redirect.rule.ids.whitelist}") Set<Integer> redirectRuleIdsWhitelist,
            @Value("${rules.publisher.long.running.rules.usernames.whitelist}") Set<String> longRulesUsernamesWhitelist) {
        this.redirectRuleIdsWhitelist = redirectRuleIdsWhitelist;
        this.longRulesUsernamesWhitelist = longRulesUsernamesWhitelist.stream()
                .map(String::toLowerCase)
                .collect(Collectors.toSet());
    }

    public boolean redirectRulesValidation(Integer ruleId, ActionType type) {
        if (type != ActionType.ProductRedirect &&
                type != ActionType.CategoryRedirect &&
                type != ActionType.URLRedirect) {
            return true;
        }
        return isEmpty(redirectRuleIdsWhitelist) || redirectRuleIdsWhitelist.contains(ruleId);
    }
    public boolean checkExtendedPermission(Rule rule, ProcessingAction action) {
        return !action.getEsActionType().isExtendedPermissionsForESActionsRequired() ||
                isUserNameInWhitePermissionsList(rule.getLastModifiedByName().toLowerCase());
    }

    private boolean isUserNameInWhitePermissionsList(String userName) {
        return longRulesUsernamesWhitelist.isEmpty() || longRulesUsernamesWhitelist.contains(userName.toLowerCase());
    }


}
