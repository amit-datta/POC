package com.macys.search.analysis;

import lombok.AllArgsConstructor;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.pattern.PatternReplaceCharFilter;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;

import java.io.*;
import java.util.regex.Pattern;

/**
 * Simple phrase analyser
 * <p>
 * This implementation is not thread-safe.
 * </p>
 */
@AllArgsConstructor
public class SimplePhraseAnalyzer implements PhraseAnalyzer {
    private final Pattern replacePattern;
    private final Tokenizer tokenizer;
    private final TokenStream tokenStream;

    @Override
    public String analise(String inputString) {
        try (Reader inputReader = new StringReader(inputString)) {
            Reader charFilter = inputReader;
            if (replacePattern != null) {
                charFilter = new PatternReplaceCharFilter(replacePattern, "", inputReader);
            }
            tokenizer.setReader(charFilter);
            tokenStream.reset();
            tokenStream.incrementToken();
            tokenStream.close();
            return tokenStream.getAttribute(CharTermAttribute.class).toString();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
