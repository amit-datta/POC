package com.macys.search.bizrules.rest;

import com.macys.search.bizrules.dto.GetJobStatusResponse;
import com.macys.search.bizrules.dto.IndexingStatusResponse;
import com.macys.search.bizrules.dto.PubSubTriggerResponse;
import com.macys.search.bizrules.dto.StartFullReindexingResponse;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.services.RuleMaintenanceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.launch.JobExecutionNotRunningException;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

import static com.macys.search.bizrules.enums.PubSubProcessType.START_INDEXING;
import static com.macys.search.bizrules.enums.PubSubProcessType.STOP_SESSION;

/**
 * Rule indexing rest controller
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class RuleMaintenanceController {

    private final RuleMaintenanceService ruleMaintenanceService;

    @PostMapping("/rules/indexing/job/start")
    public StartFullReindexingResponse startFullReindexing(@RequestParam SiteName siteName,
                                                           @RequestParam(required = false) String customDate) {
        return StartFullReindexingResponse.of(ruleMaintenanceService.startIndexing(siteName, customDate));
    }

    @GetMapping("/rules/indexing/job/{executionId}/status")
    public GetJobStatusResponse getReindexingStatus(@PathVariable Long executionId) {
        return GetJobStatusResponse.of(ruleMaintenanceService.getJobStatus(executionId));
    }

    @PostMapping("/rules/indexing/session/start")
    public PubSubTriggerResponse publishMessage(@RequestParam SiteName siteName) {
        return ruleMaintenanceService.publishMessage(siteName, UUID.randomUUID().toString(), START_INDEXING);
    }

    @GetMapping("/rules/indexing/session/{sessionId}/status")
    public IndexingStatusResponse getAllRegionsIndexingStatus(@PathVariable String sessionId) {
        return ruleMaintenanceService.getJobStatusBySessionId(sessionId);
    }

    @GetMapping("/rules/indexing/job/lastNDays")
    public List<GetJobStatusResponse> getAllJobsForTheLastNDays(@RequestParam Integer days) {
        return ruleMaintenanceService.getAllJobsForLastNDays(days);
    }

    @PostMapping("/rules/indexing/job/{executionId}/stop")
    public ResponseEntity<String> stopJob(@PathVariable Long executionId) throws NoSuchJobExecutionException,
            JobExecutionNotRunningException, NoSuchJobException {
        return ruleMaintenanceService.stopJob(executionId);
    }

    @PostMapping("/rules/indexing/session/{sessionId}/stop")
    public PubSubTriggerResponse stopSession(@PathVariable String sessionId) {
        return ruleMaintenanceService.publishMessage(null, sessionId, STOP_SESSION);
    }

}
