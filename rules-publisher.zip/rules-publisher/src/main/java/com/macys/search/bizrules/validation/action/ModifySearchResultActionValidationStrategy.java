package com.macys.search.bizrules.validation.action;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;
import static com.macys.search.bizrules.validation.CriteriaAttributesValidator.validateCriteriaMap;
import static java.text.MessageFormat.format;

/**
 * Validation correspond to following algorithm: This action has the following
 * parameters Group – "Operations" (validation: unique, mandatory)
 * </li>Parameter – "SubsetMode" (validation: unique, mandatory, values –
 * "KEEP") </li> Parameter – "OrderMode" (validation: unique, mandatory, values
 * – "OPERATION_BOOST")
 * <p/>
 * Group – "Pool" (validation: unique, mandatory) </li>Parameter – "PoolId"
 * (validation: mandatory, values – integers)
 */
@Slf4j
@Component
public class ModifySearchResultActionValidationStrategy implements ActionValidationStrategy {

    private static final String OPERATIONS = "Operations";

    private static final Pattern attributeGroupPattern = Pattern.compile("AttributesGroup[0-9]+");
    private static final List<String> GROUP_TYPES = Arrays.asList(OPERATIONS, MSR_POOL, MSR_PRODUCT);

    @ResourceMapping("classpath:merch-validation-template/action/MSRAttributeOperations.json")
    private ConfigTemplate attributeOperationsTemplate;
    @ResourceMapping("classpath:merch-validation-template/action/MSROperations.json")
    private ConfigTemplate operationsTemplate;
    @ResourceMapping("classpath:merch-validation-template/action/MSRPool.json")
    private ConfigTemplate poolTemplate;
    @ResourceMapping("classpath:merch-validation-template/action/MSRProduct.json")
    private ConfigTemplate productTemplate;

    @Override
    public ActionType applicableFor() {
        return ActionType.ModifySearchResults;
    }

    @Override
    public ValidationResult validate(Action action) {
        Optional<String> attributesGroup = action.getCriteriaMap().keySet().stream()
                .filter(name -> name.startsWith(MSR_ATTRIBUTES_GROUP))
                .findAny();

        if (attributesGroup.isPresent()) {
            return validateAttributesGroup(action);
        }

        if (!GROUP_TYPES.containsAll(action.getCriteriaMap().keySet())) {
            final String message = format("Invalid groups exist in {0} compare to possible ones {1}",
                    action.getCriteriaMap().keySet(), GROUP_TYPES);
            return ValidationResult.failResult(message);
        }

        ValidationResult operationValidateResult = validateCriteriaMap(action.getCriteriaMap(), operationsTemplate);
        if (!operationValidateResult.isValid()) {
            return operationValidateResult;
        }

        ValidationResult poolValidationResult = validateCriteriaMap(action.getCriteriaMap(), poolTemplate);
        if (poolValidationResult.isValid()) {
            return poolValidationResult;
        }

        ValidationResult productValidationResult = validateCriteriaMap(action.getCriteriaMap(), productTemplate);
        if (productValidationResult.isValid()) {
            return productValidationResult;
        }

        return ValidationResult.failResult("At least one of groups: Product, Pool should be valid.");
    }

    private ValidationResult validateAttributesGroup(Action action) {
        if (action.getCriteria(MSR_POOL) != null || action.getCriteria(MSR_PRODUCT) != null) {
            return ValidationResult.failResult("Criteria map contains AttributesGroup and group of Pool or Product.");
        }

        ValidationResult validationResult = validateCriteriaMap(action.getCriteriaMap(), attributeOperationsTemplate);
        if (!validationResult.isValid()) {
            return validationResult;
        }

        if (action.isNonEqualSeqNumberInSomeCriteria()) {
            return ValidationResult.failResult("MSR boost by attr contains different seq numbers into one group");
        }

        for (Map.Entry<String, Criteria> entry : action.getCriteriaMap().entrySet()) {
            String groupName = entry.getKey();
            Criteria criteria = entry.getValue();

            if (!groupName.startsWith(MSR_ATTRIBUTES_GROUP)) {
                continue;
            }

            if (!attributeGroupPattern.matcher(groupName).matches()) {
                return ValidationResult.failResult(format("{0} does not follow AttributesGroup[0-9] pattern.", groupName));
            }

            if (criteria.getCriteriaAttributes().isEmpty()) {
                return ValidationResult.failResult(format("Criteria {0} does not have any attributes", groupName));
            }

            for (Map.Entry<String, List<String>> criteriaAttributeEntry : criteria.getCriteriaAttributes().entrySet()) {
                if (StringUtils.isBlank(criteriaAttributeEntry.getKey()) || CollectionUtils.isEmpty(criteriaAttributeEntry.getValue())) {
                    String msg = "Attribute name is blank or values is empty in criteria name={0} attribute={1}";
                    return ValidationResult.failResult(format(msg, criteria.getCriteriaName(), criteriaAttributeEntry));
                }
            }

            if (criteria.getSequenceGroupNumber() == null || criteria.getSequenceGroupNumber() < 1) {
                String msg = "Sequence group number should be positive integer. Criteria name={0}, sequence number={1}";
                return ValidationResult.failResult(format(msg, criteria.getCriteriaName(), criteria.getSequenceGroupNumber()));
            }
        }
        return ValidationResult.validResult();
    }

}
