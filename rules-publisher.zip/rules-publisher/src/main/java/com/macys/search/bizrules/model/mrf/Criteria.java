package com.macys.search.bizrules.model.mrf;

import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Contains parsed merch params
 */
@Data
public class Criteria implements Serializable {
    private String criteriaName;
    //todo eliminate 3 map to one with complex value
    private Map<String, List<String>> criteriaAttributes = new HashMap<>();
    private Map<String, List<DateAwareAttribute>> criteriaDateAwareAttributes = new HashMap<>();
    private Map<String, List<Integer>> attributeToSeqNumbersMap = new HashMap<>();
    private Integer sequenceGroupNumber;
}
