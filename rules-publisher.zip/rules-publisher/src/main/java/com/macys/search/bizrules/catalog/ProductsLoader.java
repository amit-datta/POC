package com.macys.search.bizrules.catalog;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Iterator;

public interface ProductsLoader {

    /**
     * Load all products from resource
     *
     * @param siteName          site name
     * @param customDate        custom date
     * @param timeStatistics    time statistics
     * @return collection of products
     */
    Collection<Product> loadAll(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics);

    /**
     * @param siteName          site name
     * @param customDate        custom date
     * @param timeStatistics    time statistics
     * @return iterator on collection of categories
     */
    Iterator<Product> iterator(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics);
}
