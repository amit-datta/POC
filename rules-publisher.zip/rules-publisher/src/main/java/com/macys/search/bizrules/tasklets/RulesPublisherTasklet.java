package com.macys.search.bizrules.tasklets;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.lang.NonNull;

import static com.macys.search.bizrules.tasklets.ProcessingContext.getContext;
import static org.springframework.batch.repeat.RepeatStatus.FINISHED;

/**
 * Wrapper for {@link Tasklet}.
 * It changes invocation params from String Batch context to custom {@link ProcessingContext}.
 */
public interface RulesPublisherTasklet extends Tasklet {

    default RepeatStatus execute(@NonNull StepContribution contribution, @NonNull ChunkContext chunkContext) throws Exception {
        ProcessingContext ctx = getContext(contribution);
        execute(ctx);
        return FINISHED;
    }

    void execute(ProcessingContext ctx) throws Exception;

}
