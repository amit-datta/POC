package com.macys.search.bizrules.validation.action;

import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.ConfigTemplate;

import static com.macys.search.bizrules.validation.CriteriaAttributesValidator.validateCriteriaMap;

/**
 * Simple validation by merch config template
 */
public abstract class AbstractActionCriteriaValidationStrategy implements ActionValidationStrategy {

    abstract ConfigTemplate getTemplate();

    @Override
    public ValidationResult validate(Action action) {
        return validateCriteriaMap(action.getCriteriaMap(), getTemplate());
    }

}
