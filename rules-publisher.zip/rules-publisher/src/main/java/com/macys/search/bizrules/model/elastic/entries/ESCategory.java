package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import static com.macys.search.bizrules.model.elastic.mappings.CategoryFieldMapping.*;

/**
 * Elastic search category instruction
 */
@Setter
@ToString
@RequiredArgsConstructor
public class ESCategory implements ESEntry {

    private final Category category;
    private String categoryPath;
    private String titlesPath;

    @Override
    public String getElasticId() {
        return String.valueOf(category.getId());
    }

    @Override
    public Map<String, ?> getSource() {
        Map<String, Object> map = new LinkedHashMap<>();

        map.put(CATEGORY_ID.getFieldName(), category.getId());
        map.put(IDS_PATH.getFieldName(), categoryPath);
        map.put(TITLES_PATH.getFieldName(), titlesPath);
        map.computeIfAbsent(SEARCH_PHRASE.getFieldName(), k -> getSearchPhrase(category));

        return map;
    }

    private static String getSearchPhrase(Category category) {
        return Optional.ofNullable(category.getAttributes().get(CategoryAttributeName.SEARCH_PHRASE))
                .map(CategoryAttribute::getUnaryValue)
                .orElse(null);
    }
}
