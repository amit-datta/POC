package com.macys.search.bizrules.validation.trigger;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;

/**
 * Interface for strategies, that is used for Trigger validations during loading
 */
public interface TriggerValidationStrategy {

    /**
     * @return {@link TriggerType} the strategy valid for
     */
    TriggerType applicableFor();

    /**
     * @param trigger trigger that must be validated
     * @return true in case of successful validation. Otherwise return false and add to log explicit warn about about
     * the reason of failed validation
     */
    ValidationResult validate(Trigger trigger, ProcessingContext context);
}
