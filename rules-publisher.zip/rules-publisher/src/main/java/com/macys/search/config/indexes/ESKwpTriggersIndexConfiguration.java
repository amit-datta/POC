package com.macys.search.config.indexes;

import com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import com.macys.search.config.utils.ESIndicesUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.macys.search.bizrules.model.elastic.ESIndex.KWP_TRIGGERS;

@Configuration
public class ESKwpTriggersIndexConfiguration extends AbstractElasticIndexConfiguration {

    @Value("${rules.publisher.mcom.kwp.triggers.alias.name}")
    private String mcomAliasName;
    @Value("${rules.publisher.mcom.kwp.triggers.number-of-shards}")
    private int mcomShardsCount;
    @Value("${rules.publisher.mcom.kwp.triggers.number-of-replicas}")
    private int mcomReplicasCount;

    @Value("${rules.publisher.bcom.kwp.triggers.alias.name}")
    private String bcomAliasName;
    @Value("${rules.publisher.bcom.kwp.triggers.number-of-shards}")
    private int bcomShardsCount;
    @Value("${rules.publisher.bcom.kwp.triggers.number-of-replicas}")
    private int bcomReplicasCount;

    @Bean
    public CreateIndexTasklet createKwpTriggersIndexTasklet(ElasticSearchFacade elasticSearchFacade) {
        return new CreateIndexTasklet(elasticSearchFacade,
                mcomKwpTriggersIndexCreationProperties(), bcomKwpTriggersIndexCreationProperties(),
                mcomCommonIndexProperties, bcomCommonIndexProperties,
                indexerFactory, KWP_TRIGGERS);
    }

    private IndexCreationProperties mcomKwpTriggersIndexCreationProperties() {
        return new IndexCreationProperties(ESIndicesUtils.fullAliasNameFrom(mcomAliasName, indexVersion),
                mcomShardsCount, mcomReplicasCount, TriggerIndexFields.class, null);
    }

    private IndexCreationProperties bcomKwpTriggersIndexCreationProperties() {
        return new IndexCreationProperties(ESIndicesUtils.fullAliasNameFrom(bcomAliasName, indexVersion),
                bcomShardsCount, bcomReplicasCount, TriggerIndexFields.class, null);
    }

    @Bean
    public SwitchAliasProperties kwpTriggersSwitchAliasProperties() {
        return SwitchAliasProperties.of(
                KWP_TRIGGERS,
                mcomAliasName, bcomAliasName,
                indexVersion,
                1
        );
    }
}
