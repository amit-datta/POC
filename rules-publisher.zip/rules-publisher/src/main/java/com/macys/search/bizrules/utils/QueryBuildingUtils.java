package com.macys.search.bizrules.utils;

import lombok.experimental.UtilityClass;
import org.elasticsearch.index.query.QueryBuilder;

import java.util.function.Function;

import static com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields.*;
import static org.apache.commons.lang3.StringUtils.countMatches;
import static org.elasticsearch.index.query.QueryBuilders.constantScoreQuery;
import static org.elasticsearch.index.query.QueryBuilders.matchPhraseQuery;

@UtilityClass
public class QueryBuildingUtils {

    private static final int SKIP_SCORE = 256;

    /**
     * Returns tokens count
     */
    public static final Function<String, Integer> tokenCount = s -> countMatches(s, ' ') + 1;

    /**
     * Build exact phrase query
     */
    public static final Function<String, QueryBuilder> exactQueryBuilder = phrase ->
            constantScoreQuery(matchPhraseQuery(PHRASE_EXACT.getFieldName(), phrase)).boost(tokenCount.apply(phrase));

    /**
     * Build literal phrase query
     */
    public static final Function<String, QueryBuilder> literalQueryBuilder = phrase ->
            constantScoreQuery(matchPhraseQuery(PHRASE_LITERAL.getFieldName(), phrase)).boost(tokenCount.apply(phrase));

    /**
     * Build contains phrase query
     */
    public static final Function<String, QueryBuilder> containsQueryBuilder = phrase ->
            constantScoreQuery(matchPhraseQuery(PHRASE_CONTAINS.getFieldName(), phrase)).boost(SKIP_SCORE);
}
