package com.macys.search.bizrules.model.elastic.mappings;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.KEYWORD;

/**
 * Fields for Biz controls index
 */
@Getter
@AllArgsConstructor
public enum BizControlIndexFields implements ElasticSearchBaseFields {
    TYPE("type", KEYWORD.getProperties()),
    VALUE("value", KEYWORD.getProperties());

    private final String fieldName;
    private final Map<String, Object> properties;
}
