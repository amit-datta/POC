package com.macys.search.bizrules.tasklets.statistics;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.ToString;

import javax.annotation.concurrent.ThreadSafe;

@Getter
@ToString
@JsonDeserialize
@ThreadSafe
public class TimeStatistics {
    private long maxTime;
    @JsonIgnore
    private long timeSum;
    @JsonIgnore
    private int count;

    public synchronized void computeTime(long time) {
        if (time > maxTime) {
            this.maxTime = time;
        }
        count++;
        timeSum += time;
    }

    @JsonProperty
    public long getAvgTime() {
        if (count <= 0) return 0;
        return timeSum / count;
    }
}
