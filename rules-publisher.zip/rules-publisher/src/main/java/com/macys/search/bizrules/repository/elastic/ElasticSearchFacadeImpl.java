package com.macys.search.bizrules.repository.elastic;

import com.macys.search.bizrules.model.elastic.mappings.ElasticSearchBaseFields;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.exception.bizrules.es.ElasticSearchFailToCreateNewIndexException;
import com.macys.search.exception.bizrules.es.ElasticSearchIndexingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.admin.indices.alias.Alias;
import org.elasticsearch.action.admin.indices.alias.IndicesAliasesRequest;
import org.elasticsearch.action.admin.indices.alias.get.GetAliasesRequest;
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest;
import org.elasticsearch.action.admin.indices.forcemerge.ForceMergeRequest;
import org.elasticsearch.action.admin.indices.forcemerge.ForceMergeResponse;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.client.GetAliasesResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.client.indices.GetIndexResponse;
import org.elasticsearch.common.settings.Settings;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static org.elasticsearch.client.RequestOptions.DEFAULT;

/**
 * Implements all common Elastic search requests.
 */
@Slf4j
@RequiredArgsConstructor
public class ElasticSearchFacadeImpl implements ElasticSearchFacade {
    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final String INDEX_CREATION_DATE_SETTING_NAME = "index.creation_date";

    private final RestHighLevelClient client;
    private final RequestOptions longOperationIndexRequestOptions;

    @Override
    public String createIndex(IndexCreationProperties indexCreationProperties, CommonIndexProperties commonIndexProperties) {
        final String indexName = generateNewIndexName(indexCreationProperties);

        CreateIndexRequest request = new CreateIndexRequest(indexName);
        request.alias(new Alias(commonIndexProperties.getUnfinishedIndicesAliasName()));
        try {
            enrichIndexWithSettings(request, indexCreationProperties);
            enrichIndexWithMapping(request, indexCreationProperties);
            CreateIndexResponse response = client.indices().create(request, DEFAULT);
            if (!response.isAcknowledged()) {
                throw new ElasticSearchFailToCreateNewIndexException(indexName, "Response was not acknowledged.", request, response);
            }
        } catch (IOException ex) {
            log.error("Could not create action index.", ex);
            throw new ElasticSearchFailToCreateNewIndexException(indexName, "Could not create action index.", request, null, ex);
        }
        log.info(indexName + " was successfully created.");
        return indexName;
    }

    @Override
    public void merge(String indexName, int maxSegmentCount) {
        try {
            ForceMergeRequest forceMergeRequest = new ForceMergeRequest(indexName)
                    .maxNumSegments(maxSegmentCount)
                    .flush(true);

            ForceMergeResponse response = client.indices().forcemerge(forceMergeRequest, longOperationIndexRequestOptions);
            if (response.getFailedShards() > 0) {
                String message = String.format("%d shards was not flushed or merged", response.getFailedShards());
                throw new ElasticSearchIndexingException(indexName, message);
            }
        } catch (IOException ex) {
            throw new ElasticSearchIndexingException(indexName, "Could not flush index.", ex);
        }
    }

    @Override
    public void deleteIndices(String... indices) {
        if (indices.length == 0) {
            return;
        }

        try {
            DeleteIndexRequest request = new DeleteIndexRequest(indices);
            AcknowledgedResponse response = client.indices().delete(request, DEFAULT);
            if (!response.isAcknowledged()) {
                throw new ElasticSearchIndexingException(Arrays.toString(indices), "Response was not acknowledged.");
            }
        } catch (IOException ex) {
            log.error("Could not delete {} indices.", Arrays.toString(indices), ex);
            throw new ElasticSearchIndexingException(Arrays.toString(indices), "Could not delete indices", ex);
        }
        log.info("Indices '{}' were successfully deleted.", Arrays.toString(indices));
    }

    @Override
    public List<String> getIndicesStartingWith(String prefix) {
        List<String> indices;
        try {
            GetIndexRequest getIndexRequest = new GetIndexRequest(prefix + "*");
            GetIndexResponse getIndexResponse = client.indices().get(getIndexRequest, DEFAULT);
            indices = getIndexResponse.getSettings().entrySet().stream()
                    .sorted((entry1, entry2) -> Long.compare(Long.parseLong(entry2.getValue().get(INDEX_CREATION_DATE_SETTING_NAME)),
                            Long.parseLong(entry1.getValue().get(INDEX_CREATION_DATE_SETTING_NAME))))
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());
        } catch (IOException ex) {
            log.error("Could retrieve indices starting with '{}'", prefix);
            throw new ElasticSearchIndexingException(prefix, "Could not retrieve indices", ex);
        }

        return indices;
    }

    @Override
    public Collection<String> getIndicesWithAlias(Collection<String> aliases) {
        try {
            GetAliasesRequest indicesToAliasRequest = new GetAliasesRequest(aliases.toArray(String[]::new));
            GetAliasesResponse indicesToAliasResponse = client.indices().getAlias(indicesToAliasRequest, DEFAULT);
            return indicesToAliasResponse.getAliases().keySet();
        } catch (IOException ex) {
            log.error("Could not retrieve index names for aliases={}", aliases);
            throw new RuntimeException("Could not retrieve index names for aliases=" + aliases, ex);
        }
    }

    @Override
    public void switchAlias(Map<String, String> indexNameToAliasMapping, Collection<String> aliasesToClear) {
        if (indexNameToAliasMapping.isEmpty()) {
            return;
        }
        try {
            List<String> aliases = new ArrayList<>(indexNameToAliasMapping.values());
            aliases.addAll(aliasesToClear);

            IndicesAliasesRequest aliasRequest = new IndicesAliasesRequest();

            for (Map.Entry<String, String> entry : indexNameToAliasMapping.entrySet()) {
                String indexName = entry.getKey();
                String alias = entry.getValue();
                log.info("Adding index {} to alias {}.", indexName, alias);
                IndicesAliasesRequest.AliasActions createAliasAction =
                        new IndicesAliasesRequest.AliasActions(IndicesAliasesRequest.AliasActions.Type.ADD)
                                .index(indexName)
                                .alias(alias);
                aliasRequest.addAliasAction(createAliasAction);
            }

            Collection<String> aliasesToUnbind = getIndicesWithAlias(aliases);
            if (!aliasesToUnbind.isEmpty()) {
                log.info("Deleting indexes {} from aliases {}.", String.join(",", aliasesToUnbind),
                        String.join(",", aliases));
                IndicesAliasesRequest.AliasActions removeAlias = new IndicesAliasesRequest.AliasActions(
                        IndicesAliasesRequest.AliasActions.Type.REMOVE)
                        .indices(aliasesToUnbind.toArray(String[]::new))
                        .aliases(aliases.toArray(String[]::new));
                aliasRequest.addAliasAction(removeAlias);
            }

            AcknowledgedResponse response = client.indices().updateAliases(aliasRequest, DEFAULT);
            if (!response.isAcknowledged()) {
                throw new ElasticSearchIndexingException(indexNameToAliasMapping.keySet().toString(), "Response was not acknowledged.");
            }
        } catch (IOException ex) {
            log.error("Could not add aliases to indices '{}'", indexNameToAliasMapping);
            throw new ElasticSearchIndexingException(indexNameToAliasMapping.keySet().toString(), "Could not add alias to index", ex);
        }
        log.info("Aliases were successfully added to indices '{}'", indexNameToAliasMapping);
    }

    private String generateNewIndexName(IndexCreationProperties indexCreationProperties) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMAT);
        return indexCreationProperties.getIndexNamePrefix() + '_' + timestamp;
    }

    private void enrichIndexWithSettings(CreateIndexRequest request, IndexCreationProperties indexCreationProperties) {
        request.settings(Settings.builder()
                .put("number_of_shards", indexCreationProperties.getShardsCount())
                .put("number_of_replicas", indexCreationProperties.getReplicasCount())
                .put("similarity.default.type", "boolean")
        );
    }

    private static void enrichIndexWithMapping(CreateIndexRequest request, IndexCreationProperties indexCreationProperties) throws IOException {
        Map<String, Object> mappingMap = new HashMap<>();
        mappingMap.put("properties", propertiesFromFieldEnum(indexCreationProperties.getFieldsEnum()));
        mergeProperties(mappingMap, indexCreationProperties.getOverriddenProperties());
        request.mapping(mappingMap);
    }

    private static Map<String, Object> propertiesFromFieldEnum(Class<? extends ElasticSearchBaseFields> fieldsEnum) {
        Map<String, Object> result = new HashMap<>();
        for (ElasticSearchBaseFields field : fieldsEnum.getEnumConstants()) {
            result.put(field.getFieldName(), field.getProperties());
        }
        return result;
    }

    private static void mergeProperties(Map<String, Object> properties, Map<String, Object> overriddenProperties) {
        if (overriddenProperties == null) return;
        for (Map.Entry<String, Object> entry : overriddenProperties.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            if (!properties.containsKey(key)) {
                properties.put(key, value);
            } else {
                mergeValues(properties, key, value);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static void mergeValues(Map<String, Object> properties, String key, Object overriddenValue) {
        Object value = properties.get(key);
        if (value instanceof String) {
            properties.put(key, overriddenValue);
            return;
        }
        mergeProperties((Map<String, Object>) properties.get(key), (Map<String, Object>) overriddenValue);
    }

}
