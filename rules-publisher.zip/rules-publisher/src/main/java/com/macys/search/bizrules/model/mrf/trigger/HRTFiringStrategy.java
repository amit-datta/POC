package com.macys.search.bizrules.model.mrf.trigger;

/**
 * Firing strategies for Hierarchical Refinement trigger.
 * <ul>
 *     <li>Exact - exact match category ids</li>
 *     <li>Descendants - match descendant's category ids</li>
 * </ul>
 */
public enum HRTFiringStrategy {
    Exact,
    Descendants
}
