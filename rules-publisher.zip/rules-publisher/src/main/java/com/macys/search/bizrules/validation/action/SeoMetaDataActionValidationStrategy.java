package com.macys.search.bizrules.validation.action;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.CriteriaAttributesValidator;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.CriteriaTemplate;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Implementation of validation strategy for action {@link com.macys.search.bizrules.model.mrf.action.ActionType#SeoMetaData}
 * validates that given actionConfig {@link Action} contains attributes with uniq value - "AttributeValue"
 */
@Slf4j
@Component
public class SeoMetaDataActionValidationStrategy implements ActionValidationStrategy {

    @Getter(AccessLevel.PACKAGE)
    @ResourceMapping("classpath:merch-validation-template/action/SeoMetaData.json")
    private CriteriaTemplate template;

    @Override
    public ActionType applicableFor() {
        return ActionType.SeoMetaData;
    }

    @Override
    public ValidationResult validate(Action action) {
        for (Criteria criteria : action.getCriteriaMap().values()) {
            ValidationResult validationResult = CriteriaAttributesValidator.validateCriteriaAttributes(criteria, template);
            if (!validationResult.isValid()) {
                return validationResult;
            }
        }
        if (action.getCriteriaMap().isEmpty()) {
            return ValidationResult.failResult("Seo metadata action should contains at least one criteria");
        }
        return ValidationResult.validResult();
    }

}
