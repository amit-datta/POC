package com.macys.search.bizrules.model.mrf.action;

/**
 * Business type of {@link Action}
 */
public enum ActionType {
    CategoryRedirect(true),
    ProductRedirect(true),
    URLRedirect(true),
    ShowMedia(false),
    ModifySearchResults(false),
    SeoControl(false),
    SpecialInstruction(false),
    SeoMetaData(false);

    private final boolean extendedPermissionsRequired;

    ActionType(boolean extendedPermissionsRequired) {
        this.extendedPermissionsRequired = extendedPermissionsRequired;
    }

    public boolean isExtendedPermissionsRequired() {
        return extendedPermissionsRequired;
    }
}
