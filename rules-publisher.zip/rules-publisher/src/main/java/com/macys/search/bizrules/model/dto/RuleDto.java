package com.macys.search.bizrules.model.dto;

import com.macys.search.bizrules.validation.ValidationResult;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;

@Getter
@Setter
@Builder
public class RuleDto {
    private final Integer ruleId;
    private final Integer rulePriority;
    private final String ruleName;
    private final String ruleType;
    private final Boolean ruleEnabled;
    private final LocalDate ruleEffectiveDate;
    private final LocalDate ruleExpirationDate;
    private final LocalDateTime ruleLastModifiedDate;
    private final String ruleLastModifiedByName;

    private final ValidationResult validationResult;

    private final Collection<TriggerDto> triggers;
    private final Collection<ActionDto> actions;
}
