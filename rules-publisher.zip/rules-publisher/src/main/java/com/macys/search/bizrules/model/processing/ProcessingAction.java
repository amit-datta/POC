package com.macys.search.bizrules.model.processing;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.*;

import static java.util.Objects.requireNonNull;

/**
 * Model class to storing all significant information around one Action
 */
@Getter
@Setter
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class ProcessingAction {
    private Action action;
    private ESActionType esActionType;
    private ValidationResult validationResult;

    private boolean isProcessed;

    private Map<Integer, List<String>> disabledReasons = new HashMap<>();
    private List<Integer> ruleIds = new ArrayList<>();
    private Collection<Integer> naturalRuleIds;

    public ProcessingAction(Action action) {
        this.action = action;
    }

    public static ProcessingAction from(Action action) {
        return new ProcessingAction(requireNonNull(action));
    }

    public boolean isValid() {
        return validationResult.isValid();
    }

    public void addDisabledReason(Integer ruleId, String reason) {
        disabledReasons.computeIfAbsent(ruleId, key -> new ArrayList<>()).add(reason);
    }

    public void addRuleId(Integer ruleId) {
        ruleIds.add(ruleId);
    }

    public Integer getId() {
        return action.getId();
    }

    public ActionType getMerchActionType() {
        return action.getMerchActionType();
    }

    public Map<String, Criteria> getCriteriaMap() {
        return action.getCriteriaMap();
    }

}
