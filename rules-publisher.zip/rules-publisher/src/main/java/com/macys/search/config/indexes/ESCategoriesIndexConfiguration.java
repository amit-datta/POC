package com.macys.search.config.indexes;

import com.macys.search.bizrules.model.elastic.mappings.CategoryFieldMapping;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import com.macys.search.config.utils.ESIndicesUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.macys.search.bizrules.model.elastic.ESIndex.CATEGORIES;

@Configuration
public class ESCategoriesIndexConfiguration extends AbstractElasticIndexConfiguration {

    @Value("${rules.publisher.mcom.categories.alias.name}")
    private String mcomAliasName;
    @Value("${rules.publisher.mcom.categories.number-of-shards:1}")
    private int mcomShardsCount;
    @Value("${rules.publisher.mcom.categories.number-of-replicas:0}")
    private int mcomReplicasCount;

    @Value("${rules.publisher.bcom.categories.alias.name}")
    private String bcomAliasName;
    @Value("${rules.publisher.bcom.categories.number-of-shards:1}")
    private int bcomShardsCount;
    @Value("${rules.publisher.bcom.categories.number-of-replicas:0}")
    private int bcomReplicasCount;

    @Bean
    public CreateIndexTasklet createCategoriesIndexTasklet(ElasticSearchFacade elasticSearchFacade) {
        return new CreateIndexTasklet(elasticSearchFacade,
                mcomCategoriesIndexCreationProperties(), bcomCategoriesIndexCreationProperties(),
                mcomCommonIndexProperties, bcomCommonIndexProperties,
                indexerFactory, CATEGORIES);
    }

    private IndexCreationProperties mcomCategoriesIndexCreationProperties() {
        return new IndexCreationProperties(ESIndicesUtils.fullAliasNameFrom(mcomAliasName, indexVersion),
                mcomShardsCount, mcomReplicasCount, CategoryFieldMapping.class, null);
    }

    private IndexCreationProperties bcomCategoriesIndexCreationProperties() {
        return new IndexCreationProperties(ESIndicesUtils.fullAliasNameFrom(bcomAliasName, indexVersion),
                bcomShardsCount, bcomReplicasCount, CategoryFieldMapping.class, null);
    }

    @Bean
    public SwitchAliasProperties categoriesSwitchAliasProperties() {
        return SwitchAliasProperties.of(
                CATEGORIES,
                mcomAliasName, bcomAliasName, indexVersion,
                1
        );
    }
}
