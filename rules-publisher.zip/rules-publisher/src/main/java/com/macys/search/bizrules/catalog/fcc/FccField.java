package com.macys.search.bizrules.catalog.fcc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Builder
@AllArgsConstructor(staticName = "of")
public class FccField {
    private final String name;
    private final Collection<FccField> children;

    public static FccField of(String name) {
        return new FccField(name, List.of());
    }

    @Override
    public String toString() {
        return name + (!children.isEmpty() ? "(" + children.stream().map(FccField::toString).collect(Collectors.joining(",")) + ")": "");
    }
}
