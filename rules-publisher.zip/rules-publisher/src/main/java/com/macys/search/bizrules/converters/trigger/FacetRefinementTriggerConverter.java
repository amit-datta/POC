package com.macys.search.bizrules.converters.trigger;

import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.FacetRefinementMatchType;
import com.macys.search.bizrules.model.mrf.trigger.KWPMatchType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.model.processing.trigger.params.FacetRefinementTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static com.macys.search.bizrules.converters.ConverterUtils.getUnaryValue;
import static com.macys.search.bizrules.model.mrf.trigger.FacetRefinementMatchType.*;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.*;

/**
 * Trigger converter for {@link TriggerType#FacetRefinement}
 */
@Component
public class FacetRefinementTriggerConverter implements TriggerConverter {

    public TriggerType applicableFor() {
        return TriggerType.FacetRefinement;
    }

    public AbstractTriggerParams convert(ProcessingTrigger processingTrigger, ProcessingContext ctx) {
        Trigger trigger = processingTrigger.getTrigger();
        FacetRefinementMatchType matchType = null;
        Map<String, Set<String>> refinements = new HashMap<>();
        for (Criteria criteria : trigger.getCriteriaMap().values()) {
            if (FACET_REFINEMENT_MATCH_CONFIG.equals(criteria.getCriteriaName())) {
                matchType = getMatchType(criteria);
            } else {
                String fieldName = "refinement_" + criteria.getCriteriaName().toLowerCase();
                Set<String> values = refinements.computeIfAbsent(fieldName, f -> new HashSet<>());
                values.addAll(criteria.getCriteriaAttributes().get(FACET_REFINEMENT_ATTRIBUTE_VALUE));
            }
        }
        return FacetRefinementTriggerParams.builder()
                .triggerId(trigger.getId())
                .refinements(refinements)
                .matchType(matchType)
                .build();
    }

    private static FacetRefinementMatchType getMatchType(Criteria matchConfig) {
        KWPMatchType matchType = KWPMatchType.valueOf(getUnaryValue(matchConfig, FACET_REFINEMENT_MATCH_TYPE));
        BooleanOperation operationType = BooleanOperation.valueOf(getUnaryValue(matchConfig, FACET_REFINEMENT_MATCH_OPERATOR));

        if (matchType == KWPMatchType.Exact) {
            return operationType == BooleanOperation.AND ? exact_and : exact_or;
        }
        if (matchType == KWPMatchType.Contains) {
            return operationType == BooleanOperation.AND ? contains_and : contains_or;
        }
        throw new IllegalArgumentException("Could not parse matchType=" + matchType + ", operationType=" + operationType
                + " for facet refinement");
    }

}
