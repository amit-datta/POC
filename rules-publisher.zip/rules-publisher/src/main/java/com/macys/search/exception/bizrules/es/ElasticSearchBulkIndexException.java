package com.macys.search.exception.bizrules.es;

/**
 * Fail to send bulk request to Elastic search
 */
public class ElasticSearchBulkIndexException extends ElasticSearchIndexingException {

    public ElasticSearchBulkIndexException(String indexName, String message, Throwable cause) {
        super(indexName, message, cause);
    }
}
