package com.macys.search.bizrules.model.elastic.mappings;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.KEYWORD;
import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.LONG;

/**
 * Fields for Category index
 */
@Getter
@AllArgsConstructor
public enum CategoryFieldMapping implements ElasticSearchBaseFields {
    CATEGORY_ID("category_id", LONG.getProperties()),
    IDS_PATH("ids_path", KEYWORD.getProperties()),
    TITLES_PATH("titles_path", KEYWORD.getProperties()),
    SEARCH_PHRASE("search_phrase",  KEYWORD.getProperties());

    private final String fieldName;
    private final Map<String, Object> properties;
}
