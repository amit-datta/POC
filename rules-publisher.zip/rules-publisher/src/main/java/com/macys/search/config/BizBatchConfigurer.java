package com.macys.search.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.dao.Jackson2ExecutionContextStringSerializer;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

public class BizBatchConfigurer implements BatchConfigurer {

    private final PlatformTransactionManager platformTransactionManager;
    private final SimpleJobLauncher jobLauncher;
    private final JobRepository jobRepository;
    private final JobExplorer jobExplorer;

    public BizBatchConfigurer(DataSource dataSource) throws Exception {
        Jackson2ExecutionContextStringSerializer jacksonSerializer = createJacksonSerializer();
        this.platformTransactionManager = new DataSourceTransactionManager(dataSource);
        this.jobRepository = createJobRepository(dataSource, jacksonSerializer);
        this.jobLauncher = createJobLauncher(jobRepository);
        this.jobExplorer = createJobExplorer(dataSource, jacksonSerializer);
    }

    private Jackson2ExecutionContextStringSerializer createJacksonSerializer() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        Jackson2ExecutionContextStringSerializer jacksonSerializer = new Jackson2ExecutionContextStringSerializer();
        jacksonSerializer.setObjectMapper(objectMapper);
        return jacksonSerializer;
    }

    private JobRepository createJobRepository(DataSource dataSource, Jackson2ExecutionContextStringSerializer jacksonSerializer) throws Exception {
        JobRepositoryFactoryBean jobRepositoryFactory = new JobRepositoryFactoryBean();
        jobRepositoryFactory.setDataSource(dataSource);
        jobRepositoryFactory.setTransactionManager(platformTransactionManager);
        jobRepositoryFactory.setSerializer(jacksonSerializer);
        jobRepositoryFactory.afterPropertiesSet();
        return jobRepositoryFactory.getObject();
    }

    private SimpleJobLauncher createJobLauncher(JobRepository jobRepository) {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository);
        jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
        return jobLauncher;
    }

    private JobExplorer createJobExplorer(DataSource dataSource, Jackson2ExecutionContextStringSerializer jacksonSerializer) throws Exception {
        JobExplorerFactoryBean jobExplorerFactory = new JobExplorerFactoryBean();
        jobExplorerFactory.setDataSource(dataSource);
        jobExplorerFactory.setSerializer(jacksonSerializer);
        jobExplorerFactory.afterPropertiesSet();
        return jobExplorerFactory.getObject();
    }

    @Override
    public JobRepository getJobRepository() {
        return this.jobRepository;
    }

    @Override
    public PlatformTransactionManager getTransactionManager() {
        return this.platformTransactionManager;
    }

    @Override
    public JobLauncher getJobLauncher() {
        return this.jobLauncher;
    }

    @Override
    public JobExplorer getJobExplorer() {
        return this.jobExplorer;
    }
}
