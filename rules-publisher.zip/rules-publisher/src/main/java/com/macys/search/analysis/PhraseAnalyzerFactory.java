package com.macys.search.analysis;

import lombok.RequiredArgsConstructor;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.miscellaneous.ASCIIFoldingFilter;
import org.apache.lucene.analysis.miscellaneous.ConcatenateGraphFilter;
import org.apache.lucene.analysis.pattern.PatternReplaceCharFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

import static org.apache.lucene.analysis.miscellaneous.ConcatenateGraphFilter.DEFAULT_MAX_GRAPH_EXPANSIONS;

/**
 * Factory for all type of analyzers.
 * All analyzers use ConcatenateGraphFilter at the end. If you need tokenized phrase you need
 * either create new type of analyzer or split analysed phrase by space.
 *
 * All analyzers should be removed after Elastic search implements ConcatenateGraphFilter on his side.
 */
@Component
@RequiredArgsConstructor
public class PhraseAnalyzerFactory {

    private final Pattern replacePattern;

    /**
     * Exact phrase analyser
     *
     * Chain of char filters:
     * <ul>
     *     <li>{@link PatternReplaceCharFilter} - pattern takes as constructor parameter </li>
     * </ul>
     * <p>
     * Chain of token filters:
     * <ul>
     *     <li>{@link LowerCaseFilter}</li>
     *     <li>{@link ASCIIFoldingFilter}</li>
     *     <li>{@link ConcatenateGraphFilter}</li>
     * </ul>
     * </p>
     *
     * @return exact phrase analyser
     */
    public PhraseAnalyzer createExactPhraseAnalyzer() {
        Tokenizer tokenizer = new StandardTokenizer();

        TokenStream filter = new LowerCaseFilter(tokenizer);
        filter = new ASCIIFoldingFilter(filter);
        filter = new ConcatenateGraphFilter(filter, ' ', true, DEFAULT_MAX_GRAPH_EXPANSIONS);

        return new SimplePhraseAnalyzer(replacePattern, tokenizer, filter);
    }

    /**
     * Contains phrase analyser
     *
     * Chain of char filters:
     * <ul>
     *     <li>{@link PatternReplaceCharFilter} - pattern takes as constructor parameter </li>
     * </ul>
     * <p>
     * Chain of token filters:
     * <ul>
     *     <li>{@link LowerCaseFilter}</li>
     *     <li>{@link ASCIIFoldingFilter}</li>
     *     <li>{@link ConcatenateGraphFilter}</li>
     * </ul>
     * </p>
     *
     * @return contains phrase analyser
     */
    public PhraseAnalyzer createContainsPhraseAnalyzer() {
        Tokenizer tokenizer = new StandardTokenizer();

        TokenStream filter = new LowerCaseFilter(tokenizer);
        filter = new ASCIIFoldingFilter(filter);
        filter = new ConcatenateGraphFilter(filter, ' ', true, DEFAULT_MAX_GRAPH_EXPANSIONS);

        return new SimplePhraseAnalyzer(replacePattern, tokenizer, filter);
    }

    /**
     * Literal phrase analyser.
     *
     * This analyser does not use char replace filter.
     *
     * Chain of char filters:
     * <ul>
     *     <li>{@link PatternReplaceCharFilter} - pattern takes as constructor parameter </li>
     * </ul>
     * <p>
     * Chain of token filters:
     * <ul>
     *     <li>{@link LowerCaseFilter}</li>
     *     <li>{@link ConcatenateGraphFilter}</li>
     * </ul>
     * </p>
     *
     * @return literal phrase analyser
     */
    public PhraseAnalyzer createLiteralPhraseAnalyzer() {
        Tokenizer tokenizer = new StandardTokenizer();

        TokenStream filter = new LowerCaseFilter(tokenizer);
        filter = new ConcatenateGraphFilter(filter, ' ', true, DEFAULT_MAX_GRAPH_EXPANSIONS);

        return new SimplePhraseAnalyzer(null, tokenizer, filter);
    }
}
