package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.ATTRIBUTE_VALUE;

/**
 * {@link ActionConverter} implementation for {@link ActionType#SeoMetaData} type
 */
@Slf4j
@Component
class SeoMetaDataConverter extends AbstractActionConverter {

    @Override
    public ActionType applicableFor() {
        return ActionType.SeoMetaData;
    }

    @Override
    void enrichWithTypeSpecificProperties(Action action, ESAction doc, ProcessingContext context) {
        doc.setFieldValue(ActionsIndexFields.ACTION_TYPE, ESActionType.SEO_META_DATA);
        Map<String, String> seoMetaData = new HashMap<>();
        for (Map.Entry<String, Criteria> criteriaEntry : action.getCriteriaMap().entrySet()) {
            Map<String, List<String>> criteriaAttributes = criteriaEntry.getValue().getCriteriaAttributes();
            seoMetaData.put(criteriaEntry.getKey(), criteriaAttributes.get(ATTRIBUTE_VALUE).get(0));
        }
        doc.setFieldValueAsString(ActionsIndexFields.SEO_METADATA, seoMetaData);
    }
}
