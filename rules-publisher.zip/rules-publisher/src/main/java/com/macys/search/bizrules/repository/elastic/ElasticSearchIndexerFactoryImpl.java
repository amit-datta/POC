package com.macys.search.bizrules.repository.elastic;

import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutorService;

@Component
public class ElasticSearchIndexerFactoryImpl implements ElasticSearchIndexerFactory {

    private final RestHighLevelClient client;
    private final RequestOptions sendBulkRequestOptions;
    private final ExecutorService indexingExecutorService;

    private final Integer maxBulkSize;
    private final Integer maxQueueSize;
    private final Integer sendBulkAttemptsCount;

    public ElasticSearchIndexerFactoryImpl(RestHighLevelClient client,
                                           ExecutorService indexingExecutorService,
                                           @Value("${rules.publisher.es.indexing.bulk-size}") Integer maxBulkSize,
                                           @Value("${rules.publisher.es.indexing.send-bulk-attempts-count}") Integer sendBulkAttemptsCount,
                                           RequestOptions sendBulkRequestOptions,
                                           @Value("${rules.publisher.es.indexing.queue.size}") Integer maxQueueSize) {
        this.client = client;
        this.indexingExecutorService = indexingExecutorService;
        this.maxBulkSize = maxBulkSize;
        this.maxQueueSize = maxQueueSize;
        this.sendBulkRequestOptions = sendBulkRequestOptions;
        this.sendBulkAttemptsCount = sendBulkAttemptsCount;
    }

    @Override
    public ElasticSearchIndexer createIndexer(String indexName) {
        return new ElasticSearchIndexer(indexName, sendBulkAttemptsCount, indexingExecutorService,
                client, maxBulkSize, sendBulkRequestOptions, maxQueueSize);
    }
}
