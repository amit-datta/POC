package com.macys.search.handler;

import com.google.gson.Gson;
import com.macys.search.bizrules.dto.IndexingMessage;
import com.macys.search.bizrules.services.RuleMaintenanceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.MessageHandler;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(value = "spring.cloud.gcp.pubsub.enabled", havingValue = "true")
public class PubSubMessageEventsIndexerHandler {

    private final RuleMaintenanceService ruleMaintenanceService;
    private final Gson gson;

    public MessageHandler handleMessage() {

        return message -> {
            String payloadJson = new String((byte[]) message.getPayload());
            IndexingMessage indexingMessage = gson.fromJson(payloadJson, IndexingMessage.class);
            ruleMaintenanceService.handlePubSubMessage(indexingMessage, payloadJson);
        };
    }

}