package com.macys.search.bizrules.validation;

import com.macys.search.bizrules.tasklets.ProcessingContext;

public interface ValidationService<T> {

    ValidationResult validate(T item, ProcessingContext context);
}
