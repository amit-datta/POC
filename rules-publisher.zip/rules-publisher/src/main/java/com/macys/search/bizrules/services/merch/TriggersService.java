package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.converters.trigger.TriggerConverterService;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerParameter;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.statistics.TriggersStatistics;
import com.macys.search.bizrules.validation.TriggerValidationService;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Map;

import static com.macys.search.bizrules.validation.LoggingHelper.logTriggerValidationFailed;

/**
 * Service to work with trigger from database. Contains methods to parse attributes and fill criteriaMap.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TriggersService {

    private final TriggerValidationService triggerValidationService;
    private final TriggerConverterService triggerConverterService;

    private static ProcessingTrigger setTriggerAsFailed(ProcessingTrigger processingTrigger) {
        logTriggerValidationFailed(log, processingTrigger.getTrigger(), processingTrigger.getValidationResult().getWarning());
        processingTrigger.setProcessed(true);
        return processingTrigger;
    }

    private static ValidationResult validateRequiredTriggerFields(Trigger trigger) {
        if (trigger.getMerchTriggerType() == null) {
            return ValidationResult.failResult(String.format("Trigger with id=%d doesn't have trigger type",
                    trigger.getId()));
        }
        return ValidationResult.validResult();
    }

    /**
     * Parse and validate trigger and save result to {@link ProcessingTrigger}
     *
     * @param id  trigger id
     * @param ctx processing context
     * @return processed trigger
     */
    public ProcessingTrigger getProcessedTrigger(Integer id, ProcessingContext ctx) {
        ProcessingTrigger processingTrigger = ctx.getTriggers().get(id);
        if (processingTrigger == null || processingTrigger.isProcessed()) {
            return processingTrigger;
        }
        Trigger trigger = processingTrigger.getTrigger();
        TriggersStatistics triggersStatistics = ctx.getStatistics().getTriggersStatistics();
        processingTrigger.setValidationResult(validateRequiredTriggerFields(trigger));
        if (!processingTrigger.isValid()) {
            triggersStatistics.incrementInvalidTriggers();
            return setTriggerAsFailed(processingTrigger);
        }

        processingTrigger.setValidationResult(parseAttributes(trigger));
        if (!processingTrigger.isValid()) {
            triggersStatistics.incrementInvalidTriggers();
            return setTriggerAsFailed(processingTrigger);
        }
        processingTrigger.setValidationResult(triggerValidationService.validate(trigger, ctx));
        if (!processingTrigger.isValid()) {
            triggersStatistics.incrementInvalidTriggers();
            return setTriggerAsFailed(processingTrigger);
        }

        triggersStatistics.incrementValidTriggers();
        processingTrigger.setProcessed(true);
        return processingTrigger;
    }

    public AbstractTriggerParams generateTriggerParams(ProcessingTrigger processingTrigger, ProcessingContext ctx) {
        if (!processingTrigger.isProcessed()) {
            throw new IllegalArgumentException("Could not generate elastic document for triggerId="
                    + processingTrigger.getId());
        }
        return triggerConverterService.convertTrigger(processingTrigger, ctx);
    }

    public static ValidationResult parseAttributes(Trigger trigger) {
        if (trigger.getParams() == null) {
            return ValidationResult.failResult("Trigger with id=" + trigger.getId() + " doesn't contain params");
        }
        trigger.getParams().forEach(parameter -> addRegularCriteriaAttribute(trigger, parameter));
        trigger.setParams(null);
        return ValidationResult.validResult();
    }

    private static void addRegularCriteriaAttribute(Trigger trigger, TriggerParameter parameter) {
        Map<String, Criteria> criteriaMap = trigger.getCriteriaMap();
        String criteriaName = parameter.getGroup();

        Criteria criteria = criteriaMap.computeIfAbsent(criteriaName, key -> new Criteria());
        criteria.setCriteriaName(criteriaName);
        criteria.getCriteriaAttributes().computeIfAbsent(parameter.getName(), key -> new ArrayList<>())
                .add(parameter.getValue());
    }

}