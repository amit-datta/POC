package com.macys.search.bizrules.catalog.fcc.category.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Collection;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AttributeBinding {
    private String name;
    private Integer sortWeight;
    private Boolean visible;
    private Collection<AttributeValueBinding> attributeValues;
}
