package com.macys.search.bizrules.model.processing.trigger.params;

import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.Always;

/**
 * Trigger params for {@link com.macys.search.bizrules.model.mrf.trigger.TriggerType#Always}
 */
@Getter
@ToString
@EqualsAndHashCode
public class AlwaysTriggerParams extends AbstractTriggerParams {

    private final Integer triggerId;

    public AlwaysTriggerParams(Integer triggerId) {
        this.triggerId = triggerId;
    }

    @Override
    public List<ESTrigger> generateTriggers() {
        ESTrigger trigger = new ESTrigger(triggerId, Always);
        return Collections.singletonList(trigger);
    }
}
