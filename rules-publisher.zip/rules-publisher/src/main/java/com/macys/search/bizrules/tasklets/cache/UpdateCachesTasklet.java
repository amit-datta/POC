package com.macys.search.bizrules.tasklets.cache;

import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.cache.CategoriesCache;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class UpdateCachesTasklet implements RulesPublisherTasklet {
    private final CategoriesCache mcomCategoriesCache;
    private final CategoriesCache bcomCategoriesCache;

    public void execute(ProcessingContext ctx) {
        if (ctx.isMCOM()) {
            mcomCategoriesCache.updateCache(ctx);
        } else {
            bcomCategoriesCache.updateCache(ctx);
        }
    }
}
