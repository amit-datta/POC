package com.macys.search.bizrules.model.category;

/**
 * Category attribute enum
 */
public enum CategoryAttributeName {
    PRICE_FILTER,
    PRICE_RANGE_MIN,
    PRICE_RANGE_MAX,

    TIMED_FILTER,
    SEARCH_PHRASE
}
