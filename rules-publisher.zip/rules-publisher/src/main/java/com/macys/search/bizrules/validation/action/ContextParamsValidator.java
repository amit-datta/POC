package com.macys.search.bizrules.validation.action;

import com.macys.search.bizrules.model.context.*;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.validation.ValidationResult;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.context.ContextParameterNames.*;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.INTERNATIONAL_REGION_CODE;

/**
 * Validate context parameters for action.
 * <p>
 * Possible keys and values:
 * <ul>
 *     <li>REGION_CODE - two-character string</li>
 *     <li>APPLICATION - all values form {@link ApplicationType}</li>
 *     <li>CUSTOMER_EXPERIMENT - all values form {@link CustomerExperiment}</li>
 *     <li>DEVICE_TYPE - all values form {@link DeviceType}</li>
 *     <li>NAVIGATION_TYPE - all values form {@link NavigationType}</li>
 *     <li>SHOPPING_MODE - all values form {@link ShoppingMode}</li>
 * </ul>
 */
@Component
public class ContextParamsValidator {
    private final Map<String, Set<String>> possibleAttributesValues = Map.of(
            APPLICATION, convertValues(ApplicationType.values()),
            CUSTOMER_EXPERIMENT, convertValues(CustomerExperiment.values()),
            DEVICE_TYPE, convertValues(DeviceType.values()),
            NAVIGATION_TYPE, convertValues(NavigationType.values()),
            SHOPPING_MODE, convertValues(ShoppingMode.values()),
            REGION_CODE, Collections.emptySet()
    );

    private static Set<String> convertValues(Enum<?>[] values) {
        return Arrays.stream(values).map(Enum::name).collect(Collectors.toSet());
    }

    /**
     * Validate context parameters
     *
     * @param action action to validate
     * @return true if all correct otherwise false
     */
    public ValidationResult validate(Action action) {
        for (Map.Entry<String, Collection<String>> entry : action.getContextAttributes().entrySet()) {
            ValidationResult result = validateAttribute(action, entry.getKey(), entry.getValue());
            if (!result.isValid()) {
                return result;
            }
        }
        return ValidationResult.validResult();
    }

    private ValidationResult validateAttribute(Action action, String attrName, Collection<String> attrValues) {
        if (REGION_CODE.equals(attrName)) {
            if (attrValues.size() != 1) {
                return ValidationResult.failResult(validationErrorMessage(action, REGION_CODE + " attr must contain one value but contains" + attrValues));
            }
            String value = attrValues.iterator().next();
            if (value == null || (value.length() != 2 && !INTERNATIONAL_REGION_CODE.equals(value))) {
                return ValidationResult.failResult(validationErrorMessage(action, REGION_CODE + " attr value must be two-character string or INTL. But was=" + value));
            }
            return ValidationResult.validResult();
        }
        Set<String> possibleValues = possibleAttributesValues.get(attrName);
        if (possibleValues == null) {
            return ValidationResult.failResult(validationErrorMessage(action, MessageFormat.format("{0} is not possible attribute name. Possible names={1}",
                    attrName, possibleAttributesValues.keySet())
            ));
        }
        if (!possibleValues.containsAll(attrValues)) {
            String msg = MessageFormat.format("{0} attribute can contains only={1} but contains={2}",
                    attrName, possibleValues, attrValues
            );
            return ValidationResult.failResult(validationErrorMessage(action, msg));
        }
        return ValidationResult.validResult();
    }

    private static String validationErrorMessage(Action action, String reason) {
        return String.format("Action with id=%d has invalid context params. %s", action.getId(), reason);
    }
}
