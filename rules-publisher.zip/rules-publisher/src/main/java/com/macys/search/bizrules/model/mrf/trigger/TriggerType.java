package com.macys.search.bizrules.model.mrf.trigger;

/**
 * Merchandising trigger types enumeration.
 */
public enum TriggerType {
    Always,
    HierarchicalRefinement,
    KeywordPattern,
    CrsBlacklisted,
    FacetRefinement,
    AmbiguousMatch,
    ResultSet,
    NumResults,
    SortBy,
    LegacyRDPP,
    Context,
    UserSort
}
