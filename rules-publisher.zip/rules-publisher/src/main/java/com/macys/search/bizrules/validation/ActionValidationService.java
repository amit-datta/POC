package com.macys.search.bizrules.validation;

import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.action.ActionValidationStrategy;
import com.macys.search.bizrules.validation.action.ContextParamsValidator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.List;

@Component
public class ActionValidationService implements ValidationService<Action> {

    private final ContextParamsValidator contextParamsValidator;
    private final EnumMap<ActionType, ActionValidationStrategy> actionStrategiesMap = new EnumMap<>(ActionType.class);

    public ActionValidationService(ContextParamsValidator contextParamsValidator,
                                   List<ActionValidationStrategy> actionValidationStrategies,
                                   @Value("${rules.publisher.enabled.action-types}")
                                   List<ActionType> enabledActions) {
        actionValidationStrategies.stream()
                .filter(s -> enabledActions.contains(s.applicableFor()))
                .forEach(s -> actionStrategiesMap.put(s.applicableFor(), s));
        if (!actionStrategiesMap.keySet().containsAll(enabledActions)) {
            throw new RuntimeException(MessageFormat.format("Some of action validators have not implemented yet. Enabled action types={0}" +
                    " Implemented validators types={1}", enabledActions, actionStrategiesMap.keySet()));
        }
        this.contextParamsValidator = contextParamsValidator;
    }

    @Override
    public ValidationResult validate(Action item, ProcessingContext context) {
        ActionValidationStrategy validationStrategy = actionStrategiesMap.get(item.getMerchActionType());

        if (validationStrategy != null) {
            ValidationResult validationResult = validationStrategy.validate(item);
            if (!validationResult.isValid()) {
                return validationResult;
            }
            validationResult = contextParamsValidator.validate(item);
            if (!validationResult.isValid()) {
                return validationResult;
            }
            return ValidationResult.validResult();
        }
        return ValidationResult.failResult(String.format("Didn't find validation strategy for action with id=%d and type=%s",
                item.getId(), item.getMerchActionType().name()));
    }
}
