package com.macys.search.bizrules.model.mrf;

/**
 * Simple boolean operation enum with 'AND' and 'OR' values.
 * This class is used into different parsers and case of elements is important.
 */
public enum BooleanOperation {
    AND, OR
}
