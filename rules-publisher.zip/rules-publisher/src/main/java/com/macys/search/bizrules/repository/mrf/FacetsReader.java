package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.mrf.Facet;
import com.macys.search.bizrules.tasklets.ProcessingContext;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

public class FacetsReader extends AbstractMysqlRepository {

    public FacetsReader(DataSource mcomDataSource, DataSource bcomDataSource, boolean isStreamMode) {
        super(mcomDataSource, bcomDataSource, isStreamMode);
    }

    public List<Facet> getFacets(ProcessingContext ctx) {
        List<Facet> facets = new ArrayList<>();
        read(ctx.getSiteName(),
                "select ATTR_NAME, FACET_DISPLAY_NAME from attribute where FACET_ATTRIBUTE='Y'",
                rs -> {
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        facets.add(Facet.of(rs.getString(1), rs.getString(2)));
                    }
                });
        return facets;
    }

}
