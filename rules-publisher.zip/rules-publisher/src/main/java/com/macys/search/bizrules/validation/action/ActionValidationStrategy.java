package com.macys.search.bizrules.validation.action;

import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.ValidationResult;

/**
 * Interface for strategies, that is used for Actions validations during loading
 */
public interface ActionValidationStrategy {

    /**
     * @return {@link ActionType} the strategy valid for
     */
    ActionType applicableFor();

    /**
     * @param action action that must be validated
     * @return true in case of successful validation. Otherwise return false and add to log explicit warn about
     * the reason of failed validation
     */
    ValidationResult validate(Action action);
}
