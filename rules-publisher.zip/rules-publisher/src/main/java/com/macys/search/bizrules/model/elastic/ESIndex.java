package com.macys.search.bizrules.model.elastic;

public enum ESIndex {
    RULES,
    TRIGGERS,
    KWP_TRIGGERS,
    ACTIONS,

    BIZ_CONTROLS_DB,

    CATEGORIES,
    PRODUCTS
}
