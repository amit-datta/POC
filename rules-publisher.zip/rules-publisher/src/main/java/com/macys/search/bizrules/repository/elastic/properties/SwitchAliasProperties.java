package com.macys.search.bizrules.repository.elastic.properties;

import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.config.utils.ESIndicesUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor(staticName = "of")
public class SwitchAliasProperties {
    private final ESIndex index;
    private final String mcomAliasName;
    private final String bcomAliasName;
    private final String indexVersion;
    private final int maxSegmentsNumber;

    public String getMcomFullAliasName() {
        return ESIndicesUtils.fullAliasNameFrom(mcomAliasName, indexVersion);
    }

    public String getBcomFullAliasName() {
        return ESIndicesUtils.fullAliasNameFrom(bcomAliasName, indexVersion);
    }


    public String getMcomShortAliasName() {
        return mcomAliasName;
    }

    public String getBcomShortAliasName() {
        return bcomAliasName;
    }
}
