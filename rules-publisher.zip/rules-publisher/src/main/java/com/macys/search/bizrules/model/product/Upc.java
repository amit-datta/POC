package com.macys.search.bizrules.model.product;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class Upc {
    private final int upcId;
    private final Price price;
    private final boolean available;
}
