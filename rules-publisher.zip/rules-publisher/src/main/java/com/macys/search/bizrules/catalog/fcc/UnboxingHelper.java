package com.macys.search.bizrules.catalog.fcc;

import lombok.experimental.UtilityClass;

/**
 * Contains rules for null unboxing
 */
@UtilityClass
public class UnboxingHelper {

    public static int unbox(Integer id) {
        if (id == null) return -1;
        return id;
    }

    public static double unbox(Double value) {
        if (value == null) return 0;
        return value;
    }

    public static boolean unbox(Boolean bool) {
        return Boolean.TRUE.equals(bool);
    }

}
