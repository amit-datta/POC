package com.macys.search.bizrules.model.category;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Collection;
import java.util.Map;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class Category {
    private final Integer id;
    private final String name;
    private final Integer parentCategoryId;
    private final Map<CategoryAttributeName, CategoryAttribute> attributes;
    private final Collection<String> countryExclusion;
    private final Collection<ContextOverride> contextOverrides;
    private final String externalHostUrl;
    private final int sequenceNumber;
}
