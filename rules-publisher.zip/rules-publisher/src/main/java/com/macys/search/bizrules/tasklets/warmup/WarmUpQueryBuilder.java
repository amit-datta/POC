package com.macys.search.bizrules.tasklets.warmup;

import com.macys.search.analysis.PhraseAnalyzerFactory;
import com.macys.search.bizrules.model.context.*;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.utils.QueryBuildingUtils;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.common.bytes.BytesReference;
import org.elasticsearch.common.lucene.search.function.FunctionScoreQuery;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.percolator.PercolateQueryBuilder;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.xcontent.XContentBuilder;
import org.elasticsearch.xcontent.XContentFactory;
import org.elasticsearch.xcontent.XContentType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields.*;
import static com.macys.search.bizrules.model.elastic.mappings.CategoryFieldMapping.CATEGORY_ID;
import static com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields.RULE_EFFECTIVE_DATE;
import static com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields.RULE_EXPIRATION_DATE;
import static com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields.*;
import static org.elasticsearch.index.query.QueryBuilders.*;
import static org.springframework.util.CollectionUtils.isEmpty;

@Component
@RequiredArgsConstructor
public class WarmUpQueryBuilder {
    private static final String US_REGION_CODE = "US";
    private static final String ANY_REGION_CODE = "ANY_REGION_CODE";
    private static final String ANY_FILTER_VALUE = "ANY";

    private final PhraseAnalyzerFactory analyzerFactory;

    @SneakyThrows
    private static QueryBuilder createKeywordPercolateQuery(String exact, String contains, String literal) {
        XContentBuilder docBuilder = XContentFactory.jsonBuilder().startObject();
        docBuilder.field(PHRASE_EXACT.getFieldName(), exact);
        docBuilder.field(PHRASE_CONTAINS.getFieldName(), contains);
        docBuilder.field(PHRASE_LITERAL.getFieldName(), literal);
        docBuilder.endObject();

        return new PercolateQueryBuilder(TRIGGER_QUERY.getFieldName(),
                BytesReference.bytes(docBuilder),
                XContentType.JSON
        );
    }

    private static QueryBuilder createDateRangeQuery(WarmUpRequest request) {
        LocalDate previewDate = Objects.requireNonNull(request.getCustomDate());

        RangeQueryBuilder effectiveDate = QueryBuilders.rangeQuery(RULE_EFFECTIVE_DATE.getFieldName());
        effectiveDate.lte(previewDate);

        RangeQueryBuilder expirationDate = QueryBuilders.rangeQuery(RULE_EXPIRATION_DATE.getFieldName());
        expirationDate.gte(previewDate);

        BoolQueryBuilder rangeQuery = boolQuery();
        rangeQuery.filter(effectiveDate);
        rangeQuery.filter(expirationDate);
        return rangeQuery;
    }

    private static void addContextAttributesQueries(BoolQueryBuilder query) {
        addContextQuery(DEVICE_TYPE_CTX_ATTR, List.of(DeviceType.values()), query);
        addContextQuery(SHOPPING_MODE_CTX_ATTR, List.of(ShoppingMode.values()), query);
        addContextQuery(NAVIGATION_TYPE_CTX_ATTR, List.of(NavigationType.values()), query);
        addContextQuery(APPLICATION_TYPE_CTX_ATTR, List.of(ApplicationType.values()), query);
        addContextQuery(CUSTOMER_EXPERIMENT_CTX_ATTR, List.of(CustomerExperiment.values()), query);
        query.filter(termsQuery(REGION_CODE_CTX_ATTR.getFieldName(), US_REGION_CODE, ANY_REGION_CODE));
    }

    private static <E extends Enum<E>> void addContextQuery(ActionsIndexFields field,
                                                            Collection<E> ctxValues,
                                                            BoolQueryBuilder query) {
        if (!isEmpty(ctxValues)) {
            query.filter(termsQuery(field.getFieldName(), fromEnumCollection(ctxValues)));
        }
    }

    private static QueryBuilder createActionTypeQuery(WarmUpRequest request) {
        if (CollectionUtils.isEmpty(request.getActionTypes())) {
            throw new IllegalArgumentException("ActionsSearchRequest must contain at least one action type. request=" +
                    request
            );
        }
        return termsQuery(ACTION_TYPE.getFieldName(), fromEnumCollection(request.getActionTypes()));
    }

    private static <E extends Enum<E>> Collection<String> fromEnumCollection(Collection<E> input) {
        return input.stream()
                .map(Enum::name)
                .collect(Collectors.toList());
    }

    public SearchSourceBuilder build(WarmUpRequest request) {
        return SearchSourceBuilder.searchSource()
                .query(buildQuery(request));
    }

    private QueryBuilder buildQuery(WarmUpRequest request) {
        BoolQueryBuilder query = boolQuery();
        query.filter(createActionTypeQuery(request));
        query.filter(createDateRangeQuery(request));
        addContextAttributesQueries(query);

        if (StringUtils.isNotBlank(request.getSearchPhrase())) {
            return buildKeywordQuery(request, query);
        }
        if (request.getCategoryId() != null) {
            return query.filter(QueryBuilders.termQuery(CATEGORY_ID.getFieldName(), request.getCategoryId()));
        }
        throw new AssertionError("Request must contain either phrase or catId. Request=" + request);
    }

    private QueryBuilder buildKeywordQuery(WarmUpRequest request, BoolQueryBuilder query) {
        String exact = analyzerFactory.createExactPhraseAnalyzer().analise(request.getSearchPhrase());
        String contains = analyzerFactory.createContainsPhraseAnalyzer().analise(request.getSearchPhrase());
        String literal = analyzerFactory.createLiteralPhraseAnalyzer().analise(request.getSearchPhrase());
        query.must(createKeywordPercolateQuery(exact, contains, literal));
        String joinedPhrases = String.join(" ", new HashSet<>(Arrays.asList(exact, contains, literal)));
        BoolQueryBuilder filterQuery = boolQuery()
                .should(termQuery(PERCOLATOR_FILTER.getFieldName(), ANY_FILTER_VALUE))
                .should(matchQuery(PERCOLATOR_FILTER.getFieldName(), joinedPhrases));
        query.filter(filterQuery);
        return QueryBuilders.functionScoreQuery(query)
                .setMinScore(QueryBuildingUtils.tokenCount.apply(literal))
                .scoreMode(FunctionScoreQuery.ScoreMode.SUM);
    }

}
