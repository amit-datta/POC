package com.macys.search.bizrules.tasklets;

import org.slf4j.MDC;
import org.springframework.batch.core.*;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.tasklets.JobParams.INDEXING_SESSION_ID;
import static com.macys.search.bizrules.tasklets.JobParams.SITE_NAME_JOB_PARAM;
import static org.springframework.batch.core.ExitStatus.COMPLETED;

/**
 * Put required tracking parameters to {@link MDC}
 */
@Component
public class SessionTrackerListener implements StepExecutionListener, JobExecutionListener {

    private static final String SESSION_ID = "SessionId";
    private static final String SITE_NAME = "SiteName";

    @Override
    public void beforeStep(@NonNull StepExecution stepExecution) {
        before(stepExecution.getJobParameters());
    }

    @Override
    public void beforeJob(@NonNull JobExecution jobExecution) {
        before(jobExecution.getJobParameters());
    }

    private void before(JobParameters params) {
        MDC.put(SESSION_ID, params.getString(INDEXING_SESSION_ID));
        MDC.put(SITE_NAME, params.getString(SITE_NAME_JOB_PARAM));
    }

    @Override
    public ExitStatus afterStep(@NonNull StepExecution stepExecution) {
        return COMPLETED;
    }

    @Override
    public void afterJob(@NonNull JobExecution jobExecution) {
        MDC.clear();
    }
}
