package com.macys.search.bizrules.rest;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.dto.RuleDto;
import com.macys.search.bizrules.services.merch.PreviewService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Rule api to fetch information from database about rule, it's actions and triggers
 */
@Slf4j
@RestController
@RequiredArgsConstructor
public class RuleController {

    private final PreviewService previewService;

    @GetMapping("/rules/{id}")
    public RuleDto getRuleById(@PathVariable Integer id,
                               @RequestParam SiteName siteName,
                               @RequestParam int attributesLimit) {
        return previewService.getRuleById(siteName, id, attributesLimit);
    }
}
