package com.macys.search.bizrules.catalog.fcc.product.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductCategoryBinding {
    private Integer id;
    private String poolName;
    private Integer seqNum;
}
