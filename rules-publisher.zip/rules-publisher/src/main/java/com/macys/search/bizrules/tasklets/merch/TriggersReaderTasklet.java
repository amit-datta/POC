package com.macys.search.bizrules.tasklets.merch;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.repository.mrf.TriggersReader;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Load {@link Trigger} from db
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TriggersReaderTasklet implements RulesPublisherTasklet {

    private final TriggersReader triggersReader;
    @Value("${rules.publisher.enabled.trigger-types}")
    private final List<TriggerType> enabledTriggerTypes;

    public void execute(ProcessingContext ctx) {
        log.info("Start trigger loading");
        final Map<Integer, ProcessingTrigger> triggers = new HashMap<>();
        triggersReader.readTriggers(ctx, enabledTriggerTypes, triggers);
        ctx.setTriggers(triggers);
        ctx.getStatistics().getTriggersStatistics().setLoadedTriggers(triggers.size());
        log.info("Read {} trigger", triggers.size());
    }

}
