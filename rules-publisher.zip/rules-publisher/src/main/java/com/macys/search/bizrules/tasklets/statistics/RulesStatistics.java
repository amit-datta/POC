package com.macys.search.bizrules.tasklets.statistics;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
@JsonDeserialize
public class RulesStatistics {
    @Setter
    private int loadedRules;
    private int indexedRules;
    private int validRules;
    private int invalidRules;

    public void incrementIndexedRules() {
        indexedRules++;
    }

    public void incrementValidRules() {
        validRules++;
    }

    public void incrementInvalidRules() {
        invalidRules++;
    }
}
