package com.macys.search.bizrules.validation;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.validation.model.AttributeTemplate;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import com.macys.search.bizrules.validation.model.CriteriaTemplate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

import static com.macys.search.bizrules.validation.ValidationResult.failResult;
import static com.macys.search.bizrules.validation.ValidationResult.validResult;
import static java.text.MessageFormat.format;

/**
 * Helper functions to validate merch configs
 */
public class CriteriaAttributesValidator {

    /**
     * Compare criteriaMap with template. Template contains mandatory criteria and their mandatory attributes
     *
     * @param criteriaMap criteria map to validate
     * @param template    validation template
     * @return validation result
     */
    public static ValidationResult validateCriteriaMap(Map<String, Criteria> criteriaMap, ConfigTemplate template) {
        if (criteriaMap == null) {
            return failResult("Criteria map is null.");
        }
        for (Map.Entry<String, CriteriaTemplate> entry : template.getCriteriaNameToCriteria().entrySet()) {
            String criteriaName = entry.getKey();
            CriteriaTemplate criteriaTemplate = entry.getValue();

            Criteria criteria = criteriaMap.get(criteriaName);
            if (criteria == null) {
                return failResult("Missing criteria with name=" + criteriaName + '.');
            }
            ValidationResult attributeValidationResult = validateCriteriaAttributes(criteria, criteriaTemplate);
            if (!attributeValidationResult.isValid()) {
                return failResult(format("Criteria with name={0} validation failed. {1}",
                        criteriaName, attributeValidationResult.getWarning())
                );
            }
        }
        return validResult();
    }

    /**
     * Compare single criteria with template
     *
     * @param criteria         criteria to validate
     * @param criteriaTemplate template
     * @return validation result
     */
    public static ValidationResult validateCriteriaAttributes(Criteria criteria, CriteriaTemplate criteriaTemplate) {
        if (criteria == null) {
            return failResult("Criteria is null.");
        }
        for (Map.Entry<String, AttributeTemplate> entry : criteriaTemplate.getAttributeNameToAttribute().entrySet()) {
            String attrName = entry.getKey();
            AttributeTemplate attrTemplate = entry.getValue();

            List<String> attrValues = criteria.getCriteriaAttributes().get(attrName);
            if (attrValues == null) {
                if (attrTemplate.isOptional()) {
                    continue;
                } else {
                    return failResult(format("Criteria={0} has missing attribute with name={1}.",
                            criteria.getCriteriaName(), attrName));
                }
            }
            if ((attrTemplate.isUniq() || attrTemplate.isNotEmpty()) && attrValues.isEmpty()) {
                return failResult(format("In Criteria {0} attribute {1} must contain value but it is empty.",
                        criteria.getCriteriaName(), attrName));
            }
            if (attrTemplate.isUniq() && attrValues.size() > 1) {
                return failResult(format("In Criteria {0} attribute {1} must contain only one value. But its values={2}.",
                        criteria.getCriteriaName(), attrName, attrValues));
            }
            if (attrTemplate.isUniq() && StringUtils.isBlank(attrValues.get(0))) {
                return failResult(format("In criteria {0} attribute {1} has blank value.",
                        criteria.getCriteriaName(), attrName));
            }
            if (attrTemplate.hasTypeValidation()) {
                for (String value : attrValues) {
                    if (!attrTemplate.getType().isValid(value)) {
                        return failResult(format("In criteria {0} attribute {1} contains wrong value={2}. Values={3} should match the type={4}.",
                                criteria.getCriteriaName(), attrName, value, attrValues, attrTemplate.getType()));
                    }
                }
            }
            if (!CollectionUtils.isEmpty(attrTemplate.getPossibleValues())) {
                if (!attrTemplate.getPossibleValues().containsAll(attrValues)) {
                    return failResult(format("In criteria {0} attribute {1} contains unexpected values. Possible values={2}, real values={3}.",
                            criteria.getCriteriaName(), attrName, attrTemplate.getPossibleValues(), attrValues));
                }
            }
        }
        return validResult();
    }

}
