package com.macys.search.bizrules.validation.model;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.macys.search.bizrules.model.mrf.Criteria;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * Template for {@link Criteria}
 */
@Getter
public class CriteriaTemplate {
    private final Map<String, AttributeTemplate> attributeNameToAttribute = new HashMap<>();

    @JsonAnySetter
    public void add(String key, AttributeTemplate value) {
        attributeNameToAttribute.put(key, value);
    }
}
