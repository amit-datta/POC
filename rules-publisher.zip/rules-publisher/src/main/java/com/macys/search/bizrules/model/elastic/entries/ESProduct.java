package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.model.elastic.mappings.ProductIndexFields;
import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import java.util.*;

import static com.macys.search.bizrules.model.elastic.mappings.ProductIndexFields.*;

@Setter
public class ESProduct implements ESEntry {

    private Integer productId;

    private Collection<Integer> catIds;
    private Collection<String> catPaths;
    @Getter
    private Set<Integer> msrBoost = new HashSet<>();
    @Getter
    private Set<Integer> msrAdd = new HashSet<>();
    @Getter
    private Set<Integer> msrReplace = new HashSet<>();
    @Getter
    private Set<Integer> msrRemove = new HashSet<>();
    @Getter
    private Set<String> msrBoostWithSequenceNumber = new HashSet<>();

    @Override
    public String getElasticId() {
        return productId.toString();
    }

    @Override
    public Map<String, ?> getSource() {
        Map<String, Object> map = new LinkedHashMap<>();

        map.put(PRODUCT_ID.getFieldName(), productId);

        putCollection(CAT_IDS, catIds, map);
        putCollection(CAT_PATHS, catPaths, map);

        putCollection(MSR_BOOST, msrBoost, map);
        putCollection(MSR_ADD, msrAdd, map);
        putCollection(MSR_REMOVE, msrRemove, map);
        putCollection(MSR_REPLACE, msrReplace, map);
        putCollection(MSR_BOOST_WITH_SEQUENCE_NUMBER, msrBoostWithSequenceNumber, map);
        return map;
    }

    private static void putCollection(ProductIndexFields field, Collection<?> collection, Map<String, Object> map) {
        if (!CollectionUtils.isEmpty(collection)) {
            map.put(field.getFieldName(), collection);
        }
    }
}
