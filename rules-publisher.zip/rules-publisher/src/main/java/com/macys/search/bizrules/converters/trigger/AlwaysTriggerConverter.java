package com.macys.search.bizrules.converters.trigger;

import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.model.processing.trigger.params.AlwaysTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.stereotype.Component;

/**
 * Convert triggers with {@link TriggerType#Always}.
 * Always use {@link org.elasticsearch.index.query.MatchAllQueryBuilder} as trigger query
 */
@Component
public class AlwaysTriggerConverter implements TriggerConverter {

    public TriggerType applicableFor() {
        return TriggerType.Always;
    }

    public AbstractTriggerParams convert(ProcessingTrigger processingTrigger, ProcessingContext ctx) {
        return new AlwaysTriggerParams(processingTrigger.getId());
    }
}
