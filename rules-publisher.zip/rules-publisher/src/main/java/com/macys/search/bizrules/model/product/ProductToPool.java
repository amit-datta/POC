package com.macys.search.bizrules.model.product;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductToPool {
    private final Integer poolId;
    private final Integer sequenceNumber;
}
