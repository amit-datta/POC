package com.macys.search.bizrules.tasklets.statistics;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.macys.search.bizrules.model.SiteName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * High-level indexing statistics
 */
@Getter
@ToString
@JsonDeserialize
public class IndexingStatistics {
    @Setter
    private SiteName siteName;
    @Setter
    private String sessionId;

    private final ActionsStatistics actionsStatistics = new ActionsStatistics();
    private final RulesStatistics rulesStatistics = new RulesStatistics();
    private final TriggersStatistics triggersStatistics = new TriggersStatistics();
    private final FCCCategoriesStatistics fccCategoriesStatistics = new FCCCategoriesStatistics();
    private final FCCProductsStatistics fccProductsStatistics = new FCCProductsStatistics();
}
