package com.macys.search.bizrules.catalog.fcc.product;

import com.macys.search.bizrules.catalog.ProductsLoader;
import com.macys.search.bizrules.catalog.fcc.AbstractFCCLoader;
import com.macys.search.bizrules.catalog.fcc.FccField;
import com.macys.search.bizrules.catalog.fcc.product.bindings.ProductsRootBinding;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.catalog.fcc.AbstractFCCLoader.URIParams.*;

@Slf4j
public class ProductsLoaderImpl extends AbstractFCCLoader<ProductsRootBinding, Product> implements ProductsLoader {

    protected static final String CUSTOM_DATE = "CUSTOM_DATE";
    protected static final String UNAVAILABLE_SINCE = "UNAVAILABLE_SINCE";
    protected static final String UNAVAILABLE_CREATED_SINCE = "UNAVAILABLE_CREATED_SINCE";
    protected static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    protected final int includeUnavailableSince;
    protected final int includeUnavailableCreatedSince;
    protected final String urlBasePath;

    public ProductsLoaderImpl(RestTemplate restTemplate,
                              String mcomFccURL,
                              String bcomFccURL,
                              int batchSize,
                              int retryCount,
                              int threadsCount,
                              int includeUnavailableSince,
                              int includeUnavailableCreatedSince,
                              Collection<FccField> fields) {
        super(restTemplate, mcomFccURL, bcomFccURL, batchSize, retryCount, threadsCount, ProductsRootBinding.class);
        this.includeUnavailableSince = includeUnavailableSince;
        this.includeUnavailableCreatedSince = includeUnavailableCreatedSince;
        this.urlBasePath = buildUrlBasePath(fields);
    }


    @Override
    public Collection<Product> loadAll(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics) {
        log.info("Start products from FCC for {}", siteName);
        Collection<Product> result = loadAll(siteName, additionalParams(customDate), "Product", timeStatistics);
        log.info("From FCC loaded {} products", result.size());
        return result;
    }

    @Override
    public Iterator<Product> iterator(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics) {
        return iterator(siteName, additionalParams(customDate), "Product", timeStatistics);
    }

    private Map<String, String> additionalParams(LocalDate customDate) {
        return Map.of(
                CUSTOM_DATE, customDate.format(DATE_FORMAT),
                UNAVAILABLE_SINCE, customDate.minusDays(includeUnavailableSince).format(DATE_FORMAT),
                UNAVAILABLE_CREATED_SINCE, customDate.minusDays(includeUnavailableCreatedSince).format(DATE_FORMAT)
        );
    }

    @Override
    public String getPathWithParams() {
        return urlBasePath;
    }

    @Override
    public boolean isBatchEmpty(ProductsRootBinding root) {
        return root.getProducts() == null || CollectionUtils.isEmpty(root.getProducts().getProduct());
    }

    @Override
    public Collection<Product> convert(ProductsRootBinding root) {
        return root.getProducts().getProduct().stream()
                .map(FCCProductConverter::convert)
                .collect(Collectors.toList());
    }

    private String buildUrlBasePath(Collection<FccField> productFields) {
        String fields = productFields.stream().map(FccField::toString).collect(Collectors.joining(","));
        String url = "/api/catalog/v2/products" +
                "?filter=PURCHASABLE_BOPS" +

                "&_expand=memberProducts(" + fields + ")" +
                "&_fields=" + fields +
                "&_offset={" + OFFSET + "}" +
                "&_limit={" + LIMIT + "}" +
                "&partition={" + PARTITION + "}" +
                "&partitions={" + PARTITIONS + "}" +
                "&reqDate={" + CUSTOM_DATE + "}" +
                "&includeUnavailableSince={" + UNAVAILABLE_SINCE + "}" +
                "&includeUnavailableCreatedSince={" + UNAVAILABLE_CREATED_SINCE + "}";

        log.info("FccProducts base url={}", url);
        return url;
    }
}
