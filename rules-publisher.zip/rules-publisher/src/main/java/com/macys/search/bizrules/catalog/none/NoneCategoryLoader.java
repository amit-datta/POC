package com.macys.search.bizrules.catalog.none;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

/**
 * Stub for disable category loading
 */
public class NoneCategoryLoader implements CategoryLoader {

    @Override
    public Collection<Category> loadAll(SiteName siteName, TimeStatistics timeStatistics) {
        return Collections.emptyList();
    }

    @Override
    public Iterator<Category> iterator(SiteName siteName, TimeStatistics timeStatistics) {
        return Collections.emptyIterator();
    }
}
