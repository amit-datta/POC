package com.macys.search.bizrules.model.mrf.action;

import com.macys.search.bizrules.model.mrf.Criteria;
import lombok.Data;

import java.time.LocalDate;
import java.util.*;

/**
 * Merchandising action configuration.
 * Contains data which describes actions which should be preformed when merchandising rule containing this actionConfig is fired.
 */
@Data
public class Action {
    private Integer id;
    private LocalDate lastModified;
    private LocalDate createdDate;
    private String lastModifiedByName;
    private ActionType merchActionType;
    private List<ActionParameter> params = new ArrayList<>();

    private Map<String, Collection<String>> contextAttributes = new HashMap<>();
    private Map<String, Criteria> criteriaMap = new HashMap<>();
    private boolean nonEqualSeqNumberInSomeCriteria;

    public Criteria getCriteria(String name) {
        return criteriaMap.get(name);
    }
}
