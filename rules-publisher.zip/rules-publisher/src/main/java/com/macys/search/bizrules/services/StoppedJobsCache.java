package com.macys.search.bizrules.services;

import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class StoppedJobsCache {
    private final Set<Long> stoppedJobs = new HashSet<>();

    public void add(long executionId) {
        stoppedJobs.add(executionId);
    }

    public void remove(long executionId) {
        stoppedJobs.remove(executionId);
    }

    public boolean contains(long executionId) {
        return stoppedJobs.contains(executionId);
    }
}
