package com.macys.search.bizrules.converters.trigger;

import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.List;

@Slf4j
@Component
public class TriggerConverterService {

    private final EnumMap<TriggerType, TriggerConverter> convertersMap = new EnumMap<>(TriggerType.class);

    @Autowired
    public TriggerConverterService(
            List<TriggerConverter> parsers,
            @Value("${rules.publisher.enabled.trigger-types}") List<TriggerType> enabledTriggers) {
        parsers.stream()
                .filter(parser -> enabledTriggers.contains(parser.applicableFor()))
                .forEach(parser -> convertersMap.put(parser.applicableFor(), parser));
        if (!convertersMap.keySet().containsAll(enabledTriggers)) {
            throw new RuntimeException(MessageFormat.format("Some of trigger converter have not implemented yet. Enabled trigger types={0}" +
                    " Implemented converter types={1}", enabledTriggers, convertersMap.keySet()));
        }
    }

    public AbstractTriggerParams convertTrigger(ProcessingTrigger processingTrigger, ProcessingContext ctx) {
        TriggerConverter triggerConverter = convertersMap.get(processingTrigger.getTriggerType());
        if (triggerConverter == null) {
            log.error("Was not found trigger converter for triggerId={} type={}", processingTrigger.getId(),
                    processingTrigger.getTriggerType()
            );
            return null;
        }
        return triggerConverter.convert(processingTrigger, ctx);
    }
}
