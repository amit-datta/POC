package com.macys.search.bizrules.utils;

import com.macys.search.bizrules.repository.mrf.CustomDateReader;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;

@Slf4j
@UtilityClass
public class CustomDateUtils {
    public static LocalDate getCustomDate(ProcessingContext ctx, CustomDateReader customDateReader) {
        if (ctx.getCustomDate() != null) {
            return ctx.getCustomDate();
        }
        final LocalDate customDateFromDb = customDateReader.getCustomDate(ctx.getSiteName());
        if (customDateFromDb != null) {
            log.info("CustomDate={}", customDateFromDb);
            ctx.setCustomDate(customDateFromDb);
            return customDateFromDb;
        }
        log.warn("Custom date is null. Continue indexing using current date");
        ctx.setCustomDate(LocalDate.now());
        return ctx.getCustomDate();
    }
}
