package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.converters.ConverterUtils;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.CATEGORY_REDIRECT;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.CATEGORY_REDIRECT_ID;

/**
 * {@link ActionConverter} implementation for {@link ActionType#CategoryRedirect} type
 */
@Component
class CategoryRedirectConverter extends AbstractActionConverter {

    @Override
    public ActionType applicableFor() {
        return ActionType.CategoryRedirect;
    }

    @Override
    void enrichWithTypeSpecificProperties(Action action, ESAction doc, ProcessingContext context) {
        doc.setFieldValue(ActionsIndexFields.ACTION_TYPE, ESActionType.CATEGORY_REDIRECT);
        String value = ConverterUtils.getUnaryValue(action, CATEGORY_REDIRECT, CATEGORY_REDIRECT_ID);
        doc.setFieldValue(ActionsIndexFields.CATEGORY_REDIRECT_ID, value);
    }

}
