package com.macys.search.exception;

public class RulesPublisherException extends Exception {
    public RulesPublisherException(String message) {
        super(message);
    }
    public RulesPublisherException(String message, Throwable cause) {
        super(message, cause);
    }
}
