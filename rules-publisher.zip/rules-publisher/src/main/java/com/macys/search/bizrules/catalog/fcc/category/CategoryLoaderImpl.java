package com.macys.search.bizrules.catalog.fcc.category;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.catalog.fcc.AbstractFCCLoader;
import com.macys.search.bizrules.catalog.fcc.FccField;
import com.macys.search.bizrules.catalog.fcc.category.bindings.CategoriesRootBinding;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.catalog.fcc.AbstractFCCLoader.URIParams.*;

@Slf4j
public class CategoryLoaderImpl extends AbstractFCCLoader<CategoriesRootBinding, Category> implements CategoryLoader {

    protected final String urlBasePath;

    public CategoryLoaderImpl(RestTemplate restTemplate,
                              String mcomFccURL,
                              String bcomFccURL,
                              int batchSize,
                              int retryCount,
                              int threadsCount,
                              Collection<FccField> fields) {
        super(restTemplate, mcomFccURL, bcomFccURL, batchSize, retryCount,
                threadsCount, CategoriesRootBinding.class);
        this.urlBasePath = buildUrlBasePath(fields);
    }

    @Override
    protected boolean isBatchEmpty(CategoriesRootBinding root) {
        return root.getCategories() == null || CollectionUtils.isEmpty(root.getCategories().getCategory());
    }

    @Override
    protected Collection<Category> convert(CategoriesRootBinding root) {
        return root.getCategories().getCategory().stream()
                .map(FCCCategoryConverter::convert)
                .collect(Collectors.toList());
    }

    @Override
    public Collection<Category> loadAll(SiteName siteName, TimeStatistics timeStatistics) {
        log.info("Start loading categories from FCC for {}", siteName);
        Collection<Category> result = loadAll(siteName, Map.of(), "Category", timeStatistics);
        log.info("From FCC loaded {} categories", result.size());
        return result;
    }

    @Override
    public Iterator<Category> iterator(SiteName siteName, TimeStatistics timeStatistics) {
        return iterator(siteName, Map.of(), "Category", timeStatistics);
    }

    @Override
    protected String getPathWithParams() {
        return urlBasePath;
    }

    protected String buildUrlBasePath(Collection<FccField> categoryFields) {
        String fields = categoryFields.stream().map(FccField::toString).collect(Collectors.joining(","));
        String url = "/api/catalog/v2/categories" +
                "?filter=ACTIVE" +
                "&applyOverride=false" +
                "&_fields=" + fields +
                "&_offset={" + OFFSET + "}" +
                "&_limit={" + LIMIT + "}" +
                "&partition={" + PARTITION + "}" +
                "&partitions={" + PARTITIONS + "}";

        log.info("FccCategory base url={}", url);
        return url;
    }
}
