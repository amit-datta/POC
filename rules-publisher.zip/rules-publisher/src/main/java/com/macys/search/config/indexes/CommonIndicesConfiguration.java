package com.macys.search.config.indexes;

import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CommonIndicesConfiguration {
    @Value("${rules.publisher.mcom.indices-to-keep}")
    private int mcomIndicesToKeep;
    @Value("${rules.publisher.bcom.indices-to-keep}")
    private int bcomIndicesToKeep;
    @Value("${rules.publisher.mcom.unfinished.indices.alias.name}")
    private String mcomUnfinishedAlias;
    @Value("${rules.publisher.bcom.unfinished.indices.alias.name}")
    private String bcomUnfinishedAlias;

    @Bean
    public CommonIndexProperties mcomCommonIndexProperties() {
        return new CommonIndexProperties(mcomIndicesToKeep, mcomUnfinishedAlias);
    }

    @Bean
    public CommonIndexProperties bcomCommonIndexProperties() {
        return new CommonIndexProperties(bcomIndicesToKeep, bcomUnfinishedAlias);
    }
}
