package com.macys.search.bizrules.model.mrf.rule;

/**
 * Business types of {@link Rule}
 */
public enum RuleType {
    MERCH,
    SEO
}