package com.macys.search.bizrules.validation.action;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionConstants;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.validation.CriteriaAttributesValidator.validateCriteriaMap;
import static java.text.MessageFormat.format;

/**
 * Implementation of validation strategy for action {@link com.macys.search.bizrules.model.mrf.action.ActionType#ShowMedia}
 * validates that given actionConfig {@link Action} contains either valid Canvas with CanvasId parameter or
 * MediaId as positive integer and MediaIdType with "MediaGroup" or "MediaPool" value attributes
 */
@Slf4j
@Component
public class ShowMediaActionValidationStrategy implements ActionValidationStrategy {

    @ResourceMapping("classpath:merch-validation-template/action/ShowMediaCanvas.json")
    private ConfigTemplate canvasValidationTemplate;

    @Override
    public ActionType applicableFor() {
        return ActionType.ShowMedia;
    }

    @Override
    public ValidationResult validate(Action action) {
        Criteria canvasCriteria = action.getCriteria(ActionConstants.SHOW_MEDIA_CANVAS);
        if (canvasCriteria != null) {
            if (action.getCriteriaMap().size() > 1) {
                String msg = "Canvas criteria should be single criteria in map. Criteria={0}";
                return ValidationResult.failResult(format(msg, action.getCriteriaMap().keySet()));
            }
            ValidationResult validationResult = validateCriteriaMap(action.getCriteriaMap(), canvasValidationTemplate);
            if (!validationResult.isValid()) {
                return validationResult;
            }
            return ValidationResult.validResult();
        }

        if (action.getCriteriaMap().isEmpty()) {
            return ValidationResult.failResult("Show media action should contains at least one criteria");
        }

        return ValidationResult.failResult("Only show canvas id actions available.");
    }

}
