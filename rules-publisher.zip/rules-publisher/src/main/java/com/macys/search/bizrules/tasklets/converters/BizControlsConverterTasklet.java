package com.macys.search.bizrules.tasklets.converters;

import com.macys.search.bizrules.model.elastic.entries.ESBizControl;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.model.elastic.ESBizControlType.*;
import static com.macys.search.bizrules.model.elastic.ESIndex.*;

@Slf4j
@Component
@AllArgsConstructor
public class BizControlsConverterTasklet implements RulesPublisherTasklet {

    private final ElasticSearchIndexerFactory elasticSearchIndexerFactory;

    public void execute(ProcessingContext ctx) {
        String bizControlsDbIndexName = ctx.getIndexName(BIZ_CONTROLS_DB);
        ElasticSearchIndexer indexer = elasticSearchIndexerFactory.createIndexer(bizControlsDbIndexName);

        indexer.add(ESBizControl.of(CUSTOM_DATE, ctx.getCustomDate().toString()));

        indexer.add(ESBizControl.of(ACTIONS_INDEX, ctx.getIndexName(ACTIONS)));
        indexer.add(ESBizControl.of(RULES_INDEX, ctx.getIndexName(RULES)));
        indexer.add(ESBizControl.of(TRIGGERS_INDEX, ctx.getIndexName(TRIGGERS)));
        indexer.add(ESBizControl.of(KWP_TRIGGERS_INDEX, ctx.getIndexName(KWP_TRIGGERS)));

        if (!indexer.flush()) {
            throw new RuntimeException("Some exception occurred during send documents to Elastic search. " +
                    "Please check logs for additional information");
        }
    }
}
