package com.macys.search.bizrules.tasklets.esmanaging;

import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * Remove processing Elastic search index.
 * This tasklet should be executed only if any error occurs during indexing process.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class RemoveIndicesTasklet implements RulesPublisherTasklet {
    private final ElasticSearchFacade elasticSearchFacade;

    public void execute(ProcessingContext ctx) {
        Collection<String> indices = ctx.getIndexNames().values();
        log.error("Deleting indices {} because of errors during inserting data", indices);
        elasticSearchFacade.deleteIndices(indices.toArray(String[]::new));
        throw new RuntimeException("Job failed due to errors. Check logs for additional info");
    }
}
