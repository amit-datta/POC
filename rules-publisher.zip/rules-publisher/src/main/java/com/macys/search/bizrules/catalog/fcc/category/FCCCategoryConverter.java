package com.macys.search.bizrules.catalog.fcc.category;

import com.macys.search.bizrules.catalog.fcc.category.bindings.*;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import com.macys.search.bizrules.model.category.ContextOverride;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public class FCCCategoryConverter {

    private final static Set<String> processingAttrNames = Arrays.stream(CategoryAttributeName.values())
            .map(String::valueOf)
            .collect(Collectors.toUnmodifiableSet());

    public static Category convert(CategoryBinding binding) {
        return Category.builder()
                .id(binding.getId())
                .name(binding.getName())
                .parentCategoryId(binding.getParentCategoryId())
                .attributes(convertAttributes(binding.getAttributes()))
                .externalHostUrl(binding.getExternalHostUrl())
                .sequenceNumber(binding.getSequenceNumber())
                .countryExclusion(convertCountryExclusion(binding.getCountryExclusion()))
                .contextOverrides(convertContextOverrides(binding.getContextOverrides(), binding.getId()))
                .build();
    }

    private static Map<CategoryAttributeName, CategoryAttribute> convertAttributes(Collection<AttributeBinding> attrs) {
        if (CollectionUtils.isEmpty(attrs)) return Collections.emptyMap();
        return attrs.stream()
                .filter(binding -> StringUtils.isNotBlank(binding.getName())
                        && processingAttrNames.contains(binding.getName()))
                .map(FCCCategoryConverter::convertAttribute)
                .collect(Collectors.toMap(
                                CategoryAttribute::getName,
                                Function.identity(),
                                (a, b) -> {
                                    log.warn("Duplicated attr name={}. Values={} and {}", a.getName(),
                                            a.getValues(), b.getValues()
                                    );
                                    return a;
                                },
                                () -> new EnumMap<>(CategoryAttributeName.class)
                        )
                );
    }

    private static CategoryAttribute convertAttribute(AttributeBinding binding) {
        return CategoryAttribute.builder()
                .name(CategoryAttributeName.valueOf(binding.getName()))
                .values(convertAttrValues(binding.getAttributeValues()))
                .sortWeight(binding.getSortWeight())
                .visible(binding.getVisible())
                .build();
    }

    private static Set<String> convertAttrValues(Collection<AttributeValueBinding> values) {
        if (CollectionUtils.isEmpty(values)) return Collections.emptySet();
        return values.stream()
                .map(AttributeValueBinding::getValue)
                .filter(Objects::nonNull)
                .collect(Collectors.toUnmodifiableSet());
    }

    private static Collection<String> convertCountryExclusion(Collection<String> countryExclusion) {
        if (CollectionUtils.isEmpty(countryExclusion)) {
            return countryExclusion;
        }
        return countryExclusion.stream().map(String::trim).collect(Collectors.toSet());
    }

    private static Collection<ContextOverride> convertContextOverrides(ContextOverridesBinding contextOverrides, Integer categoryId) {
        List<ContextOverride> result = new ArrayList<>();
        if (contextOverrides != null && !CollectionUtils.isEmpty(contextOverrides.getContextOverride())) {
            for(ContextOverrideBinding overrideBinding: contextOverrides.getContextOverride()) {
                ContextOverride contextOverride = new ContextOverride();
                final ContextBinding context = overrideBinding.getContext();
                if (context == null) {
                    throw new IllegalArgumentException(String.format("Category override context is null for context " +
                            "override of category %d: %s", categoryId, overrideBinding));
                }
                contextOverride.setId(context.getId());
                contextOverride.setName(overrideBinding.getName());
                final Integer sequenceNumber = overrideBinding.getSequenceNumber();
                if (sequenceNumber != null) {
                    contextOverride.setSequenceNumber(sequenceNumber);
                }
                final Boolean suppressed = overrideBinding.getSuppressed();
                if (suppressed != null) {
                    contextOverride.setSuppressed(suppressed);
                }
                final ContextAttributesBinding contextAttributes = context.getContextAttributes();
                if (contextAttributes == null || contextAttributes.getAttribute() == null) {
                    throw new IllegalArgumentException(String.format("Category override context has no attributes" +
                            " for category %d: %s", categoryId, overrideBinding));
                }
                for (ContextAttributeBinding attributeBinding : contextAttributes.getAttribute()) {
                    contextOverride.addAttribute(attributeBinding.getName(), attributeBinding.getValue());
                }
                result.add(contextOverride);
            }
        }
        return result;
    }
}
