package com.macys.search.bizrules.model.context;

/**
 * ApplicationType context attribute
 */
public enum ApplicationType {
    SITE,
    ASSOCIATE,
    MOBILE,
    MEW,
    SEO_LINK_MODULE,
    SEARCH_AND_SEND,
    MSA
}
