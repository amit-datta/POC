package com.macys.search.bizrules.model.processing;

import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@Getter
@Setter
public class ProcessingRule {
    private static final Integer ENABLED_STATE = 1;

    private Rule rule;
    private ValidationResult validationResult;
    private int naturalId;
    private Collection<Integer> naturalTriggerIds;

    private boolean isProcessed;

    private LocalDate overriddenExpirationDate;
    private List<ProcessingAction> actions;
    private List<ProcessingTrigger> validTriggers;

    private ProcessingRule(Rule rule) {
        this.rule = rule;
    }

    public static ProcessingRule from(Rule rule) {
        return new ProcessingRule(rule);
    }

    public boolean isValid() {
        return validationResult.isValid();
    }

    public Integer getRuleId() {
        return rule.getId();
    }

    public Integer getRulePriority() {
        return rule.getPriority();
    }

    public String getRuleName() {
        return rule.getName();
    }

    public RuleType getRuleType() {
        return rule.getMerchRuleType();
    }

    public LocalDate getRuleEffectiveDate() {
        return rule.getEffectiveDate();
    }

    public LocalDate getRuleExpirationDate() {
        return overriddenExpirationDate == null ? rule.getExpirationDate() : overriddenExpirationDate;
    }

    public LocalDateTime getRuleCreatedDate() {
        return rule.getCreatedDate();
    }

    public LocalDateTime getRuleLastModifiedDate() {
        return rule.getLastModified();
    }

    public String getLastModifiedByName() {
        return rule.getLastModifiedByName();
    }

    public String getRuleOwner() {
        return rule.getAuthorName();
    }

    public String getRuleDescription() {
        return rule.getDescription();
    }

    public boolean isEnabled() {
        return ENABLED_STATE.equals(rule.getStateCode());
    }

    public BooleanOperation getTriggerOperation() {
        return rule.getTriggerOperation() == null ? BooleanOperation.OR : rule.getTriggerOperation();
    }

    public Set<Integer> getRuleCategoryIds() {
        return rule.getCategoryIds();
    }

}
