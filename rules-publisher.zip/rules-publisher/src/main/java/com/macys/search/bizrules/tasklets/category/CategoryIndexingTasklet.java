package com.macys.search.bizrules.tasklets.category;

import com.macys.search.bizrules.converters.category.CategoryConverter;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.ESCategory;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.tasklets.statistics.FCCCategoriesStatistics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class CategoryIndexingTasklet implements RulesPublisherTasklet {

    private final ElasticSearchIndexerFactory elasticSearchIndexerFactory;
    private final CategoryConverter converter;

    public void execute(ProcessingContext ctx) {
        ElasticSearchIndexer indexer = elasticSearchIndexerFactory.createIndexer(
                ctx.getIndexName(ESIndex.CATEGORIES)
        );
        FCCCategoriesStatistics statistics = ctx.getStatistics().getFccCategoriesStatistics();
        CategoryTree categoryTree = ctx.getCategoryTree();

        for (Category category : categoryTree) {
            ESCategory esCategory = converter.convert(category, categoryTree);
            indexer.add(esCategory);
            statistics.incrementIndexedCategories();
        }

        if (!indexer.flush()) {
            throw new RuntimeException("Some exception occurred during send categories to Elastic search. " +
                    "Please check logs for additional information");
        }
    }

}
