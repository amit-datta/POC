package com.macys.search.bizrules.catalog.fcc.product;

import com.macys.search.bizrules.catalog.ProductsLoader;
import com.macys.search.bizrules.catalog.fcc.FccField;
import com.macys.search.bizrules.catalog.none.NoneProductsLoader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;

@Configuration
@Slf4j
public class ProductsLoaderConfiguration {

    private final RestTemplate restTemplate;
    private final String mcomFccURL;
    private final String bcomFccURL;
    private final int batchSize;
    private final int retryCount;
    private final int threadsCount;
    private final int includeUnavailableSince;
    private final int includeUnavailableCreatedSince;
    private final Collection<FccField> fccProductFields;
    private final Collection<FccField> fccLightProductFields;

    public ProductsLoaderConfiguration(RestTemplate restTemplate,
                                       @Value("${rules.publisher.mcom.fcc.products.url}") String mcomFccURL,
                                       @Value("${rules.publisher.bcom.fcc.products.url}") String bcomFccURL,
                                       @Value("${rules.publisher.fcc.products.batch-size}") int batchSize,
                                       @Value("${rules.publisher.fcc.request.retries}") int retryCount,
                                       @Value("${rules.publisher.fcc.products.load.threads-count}") int threadsCount,
                                       @Value("${rules.publisher.fcc.products.index.unavailable.days.threshold}") int includeUnavailableSince,
                                       @Value("${rules.publisher.fcc.products.index.unavailable.recently.created.days.threshold}") int includeUnavailableCreatedSince,
                                       Collection<FccField> fccProductFields,
                                       Collection<FccField> fccLightProductFields) {
        this.restTemplate = restTemplate;
        this.mcomFccURL = mcomFccURL;
        this.bcomFccURL = bcomFccURL;
        this.batchSize = batchSize;
        this.retryCount = retryCount;
        this.threadsCount = threadsCount;
        this.includeUnavailableSince = includeUnavailableSince;
        this.includeUnavailableCreatedSince = includeUnavailableCreatedSince;
        this.fccProductFields = fccProductFields;
        this.fccLightProductFields = fccLightProductFields;
    }

    @Bean
    @ConditionalOnProperty(name = "rules.publisher.load.products.from",
            havingValue = "NONE",
            matchIfMissing = true
    )
    public ProductsLoader noneProductsLoader() {
        log.info("NoneProductsLoader was created");
        return new NoneProductsLoader();
    }


    @Bean
    @ConditionalOnProperty(name = "rules.publisher.load.products.from", havingValue = "FCC")
    public ProductsLoader fccProductsLoader() {
        log.info("FccProductsLoader was created");
        return new ProductsLoaderImpl(restTemplate, mcomFccURL, bcomFccURL, batchSize, retryCount, threadsCount,
                includeUnavailableSince, includeUnavailableCreatedSince, fccProductFields);
    }

    @Bean
    @ConditionalOnProperty(name = "rules.publisher.load.products.from", havingValue = "FCC_LIGHT")
    public ProductsLoader fccLightProductsLoader() {
        log.info("FccLightProductsLoader was created");
        return new ProductsLoaderImpl(restTemplate, mcomFccURL, bcomFccURL, batchSize, retryCount, threadsCount,
                includeUnavailableSince, includeUnavailableCreatedSince, fccLightProductFields);
    }

}
