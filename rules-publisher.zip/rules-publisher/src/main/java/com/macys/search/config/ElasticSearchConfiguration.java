package com.macys.search.config;

import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacadeImpl;
import com.macys.search.bizrules.repository.elastic.IndexerThreadFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.elasticsearch.ElasticSearchRestHealthContributorAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.health.HealthEndpointProperties;
import org.springframework.boot.autoconfigure.data.elasticsearch.ElasticsearchDataAutoConfiguration;
import org.springframework.boot.autoconfigure.elasticsearch.ElasticsearchRestClientAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.RestClients;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Slf4j
@Configuration
@Import({
        ElasticsearchDataAutoConfiguration.class,
        ElasticsearchRestClientAutoConfiguration.class,
        ElasticSearchRestHealthContributorAutoConfiguration.class
})
@RequiredArgsConstructor
public class ElasticSearchConfiguration {

    private final HealthEndpointProperties healthEndpointProperties;

    @Value("${rules.publisher.elastic-search.host-and-port}")
    private String hostAndPort;
    @Value("${rules.publisher.es.indexing.threads-count}")
    private int indexingThreadsCount;
    @Value("${rules.publisher.elastic-search.merge-timeout}")
    private Integer mergeTimeout;
    @Value("${rules.publisher.elastic-search.send-bulk-timeout}")
    private Integer sendBulkTimeout;
    @Value("${rules.publisher.elastic-search.warmup-timeout}")
    private Integer warmupTimeout;
    @Value("${rules.publisher.elastic-search.username}")
    private String username;
    @Value("${rules.publisher.elastic-search.password}")
    private String password;

    @PostConstruct
    public void init() {
        healthEndpointProperties.getGroup().get("readiness").getInclude().add("elasticsearch");
    }

    @Bean
    public RestHighLevelClient client() {
        ClientConfiguration.MaybeSecureClientConfigurationBuilder clientConfigurationBuilder =
                ClientConfiguration.builder()
                        .connectedTo(hostAndPort);

        if (!StringUtils.isEmpty(username) && !StringUtils.isEmpty(password)) {
            clientConfigurationBuilder.withBasicAuth(username, password);
        }

        return RestClients.create(clientConfigurationBuilder.build()).rest();
    }

    @Bean
    public ExecutorService indexingExecutorService() {
        return new ThreadPoolExecutor(0, indexingThreadsCount,
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>(),
                new IndexerThreadFactory()
        );
    }

    @Bean
    public RequestOptions mergeIndexRequestOptions() {
        return requestOptions(mergeTimeout);
    }

    @Bean
    public RequestOptions sendBulkRequestOptions() {
        return requestOptions(sendBulkTimeout);
    }

    @Bean
    public RequestOptions warmupRequestOptions() {
        return requestOptions(warmupTimeout);
    }

    private static RequestOptions requestOptions(Integer timeout) {
        RequestOptions.Builder requestOptionsBuilder = RequestOptions.DEFAULT.toBuilder();
        RequestConfig.Builder config = RequestConfig.custom();
        config.setSocketTimeout(timeout);
        requestOptionsBuilder.setRequestConfig(config.build());
        return requestOptionsBuilder.build();
    }

    @Bean
    public ElasticSearchFacade elasticSearchFacade(
            RestHighLevelClient client,
            RequestOptions mergeIndexRequestOptions) {
        return new ElasticSearchFacadeImpl(client, mergeIndexRequestOptions);
    }
}
