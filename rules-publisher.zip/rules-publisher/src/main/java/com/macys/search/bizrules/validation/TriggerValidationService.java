package com.macys.search.bizrules.validation;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.trigger.TriggerValidationStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.List;

@Component
public class TriggerValidationService implements ValidationService<Trigger> {

    private final EnumMap<TriggerType, TriggerValidationStrategy> triggerStrategiesMap = new EnumMap<>(TriggerType.class);

    public TriggerValidationService(List<TriggerValidationStrategy> triggerValidationStrategies,
                                    @Value("${rules.publisher.enabled.trigger-types}") List<TriggerType> enabledTriggers) {
        triggerValidationStrategies.stream()
                .filter(s -> enabledTriggers.contains(s.applicableFor()))
                .forEach(s -> triggerStrategiesMap.put(s.applicableFor(), s));
        if (!triggerStrategiesMap.keySet().containsAll(enabledTriggers)) {
            throw new RuntimeException(MessageFormat.format("Some of trigger validators have not implemented yet. Enabled trigger types={0}" +
                    " Implemented validators types={1}", enabledTriggers, triggerStrategiesMap.keySet()));
        }
    }


    @Override
    public ValidationResult validate(Trigger item, ProcessingContext context) {
        TriggerValidationStrategy strategy = triggerStrategiesMap.get(item.getMerchTriggerType());
        if (strategy != null) {
            return strategy.validate(item, context);
        }
        return ValidationResult.failResult(String.format("Didn't find validation strategy for action with id=%d and type=%s",
                item.getId(), item.getMerchTriggerType().name()));
    }
}
