package com.macys.search.bizrules.repository.batch;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.batch.BatchJobExecutionParams;
import com.macys.search.bizrules.repository.mrf.AbstractMysqlRepository;
import lombok.extern.slf4j.Slf4j;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

@Slf4j
public class BatchRepository extends AbstractMysqlRepository {

    private static final BiConsumer<ResultSet, BatchJobExecutionParams> JOB_PARAMS_CONVERTER = (rs, params) -> {
        try {
            params.setJobExecutionId(rs.getLong("JOB_EXECUTION_ID"));
            params.setTypeCd(rs.getString("TYPE_CD"));
            params.setKeyName(rs.getString("KEY_NAME"));
            params.setStringVal(rs.getString("STRING_VAL"));
            params.setDateVal(rs.getDate("DATE_VAL"));
            params.setLongVal(rs.getLong("LONG_VAL"));
            params.setDoubleVal(rs.getDouble("DOUBLE_VAL"));
            params.setIdentifying(rs.getString("IDENTIFYING"));
        } catch (SQLException exception) {
            log.error("Error while reading batch jobs params", exception);
        }
    };

    public BatchRepository(DataSource dataSource, boolean isStreamMode) {
        super(dataSource, dataSource, isStreamMode);
    }

    public List<BatchJobExecutionParams> getBatchJobExecutionParamsBySessionId(String sessionId) {
        List<BatchJobExecutionParams> result = new ArrayList<>();
        read(SiteName.MCOM,"SELECT * FROM BATCH_JOB_EXECUTION_PARAMS WHERE STRING_VAL = ?",
                st -> {
                    try {
                        st.setString(1, sessionId);
                    } catch (SQLException ex) {
                        log.error("Could not set parameters for batch params fetching", ex);
                    }
                },
                rs -> {
                    while (rs.next()) {
                        BatchJobExecutionParams param = new BatchJobExecutionParams();
                        JOB_PARAMS_CONVERTER.accept(rs, param);
                        result.add(param);
                    }
                }
        );
        return result;
    }

    public List<Long> getBatchJobIdsStartingFromDate(LocalDate from) {
        List<Long> result = new ArrayList<>();
        read(SiteName.MCOM,"SELECT JOB_EXECUTION_ID FROM BATCH_JOB_EXECUTION WHERE START_TIME >= ?",
                st -> {
                    try {
                        st.setString(1, from.toString());
                    } catch (SQLException ex) {
                        log.error("Could not set parameters for batch params fetching", ex);
                    }
                },
                rs -> {
                    while (rs.next()) {
                        result.add(rs.getLong(1));
                    }
                }
        );
        return result;
    }

}
