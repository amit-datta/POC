package com.macys.search.bizrules.catalog;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;

import java.util.Collection;
import java.util.Iterator;

public interface CategoryLoader {

    /**
     * Load all categories from resource
     *
     * @param siteName          site name
     * @param timeStatistics    time statistics
     * @return collection of categories
     */
    Collection<Category> loadAll(SiteName siteName, TimeStatistics timeStatistics);

    /**
     * @param siteName          site name
     * @param timeStatistics    time statistics
     * @return iterator on collection of categories
     */
    Iterator<Category> iterator(SiteName siteName, TimeStatistics timeStatistics);
}
