package com.macys.search.bizrules.catalog.fcc.category;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.catalog.fcc.FccField;
import com.macys.search.bizrules.catalog.none.NoneCategoryLoader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;

@Configuration
@Slf4j
public class CategoryLoaderConfiguration {

    private final RestTemplate restTemplate;
    private final String mcomFccURL;
    private final String bcomFccURL;
    private final int batchSize;
    private final int retryCount;
    private final int threadsCount;
    private final Collection<FccField> fccCategoryFields;
    private final Collection<FccField> fccLightCategoryFields;

    public CategoryLoaderConfiguration(RestTemplate restTemplate,
                                       @Value("${rules.publisher.mcom.fcc.categories.url}") String mcomFccURL,
                                       @Value("${rules.publisher.bcom.fcc.categories.url}") String bcomFccURL,
                                       @Value("${rules.publisher.fcc.category.batch-size}") int batchSize,
                                       @Value("${rules.publisher.fcc.request.retries}") int retryCount,
                                       @Value("${rules.publisher.fcc.category.load.threads-count}") int threadsCount,
                                       Collection<FccField> fccCategoryFields,
                                       Collection<FccField> fccLightCategoryFields) {
        this.restTemplate = restTemplate;
        this.mcomFccURL = mcomFccURL;
        this.bcomFccURL = bcomFccURL;
        this.batchSize = batchSize;
        this.retryCount = retryCount;
        this.threadsCount = threadsCount;
        this.fccCategoryFields = fccCategoryFields;
        this.fccLightCategoryFields = fccLightCategoryFields;
    }

    @Bean
    @ConditionalOnProperty(name = "rules.publisher.load.categories.from",
            havingValue = "NONE",
            matchIfMissing = true
    )
    public CategoryLoader noneCategoryLoader() {
        log.info("NoneProductsLoader was created");
        return new NoneCategoryLoader();
    }

    @Bean
    @ConditionalOnProperty(name = "rules.publisher.load.categories.from", havingValue = "FCC")
    public CategoryLoader fccCategoryLoader() {
        log.info("FccCategoryLoader was created");
        return new CategoryLoaderImpl(restTemplate, mcomFccURL, bcomFccURL, batchSize, retryCount,
                threadsCount, fccCategoryFields);
    }

    @Bean
    @ConditionalOnProperty(name = "rules.publisher.load.categories.from", havingValue = "FCC_LIGHT")
    public CategoryLoader fccLightCategoryLoader() {
        log.info("FccLightCategoryLoader was created");
        return new CategoryLoaderImpl(restTemplate, mcomFccURL, bcomFccURL, batchSize, retryCount,
                threadsCount, fccLightCategoryFields);
    }
}
