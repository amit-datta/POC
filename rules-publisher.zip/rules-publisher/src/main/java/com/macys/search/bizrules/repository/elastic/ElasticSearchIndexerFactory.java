package com.macys.search.bizrules.repository.elastic;

public interface ElasticSearchIndexerFactory {

    /**
     * Create new {@link ElasticSearchIndexer} for indexing purposes.
     * <p>
     * ElasticSearchIndexer is thread safe. Need only one instance for indexing
     *
     * @param indexName index name
     * @return indexer
     */
    ElasticSearchIndexer createIndexer(String indexName);
}
