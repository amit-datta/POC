package com.macys.search.bizrules.validation;

import lombok.*;

/**
 * Result of validation.
 * {@link #isValid} - contains true value if validation successful otherwise false.
 * {@link #warning} - warning message
 */
@Getter
@ToString
@EqualsAndHashCode
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class ValidationResult {
    private static final ValidationResult VALID = new ValidationResult(true, null);

    private final boolean isValid;
    private final String warning;

    public static ValidationResult failResult(String warning) {
        return new ValidationResult(false, warning);
    }

    public static ValidationResult validResult() {
        return VALID;
    }
}
