package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.converters.trigger.TriggerConverterService;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.dto.ActionDto;
import com.macys.search.bizrules.model.dto.RuleDto;
import com.macys.search.bizrules.model.dto.TriggerDto;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.repository.mrf.*;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.cache.CategoriesCache;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.utils.CustomDateUtils.getCustomDate;

/**
 * need to be tested and refactored in next stories
 */
@Component
@RequiredArgsConstructor
public class PreviewService {

    private final RuleService ruleService;
    private final ActionsService actionService;
    private final TriggersService triggerService;
    private final TriggerConverterService triggerConverterService;

    private final RulesReader rulesReader;
    private final TriggerExpressionReader triggerExpressionReader;
    private final ActionsReader actionsReader;
    private final TriggersReader triggersReader;
    private final CustomDateReader customDateReader;

    private final CategoriesCache mcomCategoriesCache;
    private final CategoriesCache bcomCategoriesCache;

    @Value("${rules.publisher.enabled.action-types}")
    private List<ActionType> enabledActionTypes;
    @Value("${rules.publisher.enabled.trigger-types}")
    private List<TriggerType> enabledTriggerTypes;

    public RuleDto getRuleById(final SiteName siteName, final Integer ruleId, final int attributesLimit) {
        ProcessingContext ctx = new ProcessingContext();

        Rule rule = rulesReader.getRuleById(siteName, ruleId);
        if (rule == null) {
            return RuleDto.builder().build();
        }
        triggerExpressionReader.readTriggerExpressionForRule(siteName, rule);
        ProcessingRule processingRule = ProcessingRule.from(rule);
        ValidationResult ruleFieldsValidationResult = RuleService.validateRequiredRuleFields(rule);
        if (!ruleFieldsValidationResult.isValid()) {
            return RuleDto.builder().validationResult(ruleFieldsValidationResult).build();
        }
        ctx.setRules(Map.of(ruleId, processingRule));
        ctx.setActions(loadActions(rule, siteName));
        ctx.setCustomDate(getCustomDate(ctx, customDateReader));
        ctx.setTriggers(loadTriggers(rule, siteName));
        ctx.setCategoryTree(siteName == SiteName.MCOM ? mcomCategoriesCache.getCategoryTree()
                : bcomCategoriesCache.getCategoryTree()
        );

        ProcessingRule processedRule = ruleService.getProcessedRule(ruleId, ctx);
        if (!processedRule.getValidationResult().isValid()) {
            return RuleDto.builder().validationResult(processedRule.getValidationResult()).build();
        }

        RuleDto.RuleDtoBuilder ruleDtoBuilder = ruleDtoBuilderFrom(processedRule);

        List<ActionDto> actions = new ArrayList<>(ctx.getActions().size());
        for (Integer actionId : ctx.getActions().keySet()) {
            ProcessingAction processedAction = actionService.getProcessedAction(actionId, ctx);

            Map<String, Criteria> criteriaMap = new HashMap<>(processedAction.getCriteriaMap());
            boolean isCriteriaMapFull = shrinkCriteriaMap(criteriaMap, attributesLimit);
            actions.add(ActionDto.builder()
                    .actionId(actionId)
                    .criteriaMap(criteriaMap)
                    .isCriteriaMapFull(isCriteriaMapFull)
                    .validationResult(processedAction.getValidationResult())
                    .contextAttributes(processedAction.getAction().getContextAttributes())
                    .build()
            );
        }
        ruleDtoBuilder.actions(actions);

        List<TriggerDto> triggers = new ArrayList<>(ctx.getTriggers().size());
        for (Integer triggerId : ctx.getTriggers().keySet()) {
            ProcessingTrigger processedTrigger = triggerService.getProcessedTrigger(triggerId, ctx);
            Trigger trigger = processedTrigger.getTrigger();

            Map<String, Criteria> criteriaMap = new HashMap<>(trigger.getCriteriaMap());
            boolean isCriteriaMapFull = shrinkCriteriaMap(criteriaMap, attributesLimit);

            triggers.add(TriggerDto.builder()
                    .triggerId(triggerId)
                    .triggerType(processedTrigger.getType())
                    .triggerParams(triggerConverterService.convertTrigger(processedTrigger, ctx))
                    .criteriaMap(criteriaMap)
                    .isCriteriaMapFull(isCriteriaMapFull)
                    .validationResult(processedTrigger.getValidationResult())
                    .build());
        }

        ruleDtoBuilder.triggers(triggers);

        return ruleDtoBuilder.build();
    }

    private RuleDto.RuleDtoBuilder ruleDtoBuilderFrom(ProcessingRule processedRule) {
        return RuleDto.builder()
                .ruleId(processedRule.getRuleId())
                .ruleName(processedRule.getRuleName())
                .ruleType(processedRule.getRuleType().name())
                .ruleEffectiveDate(processedRule.getRuleEffectiveDate())
                .ruleExpirationDate(processedRule.getRuleExpirationDate())
                .ruleLastModifiedDate(processedRule.getRuleLastModifiedDate())
                .rulePriority(processedRule.getRulePriority())
                .ruleEnabled(processedRule.isEnabled())
                .ruleLastModifiedByName(processedRule.getLastModifiedByName())
                .validationResult(ValidationResult.validResult());
    }

    private Map<Integer, ProcessingAction> loadActions(Rule rule, SiteName siteName) {
        if (CollectionUtils.isEmpty(rule.getActionsIds())) return Map.of();

        return rule.getActionsIds().stream()
                .map(id -> actionsReader.getActionsById(siteName, id, enabledActionTypes))
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(Action::getId, ProcessingAction::from));
    }

    private Map<Integer, ProcessingTrigger> loadTriggers(Rule rule, SiteName siteName) {
        if (CollectionUtils.isEmpty(rule.getTriggerIds())) return Map.of();

        return rule.getTriggerIds().stream()
                .map(id -> triggersReader.getTriggerById(siteName, id, enabledTriggerTypes))
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(Trigger::getId, ProcessingTrigger::from));
    }

    private static boolean shrinkCriteriaMap(Map<String, Criteria> criteriaMap, int size) {
        if (size == -1) {
            return true;
        }
        boolean isCriteriaMapFull = true;
        for (Map.Entry<String, Criteria> entry : criteriaMap.entrySet()) {
            Criteria criteria = entry.getValue();
            if (needToShrunkMap(criteria.getCriteriaAttributes(), size)) {
                isCriteriaMapFull = false;
                criteria.setCriteriaAttributes(getShrunkMap(criteria.getCriteriaAttributes(), size));
            }

            if (needToShrunkMap(criteria.getCriteriaDateAwareAttributes(), size)) {
                isCriteriaMapFull = false;
                criteria.setCriteriaDateAwareAttributes(getShrunkMap(criteria.getCriteriaDateAwareAttributes(), size));
            }

            if (needToShrunkMap(criteria.getAttributeToSeqNumbersMap(), size)) {
                isCriteriaMapFull = false;
                criteria.setAttributeToSeqNumbersMap(getShrunkMap(criteria.getAttributeToSeqNumbersMap(), size));
            }
        }
        return isCriteriaMapFull;
    }

    private static <T> boolean needToShrunkMap(Map<String, List<T>> map, int size) {
        return map.size() > size || map.values().stream().anyMatch(list -> list.size() > size);
    }

    private static <T> Map<String, List<T>> getShrunkMap(Map<String, List<T>> map, int size) {
        Map<String, List<T>> shrunkMap = new HashMap<>();
        if (map.size() > size) {
            int count = 0;
            for (Map.Entry<String, List<T>> entry : map.entrySet()) {
                String key = entry.getKey();
                List<T> values = entry.getValue();
                if (values.size() > size) values = values.subList(0, size);
                shrunkMap.put(key, values);
                count++;
                if (count >= size) break;
            }
        }

        for (Map.Entry<String, List<T>> entry : map.entrySet()) {
            List<T> values = entry.getValue();
            if (values.size() > size) {
                values = values.subList(0, size);
                shrunkMap.put(entry.getKey(), values);
            }
        }

        return shrunkMap;
    }
}
