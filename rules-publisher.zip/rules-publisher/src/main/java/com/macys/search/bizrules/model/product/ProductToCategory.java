package com.macys.search.bizrules.model.product;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProductToCategory {
    private final Integer categoryId;
    private final Integer sequenceNumber;
    private final String poolName;
}
