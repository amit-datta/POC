package com.macys.search.bizrules.model.mrf;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Contains parsed merch value with effective dates
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DateAwareAttribute {
    private String value;
    private LocalDate effectiveDate;
    private LocalDate expirationDate;
}
