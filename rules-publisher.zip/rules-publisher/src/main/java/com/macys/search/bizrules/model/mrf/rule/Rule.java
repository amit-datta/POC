package com.macys.search.bizrules.model.mrf.rule;

import com.macys.search.bizrules.model.mrf.BooleanOperation;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Configuration for merchandising rule.
 * Describes relation between triggers and action entities
 */
@Data
public class Rule {
    private Integer id;
    private String name;
    private String description;
    private LocalDate effectiveDate;
    private LocalDate expirationDate;
    private Integer priority;
    private Integer stateCode;
    private LocalDateTime lastModified;
    private LocalDateTime createdDate;
    private String authorName;
    private String lastModifiedByName;
    private RuleType merchRuleType;
    private Set<Integer> categoryIds;

    private BooleanOperation triggerOperation;
    private List<Integer> triggerIds = new ArrayList<>();
    private List<Integer> actionsIds = new ArrayList<>();
}
