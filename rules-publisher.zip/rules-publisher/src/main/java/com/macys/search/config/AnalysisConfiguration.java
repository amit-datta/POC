package com.macys.search.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.regex.Pattern;

@Configuration
public class AnalysisConfiguration {

    @Value("${rules.publisher.es.keyword.replace.pattern}")
    String keywordReplacePatternString;

    @Bean
    public Pattern keywordReplacePattern() {
        return Pattern.compile(keywordReplacePatternString);
    }

}
