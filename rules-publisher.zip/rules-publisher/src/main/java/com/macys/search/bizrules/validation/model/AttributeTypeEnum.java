package com.macys.search.bizrules.validation.model;

import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.function.Function;

/**
 * Attribute template
 */
@AllArgsConstructor
public enum AttributeTypeEnum {

    PositiveInteger(str -> {
        try {
            return Integer.parseUnsignedInt(str) > 0;
        } catch (NumberFormatException ex) {
            return false;
        }
    }),

    NonBlankString(StringUtils::isNotBlank);

    private final Function<String, Boolean> function;

    public boolean isValid(String str) {
        return function.apply(str);
    }
}
