package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.repository.elastic.ElasticSearchFacadeImpl;

import java.util.Map;

/**
 * Entry which can be indexed into elastic search via {@link ElasticSearchFacadeImpl}
 */
public interface ESEntry {

    /**
     * Elastic search document id.
     * For null value elastic search will generate id automatically
     *
     * @return id or null
     */
    String getElasticId();

    /**
     * Mapping elastic search field to value
     *
     * @return mapping
     */
    Map<String, ?> getSource();
}
