package com.macys.search.bizrules.model.processing.trigger.params;

import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields;
import com.macys.search.bizrules.model.mrf.trigger.HRTFiringStrategy;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.HierarchicalRefinement;

@Builder
@ToString
@Getter
@EqualsAndHashCode
public class HierarchicalRefinementTriggerParams extends AbstractTriggerParams {
    private final Integer triggerId;
    private final Set<Integer> catIds;
    private final Set<Integer> excludedCatIds;
    private final HRTFiringStrategy strategy;

    @Override
    public List<ESTrigger> generateTriggers() {
        ESTrigger trigger = new ESTrigger(triggerId, HierarchicalRefinement);
        trigger.setFieldValue(TriggerIndexFields.CATEGORY_ID, catIds);
        trigger.setFieldValue(TriggerIndexFields.MATCH_TYPE, strategy.name());
        if (!CollectionUtils.isEmpty(excludedCatIds)) {
            trigger.setFieldValue(TriggerIndexFields.EXCLUDED_CATEGORY_ID, excludedCatIds);
        }
        return Collections.singletonList(trigger);
    }

    @Override
    public void enrichProcessingRule(ProcessingRule processingRule) {
        Set<Integer> categoryIds = processingRule.getRuleCategoryIds();
        if (categoryIds == null) {
            processingRule.getRule().setCategoryIds(catIds);
        } else {
            categoryIds.addAll(catIds);
        }
    }
}
