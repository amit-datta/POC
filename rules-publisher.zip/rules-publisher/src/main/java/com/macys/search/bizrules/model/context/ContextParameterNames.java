package com.macys.search.bizrules.model.context;

/**
 * Contains all context parameters names
 */
public final class ContextParameterNames {
    public static final String REGION_CODE = "REGION_CODE";
    public static final String APPLICATION = "APPLICATION";
    public static final String CUSTOMER_EXPERIMENT = "CUSTOMER_EXPERIMENT";
    public static final String DEVICE_TYPE = "DEVICE_TYPE";
    public static final String NAVIGATION_TYPE = "NAVIGATION_TYPE";
    public static final String SHOPPING_MODE = "SHOPPING_MODE";
}
