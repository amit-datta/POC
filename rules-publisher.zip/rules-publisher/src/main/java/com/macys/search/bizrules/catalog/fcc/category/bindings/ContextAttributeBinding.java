package com.macys.search.bizrules.catalog.fcc.category.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Collection;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextAttributeBinding {
    private String name;
    private Collection<String> value;
}
