package com.macys.search.bizrules.tasklets;

/**
 * Contains all available job params
 */
public class JobParams {
    public static final String SITE_NAME_JOB_PARAM = "site-name";
    public static final String CUSTOM_DATE_JOB_PARAM = "custom-date";
    public static final String START_TIME_JOB_PARAM = "start-time";
    public static final String INDEXING_SESSION_ID = "indexing-session-id";
    public static final String CLOUD_REGION = "cloud-region";
}
