package com.macys.search.bizrules.converters.trigger;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;

/**
 * Convert {@link Trigger} representation to {@link com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams}
 */
public interface TriggerConverter {

    /**
     * @return {@link TriggerType} the converter valid for
     */
    TriggerType applicableFor();

    /**
     * Convert trigger to trigger params and set that params into processingTrigger
     *
     * @param processingTrigger processing trigger
     * @param ctx               context
     */
    AbstractTriggerParams convert(ProcessingTrigger processingTrigger, ProcessingContext ctx);

}
