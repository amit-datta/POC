package com.macys.search.bizrules.model.dto;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.Builder;
import lombok.Getter;

import java.util.Collection;
import java.util.Map;

@Builder
@Getter
public class ActionDto {
    private final Integer actionId;
    private final Map<String, Criteria> criteriaMap;
    private final boolean isCriteriaMapFull;
    private ValidationResult validationResult;
    private final Map<String, Collection<String>> contextAttributes;
}
