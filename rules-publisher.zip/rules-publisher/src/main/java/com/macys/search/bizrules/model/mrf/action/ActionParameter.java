package com.macys.search.bizrules.model.mrf.action;

import lombok.Data;

import java.time.LocalDate;

/**
 * Hold single action parameter
 */
@Data
public class ActionParameter {
    private String name;
    private String group;
    private String value;
    private Integer sequenceNumber;
    private Integer groupSequenceNumber;
    private LocalDate effectiveDate;
    private LocalDate expirationDate;
}
