package com.macys.search.analysis;

/**
 * Indoor phrase analyser based on Lucene token filters.
 * <p>
 * Last version of Elastic search doesn't have concatenate plugin so
 * we should implement indoor analysers for keyword field types.
 * Keyword field type use into term query.
 * </p>
 */
public interface PhraseAnalyzer {

    /**
     * Apply chain of token filters to {@code input}
     *
     * @param input input string
     * @return analyzed string
     */
    String analise(String input);

}
