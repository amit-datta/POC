package com.macys.search.bizrules.converters.actions;

import lombok.Data;

import java.util.*;

@Data
public class MsrBavAttribute {
    private Integer priority;
    // Map fieldName to Set of fieldValues
    private Map<String, Set<String>> attrs = new HashMap<>();


    public MsrBavAttribute(Integer priority, Map<String, List<String>> criteriaAttributes) {
        this.priority = priority;
        criteriaAttributes.forEach((k, v) -> this.attrs.put(k, new HashSet<>(v)));
    }

    public MsrBavAttribute() {
    }
}
