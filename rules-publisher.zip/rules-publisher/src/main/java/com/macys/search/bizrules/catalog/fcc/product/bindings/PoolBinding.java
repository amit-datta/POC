package com.macys.search.bizrules.catalog.fcc.product.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PoolBinding {
    private Integer id;
    private Integer seqNumber;
}
