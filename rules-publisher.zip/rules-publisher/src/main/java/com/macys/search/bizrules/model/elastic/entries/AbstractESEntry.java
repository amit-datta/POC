package com.macys.search.bizrules.model.elastic.entries;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.model.elastic.mappings.ElasticSearchBaseFields;
import lombok.Getter;
import lombok.SneakyThrows;

import java.util.HashMap;
import java.util.Map;

@Getter
public abstract class AbstractESEntry<T extends ElasticSearchBaseFields> implements ESEntry {

    private static final ObjectMapper mapper = new ObjectMapper();

    private final String elasticId;

    private final Map<String, Object> source = new HashMap<>();

    protected AbstractESEntry(String elasticId) {
        this.elasticId = elasticId;
    }

    protected AbstractESEntry() {
        this(null);
    }

    protected void setFieldValue(String fieldName, Object value) {
        if (value == null) return;
        source.put(fieldName, value);
    }

    public void setFieldValue(T field, Object value) {
        setFieldValue(field.getFieldName(), value);
    }

    @SneakyThrows
    public void setFieldValueAsString(T field, Object value) {
        setFieldValue(field.getFieldName(), mapper.writeValueAsString(value));
    }

}
