package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.SiteName;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.core.CheckedConsumer;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractMysqlRepository {
    private final DataSource mcomDataSource;
    private final DataSource bcomDataSource;
    private final boolean isStreamMode;

    protected final static IntFunction<String> paramSymbolsGenerator =
            size -> IntStream.range(0, size).mapToObj(i -> "?").collect(Collectors.joining(","));

    @SneakyThrows
    protected static void fillStringsInStatement(PreparedStatement statement, List<?> collection) {
        for (int i = 0; i < collection.size(); i++) {
            statement.setString(i + 1, String.valueOf(collection.get(i)));
        }
    }

    protected void read(SiteName siteName, String sql, Consumer<PreparedStatement> paramsFiller,
                        CheckedConsumer<ResultSet, SQLException> consumer) {
        DataSource dataSource = siteName == SiteName.MCOM ? mcomDataSource : bcomDataSource;
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, ResultSet.FETCH_FORWARD)) {

            paramsFiller.accept(statement);
            if (isStreamMode) {
                statement.setFetchSize(Integer.MIN_VALUE);
            }

            try (ResultSet rs = statement.executeQuery()) {
                consumer.accept(rs);
            }
        } catch (SQLException exception) {
            log.error("Could not load entry from mysql.", exception);
            throw new RuntimeException(exception);
        }
    }

    protected void read(SiteName siteName, String sql, CheckedConsumer<ResultSet, SQLException> consumer) {
        read(siteName, sql, st -> {
        }, consumer);
    }

}
