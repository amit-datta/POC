package com.macys.search.config.indexes;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.util.Map;

public abstract class AbstractElasticIndexConfiguration {
    private static final ObjectMapper mapper = new ObjectMapper();

    @Autowired
    protected ElasticSearchIndexerFactory indexerFactory;
    @Autowired
    protected CommonIndexProperties mcomCommonIndexProperties;
    @Autowired
    protected CommonIndexProperties bcomCommonIndexProperties;

    @Value("${rules.publisher.index.version}")
    String indexVersion;

    static Map<String, Object> readOverriddenProperties(Resource resource) throws IOException {
        if (resource == null) return null;
        TypeReference<Map<String, Object>> typeRef = new TypeReference<>() {
        };
        return mapper.readValue(resource.getInputStream(), typeRef);
    }
}
