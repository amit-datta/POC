package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.converters.ConverterUtils;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionConstants;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.stereotype.Component;

/**
 * {@link ActionConverter} implementation for {@link ActionType#ProductRedirect} type
 */
@Component
class ProductRedirectConverter extends AbstractActionConverter {
    @Override
    public ActionType applicableFor() {
        return ActionType.ProductRedirect;
    }

    @Override
    void enrichWithTypeSpecificProperties(Action action, ESAction doc, ProcessingContext context) {
        doc.setFieldValue(ActionsIndexFields.ACTION_TYPE, ESActionType.PRODUCT_REDIRECT);
        String value = ConverterUtils.getUnaryValue(action, ActionConstants.PDP_PRODUCT, ActionConstants.PDP_PRODUCT_ID);
        doc.setFieldValue(ActionsIndexFields.PRODUCT_REDIRECT_ID, value);
    }
}
