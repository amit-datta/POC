package com.macys.search.bizrules.model.dto;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.Builder;
import lombok.Getter;

import java.util.Map;

@Getter
@Builder
public class TriggerDto {
    private final Integer triggerId;

    private final TriggerType triggerType;
    private final AbstractTriggerParams triggerParams;

    private final Map<String, Criteria> criteriaMap;
    private final boolean isCriteriaMapFull;
    private final ValidationResult validationResult;
}
