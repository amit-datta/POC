package com.macys.search.bizrules.converters.products.filters;

import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.category.CategoryAttributeName;
import com.macys.search.bizrules.model.product.Price;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.model.product.Upc;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import static com.macys.search.bizrules.model.category.CategoryAttributeName.*;

@Component
public class ColorwayPriceCategoryFilter implements CategoryFilter {

    private static final double EPSILON = 0.000001;

    @Override
    public boolean pass(Category category, Product product) {
        Map<CategoryAttributeName, CategoryAttribute> attributes = category.getAttributes();

        CategoryAttribute priceFilterAttr = attributes.get(PRICE_FILTER);
        Collection<String> priceFilterValues = priceFilterAttr != null ? priceFilterAttr.getValues() :
                Collections.emptyList();
        CategoryAttribute minPriceAttr = attributes.get(PRICE_RANGE_MIN);
        String minPrice = minPriceAttr != null ? minPriceAttr.getUnaryValue() : null;
        CategoryAttribute maxPriceAttr = attributes.get(PRICE_RANGE_MAX);
        String maxPrice = maxPriceAttr != null ? maxPriceAttr.getUnaryValue() : null;

        // check if the category has Price Filter attributes
        if (CollectionUtils.isEmpty(priceFilterValues) && minPrice == null && maxPrice == null) {
            return true;
        }
        for (Upc upc : product.getUpcs()) {
            if (checkAvailability(upc)) {
                final Price price = upc.getPrice();
                if (price == null) {
                    continue;
                }
                if (isPriceSatisfyTypeFilter(priceFilterValues, price.getPriceType()) &&
                        isPriceSatisfyRangeFilter(price.getRetailPrice(), minPrice, maxPrice)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean isSelfBased() {
        return false;
    }

    private boolean checkAvailability(Upc upc) {
        return Boolean.TRUE.equals(upc.isAvailable());
    }

    private static boolean isPriceSatisfyTypeFilter(Collection<String> priceFilterValues, int priceType) {
        return priceFilterValues.isEmpty() || priceFilterValues.contains(String.valueOf(priceType));
    }

    /**
     * Checks whether the value of the price belongs to the price range.
     * NULL value for the minPrice/maxPrice is considered as -/+ Infinity.
     * If both range constraints are NULL, returned value is TRUE even if price value is NULL.
     *
     * @param price    price value
     * @param minPrice max allowable price
     * @param maxPrice min allowable price
     */
    private static boolean isPriceSatisfyRangeFilter(final Double price, final String minPrice, final String maxPrice) {
        if (minPrice == null && maxPrice == null) {
            return true;
        }
        if (price == null) {
            return false;
        }
        if (minPrice != null && maxPrice != null) {
            return greaterOrEqual(price, Double.valueOf(minPrice)) && greaterOrEqual(Double.valueOf(maxPrice), price);
        } else if (minPrice == null) {
            return greaterOrEqual(Double.valueOf(maxPrice), price);
        } else {
            return greaterOrEqual(price, Double.valueOf(minPrice));
        }
    }

    private static boolean greaterOrEqual(Double value1, Double value2) {
        return value1 > value2 || Math.abs(value1 - value2) < EPSILON;
    }

}

