package com.macys.search.bizrules.catalog.fcc.category.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AttributeValueBinding {
    private String value;
}
