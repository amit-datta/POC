package com.macys.search.bizrules.catalog.fcc.category.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextOverrideBinding {
    private ContextBinding context;
    private String name;
    private Integer sequenceNumber;
    private Boolean suppressed;
}
