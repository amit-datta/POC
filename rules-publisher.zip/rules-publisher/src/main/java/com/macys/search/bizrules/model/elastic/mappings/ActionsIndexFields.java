package com.macys.search.bizrules.model.elastic.mappings;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.*;

/**
 * Fields for Actions index
 */
@Getter
@AllArgsConstructor
public enum ActionsIndexFields implements ElasticSearchBaseFields {
    ACTION_ID("action_id", LONG.getProperties()),
    ACTION_NATURAL_RULE_IDS("action_rule_natural_ids", LONG.getProperties()),
    ACTION_TYPE("action_type", KEYWORD.getProperties()),
    ACTION_TYPE_PRIORITY("action_type_priority", LONG.getProperties()),

    // Redirects
    PRODUCT_REDIRECT_ID("product_redirect_id", KEYWORD.getProperties()),
    CATEGORY_REDIRECT_ID("category_redirect_id", KEYWORD.getProperties()),
    URL_REDIRECT_TYPE("url_redirect_type", KEYWORD.getProperties()),
    URL_REDIRECT_VALUE("url_redirect_value", KEYWORD.getProperties()),
    // Show media
    CANVAS_ID("canvas_id", LONG.getProperties()),
    // Seo control
    INDEX_FOLLOW("index_follow", BOOLEAN.getProperties()),
    // MSR
    MSR_BOOST_BY_ATTRIBUTES("boost_by_attribute", KEYWORD.getProperties()),
    POOL("pool", LONG.getProperties()),
    PRODUCT("product", LONG.getProperties()),
    MSR_PREVIEW("msr_preview", KEYWORD.getProperties()),
    // Seo metadata
    SEO_METADATA("seo_metadata", KEYWORD.getProperties()),
    // CRS blacklisted
    CRS_BLACKLISTED("crs_blacklisted", BOOLEAN.getProperties()),

    // Context attributes
    REGION_CODE_CTX_ATTR("region_code_ctx_attr", KEYWORD.getProperties()),
    DEVICE_TYPE_CTX_ATTR("device_type_ctx_attr", KEYWORD.getProperties()),
    SHOPPING_MODE_CTX_ATTR("shopping_mode_ctx_attr", KEYWORD.getProperties()),
    NAVIGATION_TYPE_CTX_ATTR("navigation_type_ctx_attr", KEYWORD.getProperties()),
    APPLICATION_TYPE_CTX_ATTR("application_type_ctx_attr", KEYWORD.getProperties()),
    CUSTOMER_EXPERIMENT_CTX_ATTR("customer_experiment_ctx_attr", KEYWORD.getProperties()),

    DISABLED_REASONS("disabled_reasons", KEYWORD.getProperties());

    private final String fieldName;
    private final Map<String, Object> properties;

}
