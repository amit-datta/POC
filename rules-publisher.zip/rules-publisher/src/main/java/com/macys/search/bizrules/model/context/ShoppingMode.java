package com.macys.search.bizrules.model.context;

/**
 * Shopping mode context attribute
 */
public enum ShoppingMode {
    SITE,
    WEDDING_REGISTRY,
    STORE
}
