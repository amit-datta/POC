package com.macys.search.bizrules.tasklets.merch;

import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.repository.mrf.CustomDateReader;
import com.macys.search.bizrules.repository.mrf.RulesReader;
import com.macys.search.bizrules.repository.mrf.TriggerExpressionReader;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.utils.CustomDateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Load {@link Rule} from db
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class RulesReaderTasklet implements RulesPublisherTasklet {

    private final RulesReader rulesReader;
    private final TriggerExpressionReader triggerExpressionReader;
    private final CustomDateReader customDateReader;

    public void execute(ProcessingContext ctx) {
        log.info("Start rules loading");
        final Map<Integer, ProcessingRule> rules = new HashMap<>();
        final Map<Integer, Integer> expressionToRuleMapping = new HashMap<>();
        LocalDate customDate = CustomDateUtils.getCustomDate(ctx, customDateReader);
        rulesReader.readRules(ctx, customDate, rules, expressionToRuleMapping);
        triggerExpressionReader.readTriggerExpression(ctx, rules, expressionToRuleMapping);
        ctx.setRules(rules);
        ctx.getStatistics().getRulesStatistics().setLoadedRules(rules.size());
        log.info("Read {} rules", rules.size());
    }

}
