package com.macys.search.bizrules.converters;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import org.elasticsearch.index.query.DisMaxQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

import java.util.List;

/**
 * Set of util methods for converters
 */
public final class ConverterUtils {

    /**
     * Retrieve unary attribute value
     *
     * @param config        criteria
     * @param attributeName attribute name
     * @return unary attribute value
     */
    public static String getUnaryValue(Criteria config, String attributeName) {
        return config.getCriteriaAttributes().get(attributeName).get(0);
    }

    /**
     * Retrieve unary attribute value
     *
     * @param action        action
     * @param criteriaName  criteria name
     * @param attributeName attribute name
     * @return unary attribute value
     */
    public static String getUnaryValue(Action action, String criteriaName, String attributeName) {
        return getUnaryValue(action.getCriteria(criteriaName), attributeName);
    }

    /**
     * Create dis max query from collection.
     * if collection contains only one query that query would be returned
     *
     * @param queries list of disjunctions
     * @return collection combined into dis max query
     */
    public static QueryBuilder combineIntoDismaxQuery(List<QueryBuilder> queries) {
        if (queries.size() == 0) return null;
        if (queries.size() == 1) return queries.get(0);
        DisMaxQueryBuilder disMax = QueryBuilders.disMaxQuery();
        for (QueryBuilder innerQuery : queries) {
            disMax.add(innerQuery);
        }
        return disMax;
    }

}
