package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.model.elastic.entries.ESRule;
import com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields.*;

@Slf4j
@Component
public class RuleConverterService {

    public ESRule convert(ProcessingRule processingRule) {
        ESRule doc = new ESRule();

        doc.setFieldValue(RulesIndexFields.RULE_ID, processingRule.getRuleId());
        doc.setFieldValue(RULE_NAME, processingRule.getRuleName());
        doc.setFieldValue(RULE_TYPE, processingRule.getRuleType());
        doc.setFieldValue(RULE_OWNER, processingRule.getRuleOwner());
        doc.setFieldValue(RULE_DESCRIPTION, processingRule.getRuleDescription());
        doc.setFieldValue(RULE_CATEGORY_IDS, processingRule.getRuleCategoryIds());

        doc.setFieldValue(RULE_PRIORITY, processingRule.getRulePriority());
        doc.setFieldValue(RULE_ENABLED, processingRule.isEnabled());

        doc.setFieldValue(RULE_EFFECTIVE_DATE, processingRule.getRuleEffectiveDate());
        doc.setFieldValue(RULE_EXPIRATION_DATE, processingRule.getRuleExpirationDate());
        doc.setFieldValue(RULE_CREATED_DATE, processingRule.getRuleCreatedDate());

        doc.setFieldValue(RULE_LAST_MODIFICATION_DATE, processingRule.getRuleLastModifiedDate());
        doc.setFieldValue(RULE_LAST_MODIFICATION_NAME, processingRule.getLastModifiedByName());

        doc.setFieldValue(RULE_TRIGGER_IDS, processingRule.getValidTriggers().stream().map(ProcessingTrigger::getId)
                .collect(Collectors.toSet()));
        doc.setFieldValue(RULE_TRIGGER_OPERATOR, processingRule.getTriggerOperation());

        return doc;
    }

}
