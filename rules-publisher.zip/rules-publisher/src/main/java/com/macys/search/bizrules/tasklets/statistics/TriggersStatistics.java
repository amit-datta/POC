package com.macys.search.bizrules.tasklets.statistics;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
@JsonDeserialize
public class TriggersStatistics {
    @Setter
    private int loadedTriggers;
    private int validTriggers;
    private int invalidTriggers;

    public void incrementValidTriggers() {
        validTriggers++;
    }

    public void incrementInvalidTriggers() {
        invalidTriggers++;
    }
}
