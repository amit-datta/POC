package com.macys.search.bizrules.catalog.fcc.product;

import com.macys.search.bizrules.catalog.fcc.category.bindings.AttributeBinding;
import com.macys.search.bizrules.catalog.fcc.category.bindings.AttributeValueBinding;
import com.macys.search.bizrules.catalog.fcc.product.bindings.*;
import com.macys.search.bizrules.model.product.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.catalog.fcc.UnboxingHelper.unbox;

@Slf4j
public class FCCProductConverter {

    public static Product convert(ProductBinding binding) {
        Product.ProductBuilder builder = Product.builder()
                .productId(unbox(binding.getId()))
                .isNew(unbox(binding.getIsNew()))
                .newMarkdown(binding.getPrice() != null && unbox(binding.getPrice().getNewMarkdown()))
                .members(convertMembers(binding.getMemberProducts()))
                .parentCategories(convertCategories(binding.getCategories()))
                .pools(convertPools(binding.getPools()))
                .upcs(convertUpcs(binding.getUpcs()))
                .name(binding.getName())
                .typeName(binding.getTypeName())
                .attributes(convertAttributes(binding.getAttributes()))
                .visible(binding.getVisible())
                .productGroup(binding.getProductGroup())
                .countryExclusion(binding.getCountryExclusion())
                .recentlyReviewTimestamp(getRecentlyReviewTS(binding))
                .startDate(binding.getStartDate())
                .effectiveDate(binding.getEffectiveDate())
                .firstAvailableDate(binding.getFirstAvailableDate())
                .colorwayUpcCount(binding.getColorwayUpcCount())
                .newnessDays(binding.getNewnessDays())
                .primaryPortraitSource(binding.getPrimaryPortraitSource())
                .canonicalProductUrl(binding.getCanonicalProductUrl())
                .originalPriceHigh(binding.getOriginalPriceHigh())
                .retailPriceHigh(binding.getRetailPriceHigh());

        setMetrics(builder, binding.getMetrics());
        return builder.build();
    }

    private static Collection<Product> convertMembers(Collection<ProductBinding> memberProducts) {
        if (CollectionUtils.isEmpty(memberProducts)) return Collections.emptyList();
        return memberProducts.stream()
                .map(FCCProductConverter::convert)
                .collect(Collectors.toUnmodifiableList());
    }

    private static Collection<ProductToCategory> convertCategories(Collection<ProductCategoryBinding> cats) {
        if (CollectionUtils.isEmpty(cats)) return Collections.emptyList();
        return cats.stream()
                .filter(Objects::nonNull)
                .map(productCategoryBinding -> ProductToCategory.builder()
                                                .categoryId(productCategoryBinding.getId())
                                                .sequenceNumber(productCategoryBinding.getSeqNum())
                                                .poolName(productCategoryBinding.getPoolName())
                                                .build())
                .collect(Collectors.toUnmodifiableList());
    }

    private static Collection<ProductToPool> convertPools(Collection<PoolBinding> cats) {
        if (CollectionUtils.isEmpty(cats)) return Collections.emptyList();
        return cats.stream()
                .filter(Objects::nonNull)
                .map(poolBinding -> ProductToPool.builder()
                        .poolId(poolBinding.getId())
                        .sequenceNumber(poolBinding.getSeqNumber())
                        .build()
                )
                .collect(Collectors.toUnmodifiableList());
    }

    private static Collection<Upc> convertUpcs(Collection<UpcBinding> upcs) {
        if (CollectionUtils.isEmpty(upcs)) return Collections.emptyList();
        return upcs.stream()
                .filter(Objects::nonNull)
                .filter(upc -> Boolean.TRUE.equals(upc.getActive()))
                .map(FCCProductConverter::convertUpc)
                .collect(Collectors.toUnmodifiableList());
    }

    private static Upc convertUpc(UpcBinding binding) {
        return Upc.builder()
                .upcId(unbox(binding.getId()))
                .available(convertAvailability(binding))
                .price(convertPrice(binding.getPrice()))
                .build();
    }

    private static boolean convertAvailability(UpcBinding binding) {
        return binding.getAvailability() != null && unbox(binding.getAvailability().getAvailable());
    }

    private static Price convertPrice(PriceBinding binding) {
        if (binding == null) return null;
        return Price.builder()
                .priceType(unbox(binding.getPriceType()))
                .retailPrice(binding.getRetailPrice())
                .originalPrice(unbox(binding.getOriginalPrice()))
                .originalPriceHigh(binding.getOriginalPriceHigh())
                .intermediatePrice(unbox(binding.getIntermediatePrice()))
                .intermediatePriceHigh(binding.getIntermediatePriceHigh())
                .basePriceType(unbox(binding.getBasePriceType()))
                .retailPriceHigh(binding.getRetailPriceHigh())
                .saleValue(unbox(binding.getSaleValue()))
                .saleValueHigh(binding.getSaleValueHigh())
                .intermediateSaleValue(unbox(binding.getIntermediateSaleValue()))
                .intermediateSaleValueHigh(binding.getIntermediateSaleValueHigh())
                .expirationDate(binding.getExpirationDate())
                .effectiveDate(binding.getEffectiveDate())
                .displayCode(binding.getDisplayCode())
                .onSale(unbox(binding.getOnSale()))
                .memberProductOnSale(binding.getMemberProductOnSale())
                .percentageOff(binding.getPercentageOff())
                .build();
    }

    private static Long getRecentlyReviewTS(ProductBinding product) {
        ReviewStatisticBinding statistics = product.getReviewStatistics();
        return statistics == null ? null : statistics.getRecentlyReviewTimestamp();
    }

    private static void setMetrics(Product.ProductBuilder builder, Collection<MetricBinding> metricBindings) {
        Map<String, Integer> productMetricsMap = null;
        Map<String, String> productRawMetricsMap = null;
        if (metricBindings != null) {
            productMetricsMap = new HashMap<>();
            productRawMetricsMap = new HashMap<>();
            for (MetricBinding metricBinding : metricBindings) {
                String metricName = metricBinding.getName();
                if (metricName != null) {
                    Integer metricBindingValue = metricBinding.getValue();
                    if (metricBindingValue != null) {
                        productMetricsMap.put(metricName, metricBindingValue);
                    }
                    String metricBindingRawValue = metricBinding.getRawValue();
                    if (metricBindingRawValue != null) {
                        productRawMetricsMap.put(metricName, metricBindingRawValue);
                    }
                } else {
                    log.info("Skipped metric binding: {} ", metricBinding);
                }
            }
        }
        builder.productMetrics(productMetricsMap);
        builder.productRawMetrics(productRawMetricsMap);
    }

    private static Map<String, Collection<String>> convertAttributes(Collection<AttributeBinding> attributes) {
        if (!CollectionUtils.isEmpty(attributes)) {
            Map<String, Collection<String>> result = new HashMap<>();
            attributes.forEach(attribute -> result.put(attribute.getName(),
                    attribute.getAttributeValues().stream().map(AttributeValueBinding::getValue).collect(Collectors.toSet())));
            return result;
        }
        return null;
    }

}
