package com.macys.search.config;

import com.macys.search.config.utils.ESIndicesUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class IndexVersionInfoContributor implements InfoContributor {
    private static final String EMPTY_INDEX = "N/A";
    private final Map<String, Object> infoMap = new LinkedHashMap<>();

    public IndexVersionInfoContributor(@Value("${rules.publisher.mcom.kwp.triggers.alias.name}") String mcomKWPIndexName,
                                       @Value("${rules.publisher.bcom.kwp.triggers.alias.name}") String bcomKWPIndexName,
                                       @Value("${rules.publisher.mcom.triggers.alias.name}") String mcomTriggersIndexName,
                                       @Value("${rules.publisher.bcom.triggers.alias.name}") String bcomTriggersIndexName,
                                       @Value("${rules.publisher.mcom.biz_controls_db.alias.index.name}") String mcomContolsDBIndexName,
                                       @Value("${rules.publisher.bcom.biz_controls_db.alias.index.name}") String bcomControlsDBIndexName,
                                       @Value("${rules.publisher.index.version}") String indexVersion) {

        Map<String, String> indicesInfo = new LinkedHashMap<>();
        indicesInfo.put("mcom_kwp_triggers", checkIndexNotEmpty(ESIndicesUtils.fullAliasNameFrom(mcomKWPIndexName, indexVersion)));
        indicesInfo.put("mcom_triggers", checkIndexNotEmpty(ESIndicesUtils.fullAliasNameFrom(mcomTriggersIndexName, indexVersion)));
        indicesInfo.put("bcom_kwp_triggers", checkIndexNotEmpty(ESIndicesUtils.fullAliasNameFrom(bcomKWPIndexName, indexVersion)));
        indicesInfo.put("bcom_triggers", checkIndexNotEmpty(ESIndicesUtils.fullAliasNameFrom(bcomTriggersIndexName, indexVersion)));
        indicesInfo.put("mcom_controls_db", checkIndexNotEmpty(ESIndicesUtils.fullAliasNameFrom(mcomContolsDBIndexName, indexVersion)));
        indicesInfo.put("bcom_controls_db", checkIndexNotEmpty(ESIndicesUtils.fullAliasNameFrom(bcomControlsDBIndexName, indexVersion)));
        infoMap.put("Indexes", indicesInfo);
    }

    @Override
    public void contribute(Info.Builder builder) {
        builder.withDetails(infoMap);
    }

    private String checkIndexNotEmpty(String index) {
        return !StringUtils.isBlank(index) ? index : EMPTY_INDEX;
    }
}
