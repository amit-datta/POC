package com.macys.search.bizrules.model.mrf.trigger;

/**
 * Facet refinement match type
 */
public enum FacetRefinementMatchType {
    exact_and,
    exact_or,
    contains_and,
    contains_or
}
