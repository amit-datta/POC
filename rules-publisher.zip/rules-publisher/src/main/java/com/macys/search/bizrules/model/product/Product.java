package com.macys.search.bizrules.model.product;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Collection;
import java.util.Map;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class Product {
    private final int productId;

    private final boolean isNew;
    private final boolean newMarkdown;

    private final Collection<Product> members;
    private final Collection<ProductToCategory> parentCategories;
    private final Collection<ProductToPool> pools;
    private final Collection<Upc> upcs;

    private final String name;
    private final String typeName;
    private final Map<String, Collection<String>> attributes;
    private final Price price;
    private final Boolean visible;
    private final Boolean productGroup;
    private final Map<String, Integer> productMetrics;
    private final Map<String, String> productRawMetrics;
    private final Collection<String> countryExclusion;
    private final Long recentlyReviewTimestamp;
    private final Long startDate;
    private final Long effectiveDate;
    private final Long firstAvailableDate;
    private final Long colorwayUpcCount;
    private final Long newnessDays;
    private final String primaryPortraitSource;
    private final String canonicalProductUrl;
    private final Double originalPriceHigh;
    private final Double retailPriceHigh;
}
