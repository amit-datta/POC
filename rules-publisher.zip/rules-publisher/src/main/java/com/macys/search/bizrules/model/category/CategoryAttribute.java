package com.macys.search.bizrules.model.category;

import lombok.Builder;
import lombok.Data;

import java.util.Set;

@Data
@Builder
public class CategoryAttribute {
    private final CategoryAttributeName name;
    private final Set<String> values;
    private Integer sortWeight;
    private Boolean visible;
    public String getUnaryValue() {
        return values.iterator().next();
    }
}
