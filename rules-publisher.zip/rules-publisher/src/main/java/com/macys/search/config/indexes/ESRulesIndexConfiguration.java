package com.macys.search.config.indexes;

import com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.macys.search.bizrules.model.elastic.ESIndex.RULES;
import static com.macys.search.config.utils.ESIndicesUtils.fullAliasNameFrom;

@Configuration
public class ESRulesIndexConfiguration extends AbstractElasticIndexConfiguration {

    @Value("${rules.publisher.mcom.rules.alias.name}")
    private String mcomAliasName;
    @Value("${rules.publisher.mcom.rules.number-of-shards:1}")
    private int mcomShardsCount;
    @Value("${rules.publisher.mcom.rules.number-of-replicas:0}")
    private int mcomReplicasCount;

    @Value("${rules.publisher.bcom.rules.alias.name}")
    private String bcomAliasName;
    @Value("${rules.publisher.bcom.rules.number-of-shards:1}")
    private int bcomShardsCount;
    @Value("${rules.publisher.bcom.rules.number-of-replicas:0}")
    private int bcomReplicasCount;

    @Bean
    public CreateIndexTasklet createRulesIndexTasklet(ElasticSearchFacade elasticSearchFacade) {
        return new CreateIndexTasklet(elasticSearchFacade,
                mcomRulesIndexCreationProperties(), bcomRulesIndexCreationProperties(),
                mcomCommonIndexProperties, bcomCommonIndexProperties,
                indexerFactory, RULES);
    }

    private IndexCreationProperties mcomRulesIndexCreationProperties() {
        return new IndexCreationProperties(fullAliasNameFrom(mcomAliasName, indexVersion),
                mcomShardsCount, mcomReplicasCount, RulesIndexFields.class, null);
    }

    private IndexCreationProperties bcomRulesIndexCreationProperties() {
        return new IndexCreationProperties(fullAliasNameFrom(bcomAliasName, indexVersion),
                bcomShardsCount, bcomReplicasCount, RulesIndexFields.class, null);
    }

    @Bean
    public SwitchAliasProperties rulesSwitchAliasProperties() {
        return SwitchAliasProperties.of(
                RULES,
                mcomAliasName, bcomAliasName, indexVersion,
                1);
    }

}
