package com.macys.search.cache;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Component
@ConditionalOnProperty(value = "spring.redis.enabled", havingValue = "true", matchIfMissing = true)
public class RedisCacheUtil {

    @Resource
    private StringRedisTemplate redisTemplate;

    @Value("${text.char-to-keep-regex}")
    private String queryPhraseCharToKeepRegexp;

    @Value("${text.compound-designators}")
    private String queryPhraseCompoundDesignators;

    public void flushAndFillStorageDataIntoCache(Set<String> blacklistedPhrases, String redisKey) {
        redisTemplate.delete(redisKey);
        blacklistedPhrases.parallelStream().map(this::normalizePhrase).forEach(phrase->addStorageData(phrase,redisKey));
    }

    private String normalizePhrase(final String phrase) {
        return normalize(phrase).get();
    }

    private Long addStorageData(final String phrase, String redisKey){
        return redisTemplate.opsForSet().add(redisKey, phrase);
    }

    public void emptyPhrasesInCache(String redisKey) {
        redisTemplate.delete(redisKey);
        redisTemplate.opsForSet().add(redisKey,"");
    }

    public boolean isKeyExists(String key) {
        Boolean isExists = redisTemplate.hasKey(key);
        return null!= isExists && isExists;
    }

     /**
     * Normalizing input text such as handling Special Characters as À
     *
     * @param text
     * @return
     */
    public Optional<String> normalize(String text) {
        if (null == text){
            return Optional.empty();
        }
        text = text.replaceAll(queryPhraseCharToKeepRegexp, "").replaceAll(queryPhraseCompoundDesignators, " ");
        text = StringUtils.stripAccents(text);
        text = StringUtils.normalizeSpace(text);
        return Optional.of(text.toLowerCase().trim());
    }
}
