package com.macys.search.handler;

import com.macys.search.cache.RedisCacheUtil;
import com.macys.search.exception.RulesPublisherException;
import com.macys.search.exception.StorageClientException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.GcpPubSubHeaders;
import org.springframework.messaging.MessageHandler;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

@Slf4j
@Component
@ConditionalOnProperty(
        value = {
                "spring.cloud.gcp.pubsub.enabled",
                "rules.publisher.load.rules.from.pubsub"
        },
        havingValue = "true"
)
public class PubSubMessageEventsHandler {
    @Resource
    private RulesStorageBucketHandler rulesStorageBucketHandler;

    @Resource
    private RedisCacheUtil redisCacheUtil;

    @Value("${blacklisted-phrases.mcom.storage.object}")
    private String mcomBlacklistPhrasesObject;

    @Value("${seo-whitelist-phrases.mcom.storage.object}")
    private String mcomSeoWhitelistPhrasesObject;

    @Value("${blacklisted-phrases.bcom.storage.object}")
    private String bcomBlacklistPhrasesObject;

    @Value("${seo-whitelist-phrases.bcom.storage.object}")
    private String bcomSeoWhitelistPhrasesObject;

    @Value("${blacklisted-phrases.mcom.redis.key}")
    private String mcomBlacklistedPhraseRedisKey;

    @Value("${seo-whitelist-phrases.mcom.redis.key}")
    private String mcomSeoWhitelistPhraseRedisKey;

    @Value("${blacklisted-phrases.bcom.redis.key}")
    private String bcomBlacklistedPhraseRedisKey;

    @Value("${seo-whitelist-phrases.bcom.redis.key}")
    private String bcomSeoWhitelistPhraseRedisKey;

    @Value("${rules.storage.bucket}")
    private String rulesStorageBucket;

    @Value("${blacklisted-categories.mcom.storage.object}")
    private String mcomBlacklistCategoriesObject;

    @Value("${blacklisted-categories.bcom.storage.object}")
    private String bcomBlacklistCategoriesObject;

    @Value("${blacklisted-categories.mcom.redis.key}")
    private String mcomBlacklistedCategoriesRedisKey;

    @Value("${blacklisted-categories.bcom.redis.key}")
    private String bcomBlacklistedCategoriesRedisKey;

    private static final String OBJECT_ID = "objectId";
    private static final String EVENT_TYPE = "eventType";
    private static final String BUCKET_ID = "bucketId";
    private static final String OBJECT_FINALIZE = "OBJECT_FINALIZE";
    private static final String COMMA =",";
    private static final String NEW_LINE ="\\r?\\n";

    @PostConstruct
    public void preloadCache() {
        try {
            if(!redisCacheUtil.isKeyExists(mcomBlacklistedPhraseRedisKey)) {
                rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(OBJECT_FINALIZE, mcomBlacklistPhrasesObject, mcomBlacklistedPhraseRedisKey,COMMA,"MCOM blacklisted phrases");
            }
            if(!redisCacheUtil.isKeyExists(bcomBlacklistedPhraseRedisKey)) {
                rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(OBJECT_FINALIZE, bcomBlacklistPhrasesObject, bcomBlacklistedPhraseRedisKey,COMMA,"BCOM blacklisted phrases");
            }
            if(!redisCacheUtil.isKeyExists(mcomSeoWhitelistPhraseRedisKey)) {
                rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(OBJECT_FINALIZE, mcomSeoWhitelistPhrasesObject, mcomSeoWhitelistPhraseRedisKey,NEW_LINE,"MCOM SEO whitelisted");
            }
            if(!redisCacheUtil.isKeyExists(bcomSeoWhitelistPhraseRedisKey)) {
                rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(OBJECT_FINALIZE, bcomSeoWhitelistPhrasesObject, bcomSeoWhitelistPhraseRedisKey,NEW_LINE,"BCOM SEO whitelisted");
            }
            if(!redisCacheUtil.isKeyExists(mcomBlacklistedCategoriesRedisKey)) {
                rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(OBJECT_FINALIZE, mcomBlacklistCategoriesObject, mcomBlacklistedCategoriesRedisKey,COMMA,"MCOM blacklisted categories");
            }
            if(!redisCacheUtil.isKeyExists(bcomBlacklistedCategoriesRedisKey)) {
                rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(OBJECT_FINALIZE, bcomBlacklistCategoriesObject, bcomBlacklistedCategoriesRedisKey,COMMA,"BCOM blacklisted categories");
            }
        } catch(Exception e) {
            log.error("",new RulesPublisherException("Exception occurred while preloading data in the cache with error:"+e.getMessage(),e));
            throw e;
        }
    }

    /**
     * Any change in the storage bucket is notified to pub-sub
     * and the subscriber then reads the file from the storage and uploads to the mem-store
     * There are two subscribers one each in a region corresponding to the regional mem-store
     *
     * @return
     */
    public MessageHandler handleMessage() {
        return message -> {
            BasicAcknowledgeablePubsubMessage originalMessage =
                    message.getHeaders().get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class);
            String storageObjectId = (null != message.getHeaders().get(OBJECT_ID)) ? message.getHeaders().get(OBJECT_ID).toString() : null;
            String eventType = (null != message.getHeaders().get(EVENT_TYPE)) ? message.getHeaders().get(EVENT_TYPE).toString() : null;
            String bucketId = (null != message.getHeaders().get(BUCKET_ID)) ? message.getHeaders().get(BUCKET_ID).toString() : null;

            if(bucketId.equalsIgnoreCase(rulesStorageBucket) && StringUtils.isNotBlank(storageObjectId)) {
                boolean isSuccess;
                if(storageObjectId.equalsIgnoreCase(mcomBlacklistPhrasesObject) || storageObjectId.equalsIgnoreCase(bcomBlacklistPhrasesObject)) {
                    isSuccess = rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(eventType, storageObjectId,
                            storageObjectId.equalsIgnoreCase(mcomBlacklistPhrasesObject)?mcomBlacklistedPhraseRedisKey:bcomBlacklistedPhraseRedisKey,COMMA,
                            storageObjectId.equalsIgnoreCase(mcomBlacklistPhrasesObject)?"MCOM blacklisted phrases":"BCOM blacklisted phrases");
                } else if(storageObjectId.equalsIgnoreCase(mcomSeoWhitelistPhrasesObject) || storageObjectId.equalsIgnoreCase(bcomSeoWhitelistPhrasesObject)) {
                    isSuccess = rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(eventType, storageObjectId,
                            storageObjectId.equalsIgnoreCase(mcomSeoWhitelistPhrasesObject)?mcomSeoWhitelistPhraseRedisKey:bcomSeoWhitelistPhraseRedisKey,NEW_LINE,
                            storageObjectId.equalsIgnoreCase(mcomSeoWhitelistPhrasesObject)?"MCOM SEO whitelisted":"BCOM SEO whitelisted");
                } else if(storageObjectId.equalsIgnoreCase(mcomBlacklistCategoriesObject) || storageObjectId.equalsIgnoreCase(bcomBlacklistCategoriesObject)) {
                    isSuccess = rulesStorageBucketHandler.readDataFromStorageBucketIntoRedis(eventType, storageObjectId,
                            storageObjectId.equalsIgnoreCase(mcomBlacklistCategoriesObject)?mcomBlacklistedCategoriesRedisKey:bcomBlacklistedCategoriesRedisKey,COMMA,
                            storageObjectId.equalsIgnoreCase(mcomBlacklistCategoriesObject)?"MCOM blacklisted categories":"BCOM blacklisted categories");
                }else {
                    log.error("",new StorageClientException("Exception occurred in PubSubMessageEventsHandler- " +
                            "UNKNOWN object found in pub-sub notification: "+storageObjectId));
                    isSuccess = true;
                }
                if (isSuccess) {
                    originalMessage.ack();
                }
            }
        };
    }
}
