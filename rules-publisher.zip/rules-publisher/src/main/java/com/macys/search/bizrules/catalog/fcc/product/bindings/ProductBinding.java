package com.macys.search.bizrules.catalog.fcc.product.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.macys.search.bizrules.catalog.fcc.category.bindings.AttributeBinding;
import lombok.Data;

import java.util.Collection;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductBinding {
    private Integer id;
    private PriceBinding price;
    private Boolean isNew;

    private Collection<ProductBinding> memberProducts;
    private Collection<ProductCategoryBinding> categories;
    private Collection<PoolBinding> pools;
    private Collection<UpcBinding> upcs;

    private String name;
    private String typeName;
    private Boolean productGroup;
    private Collection<AttributeBinding> attributes;
    private Boolean visible;
    private Collection<String> countryExclusion;
    private ReviewStatisticBinding reviewStatistics;
    private Collection<MetricBinding> metrics;
    private String primaryPortraitSource;
    private String canonicalProductUrl;
    private Long startDate;
    private Long effectiveDate;
    private Long firstAvailableDate;
    private Long newnessDays;
    private Long colorwayUpcCount;
    private Double originalPriceHigh;
    private Double retailPriceHigh;
}
