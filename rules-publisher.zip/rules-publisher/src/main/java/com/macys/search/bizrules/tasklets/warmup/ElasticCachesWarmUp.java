package com.macys.search.bizrules.tasklets.warmup;

import com.google.common.base.Stopwatch;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.model.mrf.trigger.HRTFiringStrategy;
import com.macys.search.bizrules.model.mrf.trigger.KWPMatchType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.validation.TriggerValidationService;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.core.TimeValue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.converters.ConverterUtils.getUnaryValue;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.*;

/**
 * Warm up es caches with category and keyword trigger phrases requests
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ElasticCachesWarmUp implements RulesPublisherTasklet {
    private final WarmUpSearchClient searchClient;
    @Value("${rules.publisher.es.caches.warmup.requests.count}")
    private int warmupRequestsCount;
    @Value("${rules.publisher.es.caches.warmup.enabled}")
    private boolean cachesWarmupEnabled;

    private final TriggerValidationService validationService;

    public void execute(ProcessingContext ctx) {
        if (!cachesWarmupEnabled) {
            log.info("Caches warmup is disabled");
            return;
        }
        final Map<KWPMatchType, Set<String>> keywordTriggerPhrases = Map.of(
                KWPMatchType.Exact, new HashSet<>(),
                KWPMatchType.Contains, new HashSet<>(),
                KWPMatchType.Literal, new HashSet<>()
        );
        final Set<Integer> refinementTriggersCategoryIds = new HashSet<>();
        final List<SearchResponse> keywordResponses = new ArrayList<>();
        final List<SearchResponse> categoryResponses = new ArrayList<>();
        collectKeywordsAndCategoryIds(ctx, keywordTriggerPhrases, refinementTriggersCategoryIds);
        searchClient.refresh(ctx.getIndexName(ESIndex.KWP_TRIGGERS));
        searchClient.refresh(ctx.getIndexName(ESIndex.TRIGGERS));
        makeRequests(ctx, keywordTriggerPhrases, refinementTriggersCategoryIds, keywordResponses, categoryResponses);
        logStatistics(keywordResponses, categoryResponses);
    }

    private void collectKeywordsAndCategoryIds(ProcessingContext ctx,
                                               Map<KWPMatchType, Set<String>> keywordTriggerPhrases,
                                               Set<Integer> refinementTriggersCategoryIds) {
        Stopwatch collectingPhaseTimer = Stopwatch.createStarted();
        for (ProcessingTrigger processingTrigger : ctx.getTriggers().values()) {
            ValidationResult validationResult = validationService.validate(processingTrigger.getTrigger(), ctx);
            if (validationResult.isValid()) {
                if (allDataIsCollected(keywordTriggerPhrases, refinementTriggersCategoryIds)) break;
                classifyAndAddTrigger(processingTrigger.getTrigger(), keywordTriggerPhrases, refinementTriggersCategoryIds);
            }
        }
        log.info("Collecting phrases and categories time = {}", collectingPhaseTimer.elapsed(TimeUnit.MILLISECONDS));
    }

    private void makeRequests(ProcessingContext ctx,
                              Map<KWPMatchType, Set<String>> keywordTriggerPhrases,
                              Set<Integer> refinementTriggersCategoryIds,
                              List<SearchResponse> keywordRequestsTime,
                              List<SearchResponse> categoryRequestsTime) {
        String kwpIndexName = ctx.getIndexName(ESIndex.KWP_TRIGGERS);
        String triggersIndexName = ctx.getIndexName(ESIndex.TRIGGERS);
        refinementTriggersCategoryIds.forEach(categoryId -> {
            SearchResponse response = searchClient.search(getWarmUpRequestTemplate(ctx)
                    .categoryId(categoryId).build(), triggersIndexName);
            if (response != null) categoryRequestsTime.add(response);
        });
        keywordTriggerPhrases.values().stream().flatMap(Collection::stream).forEach(phrase -> {
            SearchResponse response = searchClient.search(getWarmUpRequestTemplate(ctx)
                    .searchPhrase(phrase)
                    .build(), kwpIndexName);
            if (response != null) keywordRequestsTime.add(response);
        });
    }

    private <T> boolean isCollectionFull(Collection<T> triggers) {
        return triggers.size() >= warmupRequestsCount;
    }

    private int getLastIndexOfElementGreaterThan(List<Long> list, Long value) {
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i) > value) return i;
        }
        return -1;
    }

    private boolean allDataIsCollected(Map<KWPMatchType, Set<String>> keywordTriggerPhrases,
                                       Set<Integer> refinementTriggersCategoryIds) {
        return isCollectionFull(keywordTriggerPhrases.get(KWPMatchType.Exact)) &&
                isCollectionFull(keywordTriggerPhrases.get(KWPMatchType.Contains)) &&
                isCollectionFull(keywordTriggerPhrases.get(KWPMatchType.Literal)) &&
                isCollectionFull(refinementTriggersCategoryIds);
    }

    void classifyAndAddTrigger(Trigger trigger, Map<KWPMatchType, Set<String>> keywordTriggerPhrases,
                               Set<Integer> refinementTriggersCategoryIds) {
        if (trigger.getMerchTriggerType() == TriggerType.KeywordPattern) {
            Criteria matchConfig = trigger.getCriteriaMap().get(KEYWORD_PATTERN_MATCH_CONFIG);
            KWPMatchType matchType = KWPMatchType.valueOf(getUnaryValue(matchConfig, KEYWORD_PATTERN_MATCH_TYPE));
            for (Criteria criteria : trigger.getCriteriaMap().values()) {
                if (isCollectionFull(keywordTriggerPhrases.get(matchType))) break;
                if (!criteria.getCriteriaName().equals(KEYWORD_PATTERN_MATCH_CONFIG)) {
                    for (String phrase : criteria.getCriteriaAttributes().get(KEYWORD_PATTERN_KEYWORD_VALUE)) {
                        if (isCollectionFull(keywordTriggerPhrases.get(matchType))) break;
                        keywordTriggerPhrases.get(matchType).add(phrase);
                    }
                }
            }
        } else if (trigger.getMerchTriggerType() == TriggerType.HierarchicalRefinement) {
            Criteria matchConfig = trigger.getCriteriaMap().get(HIERARCHICAL_REFINEMENT_CATEGORY_ID);
            HRTFiringStrategy firingStrategy = HRTFiringStrategy.valueOf(
                    getUnaryValue(matchConfig, HIERARCHICAL_REFINEMENT_FIRING_STRATEGY)
            );
            if (firingStrategy == HRTFiringStrategy.Exact) {
                for (Integer categoryId : matchConfig.getCriteriaAttributes().get(HIERARCHICAL_REFINEMENT_ATTRIBUTE_VALUE)
                        .stream().map(Integer::valueOf).collect(Collectors.toList())) {
                    if (isCollectionFull(refinementTriggersCategoryIds)) break;
                    refinementTriggersCategoryIds.add(categoryId);
                }
            }
        }
    }

    private WarmUpRequest.WarmUpRequestBuilder getWarmUpRequestTemplate(ProcessingContext ctx) {
        return WarmUpRequest.builder()
                .customDate(ctx.getCustomDate())
                .siteName(ctx.getSiteName())
                .actionTypes(List.of(ESActionType.values()));
    }

    private void logStatistics(List<SearchResponse> keywordResponses,
                               List<SearchResponse> categoryResponses) {
        List<Long> keywordResponsesTime = keywordResponses.stream()
                .map(SearchResponse::getTook).map(TimeValue::getMillis).collect(Collectors.toList());
        List<Long> categoryResponsesTime = categoryResponses.stream()
                .map(SearchResponse::getTook).map(TimeValue::getMillis).collect(Collectors.toList());

        long nonZeroHitsKeywordReq = keywordResponses.stream().filter(searchResponse -> searchResponse.getHits().getTotalHits().value > 0)
                .count();
        long nonZeroHitsCategoryReq = categoryResponses.stream().filter(searchResponse -> searchResponse.getHits().getTotalHits().value > 0)
                .count();

        log.info("Warmup statistics:");
        LongSummaryStatistics categoryRequestStats = categoryResponsesTime.stream().collect(Collectors.summarizingLong(x -> x));
        LongSummaryStatistics keywordRequestStats = keywordResponsesTime.stream().collect(Collectors.summarizingLong(x -> x));
        logStatistics("category request stats avg={}, min={}, max={}, last index with bigger than avg time={}," +
                        "non zero hits={}",
                categoryRequestStats,
                getLastIndexOfElementGreaterThan(categoryResponsesTime, Double.valueOf(categoryRequestStats.getAverage()).longValue()),
                nonZeroHitsCategoryReq);
        logStatistics("keyword request stats avg={}, min={}, max={}, last index with bigger than avg time={}," +
                        "non zero hits={}",
                keywordRequestStats,
                getLastIndexOfElementGreaterThan(keywordResponsesTime, Double.valueOf(keywordRequestStats.getAverage()).longValue()),
                nonZeroHitsKeywordReq);
    }

    private void logStatistics(String template, LongSummaryStatistics statistics, int lastIndexOfElementGreaterThan, long nonZeroHits) {
        log.info(template,
                String.format("%.2f", statistics.getAverage()),
                statistics.getMin(),
                statistics.getMax(),
                lastIndexOfElementGreaterThan,
                nonZeroHits
        );
    }
}