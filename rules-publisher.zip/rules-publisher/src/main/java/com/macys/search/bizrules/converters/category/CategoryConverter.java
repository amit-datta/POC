package com.macys.search.bizrules.converters.category;

import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESCategory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class CategoryConverter {

    public ESCategory convert(Category category, CategoryTree tree) {
        ESCategory result = new ESCategory(category);
        setPaths(result, category.getId(), tree);
        return result;
    }

    private static void setPaths(ESCategory result, Integer id, CategoryTree tree) {
        List<Integer> ids = new ArrayList<>(tree.getParents(id));
        ids.add(id);
        String categoryPath = ids.stream().map(Object::toString).collect(Collectors.joining(" > "));
        result.setCategoryPath(categoryPath);
        String titlesPath = ids.stream().map(categoryId -> tree.get(categoryId).getName()).collect(Collectors.joining(" > "));
        result.setTitlesPath(titlesPath);
    }

}
