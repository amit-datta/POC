package com.macys.search.bizrules.converters.trigger;

import com.macys.search.analysis.PhraseAnalyzer;
import com.macys.search.analysis.PhraseAnalyzerFactory;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.KWPMatchType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.model.processing.trigger.params.KeywordPatternTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.DisMaxQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.converters.ConverterUtils.combineIntoDismaxQuery;
import static com.macys.search.bizrules.converters.ConverterUtils.getUnaryValue;
import static com.macys.search.bizrules.model.mrf.trigger.KWPMatchType.*;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.*;
import static com.macys.search.bizrules.utils.QueryBuildingUtils.*;
import static java.util.Collections.singletonList;

/**
 * Convert triggers with {@link TriggerType#KeywordPattern}.
 * Keyword pattern trigger can contain one or more keyword patterns.
 * All keyword pattern have similar type.
 * There are three type of patterns:
 * <ul>
 *     <li>Exact and Literal - converts to {@link org.elasticsearch.index.query.MatchPhraseQueryBuilder} with
 *     fixed score equal to matched phrase length</li>
 *     <li>Contains - converts to {@link org.elasticsearch.index.query.MatchPhraseQueryBuilder} with unbounded score
 *     to match sub phrase in phrase</li>
 * </ul>
 * In case when trigger contains more than one keyword pattern, all pattern queries combines to
 * {@link BoolQueryBuilder} or {@link DisMaxQueryBuilder} with boolean operator determined into match config MatchType property.
 * In one keyword pattern case corresponding query uses as trigger query.
 */
@Component
public class KeywordPatternTriggerConverter implements TriggerConverter {
    private static final int MAX_PREVIEW_LENGTH = 1000;
    private final EnumMap<KWPMatchType, ThreadLocal<PhraseAnalyzer>> analyzers;

    @Autowired
    KeywordPatternTriggerConverter(PhraseAnalyzerFactory analyzerFactory) {
        analyzers = new EnumMap<>(KWPMatchType.class);
        analyzers.put(Exact, ThreadLocal.withInitial(analyzerFactory::createExactPhraseAnalyzer));
        analyzers.put(Contains, ThreadLocal.withInitial(analyzerFactory::createContainsPhraseAnalyzer));
        analyzers.put(Literal, ThreadLocal.withInitial(analyzerFactory::createLiteralPhraseAnalyzer));
    }

    public TriggerType applicableFor() {
        return TriggerType.KeywordPattern;
    }

    public AbstractTriggerParams convert(ProcessingTrigger processingTrigger, ProcessingContext ctx) {
        Trigger trigger = processingTrigger.getTrigger();
        Criteria matchConfig = trigger.getCriteriaMap().get(KEYWORD_PATTERN_MATCH_CONFIG);
        KWPMatchType matchType = KWPMatchType.valueOf(getUnaryValue(matchConfig, KEYWORD_PATTERN_MATCH_TYPE));
        BooleanOperation operationType = BooleanOperation.valueOf(getUnaryValue(matchConfig, KEYWORD_PATTERN_MATCH_OPERATOR));
        PhraseAnalyzer phraseAnalyzer = analyzers.get(matchType).get();

        List<Set<String>> phrasesLists = new ArrayList<>(trigger.getCriteriaMap().size() - 1);
        Map<String, Set<String>> groupedValues = new LinkedHashMap<>();
        for (Criteria criteria : trigger.getCriteriaMap().values()) {
            if (!criteria.getCriteriaName().equals(KEYWORD_PATTERN_MATCH_CONFIG)) {
                Set<String> phrases = criteria.getCriteriaAttributes().get(KEYWORD_PATTERN_KEYWORD_VALUE).stream()
                        .map(phraseAnalyzer::analise)
                        .collect(Collectors.toCollection(LinkedHashSet::new));
                phrasesLists.add(phrases);
                String groupName = criteria.getCriteriaName();
                Set<String> values = groupedValues.getOrDefault(groupName, new HashSet<>());
                int currentSize = values.stream().map(String::length).mapToInt(Integer::intValue).sum();
                for (String phrase : phrases) {
                    if (currentSize > MAX_PREVIEW_LENGTH) {
                        break;
                    }
                    values.add(phrase);
                    currentSize += phrase.length();
                }
                groupedValues.put(groupName, values);
            }
        }
        boolean onlyOneAttribute = trigger.getCriteriaMap().size() == 2;
        List<KeywordPatternTriggerParams.KWPNode> nodes = operationType == BooleanOperation.OR || onlyOneAttribute
                ? parse(parseDisjunction, matchType, phrasesLists)
                : parse(parseConjunction, matchType, phrasesLists);

        StringBuilder keywordPatternPreviewBuilder = new StringBuilder();
        String keywordPatternPreview;
        groupedValues.keySet().stream().sorted()
                .forEach(group -> keywordPatternPreviewBuilder
                        .append(String.format("%s = %s", group, groupedValues.get(group).stream().sorted().collect(Collectors.joining(", "))))
                        .append("\n"));
        if (keywordPatternPreviewBuilder.length() > MAX_PREVIEW_LENGTH) {
            keywordPatternPreview = "The preview is too large. Here is part of it:\n" + keywordPatternPreviewBuilder.substring(0, 1000) + "...";
        } else {
            keywordPatternPreview = keywordPatternPreviewBuilder.toString();
        }
        return KeywordPatternTriggerParams.builder()
                .nodes(nodes)
                .triggerId(trigger.getId())
                .matchType(matchType)
                .operationType(operationType)
                .keywordPatternPreview(keywordPatternPreview)
                .build();
    }

    @FunctionalInterface
    private interface ParseFunction {
        List<KeywordPatternTriggerParams.KWPNode> apply(List<Set<String>> phrases, Function<String, QueryBuilder> queryFunc);
    }

    private static final ParseFunction parseDisjunction = (phrasesLists, queryFunc) ->
            phrasesLists.stream().flatMap(Set::stream)
                    .map(phrase ->
                            new KeywordPatternTriggerParams.KWPNode(queryFunc.apply(phrase), Set.of(phrase))
                    )
                    .collect(Collectors.toList());

    private static final ParseFunction parseConjunction = (phrasesLists, queryFunc) -> {
        BoolQueryBuilder bool = QueryBuilders.boolQuery();
        Set<String> allPhrases = new HashSet<>();
        for (Set<String> phrasesSet : phrasesLists) {
            List<QueryBuilder> queries = phrasesSet.stream()
                    .map(queryFunc)
                    .collect(Collectors.toList());
            bool.must(combineIntoDismaxQuery(queries));
            allPhrases.addAll(phrasesSet);
        }
        return singletonList(new KeywordPatternTriggerParams.KWPNode(bool, allPhrases));
    };

    private static List<KeywordPatternTriggerParams.KWPNode> parse(ParseFunction parseFunc, KWPMatchType matchType, List<Set<String>> allValues) {
        if (matchType == Exact)
            return parseFunc.apply(allValues, exactQueryBuilder);
        if (matchType == Literal)
            return parseFunc.apply(allValues, literalQueryBuilder);
        if (matchType == Contains)
            return parseFunc.apply(allValues, containsQueryBuilder);
        throw new AssertionError("Unknown match type=" + matchType);
    }

}
