package com.macys.search.config.indexes;

import com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import com.macys.search.config.utils.ESIndicesUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.IOException;

import static com.macys.search.bizrules.model.elastic.ESIndex.TRIGGERS;

@Configuration
public class ESTriggersIndexConfiguration extends AbstractElasticIndexConfiguration {

    @Value("${rules.publisher.mcom.triggers.alias.name}")
    private String mcomAliasName;
    @Value("${rules.publisher.mcom.triggers.number-of-shards}")
    private int mcomShardsCount;
    @Value("${rules.publisher.mcom.triggers.number-of-replicas}")
    private int mcomReplicasCount;

    @Value("${rules.publisher.bcom.triggers.alias.name}")
    private String bcomAliasName;
    @Value("${rules.publisher.bcom.triggers.number-of-shards}")
    private int bcomShardsCount;
    @Value("${rules.publisher.bcom.triggers.number-of-replicas}")
    private int bcomReplicasCount;

    @Value("classpath:schema/triggers-index-overrides.json")
    private Resource overriddenPropertiesResource;

    @Bean
    public CreateIndexTasklet createTriggersIndexTasklet(ElasticSearchFacade elasticSearchFacade) throws IOException {
        return new CreateIndexTasklet(elasticSearchFacade,
                mcomTriggersIndexCreationProperties(), bcomTriggersIndexCreationProperties(),
                mcomCommonIndexProperties, bcomCommonIndexProperties,
                indexerFactory, TRIGGERS);
    }

    private IndexCreationProperties mcomTriggersIndexCreationProperties() throws IOException {
        return new IndexCreationProperties(ESIndicesUtils.fullAliasNameFrom(mcomAliasName, indexVersion),
                mcomShardsCount, mcomReplicasCount, TriggerIndexFields.class,
                readOverriddenProperties(overriddenPropertiesResource));
    }

    private IndexCreationProperties bcomTriggersIndexCreationProperties() throws IOException {
        return new IndexCreationProperties(ESIndicesUtils.fullAliasNameFrom(bcomAliasName, indexVersion),
                bcomShardsCount, bcomReplicasCount, TriggerIndexFields.class,
                readOverriddenProperties(overriddenPropertiesResource));
    }

    @Bean
    public SwitchAliasProperties triggersSwitchAliasProperties() {
        return SwitchAliasProperties.of(
                TRIGGERS,
                mcomAliasName, bcomAliasName,
                indexVersion,
                1
        );
    }
}
