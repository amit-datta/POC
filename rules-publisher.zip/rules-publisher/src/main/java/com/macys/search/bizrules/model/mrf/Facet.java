package com.macys.search.bizrules.model.mrf;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
public class Facet {
    private String attributeName;
    private String facetDisplayName;
}
