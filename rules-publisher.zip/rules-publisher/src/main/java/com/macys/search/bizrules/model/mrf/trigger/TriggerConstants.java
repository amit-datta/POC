package com.macys.search.bizrules.model.mrf.trigger;

/**
 * Trigger criteria attributes constants
 */
public final class TriggerConstants {
    public static final String KEYWORD_PATTERN_MATCH_CONFIG = "MatchConfig";
    public static final String KEYWORD_PATTERN_MATCH_TYPE = "MatchType";
    public static final String KEYWORD_PATTERN_MATCH_OPERATOR = "MatchOperator";
    public static final String KEYWORD_PATTERN_KEYWORD_VALUE = "KeywordValue";

    public static final String HIERARCHICAL_REFINEMENT_CATEGORY_ID = "CAT_ID";
    public static final String HIERARCHICAL_REFINEMENT_FIRING_STRATEGY = "FiringStrategy";
    public static final String HIERARCHICAL_REFINEMENT_ATTRIBUTE_VALUE = "AttributeValue";
    public static final String HIERARCHICAL_REFINEMENT_EXCLUDED_VALUE = "ExcludedValue";

    public static final String FACET_REFINEMENT_MATCH_CONFIG = "MatchConfig";
    public static final String FACET_REFINEMENT_MATCH_TYPE = "MatchType";
    public static final String FACET_REFINEMENT_MATCH_OPERATOR = "MatchOperator";
    public static final String FACET_REFINEMENT_ATTRIBUTE_VALUE = "AttributeValue";

    public static final String ANY_FILTER = "ANY";
}
