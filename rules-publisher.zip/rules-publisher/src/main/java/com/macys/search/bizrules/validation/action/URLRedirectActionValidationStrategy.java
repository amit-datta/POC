package com.macys.search.bizrules.validation.action;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Implementation of validation strategy for action {@link com.macys.search.bizrules.model.mrf.action.ActionType#URLRedirect}
 * validates that given actionConfig {@link Action} contains uniq attribute URLValue and URLType with value "Relative"
 * or "Absolute"
 */
@Slf4j
@Component
public class URLRedirectActionValidationStrategy extends AbstractActionCriteriaValidationStrategy {

    @Getter(AccessLevel.PACKAGE)
    @ResourceMapping("classpath:merch-validation-template/action/URLRedirect.json")
    private ConfigTemplate template;

    @Override
    public ActionType applicableFor() {
        return ActionType.URLRedirect;
    }

}
