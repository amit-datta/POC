package com.macys.search.bizrules.model.product;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Date;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class Price {
    private final double originalPrice;
    private final double intermediatePrice;
    private final Double retailPrice;
    private final Integer priceType;
    private final double saleValue;
    private final double intermediateSaleValue;
    private final Date effectiveDate;
    private final Date expirationDate;
    private final String displayCode;
    private final int basePriceType;
    private final boolean onSale;
    private final Double originalPriceHigh;
    private final Double intermediatePriceHigh;
    private final Double retailPriceHigh;
    private final Double saleValueHigh;
    private final Double intermediateSaleValueHigh;
    private final Boolean memberProductOnSale;
    private final Double percentageOff;
}
