package com.macys.search.bizrules.model.category;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;

import java.util.*;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CategoryTree implements Iterable<Category> {
    private final Map<Integer, CategoryNode> categoryMap = new HashMap<>();
    private final List<CategoryNode> roots = new ArrayList<>();

    @NonNull
    @Override
    public Iterator<Category> iterator() {
        return new CategoryIterator(categoryMap.values().iterator());
    }

    @AllArgsConstructor
    private static class CategoryIterator implements Iterator<Category> {
        private final Iterator<CategoryNode> iterator;

        @Override
        public boolean hasNext() {
            return iterator.hasNext();
        }

        @Override
        public Category next() {
            return iterator.next().category;
        }
    }

    @RequiredArgsConstructor
    private static class CategoryNode {
        private final Category category;
        private CategoryNode parent;
        private final List<CategoryNode> children = new ArrayList<>();

        static CategoryNode from(Category category) {
            return new CategoryNode(category);
        }

        Integer getId() {
            return category.getId();
        }
    }

    /**
     * Collect all children with filter ids. NO children from category id would be in result collection
     *
     * @param catId    category id
     * @param excluded excluded categories
     * @return collection of children ids
     */
    public Collection<Integer> getChildren(Integer catId, Collection<Integer> excluded) {
        CategoryNode node = getNode(catId);
        if (node == null) {
            return Collections.emptyList();
        }
        List<Integer> result = new ArrayList<>();
        collectChildrenIds(node, excluded, result);
        return result;
    }

    /**
     * Collect ancestors in order from root
     *
     * @param catId category id
     * @return ordered list of ancestors
     */
    public List<Integer> getParents(Integer catId) {
        CategoryNode node = getNode(catId);
        if (node == null) {
            return Collections.emptyList();
        }
        List<Integer> result = new ArrayList<>();
        collectPathFromRoot(node.parent, result);
        return result;
    }

    /**
     * Collect ancestors in order from root with cat id as leaf
     *
     * @param catId category id
     * @return hierarchy
     */
    public List<Integer> getHierarchy(Integer catId) {
        CategoryNode node = getNode(catId);
        if (node == null) {
            return Collections.emptyList();
        }
        List<Integer> result = new ArrayList<>();
        collectPathFromRoot(node, result);
        return result;
    }

    /**
     * @param id category id
     * @return category by id
     */
    public Category get(Integer id) {
        CategoryNode node = categoryMap.get(id);
        return node != null ? node.category : null;
    }

    /**
     * @param id category id
     * @return if category exists in tree
     */
    public boolean isPresent(Integer id) {
        return get(id) != null;
    }

    private CategoryNode getNode(Integer id) {
        CategoryNode node = categoryMap.get(id);
        if (node == null) {
            log.debug("Category tree does not contains category with id={}", id);
            return null;
        }
        return node;
    }

    /**
     * @return categories count in category tree
     */
    public int size() {
        return categoryMap.size();
    }

    private static void collectPathFromRoot(CategoryNode node, List<Integer> path) {
        if (node == null) {
            return;
        }
        collectPathFromRoot(node.parent, path);
        path.add(node.getId());
    }

    public static CategoryTree from(Collection<Category> categories) {
        CategoryTree tree = new CategoryTree();
        for (Category category : categories) {
            tree.add(category);
        }
        tree.buildLinks();
        tree.removeCycles();
        log.info("Category tree was successfully built. Categories in tree=" + tree.categoryMap.size());
        return tree;
    }

    private void add(Category category) {
        CategoryNode node = CategoryNode.from(category);
        categoryMap.put(category.getId(), node);
    }

    private void buildLinks() {
        List<CategoryNode> lostRoots = new ArrayList<>();

        for (CategoryNode node : categoryMap.values()) {
            Category cat = node.category;
            Integer parentId = cat.getParentCategoryId();
            if (parentId == null) {
                roots.add(node);
            } else {
                CategoryNode parent = categoryMap.get(parentId);
                if (parent == null) {
                    log.warn("Parent category with id={} not found for category id={}", parentId, cat.getId());
                    lostRoots.add(node);
                } else {
                    parent.children.add(node);
                    node.parent = parent;
                }
            }
        }

        for (CategoryNode lostRoot : lostRoots) {
            Collection<Integer> childrenIds = getChildren(lostRoot.getId(), Collections.emptySet());
            for (Integer childId : childrenIds) {
                categoryMap.remove(childId);
                log.warn("Category id={} was removed because its ancestor={} has inactive root",
                        childId, lostRoot.getId());
            }
            categoryMap.remove(lostRoot.getId());
            log.warn("Category id={} was removed because it has inactive root", lostRoot.getId());
        }
    }

    private void removeCycles() {
        List<Integer> rootReachable = new ArrayList<>(categoryMap.size());
        for (CategoryNode root : roots) {
            rootReachable.add(root.getId());
            collectChildrenIds(root, Collections.emptySet(), rootReachable);
        }
        if (rootReachable.size() != categoryMap.size()) {
            Set<Integer> keysInCycles = new HashSet<>(categoryMap.keySet());
            rootReachable.forEach(keysInCycles::remove);
            log.error("Found cycle in category tree. Next categories compose one or several cycles {}", keysInCycles);
            for (Integer key : keysInCycles) {
                categoryMap.remove(key);
                log.warn("Category id={} was removed because it is located in cycle", key);
            }
        }
    }

    private static void collectChildrenIds(CategoryNode node, Collection<Integer> excluded, Collection<Integer> rootReachable) {
        for (CategoryNode child : node.children) {
            if (!excluded.contains(child.getId())) {
                rootReachable.add(child.getId());
                collectChildrenIds(child, excluded, rootReachable);
            }
        }
    }

}
