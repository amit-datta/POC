package com.macys.search.exception.bizrules.es;

import lombok.Getter;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;

import java.text.MessageFormat;

/**
 * Fail to create new index into Elastic search
 */
@Getter
public class ElasticSearchFailToCreateNewIndexException extends ElasticSearchIndexingException {

    public ElasticSearchFailToCreateNewIndexException(String indexName, String message, CreateIndexRequest request, CreateIndexResponse response) {
        super(indexName, message + requestAndResponseParams(request, response));
    }

    public ElasticSearchFailToCreateNewIndexException(String indexName, String message, CreateIndexRequest request, CreateIndexResponse response, Throwable cause) {
        super(indexName, message + requestAndResponseParams(request, response), cause);
    }

    private static String requestAndResponseParams(CreateIndexRequest request, CreateIndexResponse response) {
        return MessageFormat.format(" Request={0} Response={1}", request, response);
    }
}
