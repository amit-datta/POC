package com.macys.search.bizrules.tasklets.merch;

import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.services.merch.ActionsService;
import com.macys.search.bizrules.services.merch.RuleService;
import com.macys.search.bizrules.services.merch.TriggersService;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.elastic.ESIndex.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class MRFProcessingTasklet implements RulesPublisherTasklet {

    private final RuleService ruleService;
    private final ActionsService actionsService;
    private final TriggersService triggersService;

    private static final class IndexingContext {
        private int ruleNaturalId;
        private int triggerNaturalId;
        private final Map<Integer, Integer> triggerIdsMapping = new HashMap<>();
        private final Map<Integer, Integer> ruleIdsMapping = new HashMap<>();
        private final Set<Integer> processedActionIds = new HashSet<>();
    }

    public void execute(ProcessingContext ctx) {
        IndexingContext indexingCtx = new IndexingContext();
        for (Integer ruleId : ctx.getRules().keySet()) {
            if (ctx.isCurrentJobStopped()) {
                break;
            }
            ProcessingRule processingRule = ruleService.getProcessedRule(ruleId, ctx);
            if (processingRule.isValid()) {
                ctx.getStatistics().getRulesStatistics().incrementValidRules();
                indexRule(processingRule, ctx, indexingCtx);
            }
        }

        ElasticSearchIndexer actionsIndexer = ctx.getIndexers().get(ACTIONS);
        for (Integer actionId : indexingCtx.processedActionIds) {
            if (ctx.isCurrentJobStopped()) {
                break;
            }
            ProcessingAction processedAction = actionsService.getProcessedAction(actionId, ctx);
            processedAction.setNaturalRuleIds(
                    processedAction.getRuleIds().stream()
                            .map(indexingCtx.ruleIdsMapping::get)
                            .collect(Collectors.toList())
            );
            actionsIndexer.add(actionsService.generateESAction(processedAction, ctx));

            if (processedAction.getMerchActionType() == ActionType.ModifySearchResults) {
                ctx.getIndexedMsrAction().put(actionId, processedAction);
            }
        }
        flush(ctx, RULES, TRIGGERS, KWP_TRIGGERS, ACTIONS);

        ctx.setRuleNaturalIdsCounter(indexingCtx.ruleNaturalId);
        ctx.setTriggerNaturalIdsCounter(indexingCtx.triggerNaturalId);
    }

    private void flush(ProcessingContext ctx, ESIndex... indexNames) {
        for (ESIndex indexName : indexNames) {
            if (!ctx.getIndexers().get(indexName).flush()) {
                throw new RuntimeException("Exception occurred during " + indexName + " indexing. " +
                        "Check logs for additional information");
            }
        }
    }

    private void indexRule(ProcessingRule processingRule, ProcessingContext ctx, IndexingContext indexingCtx) {
        ElasticSearchIndexer triggersIndexer = ctx.getIndexers().get(TRIGGERS);
        ElasticSearchIndexer kwpTriggersIndexer = ctx.getIndexers().get(KWP_TRIGGERS);
        for (ProcessingTrigger processingTrigger : processingRule.getValidTriggers()) {
            if (ctx.isCurrentJobStopped()) {
                break;
            }
            AbstractTriggerParams params = triggersService.generateTriggerParams(processingTrigger, ctx);
            params.enrichProcessingRule(processingRule);
            if (!processingTrigger.isIndexed()) {
                if (params.hasPercolator()) {
                    for (ESTrigger esTrigger : params.generateTriggers()) {
                        esTrigger.setNaturalId(indexingCtx.triggerNaturalId);
                        kwpTriggersIndexer.add(esTrigger);
                    }
                } else {
                    for (ESTrigger esTrigger : params.generateTriggers()) {
                        esTrigger.setNaturalId(indexingCtx.triggerNaturalId);
                        triggersIndexer.add(esTrigger);
                    }
                }
                indexingCtx.triggerIdsMapping.put(processingTrigger.getId(), indexingCtx.triggerNaturalId++);
                processingTrigger.setIndexed(true);
            }
        }
        for (ProcessingAction action : processingRule.getActions()) {
            indexingCtx.processedActionIds.add(action.getId());
        }
        ElasticSearchIndexer ruleIndexer = ctx.getIndexers().get(RULES);
        processingRule.setNaturalId(indexingCtx.ruleNaturalId);
        processingRule.setNaturalTriggerIds(
                processingRule.getValidTriggers().stream()
                        .map(ProcessingTrigger::getId)
                        .map(indexingCtx.triggerIdsMapping::get)
                        .collect(Collectors.toList())
        );
        indexingCtx.ruleIdsMapping.put(processingRule.getRuleId(), indexingCtx.ruleNaturalId++);
        ruleIndexer.add(ruleService.generateESRule(processingRule));
        ctx.getStatistics().getRulesStatistics().incrementIndexedRules();
        ruleService.clear(processingRule.getRuleId(), ctx);
    }
}
