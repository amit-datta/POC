package com.macys.search.bizrules.converters.actions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.converters.ConverterUtils;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.Facet;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields.*;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;

/**
 * {@link ActionConverter} implementation for {@link ActionType#ModifySearchResults} type
 */
@Slf4j
@Component
class ModifySearchResultsConverter extends AbstractActionConverter {
    private static final ObjectMapper mapper = new ObjectMapper();
    private static final Pattern attributeGroupPattern = Pattern.compile("AttributesGroup[0-9]+");
    private static final String PREVIEW_FORMATTING = "%s (%s) = %s";

    private final Map<String, ESActionType> operationEsActionTypeMap = Map.of(
            MSR_BOOST, ESActionType.MSR_BOOST,
            MSR_ADD, ESActionType.MSR_ADD,
            MSR_REPLACE, ESActionType.MSR_REPLACE,
            MSR_REMOVE, ESActionType.MSR_REMOVE);

    @Override
    public ActionType applicableFor() {
        return ActionType.ModifySearchResults;
    }

    @Override
    void enrichWithTypeSpecificProperties(Action action, ESAction esAction, ProcessingContext context) {
        boolean isBoostByAttributesSet = setBoostByAttributes(action, esAction);
        if (!isBoostByAttributesSet) {
            setMSRActions(action, esAction);
        }
        setPreview(action, esAction, context);
    }

    private void setMSRActions(Action action, ESAction esAction) {
        String value = ConverterUtils.getUnaryValue(action, MSR_OPERATIONS, MSR_OPERATION);
        esAction.setFieldValue(ACTION_TYPE, operationEsActionTypeMap.get(value));
    }

    private boolean setBoostByAttributes(Action action, ESAction esAction) {
        final Set<MsrBavAttribute> attributesData = new LinkedHashSet<>();
        for (Map.Entry<String, Criteria> configEntry : action.getCriteriaMap().entrySet()) {
            if (configEntry.getKey().startsWith(MSR_ATTRIBUTES_GROUP)) {
                Criteria criteria = configEntry.getValue();
                Integer priority = criteria.getSequenceGroupNumber();
                MsrBavAttribute msrBavAttribute = new MsrBavAttribute(priority, criteria.getCriteriaAttributes());
                attributesData.add(msrBavAttribute);
            }
        }
        if (!attributesData.isEmpty()) {
            esAction.setFieldValue(ACTION_TYPE, ESActionType.MSR_BOOST_BY_ATTRIBUTE);
            try {
                esAction.setFieldValue(MSR_BOOST_BY_ATTRIBUTES, mapper.writeValueAsString(attributesData));
            } catch (JsonProcessingException e) {
                log.error("Could not convert action with id=" + action.getId(), e);
            }
            return true;
        }
        return false;
    }

    private void setPreview(Action action, ESAction esAction, ProcessingContext context) {
        Criteria poolCriteria = action.getCriteria(MSR_POOL);
        Criteria productCriteria = action.getCriteria(MSR_PRODUCT);
        List<String> resultValuesForPreview = new ArrayList<>();
        resultValuesForPreview.add(ConverterUtils.getUnaryValue(action, MSR_OPERATIONS, MSR_OPERATION));
        if (productCriteria != null || poolCriteria != null) {
            if (productCriteria != null) {
                String productIdsInNaturalOrder = String.join(", ", getCollectionInNaturalOrder(productCriteria, MSR_PRODUCT_ID));
                resultValuesForPreview.add(String.format("Prod ID = %s", productIdsInNaturalOrder));
            }
            if (poolCriteria != null) {
                String poolIdsInNaturalOrder = String.join(", ", getCollectionInNaturalOrder(poolCriteria, MSR_POOL_ID));
                resultValuesForPreview.add(String.format("Saved Set / Query ID = %s", poolIdsInNaturalOrder));
            }
        } else {
            final Set<Criteria> criteria = action.getCriteriaMap()
                    .keySet()
                    .stream()
                    .filter(group -> attributeGroupPattern.matcher(group).matches())
                    .map(action::getCriteria)
                    .collect(Collectors.toSet());
            for (Integer sequenceNumber : criteria.stream().map(Criteria::getSequenceGroupNumber)
                    .filter(Objects::nonNull)
                    .sorted()
                    .collect(Collectors.toList())) {
                resultValuesForPreview.add(String.format("Sequence %d:", sequenceNumber));
                final Map<String, List<String>> criteriaAttributes = getCriteriaAttrSortedByName(sequenceNumber, criteria);
                for (Map.Entry<String, List<String>> entry : criteriaAttributes.entrySet()) {
                    String attrName = entry.getKey();
                    List<String> sortedAttrValues = entry.getValue().stream().filter(Objects::nonNull).sorted().collect(Collectors.toList());
                    Facet facet = context.getFacets().get(attrName);
                    if (facet != null) {
                        String facetDisplayName = facet.getFacetDisplayName() == null ? "" : facet.getFacetDisplayName();
                        String preview = String.format(PREVIEW_FORMATTING, attrName, facetDisplayName, String.join(", ", sortedAttrValues));
                        resultValuesForPreview.add(preview);
                    }
                }
            }
        }
        esAction.setFieldValue(MSR_PREVIEW, resultValuesForPreview);
    }

    private List<String> getCollectionInNaturalOrder(Criteria criteria, String attributeName) {
        List<String> values = criteria.getCriteriaAttributes().get(attributeName);
        values.sort(Comparator.comparing(Integer::valueOf));
        return values;
    }

    private Map<String, List<String>> getCriteriaAttrSortedByName(Integer seqNum, final Set<Criteria> criteria) {
        Map<String, List<String>> result = new TreeMap<>();
        for (Criteria c : criteria) {
            if (seqNum.equals(c.getSequenceGroupNumber())) {
                result.putAll(c.getCriteriaAttributes());
            }
        }
        return result;
    }

}
