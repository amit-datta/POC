package com.macys.search.bizrules.converters.products.filters;


import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.product.Product;

public interface CategoryFilter {

    /**
     * @param category category
     * @param product  product
     * @return true if category passed filter for product, otherwise - false
     */
    boolean pass(Category category, Product product);

    /**
     * @return true if filter rely only on product fields, false if rely on members fields
     */
    boolean isSelfBased();

}
