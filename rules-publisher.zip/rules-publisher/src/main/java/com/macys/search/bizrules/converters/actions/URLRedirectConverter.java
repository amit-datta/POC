package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.converters.ConverterUtils;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;

/**
 * {@link ActionConverter} implementation for {@link ActionType#URLRedirect} type
 */
@Slf4j
@Component
class URLRedirectConverter extends AbstractActionConverter {
    @Override
    public ActionType applicableFor() {
        return ActionType.URLRedirect;
    }

    @Override
    void enrichWithTypeSpecificProperties(Action action, ESAction doc, ProcessingContext context) {
        doc.setFieldValue(ActionsIndexFields.ACTION_TYPE, ESActionType.URL_REDIRECT);
        Criteria config = action.getCriteria(URL_REDIRECT);
        doc.setFieldValue(ActionsIndexFields.URL_REDIRECT_TYPE, ConverterUtils.getUnaryValue(config, URL_REDIRECT_TYPE));
        doc.setFieldValue(ActionsIndexFields.URL_REDIRECT_VALUE, ConverterUtils.getUnaryValue(config, URL_REDIRECT_VALUE));
    }
}
