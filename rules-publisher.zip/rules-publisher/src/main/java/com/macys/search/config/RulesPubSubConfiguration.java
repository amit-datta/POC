package com.macys.search.config;

import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.macys.search.handler.PubSubMessageEventsHandler;
import com.macys.search.handler.PubSubMessageEventsIndexerHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.cloud.gcp.pubsub.integration.AckMode;
import org.springframework.cloud.gcp.pubsub.integration.inbound.PubSubInboundChannelAdapter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;

import javax.annotation.Resource;

@Slf4j
@Configuration
@ConditionalOnProperty(
        value = {
                "spring.cloud.gcp.pubsub.enabled",
                "rules.publisher.load.rules.from.pubsub"
        },
        havingValue = "true"
)
public class RulesPubSubConfiguration {
    @Value("${pubsub.rules.subscriber.name}")
    private String rulesEventsSubscriber;

    @Value("${spring.projectId}")
    private String projectId;

    @Value("${rules.publisher.pubsub.notifications.subscriber.name}")
    private String rulesEventsIndexerSubscriber;

    @Resource
    private PubSubMessageEventsHandler pubSubMessageEventsHandler;

    @Resource
    private PubSubMessageEventsIndexerHandler pubSubMessageEventsIndexerHandler;

    @Bean
    public PubSubInboundChannelAdapter redisEventsInputChannelAdapter(
            @Qualifier("rulesEventsInputChannel") MessageChannel inputChannel,
            PubSubTemplate pubSubTemplate) {
        PubSubInboundChannelAdapter adapter = new PubSubInboundChannelAdapter(pubSubTemplate, rulesEventsSubscriber);
        adapter.setOutputChannel(inputChannel);
        adapter.setAckMode(AckMode.MANUAL);
        return adapter;
    }

    @Bean
    public MessageChannel rulesEventsInputChannel() {
        return new DirectChannel();
    }

    @Bean
    @ServiceActivator(inputChannel = "rulesEventsInputChannel")
    public MessageHandler redisEventsMessageReceiver() {
        return pubSubMessageEventsHandler.handleMessage();
    }

    @Bean
    public PubSubInboundChannelAdapter rulesEventsIndexerInputChannelAdapter(
            @Qualifier("rulesEventsIndexerInputChannel") MessageChannel inputChannel,
            PubSubTemplate pubSubTemplate) {
        PubSubInboundChannelAdapter adapter = new PubSubInboundChannelAdapter(pubSubTemplate, rulesEventsIndexerSubscriber);
        adapter.setOutputChannel(inputChannel);
        return adapter;
    }

    @Bean
    public MessageChannel rulesEventsIndexerInputChannel() {
        return new DirectChannel();
    }

    @Bean
    @ServiceActivator(inputChannel = "rulesEventsIndexerInputChannel")
    public MessageHandler rulesEventsIndexerMessageReceiver() {
        return pubSubMessageEventsIndexerHandler.handleMessage();
    }

    @Bean
    public Storage getStorageObject() {
        return StorageOptions.newBuilder().setProjectId(projectId).build().getService();
    }

}
