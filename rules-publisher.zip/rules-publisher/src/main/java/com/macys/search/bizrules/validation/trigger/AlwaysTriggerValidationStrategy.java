package com.macys.search.bizrules.validation.trigger;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Always trigger valid for every always trigger
 */
@Slf4j
@Component
public class AlwaysTriggerValidationStrategy implements TriggerValidationStrategy {

    @Override
    public TriggerType applicableFor() {
        return TriggerType.Always;
    }

    @Override
    public ValidationResult validate(Trigger trigger, ProcessingContext context) {
        return ValidationResult.validResult();
    }
}
