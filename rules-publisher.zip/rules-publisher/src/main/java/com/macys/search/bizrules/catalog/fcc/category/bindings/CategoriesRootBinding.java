package com.macys.search.bizrules.catalog.fcc.category.bindings;

import lombok.Data;

@Data
public class CategoriesRootBinding {
    private CategoriesBinding categories;
}
