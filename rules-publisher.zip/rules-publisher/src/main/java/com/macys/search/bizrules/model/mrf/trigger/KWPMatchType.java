package com.macys.search.bizrules.model.mrf.trigger;

/**
 * Match type for keyword trigger.
 * <ul>
 *     <li>Exact - exact match phrase to field value</li>
 *     <li>Contains - search phrase has prefix or suffix or matches exact to field value</li>
 *     <li>Literal - tokenized field value contains in search phrase in any order</li>
 * </ul>
 */
public enum KWPMatchType {
    Exact,
    Contains,
    Literal
}
