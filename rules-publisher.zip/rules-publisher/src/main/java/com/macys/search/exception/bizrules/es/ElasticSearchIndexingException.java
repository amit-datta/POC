package com.macys.search.exception.bizrules.es;

import lombok.Getter;

import java.text.MessageFormat;

/**
 * Elastic search indexing exception
 */
public class ElasticSearchIndexingException extends RuntimeException {

    @Getter
    private final String indexName;

    public ElasticSearchIndexingException(String indexName, String message) {
        super(messageWithIndexName(indexName, message));
        this.indexName = indexName;
    }

    public ElasticSearchIndexingException(String indexName, String message, Throwable cause) {
        super(messageWithIndexName(indexName, message), cause);
        this.indexName = indexName;
    }

    private static String messageWithIndexName(String indexName, String message) {
        return MessageFormat.format("IndexName={0}. {1}", indexName, message);
    }
}
