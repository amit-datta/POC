package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.converters.ConverterUtils;
import com.macys.search.bizrules.converters.actions.ActionConverterService;
import com.macys.search.bizrules.converters.actions.ContextParametersConverter;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.DateAwareAttribute;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionParameter;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.statistics.ActionsStatistics;
import com.macys.search.bizrules.validation.ActionValidationService;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.MSR_ADD;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.MSR_BOOST;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.MSR_REMOVE;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.MSR_REPLACE;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;
import static com.macys.search.bizrules.model.mrf.action.ESActionType.CATEGORY_REDIRECT;
import static com.macys.search.bizrules.model.mrf.action.ESActionType.URL_REDIRECT;
import static com.macys.search.bizrules.model.mrf.action.ESActionType.*;
import static com.macys.search.bizrules.validation.LoggingHelper.logActionValidationFailed;

/**
 * Service to work with action from database. Contains methods to parse attributes and fill criteriaMap.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ActionsService {
    private static final Map<String, ESActionType> operationEsActionTypeMap = Map.of(
            MSR_BOOST, ESActionType.MSR_BOOST,
            MSR_ADD, ESActionType.MSR_ADD,
            MSR_REPLACE, ESActionType.MSR_REPLACE,
            MSR_REMOVE, ESActionType.MSR_REMOVE
    );

    public static final Integer NON_UNIQUE_SEQ_NBR = null;

    private final ActionValidationService actionValidationService;
    private final ActionConverterService actionConverterService;
    private final ContextParametersConverter contextParametersConverter;

    private static ProcessingAction setActionAsFailed(ProcessingAction processingAction) {
        logActionValidationFailed(log, processingAction.getAction(), processingAction.getValidationResult().getWarning());
        processingAction.setProcessed(true);
        return processingAction;
    }

    private static ValidationResult validateRequiredActionFields(Action action) {
        if (action.getMerchActionType() == null) {
            return ValidationResult.failResult(String.format("Action with id=%d doesn't have action type",
                    action.getId()));
        }
        return ValidationResult.validResult();
    }

    public static ValidationResult parseAttributes(Action action) {
        if (action.getParams() == null) {
            return ValidationResult.failResult("Action with id=" + action.getId() + " doesn't contain params");
        }
        action.getParams().forEach(parameter -> {
                    if ("Context".equals(parameter.getGroup())) {
                        addContextAttribute(action, parameter);
                    } else {
                        addRegularCriteriaAttribute(action, parameter);
                    }
                }
        );
        action.setParams(null);
        return ValidationResult.validResult();
    }

    public ProcessingAction getProcessedAction(Integer id, ProcessingContext ctx) {
        ProcessingAction processingAction = ctx.getActions().get(id);
        if (processingAction == null || processingAction.isProcessed()) {
            return processingAction;
        }
        Action action = processingAction.getAction();

        ActionsStatistics actionsStatistics = ctx.getStatistics().getActionsStatistics();

        processingAction.setValidationResult(validateRequiredActionFields(action));
        if (!processingAction.isValid()) {
            actionsStatistics.incrementInvalidActions();
            return setActionAsFailed(processingAction);
        }

        processingAction.setValidationResult(parseAttributes(action));
        if (!processingAction.isValid()) {
            actionsStatistics.incrementInvalidActions();
            return setActionAsFailed(processingAction);
        }

        processingAction.setValidationResult(actionValidationService.validate(action, ctx));
        if (!processingAction.isValid()) {
            actionsStatistics.incrementInvalidActions();
            return setActionAsFailed(processingAction);
        }

        processingAction.setEsActionType(getESActionType(action));

        processingAction.setProcessed(true);
        return processingAction;
    }

    public ESAction generateESAction(ProcessingAction processingAction, ProcessingContext ctx) {
        if (processingAction == null || !processingAction.isProcessed()) {
            throw new IllegalArgumentException("Could not generate elastic document for actionId="
                    + processingAction.getId());
        }
        Action action = processingAction.getAction();
        ESAction esAction = actionConverterService.convert(action, ctx);
        contextParametersConverter.convert(action, esAction);
        esAction.setFieldValue(ActionsIndexFields.ACTION_NATURAL_RULE_IDS, processingAction.getNaturalRuleIds());
        esAction.setDisabledReasons(processingAction.getDisabledReasons());

        return esAction;
    }

    private static ESActionType getESActionType(Action action) {
        switch (action.getMerchActionType()) {
            case ShowMedia:
                return SHOW_MEDIA;
            case SeoControl:
                return SEO_CONTROL;
            case CategoryRedirect:
                return CATEGORY_REDIRECT;
            case SeoMetaData:
                return SEO_META_DATA;
            case URLRedirect:
                return URL_REDIRECT;
            case ProductRedirect:
                return PRODUCT_REDIRECT;
            case SpecialInstruction:
                return SPECIAL_INSTRUCTION;
            case ModifySearchResults: {
                String value = ConverterUtils.getUnaryValue(action, MSR_OPERATIONS, MSR_OPERATION);
                return operationEsActionTypeMap.get(value);
            }
            default:
                throw new AssertionError(action.getMerchActionType() + " is not supported");
        }
    }

    private static void addContextAttribute(Action action, ActionParameter parameter) {
        Collection<String> values = action.getContextAttributes().computeIfAbsent(parameter.getName(), key -> new HashSet<>());
        values.add(parameter.getValue());
    }

    private static void addRegularCriteriaAttribute(Action action, ActionParameter parameter) {
        Map<String, Criteria> criteriaMap = action.getCriteriaMap();
        Criteria criteria = criteriaMap.computeIfAbsent(parameter.getGroup(), key -> {
            Criteria cr = new Criteria();
            cr.setCriteriaName(parameter.getGroup());
            cr.setSequenceGroupNumber(parameter.getGroupSequenceNumber());
            return cr;
        });

        addActionParameter(criteria, parameter);

        if (!Objects.equals(parameter.getGroupSequenceNumber(), criteria.getSequenceGroupNumber())) {
            log.warn("Criteria sequence number is already set and it's not equal a new value for action " + action);
            action.setNonEqualSeqNumberInSomeCriteria(true);
            criteria.setSequenceGroupNumber(NON_UNIQUE_SEQ_NBR);
        }
    }

    private static void addActionParameter(Criteria criteria, ActionParameter param) {
        String name = param.getName();

        criteria.getCriteriaAttributes().computeIfAbsent(name, key -> new ArrayList<>())
                .add(param.getValue());
        criteria.getAttributeToSeqNumbersMap().computeIfAbsent(name, key -> new ArrayList<>())
                .add(param.getSequenceNumber());
        criteria.getCriteriaDateAwareAttributes()
                .computeIfAbsent(name, key -> new ArrayList<>())
                .add(new DateAwareAttribute(param.getValue(), param.getEffectiveDate(), param.getExpirationDate()));
    }
}
