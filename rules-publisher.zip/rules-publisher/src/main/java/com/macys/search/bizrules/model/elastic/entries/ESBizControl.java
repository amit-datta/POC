package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.model.elastic.ESBizControlType;
import com.macys.search.bizrules.model.elastic.mappings.BizControlIndexFields;

import java.util.Objects;

public class ESBizControl extends AbstractESEntry<BizControlIndexFields> {

    public static ESBizControl of(ESBizControlType type, String value) {
        ESBizControl result = new ESBizControl();
        result.setFieldValue(BizControlIndexFields.TYPE, type.getName());
        result.setFieldValue(BizControlIndexFields.VALUE, Objects.requireNonNull(value));
        return result;
    }

}
