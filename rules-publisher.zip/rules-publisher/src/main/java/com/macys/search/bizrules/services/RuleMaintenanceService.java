package com.macys.search.bizrules.services;

import com.google.gson.Gson;
import com.macys.search.bizrules.dto.GetJobStatusResponse;
import com.macys.search.bizrules.dto.IndexingMessage;
import com.macys.search.bizrules.dto.IndexingStatusResponse;
import com.macys.search.bizrules.dto.PubSubTriggerResponse;
import com.macys.search.bizrules.enums.PubSubProcessType;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.batch.BatchJobExecutionParams;
import com.macys.search.bizrules.repository.batch.BatchRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.*;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.enums.PubSubProcessType.START_INDEXING;
import static com.macys.search.bizrules.enums.PubSubProcessType.STOP_SESSION;
import static com.macys.search.bizrules.tasklets.JobParams.*;

@Slf4j
@RequiredArgsConstructor
@Service
public class RuleMaintenanceService {

    private final JobLauncher asyncJobLauncher;
    private final Job ruleFullReindex;
    private final JobExplorer jobExplorer;
    private final JobRepository jobRepository;
    private final JobOperator jobOperator;
    private final BatchRepository batchRepository;
    private final RulesPubSubIndexingPublisher rulesIndexerService;
    private final Gson gson;
    @Value("${rules.publisher.pubsub.notifications.topic.name}")
    private String rulePublisherMsgTopic;
    @Value("${rules.publisher.cloud.region}")
    private String cloudRegion;
    @Value("${rules.publisher.rules.terminate.killed.jobs.on.startup}")
    private boolean terminateKilledJobsKillSwitch;
    private final StoppedJobsCache stoppedJobsCache;


    public JobExecution startIndexing(SiteName siteName, String customDate) {
        return startIndexingWithId(siteName, UUID.randomUUID().toString(), customDate);
    }

    public JobExecution startIndexingWithId(SiteName siteName, String id, String customDate) {
        try {
            log.info("Try to start new full reindexing job through pubsub");
            Instant timeParam = Instant.now();
            JobParameters jobParameters = new JobParametersBuilder()
                    .addLong(START_TIME_JOB_PARAM, timeParam.toEpochMilli())
                    .addString(SITE_NAME_JOB_PARAM, siteName.name())
                    .addString(CUSTOM_DATE_JOB_PARAM, customDate)
                    .addString(INDEXING_SESSION_ID, id)
                    .addString(CLOUD_REGION, cloudRegion)
                    .toJobParameters();
            JobExecution jobExecution = asyncJobLauncher.run(ruleFullReindex, jobParameters);
            log.info("full reindexing job started successfully through pubsub");
            return jobExecution;
        } catch (JobExecutionAlreadyRunningException
                | JobRestartException
                | JobInstanceAlreadyCompleteException
                | JobParametersInvalidException e) {
            log.error("Full reindexing job failed to start.", e);
            throw new RuntimeException(e);
        }
    }

    @EventListener({ContextRefreshedEvent.class})
    public void abandonStuckJobs() {
        if (!terminateKilledJobsKillSwitch) return;
        Set<JobExecution> stuckJobs = jobExplorer.findRunningJobExecutions(ruleFullReindex.getName()).stream()
                .filter(job -> Objects.equals(cloudRegion, job.getJobParameters().getString(CLOUD_REGION)))
                .collect(Collectors.toSet());
        stuckJobs.forEach(job -> {
            job.getStepExecutions().forEach(step -> {
                if (step.getStatus().isRunning()) {
                    step.setStatus(BatchStatus.ABANDONED);
                    step.setExitStatus(ExitStatus.STOPPED);
                    step.setEndTime(new Date());
                    jobRepository.update(step);
                }
            });
            job.setStatus(BatchStatus.ABANDONED);
            job.setExitStatus(ExitStatus.STOPPED);
            job.setEndTime(new Date());
            jobRepository.update(job);
        });
        if (!stuckJobs.isEmpty()) {
            log.info("Stuck jobs were abandoned: size={}", stuckJobs.size());
        }
    }

    public JobExecution getJobStatus(long executionId) {
        return jobExplorer.getJobExecution(executionId);
    }

    public IndexingStatusResponse getJobStatusBySessionId(String sessionId) {
        IndexingStatusResponse indexingStatusResponse = new IndexingStatusResponse();
        List<GetJobStatusResponse> executions = new ArrayList<>();
        List<BatchJobExecutionParams> batchJobExecutionParamsList =
                batchRepository.getBatchJobExecutionParamsBySessionId(sessionId);

        List<JobExecution> jobExecutionList = new ArrayList<>(3);
        List<String> overallStatus = new ArrayList<>();
        for (BatchJobExecutionParams jobParams : batchJobExecutionParamsList) {
            jobExecutionList.add(jobExplorer.getJobExecution(jobParams.getJobExecutionId()));
        }
        for (JobExecution jobExecution : jobExecutionList) {
            indexingStatusResponse.setEndTime(jobExecution.getEndTime());
            indexingStatusResponse.setStartTime(jobExecution.getStartTime().toString());
            executions.add(GetJobStatusResponse.of(jobExecution));
            overallStatus.add(jobExecution.getStatus().toString());
        }
        indexingStatusResponse.setOverallStatus(getOverallStatus(overallStatus));
        indexingStatusResponse.setExecutions(executions);
        return indexingStatusResponse;
    }

    public List<GetJobStatusResponse> getAllJobsForLastNDays(Integer lastDaysCount) {
        if (Objects.isNull(lastDaysCount)) {
            return Collections.emptyList();
        }
        LocalDate from = LocalDate.now().minusDays(lastDaysCount);
        List<Long> ids = batchRepository.getBatchJobIdsStartingFromDate(from);
        return ids.stream().map(jobExplorer::getJobExecution)
                .filter(Objects::nonNull)
                .map(GetJobStatusResponse::of)
                .collect(Collectors.toList());
    }


    private String getOverallStatus(List<String> overallStatus) {

        if (overallStatus.contains(BatchStatus.FAILED.name())) {
            return BatchStatus.FAILED.name();
        }
        if (overallStatus.contains(BatchStatus.STARTING.name())) {
            return BatchStatus.STARTING.name();
        }
        if (overallStatus.contains(BatchStatus.STARTED.name())) {
            return BatchStatus.STARTED.name();
        }
        if (overallStatus.stream().distinct().count() == 1 && overallStatus.contains(BatchStatus.COMPLETED.name())) {
            return BatchStatus.COMPLETED.name();
        }
        return BatchStatus.UNKNOWN.name();
    }

    public PubSubTriggerResponse publishMessage(SiteName siteName, String sessionId, PubSubProcessType processType) {
        PubSubTriggerResponse pubSubTriggerResponse = new PubSubTriggerResponse();
        IndexingMessage indexingMessage = new IndexingMessage();
        Timestamp startedTime = new Timestamp(System.currentTimeMillis());
        try {
            indexingMessage.setSiteName(String.valueOf(siteName));
            indexingMessage.setSessionId(sessionId);
            indexingMessage.setProcessType(processType);

            String indexingMessagePayload = gson.toJson(indexingMessage);
            rulesIndexerService.publishMessage(indexingMessagePayload);
            log.info("Message sent to the topic to trigger {} proccess - {} and the message is {}",
                    processType.toString().toLowerCase(), rulePublisherMsgTopic, indexingMessagePayload);
            getPubSubTriggerResponse(pubSubTriggerResponse, sessionId, startedTime);
        } catch (Exception e) {
            log.error("Error Publishing message for uUID " + sessionId, e);
            getPubSubTriggerResponse(pubSubTriggerResponse, sessionId, startedTime);
        }
        return pubSubTriggerResponse;
    }

    private void getPubSubTriggerResponse(PubSubTriggerResponse pubSubTriggerResponse, String uUID, Timestamp startedTime) {
        pubSubTriggerResponse.setStartTime(startedTime.toString());
        pubSubTriggerResponse.setSessionId(uUID);
    }

    public ResponseEntity<String> stopJob(Long executionId) throws NoSuchJobExecutionException,
            JobExecutionNotRunningException, NoSuchJobException {
        JobExecution job = jobExplorer.getJobExecution(executionId);
        if (job == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        if (!job.getStatus().isRunning()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Job with id = " + job.getJobId() + " is not running.");
        }
        log.info("Stopping spring job with id = {} .....", executionId);
        stoppedJobsCache.add(executionId);
        jobOperator.stop(executionId);

        BatchStatus exitStatus = job.getStatus();
        while (exitStatus != BatchStatus.STOPPED) {
            try {
                TimeUnit.MILLISECONDS.sleep(2000);
                JobExecution execution = jobExplorer.getJobExecution(executionId);
                if (execution == null) break;
                exitStatus = execution.getStatus();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            }
        }
        stoppedJobsCache.remove(executionId);
        String stopMessage = "Job was stopped externally by stopJob rest endpoint.";
        job.setExitStatus(ExitStatus.STOPPED.addExitDescription(stopMessage));
        jobRepository.update(job);
        long secondsBetween = (Instant.now().toEpochMilli() - job.getStartTime().getTime()) / 1000;
        log.info("Time passed to stop the job = {} seconds ", secondsBetween);
        String message = "Spring batch job was stopped in " + secondsBetween + " seconds.";
        return ResponseEntity.status(HttpStatus.OK).body(message);
    }

    public void handlePubSubMessage(IndexingMessage indexingMessage, String payloadJson) {
        if (START_INDEXING.equals(indexingMessage.getProcessType())) {
            log.info("Message received for indexing {}", payloadJson);
            startIndexingWithId(SiteName.valueOf(indexingMessage.getSiteName()),
                    indexingMessage.getSessionId(), null);
        } else if (STOP_SESSION.equals(indexingMessage.getProcessType())) {
            log.info("Message received for stopping session {}", payloadJson);
            String sessionId = indexingMessage.getSessionId();
            List<BatchJobExecutionParams> batchJobExecutionParamsList =
                    batchRepository.getBatchJobExecutionParamsBySessionId(sessionId);
            List<Long> jobExecutionIds = batchJobExecutionParamsList.stream()
                    .map(BatchJobExecutionParams::getJobExecutionId)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(jobExecutionIds)) {
                for (Long jobExecutionId : jobExecutionIds) {
                    try {
                        log.info("Trying to stop spring job using pub sub, for session id = {} , job id = {} .....", sessionId, jobExecutionId);
                        ResponseEntity<String> response = stopJob(jobExecutionId);
                        if (response.getStatusCode().equals(HttpStatus.OK)) {
                            log.info("Spring job for session id = {} was stopped.", sessionId);
                        } else if (response.hasBody()) {
                            log.warn(response.getBody());
                        } else {
                            log.warn(response.getStatusCode().toString());
                        }
                    } catch (NoSuchJobExecutionException
                            | JobExecutionNotRunningException
                            | NoSuchJobException e) {
                        log.error("Failed to stop spring batch job with id = " + jobExecutionId, e);
                    }
                }
            }
        }
    }
}
