package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.model.elastic.entries.ESRule;
import com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.services.MerchPermissionsCheckerService;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.statistics.RulesStatistics;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.springframework.util.CollectionUtils.isEmpty;

@Slf4j
@Component
public class RuleService {

    private final MerchPermissionsCheckerService merchPermissionsCheckerService;

    private final int longRunningRulesDuration;
    private final int effectiveDateShiftThreshold;
    private final int expirationDateShiftThreshold;
    private final Set<String> longRulesUsernamesWhitelist;

    private final ActionsService actionService;
    private final TriggerExpressionValidationService expressionService;
    private final RuleConverterService ruleConverterService;

    public RuleService(MerchPermissionsCheckerService merchPermissionsCheckerService,
                       @Value("${rules.publisher.long.running.rules.days.count}") int longRunningRulesDuration,
                       @Value("${rules.publisher.long.running.rules.usernames.whitelist}") Set<String> longRulesUsernamesWhitelist,
                       @Value("${rules.publisher.rules.validation.effective-date.shift.days.threshold}") int effectiveDateShiftThreshold,
                       @Value("${rules.publisher.rules.validation.expiration-date.shift.days.threshold}") int expirationDateShiftThreshold,
                       ActionsService actionService,
                       TriggerExpressionValidationService expressionService,
                       RuleConverterService ruleConverterService) {
        this.merchPermissionsCheckerService = merchPermissionsCheckerService;
        this.longRunningRulesDuration = longRunningRulesDuration;
        this.longRulesUsernamesWhitelist = longRulesUsernamesWhitelist.stream().map(String::toLowerCase).collect(Collectors.toSet());
        this.effectiveDateShiftThreshold = effectiveDateShiftThreshold;
        this.expirationDateShiftThreshold = expirationDateShiftThreshold;
        this.actionService = actionService;
        this.expressionService = expressionService;
        this.ruleConverterService = ruleConverterService;
    }

    public static ValidationResult validateRequiredRuleFields(Rule rule) {
        if (rule == null) {
            return ValidationResult.failResult("Rule must be not null");
        }
        if (rule.getId() == null) {
            return ValidationResult.failResult("Rule id must be not null");
        }
        if (rule.getActionsIds() == null) {
            return ValidationResult.failResult("Actions mapping must be not null");
        }
        if (rule.getLastModifiedByName() == null) {
            return ValidationResult.failResult("Last Modified by name must be not null");
        }
        return ValidationResult.validResult();
    }

    private static boolean isExtendedPermissionsRequired(Collection<ProcessingAction> actions) {
        return actions.stream()
                .map(ProcessingAction::getMerchActionType)
                .anyMatch(ActionType::isExtendedPermissionsRequired);
    }

    private ValidationResult validate(ProcessingRule processingRule, ProcessingContext ctx, List<ProcessingTrigger> validTriggers) {
        ValidationResult checkEffectivePeriodForRuleResult = validateEffectivePeriodForRule(processingRule.getRule(), ctx);
        if (!checkEffectivePeriodForRuleResult.isValid()) {
            return checkEffectivePeriodForRuleResult;
        }
        ValidationResult collectAndCheckActionsResult = collectAndCheckActions(processingRule, ctx);
        if (!collectAndCheckActionsResult.isValid()) {
            ctx.getStatistics().getActionsStatistics().incrementInvalidActions();
            return collectAndCheckActionsResult;
        }
        ValidationResult collectAndCheckTriggersResult = expressionService.validate(processingRule, ctx, validTriggers);
        if (!collectAndCheckTriggersResult.isValid()) {
            ctx.getStatistics().getTriggersStatistics().incrementInvalidTriggers();
            return collectAndCheckTriggersResult;
        }

        return ValidationResult.validResult();
    }

    private ValidationResult validateEffectivePeriodForRule(Rule rule, final ProcessingContext ctx) {
        final LocalDate customDate = ctx.getCustomDate();
        LocalDate expirationDate = rule.getExpirationDate();
        if (expirationDate == null) {
            return ValidationResult.failResult(
                    String.format("Rule id=%d invalid because of expirationDate parameter is null", rule.getId()));
        }
        LocalDate effectiveDate = rule.getEffectiveDate();
        if (effectiveDate == null) {
            return ValidationResult.failResult(String.format(
                    "Rule id=%d invalid because of effectiveDate parameter is null", rule.getId()));
        }
        long days = Duration.between(effectiveDate.atStartOfDay(), expirationDate.atStartOfDay()).toDays();
        if (days < 0) {
            return ValidationResult.failResult(String.format(
                    "Rule id=%d has wrong parameters. ExpirationDate=%s before effectiveDate=%s", rule.getId(),
                    expirationDate, effectiveDate));
        }
        if (expirationDateShiftThreshold >= 0
                && expirationDate.isBefore(customDate.minusDays(expirationDateShiftThreshold))) {
            return ValidationResult.failResult(String.format(
                    "Rule id=%d has already expired. ExpirationDate=%s CustomDate=%s ExpirationDateShiftThreshold=%d",
                    rule.getId(), expirationDate, customDate, expirationDateShiftThreshold));
        }
        if (effectiveDateShiftThreshold >= 0
                && effectiveDate.isAfter(customDate.plusDays(effectiveDateShiftThreshold))) {
            return ValidationResult.failResult(String.format("Rule id=%d is out of allowed range for effective date."
                            + " ExpirationDate=%s CustomDate=%s EffectiveDateShiftThreshold=%d",
                    rule.getId(), expirationDate, customDate, effectiveDateShiftThreshold));
        }
        return ValidationResult.validResult();
    }

    private ValidationResult collectAndCheckActions(ProcessingRule processingRule, ProcessingContext ctx) {
        Rule rule = processingRule.getRule();
        List<ProcessingAction> actions = new ArrayList<>();
        for (Integer actionId : rule.getActionsIds()) {
            ProcessingAction processingAction = actionService.getProcessedAction(actionId, ctx);
            if (processingAction != null && processingAction.isValid()) {
                ctx.getStatistics().getActionsStatistics().incrementValidActions();
                boolean enabled = true;
                if (!merchPermissionsCheckerService.redirectRulesValidation(rule.getId(), processingAction.getMerchActionType())) {
                    processingAction.addDisabledReason(rule.getId(),
                            String.format("Rule with id=%d is missing in whitelist for redirect action with id=%d",
                                    rule.getId(), processingAction.getId()));
                    enabled = false;
                }
                if (!merchPermissionsCheckerService.checkExtendedPermission(rule, processingAction)) {
                    processingAction.addDisabledReason(rule.getId(),
                            String.format("Rule with id=%d and last modified by user=%s " +
                                    "does not have required permissions", rule.getId(), rule.getLastModifiedByName()));
                    enabled = false;
                }
                if (enabled) {
                    actions.add(processingAction);
                    processingAction.addRuleId(rule.getId());
                }
            }
        }
        processingRule.setActions(actions);
        if (actions.isEmpty()) {
            return ValidationResult.failResult(String.format("Rule with id=%d invalid due empty valid action list",
                    rule.getId()));
        }
        return ValidationResult.validResult();
    }

    public ProcessingRule getProcessedRule(Integer id, ProcessingContext ctx) {
        ProcessingRule processingRule = ctx.getRules().get(id);
        if (processingRule == null || processingRule.isProcessed()) {
            return processingRule;
        }
        RulesStatistics rulesStatistics = ctx.getStatistics().getRulesStatistics();
        Rule rule = processingRule.getRule();

        processingRule.setValidationResult(validateRequiredRuleFields(rule));
        if (!processingRule.isValid()) {
            rulesStatistics.incrementInvalidRules();
            processingRule.setProcessed(true);
            return processingRule;
        }
        List<ProcessingTrigger> validTriggers = new ArrayList<>();
        processingRule.setValidationResult(validate(processingRule, ctx, validTriggers));
        if (!processingRule.isValid()) {
            rulesStatistics.incrementInvalidRules();
            processingRule.setProcessed(true);
            return processingRule;
        }
        processingRule.setValidTriggers(validTriggers);
        adjustExpirationDate(processingRule);
        processingRule.setProcessed(true);
        return processingRule;
    }

    public ESRule generateESRule(ProcessingRule processingRule) {
        ESRule esRule = ruleConverterService.convert(processingRule);
        esRule.setFieldValue(RulesIndexFields.RULE_NATURAL_ID, processingRule.getNaturalId());
        esRule.setFieldValue(RulesIndexFields.RULE_TRIGGER_NATURAL_IDS, processingRule.getNaturalTriggerIds());
        return esRule;
    }

    public void clear(Integer ruleId, ProcessingContext ctx) {
        ctx.getRules().put(ruleId, null);
    }

    private void adjustExpirationDate(ProcessingRule processedRule) {
        Rule rule = processedRule.getRule();
        long days = Duration.between(rule.getEffectiveDate().atStartOfDay(), rule.getExpirationDate().atStartOfDay()).toDays();
        if (days >= longRunningRulesDuration && !isEmpty(longRulesUsernamesWhitelist)) {
            boolean isExtendedPermissionsRequired = isExtendedPermissionsRequired(processedRule.getActions());

            if (isExtendedPermissionsRequired && !isUserNameInWhiteList(rule.getLastModifiedByName())) {
                processedRule.setOverriddenExpirationDate(rule.getEffectiveDate().plusDays(longRunningRulesDuration));
                log.info("For rule id={} set expiration date={} due to extended permission for lastModifiedBy={} user.",
                        rule.getId(), rule.getExpirationDate(), rule.getLastModifiedByName()
                );
            }
        }
    }

    private boolean isUserNameInWhiteList(String user) {
        if (user == null) return false;
        return longRulesUsernamesWhitelist.isEmpty() || longRulesUsernamesWhitelist.contains(user.toLowerCase());
    }

}