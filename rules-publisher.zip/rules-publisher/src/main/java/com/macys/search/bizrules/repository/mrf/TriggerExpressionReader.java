package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;

import javax.sql.DataSource;
import java.util.Map;

@Slf4j
public class TriggerExpressionReader extends AbstractMysqlRepository {

    public TriggerExpressionReader(DataSource mcomDataSource, DataSource bcomDataSource, boolean isStreamMode) {
        super(mcomDataSource, bcomDataSource, isStreamMode);
    }

    public void readTriggerExpression(ProcessingContext ctx, Map<Integer, ProcessingRule> rulesMap,
                                      Map<Integer, Integer> expressionToRuleMapping) {
        read(ctx.getSiteName(), "select PARENT_TRIG_EXP_ID, TRIGGER_EXP_ID, OPERATOR, TRIGGER_ID from merch_trigger_expression",
                rs -> {
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        int parentId = rs.getInt("PARENT_TRIG_EXP_ID");
                        boolean isParent = parentId == 0;
                        if (isParent) {
                            int triggerExpId = rs.getInt("TRIGGER_EXP_ID");
                            Integer ruleId = expressionToRuleMapping.get(triggerExpId);
                            if (ruleId == null) continue;
                            ProcessingRule processingRule = rulesMap.get(ruleId);
                            String operator = rs.getString("OPERATOR");
                            if (operator != null) {
                                processingRule.getRule().setTriggerOperation(BooleanOperation.valueOf(operator));
                            }
                        } else {
                            Integer ruleId = expressionToRuleMapping.get(parentId);
                            if (ruleId == null) continue;
                            ProcessingRule processingRule = rulesMap.get(ruleId);
                            processingRule.getRule().getTriggerIds().add(rs.getInt("TRIGGER_ID"));
                        }
                    }
                }
        );
    }

    private static class RuleResponse {
        private Integer triggerExpression;
    }

    public void readTriggerExpressionForRule(SiteName siteName, Rule rule) {
        RuleResponse ruleResponse = new RuleResponse();
        read(siteName, "select TRIGGER_EXP_ID from merch_rule where RULE_ID=" + rule.getId(),
                rs -> {
                    if (rs.next()) {
                        ruleResponse.triggerExpression = rs.getInt("TRIGGER_EXP_ID");
                    }
                });
        if (ruleResponse.triggerExpression == null) return;

        read(siteName, "select PARENT_TRIG_EXP_ID, OPERATOR, TRIGGER_ID from merch_trigger_expression " +
                        "where PARENT_TRIG_EXP_ID=" + ruleResponse.triggerExpression +
                        " OR TRIGGER_EXP_ID=" + ruleResponse.triggerExpression,
                rs -> {
                    while (rs.next()) {
                        int parentId = rs.getInt("PARENT_TRIG_EXP_ID");
                        boolean isParent = parentId == 0;
                        if (isParent) {
                            String operator = rs.getString("OPERATOR");
                            if (operator != null) {
                                rule.setTriggerOperation(BooleanOperation.valueOf(operator));
                            }
                        } else {
                            rule.getTriggerIds().add(rs.getInt("TRIGGER_ID"));
                        }
                    }
                }
        );
    }

}
