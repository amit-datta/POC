package com.macys.search.bizrules.tasklets.statistics;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.ToString;

import javax.annotation.concurrent.ThreadSafe;
import java.util.concurrent.atomic.AtomicInteger;

@Getter
@ToString
@JsonDeserialize
@ThreadSafe
public class FCCCategoriesStatistics {
    private final AtomicInteger indexedCategories = new AtomicInteger();

    private final TimeStatistics waitingTime = new TimeStatistics();

    public int getIndexedCategories() {
        return indexedCategories.get();
    }

    public void incrementIndexedCategories() {
        indexedCategories.incrementAndGet();
    }
}
