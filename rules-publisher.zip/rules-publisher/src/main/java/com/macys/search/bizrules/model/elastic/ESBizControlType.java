package com.macys.search.bizrules.model.elastic;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ESBizControlType {
    CUSTOM_DATE("CustomDate"),

    ACTIONS_INDEX("ActionsIndex"),
    RULES_INDEX("RulesIndex"),
    TRIGGERS_INDEX("TriggersIndex"),
    KWP_TRIGGERS_INDEX("KwpTriggersIndex");

    private final String name;
}
