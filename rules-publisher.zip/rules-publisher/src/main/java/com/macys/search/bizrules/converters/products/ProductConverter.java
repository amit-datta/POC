package com.macys.search.bizrules.converters.products;

import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESProduct;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.model.product.ProductToPool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;
import static java.lang.String.format;

/**
 * Converts product to elastic search document. This converter does not use master-member logic.
 */
@Slf4j
public class ProductConverter {
    private static final int BOOST_BY_PRODUCT_ID_SEQUENCE_NUMBER = 1;
    private static final int DEFAULT_SEQUENCE_NUMBER = 999;
    private final CategoryPathConverter categoryPathConverter;
    private final Map<Integer, ProcessingAction> actions;
    private final CategoryTree categoryTree;
    private final boolean customAttributesSequencedEnabled;


    private final Map<Integer, List<Integer>> poolIdToActionId = new HashMap<>();
    private final Map<Integer, List<Integer>> productIdToActionId = new HashMap<>();

    private static final Map<String, BiConsumer<ESProduct, Integer>> msrFunc = Map.of(
            MSR_BOOST, (product, id) -> product.getMsrBoost().add(id),
            MSR_ADD, (product, id) -> product.getMsrAdd().add(id),
            MSR_REPLACE, (product, id) -> product.getMsrReplace().add(id),
            MSR_REMOVE, (product, id) -> product.getMsrRemove().add(id)
    );

    public ProductConverter(CategoryPathConverter categoryPathConverter,
                            Map<Integer, ProcessingAction> indexedMsrAction,
                            CategoryTree categoryTree,
                            boolean customAttributesSequencedEnabled) {
        this.categoryPathConverter = categoryPathConverter;
        this.actions = indexedMsrAction;
        this.categoryTree = categoryTree;
        this.customAttributesSequencedEnabled = customAttributesSequencedEnabled;
        fillProductPools();
    }

    public ESProduct convert(Product product) {
        ESProduct esProduct = new ESProduct();
        esProduct.setProductId(product.getProductId());
        categoryPathConverter.convert(product, esProduct, categoryTree);
        setMSRFields(product, esProduct);
        return esProduct;
    }

    private void setMSRFields(Product product, ESProduct esProduct) {
        if (!CollectionUtils.isEmpty(product.getPools())) {
            for (ProductToPool pool : product.getPools()) {
                List<Integer> actionIds = poolIdToActionId.get(pool.getPoolId());
                if (actionIds != null) {
                    for (Integer actionId : actionIds) {
                        setMsrId(actions.get(actionId), esProduct, pool.getSequenceNumber());
                    }
                }
            }
        }

        List<Integer> actionIds = productIdToActionId.get(product.getProductId());
        if (actionIds != null) {
            for (Integer actionId : actionIds) {
                setMsrId(actions.get(actionId), esProduct, BOOST_BY_PRODUCT_ID_SEQUENCE_NUMBER);
            }
        }
    }

    private void setMsrId(ProcessingAction action, ESProduct esProduct, Integer seqNumber) {
        Criteria criteria = action.getCriteriaMap().get(MSR_OPERATIONS);
        if (criteria != null) {
            List<String> values = criteria.getCriteriaAttributes().get(MSR_OPERATION);
            msrFunc.get(values.get(0)).accept(esProduct, action.getId());
            if (customAttributesSequencedEnabled && ESActionType.MSR_BOOST.equals(action.getEsActionType())) {
                if (seqNumber == null) {
                    seqNumber = DEFAULT_SEQUENCE_NUMBER;
                    log.warn("Sequence number is null, 999 value will be used instead. Product id = {}, action id = {}",
                            esProduct.getElasticId(), action.getId());
                }
                esProduct.getMsrBoostWithSequenceNumber().add(format("%d_%d", seqNumber, action.getId()));
            }
        }
    }

    private void fillProductPools() {
        for (ProcessingAction action : actions.values()) {
            Map<String, Criteria> criteriaMap = action.getCriteriaMap();
            for (Integer poolId : getIds(criteriaMap.get(MSR_POOL), MSR_POOL_ID)) {
                poolIdToActionId.computeIfAbsent(poolId, k -> new ArrayList<>()).add(action.getId());
            }
            for (Integer poolId : getIds(criteriaMap.get(MSR_PRODUCT), MSR_PRODUCT_ID)) {
                productIdToActionId.computeIfAbsent(poolId, k -> new ArrayList<>()).add(action.getId());
            }
        }
    }

    private static List<Integer> getIds(Criteria criteria, String attrName) {
        if (criteria == null) return List.of();
        return criteria.getCriteriaAttributes().get(attrName).stream()
                .map(Integer::valueOf)
                .collect(Collectors.toList());
    }

}
