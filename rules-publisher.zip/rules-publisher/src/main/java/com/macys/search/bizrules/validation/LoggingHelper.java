package com.macys.search.bizrules.validation;

import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import org.slf4j.Logger;

/**
 * Helper class to standardize validation logs
 */
public class LoggingHelper {

    /**
     * Log message with standardize format
     *
     * @param logger logger
     * @param action action
     * @param msg    warning message
     */
    public static void logActionValidationFailed(Logger logger, Action action, String msg) {
        innerValidationFailedLog(logger, "Action", String.valueOf(action.getId()),
                String.valueOf(action.getMerchActionType()), msg);
    }

    /**
     * Log message with standardize format
     *
     * @param logger  logger
     * @param trigger trigger
     * @param msg     warning message
     */
    public static void logTriggerValidationFailed(Logger logger, Trigger trigger, String msg) {
        innerValidationFailedLog(logger, "Trigger", String.valueOf(trigger.getId()),
                String.valueOf(trigger.getMerchTriggerType()), msg);
    }

    private static void innerValidationFailedLog(Logger logger, String merchType, String id, String type,
                                                 String mgs) {
        logger.warn(String.format("%s with id=%s type=%s skipped due to failed validation. Message=%s",
                merchType, id, type, mgs)
        );
    }

}
