package com.macys.search.bizrules.catalog.fcc.product.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpcBinding {
    private Integer id;
    private Boolean active;
    private PriceBinding price;
    private AvailabilityBinding availability;
}
