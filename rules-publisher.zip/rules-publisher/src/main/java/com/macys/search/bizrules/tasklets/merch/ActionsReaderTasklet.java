package com.macys.search.bizrules.tasklets.merch;

import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.repository.mrf.ActionsReader;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Load {@link Action} from db
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ActionsReaderTasklet implements RulesPublisherTasklet {

    private final ActionsReader actionsReader;
    @Value("${rules.publisher.enabled.action-types}")
    private List<ActionType> enabledActions;

    @Override
    public void execute(ProcessingContext ctx) {
        log.info("Start action loading with types: {}", enabledActions);
        final Map<Integer, ProcessingAction> actions = new HashMap<>();
        actionsReader.readActions(ctx, enabledActions, actions);
        ctx.setActions(Collections.unmodifiableMap(actions));
        ctx.getStatistics().getActionsStatistics().setLoadedActions(actions.size());
        log.info("Read {} actions", actions.size());
    }

}
