package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.context.*;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionConstants;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.context.ContextParameterNames.*;
import static com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields.*;

/**
 * Context parameter converter
 */
@Component
public class ContextParametersConverter {

    private static final List<CustomerExperiment> CUSTOMER_EXPERIMENT_DEFAULT = Arrays.asList(CustomerExperiment.values());
    private static final List<ApplicationType> APPLICATION_TYPE_DEFAULT = Arrays.asList(ApplicationType.values());
    private static final List<DeviceType> DEVICE_TYPE_DEFAULT = Arrays.asList(DeviceType.values());
    private static final List<NavigationType> NAVIGATION_TYPE_DEFAULT = Arrays.asList(NavigationType.values());
    private static final List<ShoppingMode> SHOPPING_MODE_DEFAULT = Arrays.asList(ShoppingMode.values());
    private static final String REGION_CODE_DEFAULT = ActionConstants.ANY_REGION_CODE;

    /**
     * Convert context parameters
     *
     * @param action   action to take params from
     * @param esAction es action to set context params
     */
    public void convert(Action action, ESAction esAction) {
        setDefaultValues(esAction);
        for (Map.Entry<String, Collection<String>> entry : action.getContextAttributes().entrySet()) {
            convert(entry.getKey(), entry.getValue(), esAction);
        }
    }

    private static void setDefaultValues(ESAction doc) {
        doc.setFieldValue(REGION_CODE_CTX_ATTR, REGION_CODE_DEFAULT);
        doc.setFieldValue(CUSTOMER_EXPERIMENT_CTX_ATTR, CUSTOMER_EXPERIMENT_DEFAULT);

        doc.setFieldValue(APPLICATION_TYPE_CTX_ATTR, APPLICATION_TYPE_DEFAULT);
        doc.setFieldValue(DEVICE_TYPE_CTX_ATTR, DEVICE_TYPE_DEFAULT);
        doc.setFieldValue(NAVIGATION_TYPE_CTX_ATTR, NAVIGATION_TYPE_DEFAULT);
        doc.setFieldValue(SHOPPING_MODE_CTX_ATTR, SHOPPING_MODE_DEFAULT);
    }

    private void convert(String attrName, Collection<String> attrValues, ESAction doc) {
        switch (attrName) {
            case REGION_CODE:
                doc.setFieldValue(REGION_CODE_CTX_ATTR, attrValues.iterator().next());
                return;
            case APPLICATION:
                doc.setFieldValue(APPLICATION_TYPE_CTX_ATTR, convert(attrValues, ApplicationType.class));
                return;
            case CUSTOMER_EXPERIMENT:
                doc.setFieldValue(CUSTOMER_EXPERIMENT_CTX_ATTR, convert(attrValues, CustomerExperiment.class));
                return;
            case DEVICE_TYPE:
                doc.setFieldValue(DEVICE_TYPE_CTX_ATTR, convert(attrValues, DeviceType.class));
                return;
            case NAVIGATION_TYPE:
                doc.setFieldValue(NAVIGATION_TYPE_CTX_ATTR, convert(attrValues, NavigationType.class));
                return;
            case SHOPPING_MODE:
                doc.setFieldValue(SHOPPING_MODE_CTX_ATTR, convert(attrValues, ShoppingMode.class));
                return;
            default:
                throw new AssertionError("Could not converted " + attrName + " attribute");
        }
    }

    private static <E extends Enum<E>> Collection<E> convert(Collection<String> values, Class<E> enumType) {
        return values.stream().map(value -> Enum.valueOf(enumType, value)).collect(Collectors.toUnmodifiableList());
    }

}
