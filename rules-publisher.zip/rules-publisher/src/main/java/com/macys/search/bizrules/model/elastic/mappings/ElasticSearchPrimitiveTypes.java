package com.macys.search.bizrules.model.elastic.mappings;

import lombok.Getter;

import java.util.Map;

/**
 * Elastic search primitive types
 */
enum ElasticSearchPrimitiveTypes {
    KEYWORD("keyword"),
    LONG("long"),
    TEXT("text"),
    BOOLEAN("boolean"),
    PERCOLATOR("percolator"),
    DATE(Map.of("type", "date", "format", "yyyy-MM-dd")),
    DATE_TIME("date");
    
    @Getter
    private final Map<String, Object> properties;

    ElasticSearchPrimitiveTypes(String value) {
        this.properties = Map.of("type", value);
    }

    ElasticSearchPrimitiveTypes(Map<String, Object> properties) {
        this.properties = properties;
    }
}
