package com.macys.search.bizrules.model.category;

import lombok.Data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Data
public class ContextOverride {
    private int id;
    private String name;
    private Integer sequenceNumber;
    private boolean suppressed;
    private final Map<String, Collection<String>> attributes = new HashMap<>();

    public void addAttribute(String key, Collection<String> value) {
        Collection<String> values = attributes.computeIfAbsent(key, k -> new ArrayList<String>());
        if (value != null) {
            values.addAll(value);
        }
    }
}
