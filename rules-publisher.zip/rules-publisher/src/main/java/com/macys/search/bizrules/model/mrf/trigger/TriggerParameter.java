package com.macys.search.bizrules.model.mrf.trigger;

import lombok.Data;

/**
 * Hold single trigger parameter
 */
@Data
public class TriggerParameter {
    private String name;
    private String group;
    private String value;
}
