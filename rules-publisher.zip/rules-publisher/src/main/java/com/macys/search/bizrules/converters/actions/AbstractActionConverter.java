package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;

import static com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields.ACTION_ID;
import static com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields.ACTION_TYPE_PRIORITY;
import static com.macys.search.bizrules.model.mrf.action.ActionType.*;

/**
 * Process standard action field set.
 * <br>
 * Child class should implement {@link #enrichWithTypeSpecificProperties(Action, ESAction, ProcessingContext)} method,
 * which can contain type specific logic
 */
public abstract class AbstractActionConverter implements ActionConverter {

    @Override
    public ESAction convert(Action action, ProcessingContext context) {
        ESAction result = new ESAction();
        result.setFieldValue(ACTION_ID, action.getId());
        result.setFieldValue(ACTION_TYPE_PRIORITY, getActionTypePriority(action));

        enrichWithTypeSpecificProperties(action, result, context);
        return result;
    }

    private static int getActionTypePriority(Action action) {
        ActionType type = action.getMerchActionType();
        if (type == URLRedirect) {
            return 1;
        }
        if (type == CategoryRedirect) {
            return 2;
        }
        if (type == ProductRedirect) {
            return 3;
        }
        return 0;
    }

    abstract void enrichWithTypeSpecificProperties(Action action, ESAction result, ProcessingContext context);
}
