package com.macys.search.config.indexes;

import com.macys.search.bizrules.model.elastic.mappings.BizControlIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.macys.search.bizrules.model.elastic.ESIndex.BIZ_CONTROLS_DB;
import static com.macys.search.config.utils.ESIndicesUtils.fullAliasNameFrom;

@Configuration
public class ESBizControlsDbIndexConfiguration extends AbstractElasticIndexConfiguration {

    @Value("${rules.publisher.mcom.biz_controls_db.alias.index.name}")
    private String mcomAliasName;
    @Value("${rules.publisher.mcom.biz_controls_db.number-of-shards}")
    private int mcomShardsCount;
    @Value("${rules.publisher.mcom.biz_controls_db.number-of-replicas}")
    private int mcomReplicasCount;

    @Value("${rules.publisher.bcom.biz_controls_db.alias.index.name}")
    private String bcomAliasName;
    @Value("${rules.publisher.bcom.biz_controls_db.number-of-shards}")
    private int bcomShardsCount;
    @Value("${rules.publisher.bcom.biz_controls_db.number-of-replicas}")
    private int bcomReplicasCount;

    @Bean
    public CreateIndexTasklet createBizControlsDbIndexTasklet(ElasticSearchFacade elasticSearchFacade) {
        return new CreateIndexTasklet(elasticSearchFacade,
                mcomBizControlsDbIndexCreationProperties(), bcomBizControlsDbIndexCreationProperties(),
                mcomCommonIndexProperties, bcomCommonIndexProperties,
                indexerFactory, BIZ_CONTROLS_DB);
    }

    private IndexCreationProperties mcomBizControlsDbIndexCreationProperties() {
        return new IndexCreationProperties(fullAliasNameFrom(mcomAliasName, indexVersion),
                mcomShardsCount, mcomReplicasCount, BizControlIndexFields.class, null);
    }

    private IndexCreationProperties bcomBizControlsDbIndexCreationProperties() {
        return new IndexCreationProperties(fullAliasNameFrom(bcomAliasName, indexVersion),
                bcomShardsCount, bcomReplicasCount, BizControlIndexFields.class, null);
    }

    @Bean
    public SwitchAliasProperties controlsDbSwitchAliasProperties() {
        return SwitchAliasProperties.of(
                BIZ_CONTROLS_DB,
                mcomAliasName, bcomAliasName, indexVersion,
                1
        );
    }
}
