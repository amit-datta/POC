package com.macys.search.bizrules.validation.model;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * Template for merch config
 */
@Getter
public class ConfigTemplate {
    private final Map<String, CriteriaTemplate> criteriaNameToCriteria = new HashMap<>();

    @JsonAnySetter
    public void add(String key, CriteriaTemplate value) {
        criteriaNameToCriteria.put(key, value);
    }
}
