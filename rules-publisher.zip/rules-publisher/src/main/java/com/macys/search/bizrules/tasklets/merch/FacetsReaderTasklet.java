package com.macys.search.bizrules.tasklets.merch;

import com.macys.search.bizrules.model.mrf.Facet;
import com.macys.search.bizrules.repository.mrf.FacetsReader;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class FacetsReaderTasklet implements RulesPublisherTasklet {

    private final FacetsReader facetsReader;

    @Override
    public void execute(ProcessingContext ctx) throws Exception {
        log.info("Start reading facets");
        List<Facet> facets = facetsReader.getFacets(ctx);
        ctx.setFacets(facets.stream().collect(Collectors.toMap(Facet::getAttributeName, f -> f)));
        log.info("Read {} facets", facets.size());
    }
}
