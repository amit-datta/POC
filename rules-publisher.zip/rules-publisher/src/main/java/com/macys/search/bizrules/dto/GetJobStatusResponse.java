package com.macys.search.bizrules.dto;

import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.springframework.batch.core.JobExecution;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.tasklets.JobParams.*;

@Getter
public class GetJobStatusResponse {
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    private static final String UNKNOWN = "UNKNOWN";
    private String region;
    private String siteName;
    private String sessionId;
    private Long executionId;
    private String name;
    private String startTime;
    private String endTime;
    private String duration;
    private String status;
    private List<StepStatusResponse> steps;
    private Map<String, Object> statistics;

    @SuppressWarnings("unchecked")
    public static GetJobStatusResponse of(JobExecution jobExecution) {
        GetJobStatusResponse result = new GetJobStatusResponse();
        result.executionId = jobExecution.getId();
        result.name = jobExecution.getJobInstance().getJobName();
        result.startTime = formatDateOrNull(jobExecution.getStartTime());
        result.endTime = formatDateOrNull(jobExecution.getEndTime());
        result.duration = formatDuration(jobExecution.getStartTime(), jobExecution.getEndTime());
        result.status = jobExecution.getStatus().name();
        result.region = getRegion(jobExecution);
        result.siteName = getSite(jobExecution);
        result.sessionId = getSessionId(jobExecution);
        result.steps = jobExecution.getStepExecutions().stream()
                .map(StepStatusResponse::of)
                .collect(Collectors.toList());
        Map<String, Object> values = ProcessingContext.getJobExecutionData(jobExecution);
        Map<String, Object> statistics = null;
        if (values != null) {
            statistics = (Map<String, Object>) values.get("statistics");
        }
        result.statistics = statistics != null ? statistics : new HashMap<>();
        return result;
    }

    static String formatDateOrNull(Date date) {
        return date != null ? DATE_FORMAT.format(date) : null;
    }

    static String formatDuration(final Date startTime, final Date endTime) {
        if (startTime == null || endTime == null) {
            return "N/A";
        }
        final long durationMillis = endTime.getTime() - startTime.getTime();
        return DurationFormatUtils.formatDuration(durationMillis, "H:mm:ss", true);
    }

    private static String getRegion(JobExecution jobExecution) {
        if (StringUtils.isNotBlank(jobExecution.getJobParameters().getString(CLOUD_REGION))) {
            return jobExecution.getJobParameters().getString(CLOUD_REGION);
        }
        return UNKNOWN;
    }

    private static String getSite(JobExecution jobExecution) {
        if (StringUtils.isNotBlank(jobExecution.getJobParameters().getString(SITE_NAME_JOB_PARAM))) {
            return jobExecution.getJobParameters().getString(SITE_NAME_JOB_PARAM);
        }
        return UNKNOWN;
    }

    private static String getSessionId(JobExecution jobExecution) {
        if (StringUtils.isNotBlank(jobExecution.getJobParameters().getString(INDEXING_SESSION_ID))) {
            return jobExecution.getJobParameters().getString(INDEXING_SESSION_ID);
        }
        return UNKNOWN;
    }
}