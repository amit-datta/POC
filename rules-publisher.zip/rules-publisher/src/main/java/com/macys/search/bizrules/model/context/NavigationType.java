package com.macys.search.bizrules.model.context;

/**
 * NavigationType context attribute
 */
public enum NavigationType {
    SEARCH,
    BROWSE,
    LANDING
}
