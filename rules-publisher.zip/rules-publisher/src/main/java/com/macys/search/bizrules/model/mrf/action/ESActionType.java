package com.macys.search.bizrules.model.mrf.action;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Extended business type of {@link ActionType}
 */
@Getter
@AllArgsConstructor
public enum ESActionType {
    CATEGORY_REDIRECT(false),
    PRODUCT_REDIRECT(false),
    URL_REDIRECT(false),
    SHOW_MEDIA(false),
    MSR_BOOST(false),
    MSR_BOOST_BY_ATTRIBUTE(false),
    MSR_ADD(true),
    MSR_REPLACE(true),
    MSR_REMOVE(true),
    SEO_CONTROL(false),
    SPECIAL_INSTRUCTION(false),
    SEO_META_DATA(false);

    private final boolean extendedPermissionsForESActionsRequired;
}
