package com.macys.search.bizrules.model.mrf.trigger;

import com.macys.search.bizrules.model.mrf.Criteria;
import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Merchandising trigger configuration.
 * Contains data which describe condition for evaluating business rule.
 */
@Data
public class Trigger {
    private Integer id;
    private LocalDate lastModified;
    private LocalDate createdDate;
    private String authorName = "";
    private String lastModifiedByName = "";
    private TriggerType merchTriggerType;
    private boolean searchable;
    private boolean resultSetRequired;
    private List<TriggerParameter> params = new ArrayList<>();

    private Map<String, Criteria> criteriaMap = new HashMap<>();
    private boolean isValid;
}
