package com.macys.search.bizrules.validation.action;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Implementation of validation strategy for action {@link com.macys.search.bizrules.model.mrf.action.ActionType#CategoryRedirect}
 * validates that given actionConfig {@link Action} contains unary attribute CategoryId and it's value
 * is positive integer value.
 */
@Slf4j
@Component
public class CategoryRedirectActionValidationStrategy extends AbstractActionCriteriaValidationStrategy {

    @Getter(AccessLevel.PACKAGE)
    @ResourceMapping("classpath:merch-validation-template/action/CategoryRedirect.json")
    private ConfigTemplate template;

    @Override
    public ActionType applicableFor() {
        return ActionType.CategoryRedirect;
    }

}
