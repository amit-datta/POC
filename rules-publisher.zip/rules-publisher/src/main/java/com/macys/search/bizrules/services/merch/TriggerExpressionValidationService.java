package com.macys.search.bizrules.services.merch;

import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

import static com.macys.search.bizrules.model.mrf.BooleanOperation.AND;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.FacetRefinement;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.HierarchicalRefinement;

@Slf4j
@Component
@RequiredArgsConstructor
public class TriggerExpressionValidationService {

    private final TriggersService triggersService;

    public ValidationResult validate(ProcessingRule processingRule, ProcessingContext ctx, List<ProcessingTrigger> validTriggers) {
        Rule rule = processingRule.getRule();

        List<Integer> triggerIds = rule.getTriggerIds();
        if (CollectionUtils.isEmpty(triggerIds)) {
            return ValidationResult.failResult(String.format("No trigger ids for rule id=%d", rule.getId()));
        }
        BooleanOperation boolOperation = rule.getTriggerOperation();
        if (triggerIds.size() > 1 && boolOperation == null) {
            return ValidationResult.failResult(String.format(
                    "Trigger expression operation is null for rule id=%d", rule.getId()));
        }

        String notTriggerQueryMessage = "Rule with id=%s skipped because there are no valid trigger queries. ";
        for (Integer triggerId : triggerIds) {
            ValidationResult triggerExistence = checkTriggerValidity(triggerId, ctx);
            if (triggerExistence.isValid()) {
                validTriggers.add(triggersService.getProcessedTrigger(triggerId, ctx));
            } else {
                if (boolOperation == AND || triggerIds.size() == 1) {
                    return ValidationResult.failResult(String.format(notTriggerQueryMessage + triggerExistence.getWarning(),
                            rule.getId()));
                }
            }
        }

        if (validTriggers.isEmpty()) {
            return ValidationResult.failResult(String.format(notTriggerQueryMessage, rule.getId()));
        }

        ValidationResult triggerHRTValid = validateTriggersOnHRTLogic(validTriggers, boolOperation);
        if (!triggerHRTValid.isValid()) {
            validTriggers.clear();
            return triggerHRTValid;
        }
        return ValidationResult.validResult();
    }

    private ValidationResult validateTriggersOnHRTLogic(List<ProcessingTrigger> validTriggers, BooleanOperation boolOperation) {
        long countHRTTriggers = countTriggers(validTriggers, HierarchicalRefinement);
        if (countHRTTriggers > 0) {
            if (AND.equals(boolOperation)) {
                if (countHRTTriggers > 1) {
                    return ValidationResult.failResult("There should be only 1 HRT trigger when operation is AND.");
                }
                long countFRTTriggers = countTriggers(validTriggers, FacetRefinement);
                long sumOfHRTAndFRT = countHRTTriggers + countFRTTriggers;
                long totalTriggerCount = validTriggers.size();
                boolean onlyHRTAndFRTArePresent = sumOfHRTAndFRT == totalTriggerCount;
                if (!onlyHRTAndFRTArePresent) {
                    return ValidationResult.failResult("There should be either only 1 HRT trigger or 1 HRT and N FRT triggers when operation is AND.");
                }
            }
        }
        return ValidationResult.validResult();
    }

    private long countTriggers(List<ProcessingTrigger> validTriggers, TriggerType triggerType) {
        return validTriggers.stream()
                .map(ProcessingTrigger::getTrigger)
                .filter(t -> triggerType.equals(t.getMerchTriggerType()))
                .count();
    }

    private ValidationResult checkTriggerValidity(Integer triggerId, ProcessingContext ctx) {
        ProcessingTrigger processingTrigger = triggersService.getProcessedTrigger(triggerId, ctx);
        if (processingTrigger == null) {
            return ValidationResult.failResult(
                    String.format("Trigger with id=%d was not found. Maybe it has disabled type", triggerId)
            );
        }
        if (!processingTrigger.isValid()) {
            return ValidationResult.failResult(String.format("Trigger with id=%d is invalid. Msg=%s", triggerId,
                    processingTrigger.getValidationResult().getWarning()));
        }
        return ValidationResult.validResult();
    }

}
