package com.macys.search.bizrules.tasklets.esmanaging;

import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class CreateIndexTasklet implements RulesPublisherTasklet {
    private final ElasticSearchFacade elasticSearchFacade;
    private final IndexCreationProperties mcomIndexCreationProperties;
    private final IndexCreationProperties bcomIndexCreationProperties;
    private final CommonIndexProperties mcomCommonIndexProperties;
    private final CommonIndexProperties bcomCommonIndexProperties;
    private final ElasticSearchIndexerFactory elasticSearchIndexerFactory;
    @Getter
    private final ESIndex indexType;

    public void execute(ProcessingContext ctx) {
        String indexName;
        if (ctx.isMCOM()) {
            indexName = elasticSearchFacade.createIndex(mcomIndexCreationProperties, mcomCommonIndexProperties);
        } else {
            indexName = elasticSearchFacade.createIndex(bcomIndexCreationProperties, bcomCommonIndexProperties);
        }
        ctx.setupIndex(indexType, indexName, elasticSearchIndexerFactory.createIndexer(indexName));
    }
}
