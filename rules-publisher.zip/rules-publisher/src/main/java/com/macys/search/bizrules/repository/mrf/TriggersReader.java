package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerParameter;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

@Slf4j
public class TriggersReader extends AbstractMysqlRepository {

    private static final BiConsumer<ResultSet, Trigger> TRIGGER_CONVERTER = (rs, trigger) -> {
        try {
            trigger.setId(rs.getInt("TRIGGER_ID"));
            trigger.setMerchTriggerType(TriggerType.valueOf(rs.getString("TRIGGER_TYPE")));
            trigger.setSearchable(rs.getBoolean("IS_SEARCHABLE"));
            trigger.setResultSetRequired(rs.getBoolean("IS_RESULT_SET_REQUIRED"));
            trigger.setCreatedDate(rs.getDate("CREATED").toLocalDate());
            trigger.setAuthorName(rs.getString("CREATED_BY"));
            trigger.setLastModified(rs.getDate("LAST_MODIFIED").toLocalDate());
            trigger.setLastModifiedByName(rs.getString("LAST_MODIFIED_BY"));
        } catch (SQLException exception) {
            log.error("Error while reading action", exception);
        }
    };

    public static BiConsumer<ResultSet, TriggerParameter> TRIGGER_PARAMETER_CONVERTER = (rs, param) -> {
        try {
            param.setGroup(rs.getString("PARAM_GROUP"));
            param.setName(rs.getString("PARAM_NAME"));
            param.setValue(rs.getString("PARAM_VALUE"));
        } catch (SQLException exception) {
            log.error("Error while reading action param", exception);
        }
    };

    public TriggersReader(DataSource mcomDataSource, DataSource bcomDataSource, boolean isStreamMode) {
        super(mcomDataSource, bcomDataSource, isStreamMode);
    }

    public void readTriggers(ProcessingContext ctx, List<TriggerType> triggerTypes, Map<Integer, ProcessingTrigger> map) {
        read(ctx.getSiteName(), "select * from merch_trigger where TRIGGER_TYPE in (" +
                        paramSymbolsGenerator.apply(triggerTypes.size()) + ")",
                st -> fillStringsInStatement(st, triggerTypes),
                rs -> {
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        Trigger trigger = new Trigger();
                        TRIGGER_CONVERTER.accept(rs, trigger);
                        if (trigger.getId() != null) {
                            map.put(trigger.getId(), ProcessingTrigger.from(trigger));
                        }
                    }
                });

        read(ctx.getSiteName(), "select * from merch_trigger_parameter order by TRIGGER_ID",
                rs -> {
                    ProcessingTrigger processingTrigger = null;
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        TriggerParameter parameter = new TriggerParameter();
                        TRIGGER_PARAMETER_CONVERTER.accept(rs, parameter);

                        int triggerId = rs.getInt("TRIGGER_ID");
                        if (processingTrigger == null || !processingTrigger.getId().equals(triggerId)) {
                            processingTrigger = map.get(triggerId);
                        }
                        if (processingTrigger != null) {
                            processingTrigger.getTrigger().getParams().add(parameter);
                        }
                    }
                });
    }

    public Trigger getTriggerById(SiteName siteName, Integer triggerId, List<TriggerType> triggerTypes) {
        Trigger trigger = new Trigger();
        read(siteName, "select * from merch_trigger where TRIGGER_ID=" + triggerId + " AND TRIGGER_TYPE in (" +
                        paramSymbolsGenerator.apply(triggerTypes.size()) + ")",
                st -> fillStringsInStatement(st, triggerTypes),
                rs -> {
                    if (rs.next()) {
                        TRIGGER_CONVERTER.accept(rs, trigger);
                    }
                });
        if (trigger.getId() == null) {
            return null;
        }

        read(siteName, "select * from merch_trigger_parameter where TRIGGER_ID=" + triggerId,
                rs -> {
                    while (rs.next()) {
                        TriggerParameter parameter = new TriggerParameter();
                        TRIGGER_PARAMETER_CONVERTER.accept(rs, parameter);
                        trigger.getParams().add(parameter);
                    }
                });

        return trigger;
    }

}
