package com.macys.search.bizrules.model.mrf.action;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Action criteria map constants
 */
public final class ActionConstants {
    public static final String MSR_OPERATIONS = "Operations";
    public static final String MSR_OPERATION = "Operation";

    public static final String MSR_POOL = "Pool";
    public static final String MSR_POOL_ID = "PoolId";
    public static final String MSR_PRODUCT = "Product";
    public static final String MSR_PRODUCT_ID = "ProductId";
    public static final String MSR_ATTRIBUTES_GROUP = "AttributesGroup";

    public static final String PDP_PRODUCT = "Product";
    public static final String PDP_PRODUCT_ID = "ProductId";

    public static final String CATEGORY_REDIRECT = "Category";
    public static final String CATEGORY_REDIRECT_ID = "CategoryId";

    public static final String URL_REDIRECT = "URL";
    public static final String URL_REDIRECT_TYPE = "URLType";
    public static final String URL_REDIRECT_VALUE = "URLValue";

    public static final String SEO_CONTROL_PARAMS = "SeoParameters";
    public static final String SEO_CONTROL_INDEX_FOLLOW = "IndexFollow";
    public static final String SEO_CONTROL_Y = "Y";

    public static final String SHOW_MEDIA_CANVAS = "Canvas";
    public static final String SHOW_MEDIA_CANVAS_ID = "CanvasId";

    public static final String INTERNATIONAL_REGION_CODE = "INTL";
    public static final String ANY_REGION_CODE = "ANY_REGION_CODE";

    public static final String  ATTRIBUTE_VALUE = "AttributeValue";

    public static final LocalDate MAX_DATE = LocalDate.of(2099, 1, 1);
    public static final LocalDate MIN_DATE = LocalDate.of(1900, 1, 1);
    public static final LocalDateTime MIN_DATE_TIME = LocalDateTime.of(1900, 1, 1, 12, 0);
    public static final String MSR_BOOST = "BOOST";
    public static final String MSR_ADD = "ADD";
    public static final String MSR_REPLACE = "REPLACE";
    public static final String MSR_REMOVE = "REMOVE";

}
