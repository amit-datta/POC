package com.macys.search.bizrules.repository.elastic;

import com.macys.search.bizrules.model.elastic.entries.ESEntry;
import com.macys.search.exception.bizrules.es.ElasticSearchBulkIndexException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.MDC;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static java.lang.String.format;

/**
 * Wraps Elastic search indexing process.
 * This class is Thread-safe. We need only one instance for one Elastic search index.
 * If {@code maxBulkSize} document added, this bulk will be sent in async mode.
 * Count of async request limit by executor service capacity.
 * <p>
 * Usage:
 * <p>
 * 1) invoke {@link #add(ESEntry)} for all documents you need
 * to index;
 * <p>
 * 2) invoke {@link #flush()};
 */
@Slf4j
public class ElasticSearchIndexer {
    private final String indexName;
    private final int sendBulkAttemptsCount;
    private final ExecutorService indexingExecutor;
    private final RestHighLevelClient client;
    private final int maxBulkSize;
    private final RequestOptions sendBulkRequestOptions;

    private final BlockingQueue<Future<InnerBulkResponse>> responsesQueue;
    private final AtomicInteger batchCounter = new AtomicInteger(0);
    private final String indexerId = UUID.randomUUID().toString().substring(0, 6);

    private BulkRequest bulkRequest = new BulkRequest();
    private boolean allSuccessful = true;

    public ElasticSearchIndexer(String indexName, int sendBulkAttemptsCount, ExecutorService indexingExecutor,
                                RestHighLevelClient client, int maxBulkSize,
                                RequestOptions sendBulkRequestOptions, int indexingQueueSize) {
        this.indexName = indexName;
        this.sendBulkAttemptsCount = sendBulkAttemptsCount;
        this.indexingExecutor = indexingExecutor;
        this.client = client;
        this.maxBulkSize = maxBulkSize;
        this.sendBulkRequestOptions = sendBulkRequestOptions;

        this.responsesQueue = new LinkedBlockingQueue<>(indexingQueueSize);
    }

    @AllArgsConstructor
    private static class InnerBulkResponse {
        private final BulkResponse response;
        private final int batchId;
    }

    /**
     * Index one document
     *
     * @param entry document to index
     */
    public void add(ESEntry entry) {
        BulkRequest bulkToSend = null;
        synchronized (this) {
            bulkRequest.add(new IndexRequest(indexName)
                    .id(entry.getElasticId())
                    .source(entry.getSource())
            );
            if (bulkRequest.numberOfActions() >= maxBulkSize) {
                bulkToSend = bulkRequest;
                bulkRequest = new BulkRequest();
            }
        }
        indexBulk(bulkToSend);
    }

    private void indexBulk(BulkRequest bulk) {
        final Map<String, String> mdcCopy = MDC.getCopyOfContextMap();
        if (bulk == null || bulk.numberOfActions() == 0) return;
        final int batchId = batchCounter.incrementAndGet();
        Future<InnerBulkResponse> future = indexingExecutor.submit(() -> {
            MDC.setContextMap(mdcCopy);
            for (int attempt = 1; attempt < sendBulkAttemptsCount; attempt++) {
                try {
                    if (attempt > 1) {
                        log.info("[{}] Send batch with id={} attempt={}", indexerId, batchId, attempt);
                    }
                    return new InnerBulkResponse(client.bulk(bulk, sendBulkRequestOptions), batchId);
                } catch (IOException ex) {
                    log.error(format("[%s] Error while sending batch id=%d to es. Attempt %d of %d. Message=%s",
                            indexerId, batchId, attempt, sendBulkAttemptsCount, ex.getMessage())
                    );
                }
            }
            return new InnerBulkResponse(client.bulk(bulk, sendBulkRequestOptions), batchId);
        });

        cleanFirstsFinishedNaively(false);
        while (!responsesQueue.offer(future)) {
            log.info("[{}] Indexing queue is full. Wait until previous batches would be indexed",
                    indexerId);
            cleanFirstsFinishedNaively(true);
        }
    }

    /**
     * Flush buffers and wait responses from all async requests
     */
    public synchronized boolean flush() {
        indexBulk(bulkRequest);
        join();
        return allSuccessful;
    }

    private void join() {
        Future<InnerBulkResponse> future;
        while ((future = responsesQueue.poll()) != null) {
            processBulkResponseFuture(future);
        }
    }

    private synchronized void cleanFirstsFinishedNaively(boolean block) {
        Future<InnerBulkResponse> future;
        while ((future = responsesQueue.peek()) != null) {
            if (!future.isDone() && !block) return;
            future = responsesQueue.poll();
            if (future == null) return;
            processBulkResponseFuture(future);
            block = false;
        }
    }

    private void processBulkResponseFuture(Future<InnerBulkResponse> future) {
        try {
            InnerBulkResponse innerResponse = future.get();
            BulkResponse response = innerResponse.response;
            if (response.hasFailures()) {
                log.warn("[{}] Indexing to name={} {}",
                        indexerId, indexName, response.buildFailureMessage());
                allSuccessful = false;
            }
            log.info("[{}] Bulk {} indexing in index={} took {}",
                    indexerId, innerResponse.batchId, indexName, response.getTook());
        } catch (ExecutionException | InterruptedException ex) {
            throw new ElasticSearchBulkIndexException(indexName,
                    format("[%s] Bulk indexing failed.", indexerId), ex);
        }
    }
}
