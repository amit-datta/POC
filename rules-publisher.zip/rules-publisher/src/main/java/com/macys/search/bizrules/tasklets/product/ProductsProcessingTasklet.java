package com.macys.search.bizrules.tasklets.product;

import com.macys.search.bizrules.catalog.ProductsLoader;
import com.macys.search.bizrules.converters.products.CategoryPathConverter;
import com.macys.search.bizrules.converters.products.ProductConverter;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.ESProduct;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexerFactory;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.tasklets.statistics.FCCProductsStatistics;
import com.macys.search.bizrules.tasklets.statistics.IndexingStatistics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Iterator;

@Slf4j
@Component
@RequiredArgsConstructor
public class ProductsProcessingTasklet implements RulesPublisherTasklet {

    private final ProductsLoader productsLoader;
    private final ElasticSearchIndexerFactory elasticSearchIndexerFactory;
    private final CategoryPathConverter categoryPathConverter;

    @Value("${rules.publisher.load.products.from}")
    private String productsSource;
    @Value("${rules.publisher.custom.attributes.sequenced.boost.enabled}")
    private boolean customAttributesSequencedEnabled;

    public void execute(ProcessingContext ctx) {
        String indexName = ctx.getIndexName(ESIndex.PRODUCTS);
        ElasticSearchIndexer indexer = elasticSearchIndexerFactory.createIndexer(indexName);
        IndexingStatistics statistics = ctx.getStatistics();

        ProductConverter converter = new ProductConverter(categoryPathConverter, ctx.getIndexedMsrAction(),
                ctx.getCategoryTree(), customAttributesSequencedEnabled);

        log.info("Start loading and indexing products");
        FCCProductsStatistics fccProductsStatistics = ctx.getStatistics().getFccProductsStatistics();
        Iterator<Product> it = productsLoader.iterator(ctx.getSiteName(), ctx.getCustomDate(), fccProductsStatistics.getWaitingTime());
        int size = 0;
        while (it.hasNext() && !ctx.isCurrentJobStopped()) {
            Product product = it.next();
            index(converter.convert(product), indexer, statistics);
            size++;
        }
        log.info("Loaded {} products from {} source", size, productsSource);

        if (!indexer.flush()) {
            throw new RuntimeException("Some exception occurred during send products to Elastic search. " +
                    "Please check logs for additional information");
        }
    }

    private static void index(ESProduct esProduct, ElasticSearchIndexer indexer, IndexingStatistics statistics) {
        indexer.add(esProduct);
        statistics.getFccProductsStatistics().incrementIndexedProducts();
    }
}
