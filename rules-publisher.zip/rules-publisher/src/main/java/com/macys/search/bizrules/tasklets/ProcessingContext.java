package com.macys.search.bizrules.tasklets;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.mrf.Facet;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.tasklets.statistics.IndexingStatistics;
import com.macys.search.bizrules.services.StoppedJobsCache;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import static com.macys.search.bizrules.tasklets.JobParams.*;

/**
 * Holder all context parameters
 */
@Getter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProcessingContext {
    private static final String PROCESSING_CONTEXT_KEY = "PROCESSING_CONTEXT";

    @JsonIgnore
    private StepContribution contribution;
    @JsonIgnore
    private ChunkContext chunkContext;
    @Setter
    @JsonIgnore
    private boolean previewRequested;
    @Setter
    @JsonIgnore
    private Map<Integer, ProcessingAction> actions;
    @Setter
    @JsonIgnore
    private Map<Integer, ProcessingTrigger> triggers;
    @Setter
    @JsonIgnore
    private Map<Integer, ProcessingRule> rules;
    @Setter
    @JsonIgnore
    private Integer ruleNaturalIdsCounter;
    @Setter
    @JsonIgnore
    private Integer triggerNaturalIdsCounter;

    @Setter
    @JsonIgnore
    private CategoryTree categoryTree;
    @Setter
    @JsonIgnore
    private Map<Integer, ProcessingAction> indexedMsrAction = new HashMap<>();

    private SiteName siteName;

    private final Map<ESIndex, String> indexNames = new EnumMap<>(ESIndex.class);
    @JsonIgnore
    @Setter
    private LocalDate customDate;
    @JsonIgnore
    private final Map<ESIndex, ElasticSearchIndexer> indexers = new EnumMap<>(ESIndex.class);

    @JsonIgnore
    @Setter
    private Map<String, Facet> facets;

    private final IndexingStatistics statistics = new IndexingStatistics();

    @Setter
    @JsonIgnore
    private StoppedJobsCache stoppedJobsCache;

    private ProcessingContext(StepContribution contribution, ChunkContext chunkContext) {
        this.contribution = contribution;
        this.chunkContext = chunkContext;
    }

    public static ProcessingContext initContext(StepContribution contribution, ChunkContext chunkContext) {
        ProcessingContext context = new ProcessingContext(contribution, chunkContext);
        contribution.getStepExecution()
                .getJobExecution()
                .getExecutionContext()
                .put(PROCESSING_CONTEXT_KEY, context);

        context.siteName = SiteName.valueOf(chunkContext.getStepContext()
                .getJobParameters().get(SITE_NAME_JOB_PARAM).toString());

        return context;
    }

    public static ProcessingContext getContext(StepContribution contribution) {
        return (ProcessingContext) contribution.getStepExecution()
                .getJobExecution()
                .getExecutionContext()
                .get((PROCESSING_CONTEXT_KEY));
    }

    public static ProcessingContext getContext(JobExecution jobExecution) {
        return (ProcessingContext) jobExecution.getExecutionContext().get((PROCESSING_CONTEXT_KEY));
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> getJobExecutionData(JobExecution jobExecution) {
        return (Map<String, Object>) jobExecution.getExecutionContext().get((PROCESSING_CONTEXT_KEY));
    }

    public void setupIndex(ESIndex index, String indexName, ElasticSearchIndexer indexer) {
        indexNames.put(index, indexName);
        indexers.put(index, indexer);
    }

    public String getIndexName(ESIndex index) {
        return indexNames.get(index);
    }

    /**
     * Retrieve custom date from job context
     *
     * @return custom date or null if context does not contain custom date
     */
    public LocalDate getCustomDate() {
        if (customDate == null) {
            if (chunkContext == null) {
                return null;
            }
            Object customDateValue = chunkContext.getStepContext().getJobParameters().get(CUSTOM_DATE_JOB_PARAM);
            if (customDateValue != null) {
                customDate = LocalDate.parse(customDateValue.toString(), DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            }
        }
        return customDate;
    }

    /**
     * Retrieve indexing session id from job context
     *
     * @return siteName session id
     */
    public String getSessionId() {
        return chunkContext.getStepContext().getJobParameters().get(INDEXING_SESSION_ID).toString();
    }

    /**
     * @return true for MCOM false for BCOM
     */
    public boolean isMCOM() {
        return SiteName.MCOM == siteName;
    }

    public boolean isCurrentJobStopped() {
        Long jobId = chunkContext.getStepContext().getStepExecution().getJobExecution().getJobId();
        return jobId != null && stoppedJobsCache.contains(jobId);
    }
}
