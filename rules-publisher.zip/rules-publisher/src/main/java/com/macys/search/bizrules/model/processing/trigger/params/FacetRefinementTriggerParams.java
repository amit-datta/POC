package com.macys.search.bizrules.model.processing.trigger.params;

import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields;
import com.macys.search.bizrules.model.mrf.trigger.FacetRefinementMatchType;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.FacetRefinement;

@Builder
@ToString
@Getter
@EqualsAndHashCode
public class FacetRefinementTriggerParams extends AbstractTriggerParams {
    private Map<String, Set<String>> refinements;
    private FacetRefinementMatchType matchType;
    private Integer triggerId;

    @Override
    public List<ESTrigger> generateTriggers() {
        ESTrigger trigger = new ESTrigger(triggerId, FacetRefinement);
        trigger.setFieldValue(TriggerIndexFields.FRT_MATCH_TYPE, matchType);
        trigger.setFieldValue(TriggerIndexFields.FRT_REF_COUNT, refinements.size());
        for (Map.Entry<String, Set<String>> entry : refinements.entrySet()) {
            trigger.addRefinement(entry.getKey(), entry.getValue());
        }
        return Collections.singletonList(trigger);
    }
}
