package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.rule.Rule;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.model.processing.ProcessingRule;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Map;
import java.util.function.BiConsumer;

@Slf4j
public class RulesReader extends AbstractMysqlRepository {

    @Value("${rules.publisher.rules.validation.effective-date.shift.days.threshold}")
    private int effectiveDateShiftThreshold;
    @Value("${rules.publisher.rules.validation.expiration-date.shift.days.threshold}")
    private int expirationDateShiftThreshold;

    private static final BiConsumer<ResultSet, Rule> RULES_CONVERTER = (rs, rule) -> {
        try {
            rule.setId(rs.getInt("RULE_ID"));
            rule.setName(rs.getString("RULE_NAME"));
            rule.setDescription(rs.getString("RULE_DESCRIPTION"));
            rule.setEffectiveDate(rs.getDate("EFFECTIVE_DATE").toLocalDate());
            rule.setExpirationDate(rs.getDate("EXPIRATION_DATE").toLocalDate());
            rule.setAuthorName(rs.getString("CREATED_BY"));
            rule.setCreatedDate(rs.getTimestamp("CREATED").toLocalDateTime());
            rule.setLastModified(rs.getTimestamp("LAST_MODIFIED").toLocalDateTime());
            rule.setLastModifiedByName(rs.getString("LAST_MODIFIED_BY"));
            rule.setStateCode(rs.getInt("RULE_STATE_CODE"));
            rule.setPriority(rs.getInt("RULE_PRIORITY"));
            rule.setMerchRuleType(RuleType.valueOf(rs.getString("RULE_TYPE")));
        } catch (SQLException exception) {
            log.error("Error while reading action", exception);
        }
    };

    public RulesReader(DataSource mcomDataSource, DataSource bcomDataSource, boolean isStreamMode) {
        super(mcomDataSource, bcomDataSource, isStreamMode);
    }

    public void readRules(ProcessingContext ctx, LocalDate customDate, Map<Integer, ProcessingRule> rulesMap,
                          Map<Integer, Integer> expressionToRuleMapping) {
        read(ctx.getSiteName(),
                "select * from merch_rule where EFFECTIVE_DATE <= ? and ? <= EXPIRATION_DATE",
                st -> {
                    try {
                        st.setString(1, customDate.plusDays(effectiveDateShiftThreshold).toString());
                        st.setString(2, customDate.minusDays(expirationDateShiftThreshold).toString());
                    } catch (SQLException ex) {
                        log.error("Could not set parameters for rules fetching", ex);
                    }
                },
                rs -> {
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        Rule rule = new Rule();
                        RULES_CONVERTER.accept(rs, rule);
                        if (rule.getId() != null) {
                            expressionToRuleMapping.put(rs.getInt("TRIGGER_EXP_ID"), rule.getId());
                            rulesMap.put(rule.getId(), ProcessingRule.from(rule));
                        }
                    }
                }
        );

        read(ctx.getSiteName(), "select * from action_to_rule_mapping order by RULE_ID",
                rs -> {
                    ProcessingRule processingRule = null;
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        int ruleId = rs.getInt("RULE_ID");
                        int actionId = rs.getInt("ACTION_ID");
                        if (processingRule == null || !processingRule.getRuleId().equals(ruleId)) {
                            processingRule = rulesMap.get(ruleId);
                        }
                        if (processingRule != null) {
                            processingRule.getRule().getActionsIds().add(actionId);
                        }
                    }
                }
        );
    }

    public Rule getRuleById(SiteName siteName, Integer ruleId) {
        Rule rule = new Rule();
        read(siteName, "select * from merch_rule where RULE_ID = " + ruleId,
                rs -> {
                    if (rs.next()) {
                        RULES_CONVERTER.accept(rs, rule);
                    }
                }
        );
        if (rule.getId() == null) {
            return null;
        }

        read(siteName, "select * from action_to_rule_mapping where RULE_ID = " + ruleId,
                rs -> {
                    while (rs.next()) {
                        rule.getActionsIds().add(rs.getInt("ACTION_ID"));
                    }
                }
        );
        return rule;
    }

}
