package com.macys.search.bizrules.repository.elastic;

import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Set of functions to interact with Elastic Search
 */
public interface ElasticSearchFacade {

    /**
     * Create corresponding Elastic search index
     *
     * @param properties creation properties
     * @param commonIndexProperties common index properties
     * @return created index name
     */
    String createIndex(IndexCreationProperties properties, CommonIndexProperties commonIndexProperties);

    /**
     * Flush and merge indices
     *
     * @param indexName index to merge
     */
    void merge(String indexName, int maxSegmentsCount);

    /**
     * Delete indices
     *
     * @param indices indices names
     */
    void deleteIndices(String... indices);

    /**
     * Get indices starting with prefix ordered by creation date
     *
     * @param prefix prefix
     * @return list of indices names
     */
    List<String> getIndicesStartingWith(String prefix);

    /**
     * Get indices with this alias
     *
     * @param aliases collection of aliases
     * @return collection of indices
     */
    Collection<String> getIndicesWithAlias(Collection<String> aliases);

    /**
     * Switch alias to new index
     *
     * @param indexNameToAliasMapping index name: key - index, value - alias to set
     * @param aliasesToClear          list of aliases which should be cleared
     */
    void switchAlias(Map<String, String> indexNameToAliasMapping, Collection<String> aliasesToClear);
}
