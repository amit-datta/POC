package com.macys.search.annotation;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.lang.reflect.Field;

/**
 * Bean post processor for {@link ResourceMapping}
 */
@Component
@RequiredArgsConstructor
public class ResourceMappingPostProcessor implements BeanPostProcessor {

    private final ObjectMapper mapper;
    private final ResourceLoader resourceLoader;

    @Nullable
    public Object postProcessAfterInitialization(@NonNull Object bean, @NonNull String beanName) throws BeansException {
        Field[] fields = bean.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(ResourceMapping.class)) {
                ResourceMapping annotation = field.getAnnotation(ResourceMapping.class);
                field.setAccessible(true);
                try {
                    field.set(bean, readResource(annotation, field.getType()));
                } catch (IllegalAccessException | IOException e) {
                    throw new RuntimeException("Failed to load template form resource=" + annotation.value(), e);
                }
            }
        }
        return bean;
    }

    private Object readResource(ResourceMapping resourceTemplate, Class<?> clazz) throws IOException {
        Resource resource = resourceLoader.getResource(resourceTemplate.value());
        return mapper.readValue(resource.getInputStream(), clazz);
    }

}
