package com.macys.search.bizrules.model.context;

/**
 * Device type context attribute
 */
public enum DeviceType {
    DESKTOP,
    PHONE,
    TABLET,
    POS
}
