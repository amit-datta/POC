package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;

import java.util.List;
import java.util.Map;

/**
 * Action as elastic search document
 */
public class ESAction extends AbstractESEntry<ActionsIndexFields> {

    public void setDisabledReasons(Map<Integer, List<String>> reasons) {
        setFieldValueAsString(ActionsIndexFields.DISABLED_REASONS, reasons);
    }
}
