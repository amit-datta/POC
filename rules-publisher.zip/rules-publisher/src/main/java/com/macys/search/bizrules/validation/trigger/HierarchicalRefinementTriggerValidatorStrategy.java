package com.macys.search.bizrules.validation.trigger;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.CriteriaAttributesValidator;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.*;
import static org.apache.commons.lang3.StringUtils.join;

/**
 * Hierarchical Refinement trigger validation
 */
@Slf4j
@Component
public class HierarchicalRefinementTriggerValidatorStrategy implements TriggerValidationStrategy {

    @ResourceMapping("classpath:merch-validation-template/trigger/HierarchicalRefinementMatchConfig.json")
    private ConfigTemplate matchConfigCriteriaTemplate;

    @Override
    public TriggerType applicableFor() {
        return TriggerType.HierarchicalRefinement;
    }

    @Override
    public ValidationResult validate(Trigger trigger, ProcessingContext context) {
        if (!trigger.isSearchable() || trigger.isResultSetRequired()) {

            return ValidationResult.failResult("Flags isSearchable and isResultSetRequired set incorrectly");
        }

        ValidationResult result = CriteriaAttributesValidator.validateCriteriaMap(trigger.getCriteriaMap(), matchConfigCriteriaTemplate);
        if (!result.isValid()) {
            return result;
        }

        Criteria matchConfig = trigger.getCriteriaMap().get(HIERARCHICAL_REFINEMENT_CATEGORY_ID);
        List<String> categoryIdsRaw = matchConfig.getCriteriaAttributes().get(HIERARCHICAL_REFINEMENT_ATTRIBUTE_VALUE);
        Set<Integer> triggerCatIds = categoryIdsRaw
                .stream()
                .map(Integer::valueOf)
                .filter(id -> context.getCategoryTree().isPresent(id))
                .collect(Collectors.toSet());

        List<String> excludedValuesAttr = matchConfig.getCriteriaAttributes()
                .get(HIERARCHICAL_REFINEMENT_EXCLUDED_VALUE);

        Set<Integer> excludedValues = CollectionUtils.isEmpty(excludedValuesAttr)
                ? Collections.emptySet()
                : excludedValuesAttr.stream().map(Integer::valueOf).collect(Collectors.toSet());

        triggerCatIds.removeAll(excludedValues);
        if (triggerCatIds.isEmpty()) {
            Set<Integer> notLiveCategories = categoryIdsRaw
                    .stream()
                    .map(Integer::valueOf)
                    .filter(id -> !context.getCategoryTree().isPresent(id))
                    .collect(Collectors.toSet());
            return ValidationResult.failResult("HRT trigger doesn't have live categories. " +
                    "not live categories = [" + join(notLiveCategories, ", ") + "]");
        }
        return ValidationResult.validResult();
    }
}
