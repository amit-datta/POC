package com.macys.search.bizrules.converters.trigger;

import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.HRTFiringStrategy;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.model.processing.ProcessingTrigger;
import com.macys.search.bizrules.model.processing.trigger.params.AbstractTriggerParams;
import com.macys.search.bizrules.model.processing.trigger.params.HierarchicalRefinementTriggerParams;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.converters.ConverterUtils.getUnaryValue;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.*;

/**
 * Convert triggers with {@link TriggerType#HierarchicalRefinement}.
 * HierarchicalRefinement trigger should contain only one FiringStrategy.
 * HierarchicalRefinement trigger should contain at least one category id.
 * HierarchicalRefinement trigger could have empty excluded category id.
 * <p>
 * There are three types of FiringStrategy:
 * <ul>
 *     <li>Exact - set category ids value as values from trigger with filter by excluded values</li>
 *     <li>Descendants - set category ids value as values and all children from trigger with filter by excluded values</li>
 * </ul>
 */
@Component
public class HierarchicalRefinementTriggerConverter implements TriggerConverter {

    public TriggerType applicableFor() {
        return TriggerType.HierarchicalRefinement;
    }

    public AbstractTriggerParams convert(ProcessingTrigger processingTrigger, ProcessingContext ctx) {
        Trigger trigger = processingTrigger.getTrigger();
        Criteria matchConfig = trigger.getCriteriaMap().get(HIERARCHICAL_REFINEMENT_CATEGORY_ID);
        HRTFiringStrategy firingStrategy = HRTFiringStrategy.valueOf(getUnaryValue(matchConfig,
                HIERARCHICAL_REFINEMENT_FIRING_STRATEGY));

        Set<Integer> triggerCatIds = matchConfig.getCriteriaAttributes().get(HIERARCHICAL_REFINEMENT_ATTRIBUTE_VALUE)
                .stream().map(Integer::valueOf).collect(Collectors.toSet());

        List<String> excludedValuesAttr = matchConfig.getCriteriaAttributes()
                .get(HIERARCHICAL_REFINEMENT_EXCLUDED_VALUE);

        Set<Integer> excludedValues = CollectionUtils.isEmpty(excludedValuesAttr)
                ? Collections.emptySet()
                : excludedValuesAttr.stream().map(Integer::valueOf).collect(Collectors.toSet());

        triggerCatIds.removeAll(excludedValues);
        if (firingStrategy == HRTFiringStrategy.Exact) {
            return HierarchicalRefinementTriggerParams.builder()
                    .catIds(triggerCatIds)
                    .triggerId(trigger.getId())
                    .strategy(HRTFiringStrategy.Exact)
                    .excludedCatIds(excludedValues)
                    .build();
        }

        if (firingStrategy == HRTFiringStrategy.Descendants) {
            Set<Integer> result = new HashSet<>(triggerCatIds);
            for (Integer catId : triggerCatIds) {
                result.addAll(ctx.getCategoryTree().getChildren(catId, excludedValues));
            }
            return HierarchicalRefinementTriggerParams.builder()
                    .catIds(result)
                    .triggerId(trigger.getId())
                    .strategy(HRTFiringStrategy.Descendants)
                    .excludedCatIds(excludedValues)
                    .build();
        }

        throw new RuntimeException("No such Firing Strategy: " + firingStrategy.name());
    }

}
