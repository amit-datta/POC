package com.macys.search.bizrules.model.elastic.mappings;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.*;

/**
 * Fields for Trigger index
 */
@Getter
@AllArgsConstructor
public enum TriggerIndexFields implements ElasticSearchBaseFields {
    TRIGGER_ID("trigger_id", LONG.getProperties()),
    TRIGGER_NATURAL_ID("trigger_natural_id", LONG.getProperties()),
    TRIGGER_TYPE("trigger_type", KEYWORD.getProperties()),
    // FRT
    FRT_MATCH_TYPE("frt_match_type", KEYWORD.getProperties()),
    FRT_REF_COUNT("frt_ref_count", LONG.getProperties()),
    // HRT triggers
    CATEGORY_ID("category_id", LONG.getProperties()),
    EXCLUDED_CATEGORY_ID("excluded_category_id", LONG.getProperties()),
    // HRT triggers and KWP
    MATCH_TYPE("match_type", KEYWORD.getProperties()),

    // KWP
    TRIGGER_QUERY("trigger_query", PERCOLATOR.getProperties()),
    PHRASE_EXACT("phrase_exact", TEXT.getProperties()),
    PHRASE_CONTAINS("phrase_contains", TEXT.getProperties()),
    PHRASE_LITERAL("phrase_literal", TEXT.getProperties()),
    PERCOLATOR_FILTER("percolator_filter", TEXT.getProperties()),
    KEYWORD_PATTERN_PREVIEW("keyword_pattern_preview", KEYWORD.getProperties());

    private final String fieldName;
    private final Map<String, Object> properties;
}
