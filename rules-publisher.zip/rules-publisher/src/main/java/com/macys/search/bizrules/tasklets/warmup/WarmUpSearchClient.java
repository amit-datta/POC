package com.macys.search.bizrules.tasklets.warmup;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.admin.indices.refresh.RefreshRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class WarmUpSearchClient {

    private final WarmUpQueryBuilder warmUpQueryBuilder;

    private final RestHighLevelClient client;
    private final RequestOptions warmupRequestOptions;

    public SearchResponse search(WarmUpRequest warmUpRequest, String indexName) {
        SearchSourceBuilder sourceBuilder = warmUpQueryBuilder.build(warmUpRequest);
        SearchRequest request = new SearchRequest(indexName);
        request.source(sourceBuilder);
        try {
            return client.search(request, warmupRequestOptions);
        } catch (IOException ex) {
            log.error("Exception during query to elasticsearch. Query=" + request.source(), ex);
        }
        return null;
    }

    public void refresh(String indexName) {
        RefreshRequest request = new RefreshRequest(indexName);
        try {
            client.indices().refresh(request, warmupRequestOptions);
        } catch (IOException ex) {
            log.error("Exception during refresh request to elasticsearch. IndexName=" + indexName, ex);
        }
    }
}
