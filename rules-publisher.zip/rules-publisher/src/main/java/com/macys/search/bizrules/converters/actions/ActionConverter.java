package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;

/**
 * Convert {@link Action} representation to {@link ESAction}
 */
interface ActionConverter {

    /**
     * @return {@link ActionType} the converter valid for
     */
    ActionType applicableFor();

    /**
     * Create elastic search representation according to action type
     *
     * @param processingAction input action
     * @return elastic search representation of action
     */
    ESAction convert(Action processingAction, ProcessingContext context);
}
