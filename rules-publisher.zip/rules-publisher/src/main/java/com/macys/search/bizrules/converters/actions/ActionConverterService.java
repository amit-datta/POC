package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.List;

/**
 * Chooses correct converter for action
 */
@Service
public class ActionConverterService {

    private final EnumMap<ActionType, ActionConverter> convertersMap = new EnumMap<>(ActionType.class);

    @Autowired
    public ActionConverterService(
            List<ActionConverter> converters,
            @Value("${rules.publisher.enabled.action-types}") List<ActionType> enabledActions) {
        converters.stream()
                .filter(converter -> enabledActions.contains(converter.applicableFor()))
                .forEach(converter -> convertersMap.put(converter.applicableFor(), converter));
        if (!convertersMap.keySet().containsAll(enabledActions)) {
            throw new RuntimeException(MessageFormat.format("Some of action converters have not implemented yet. Enabled action types={0}" +
                    " Implemented converters types={1}", enabledActions, convertersMap.keySet()));
        }
    }

    /**
     * Chooses correct action converter implementation and invoke {@link ActionConverter#convert(Action, ProcessingContext)}
     *
     * @param action input action
     * @return elastic search representation of action
     */
    public ESAction convert(Action action, ProcessingContext context) {
        ActionConverter converter = convertersMap.get(action.getMerchActionType());
        return converter.convert(action, context);
    }
}
