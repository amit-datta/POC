package com.macys.search.bizrules.dto;

import lombok.Getter;
import org.joda.time.LocalDateTime;
import org.springframework.batch.core.JobExecution;

@Getter
public class StartFullReindexingResponse {

    private Long executionId;
    private String startTime;

    public static StartFullReindexingResponse of(JobExecution jobExecution) {
        StartFullReindexingResponse result = new StartFullReindexingResponse();
        result.executionId = jobExecution.getId();
        result.startTime = LocalDateTime.now().toString();
        return result;
    }

}