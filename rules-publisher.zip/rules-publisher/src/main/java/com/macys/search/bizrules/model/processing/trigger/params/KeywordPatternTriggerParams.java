package com.macys.search.bizrules.model.processing.trigger.params;

import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.trigger.KWPMatchType;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.QueryBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields.*;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerType.KeywordPattern;

@Builder
@ToString
@Getter
@EqualsAndHashCode
@Slf4j
public class KeywordPatternTriggerParams extends AbstractTriggerParams {

    @Getter
    @ToString
    @EqualsAndHashCode
    @AllArgsConstructor
    public static class KWPNode {
        private QueryBuilder query;
        private Set<String> percolatorFilter;
    }

    @Getter
    private List<KWPNode> nodes;
    private Integer triggerId;

    private KWPMatchType matchType;
    private BooleanOperation operationType;

    private String keywordPatternPreview;

    @Override
    public List<ESTrigger> generateTriggers() {
        List<ESTrigger> result = new ArrayList<>(nodes.size());
        int disjunctionIndex = 0;
        for (KWPNode node : nodes) {
            ESTrigger trigger = new ESTrigger(triggerId, KeywordPattern, String.valueOf(disjunctionIndex++));
            trigger.setFieldValue(TRIGGER_QUERY, node.query);
            trigger.setFieldValue(PERCOLATOR_FILTER, node.percolatorFilter);
            trigger.setFieldValue(KEYWORD_PATTERN_PREVIEW, keywordPatternPreview);
            trigger.setFieldValue(MATCH_TYPE, matchType.name());
            result.add(trigger);
        }
        return result;
    }

    @Override
    public boolean hasPercolator() {
        return true;
    }

}
