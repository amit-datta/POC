package com.macys.search.config;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.cache.CategoriesCache;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CategoriesCacheConfiguration {
    private final CategoryLoader categoryLoader;
    private final String categoriesSource;

    @Value("${rules.publisher.categories.cache.update-on-startup}")
    private boolean categoriesCacheKillSwitch;

    public CategoriesCacheConfiguration(CategoryLoader categoryLoader,
                                        @Value("${rules.publisher.load.categories.from}")
                                                String categoriesSource) {
        this.categoryLoader = categoryLoader;
        this.categoriesSource = categoriesSource;
    }

    @Bean
    public CategoriesCache bcomCategoriesCache() {
        return new CategoriesCache(SiteName.BCOM, categoryLoader, categoriesSource, categoriesCacheKillSwitch);
    }

    @Bean
    public CategoriesCache mcomCategoriesCache() {
        return new CategoriesCache(SiteName.MCOM, categoryLoader, categoriesSource, categoriesCacheKillSwitch);
    }
}
