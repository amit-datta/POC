package com.macys.search.bizrules.catalog.fcc;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.macys.search.bizrules.catalog.fcc.FccField.of;

@Configuration
public class FccConfiguration {

    @Bean
    public Collection<FccField> fccProductFields() {
        return Stream.of(
                of("id"),
                of("name"),
                of("price", List.of(of("newMarkdown"), of("retailPrice"), of("priceType"))),
                of("isNew"),
                of("memberProducts"),
                of("categories", List.of(of("id"))),
                of("pools", List.of(of("id"), of("seqNumber"))),
                of("upcs",
                        List.of(
                                of("id"),
                                of("upc"),
                                of("price", List.of(of("retailPrice"), of("priceType"))),
                                of("active"),
                                of("availability", List.of(of("available")))
                        )
                ),
                of("typeName"),
                of("productGroup"),
                of("active"),
                of("attributes"),
                of("masterProductIds"),
                of("visible"),
                of("countryExclusion"),
                of("reviewStatistics"),
                of("metrics"),
                of("primaryPortraitSource"),
                of("canonicalProductUrl"),
                of("startDate"),
                of("effectiveDate"),
                of("firstAvailableDate"),
                of("newnessDays"),
                of("colorwayUpcCount"),
                of("originalPriceHigh"),
                of("retailPriceHigh")
        ).collect(Collectors.toCollection(LinkedList::new));
    }

    @Bean
    public Collection<FccField> fccLightProductFields() {
        return Stream.of(
                of("id"),
                of("name"),
                of("price", List.of(of("newMarkdown"), of("retailPrice"), of("priceType"))),
                of("isNew"),
                of("memberProducts"),
                of("categories", List.of(of("id"))),
                of("pools", List.of(of("id"), of("seqNumber"))),

                of("upcs",
                        List.of(
                                of("id"),
                                of("upc"),
                                of("price", List.of(of("retailPrice"), of("priceType"))),
                                of("active"),
                                of("availability", List.of(of("available")))
                        )
                )
        ).collect(Collectors.toCollection(LinkedList::new));
    }

    @Bean
    public Collection<FccField> fccCategoryFields() {
        return Stream.of(
                of("id"),
                of("name"),
                of("parentCategoryId"),
                of("externalHostUrl"),
                of("attributes"),
                of("countryExclusion"),
                of("sequenceNumber"),
                of("contextOverrides")
        ).collect(Collectors.toCollection(LinkedList::new));
    }

    @Bean
    public Collection<FccField> fccLightCategoryFields() {
        return Stream.of(
                of("id"),
                of("name"),
                of("parentCategoryId"),
                of("externalHostUrl"),
                of("attributes")
        ).collect(Collectors.toCollection(LinkedList::new));
    }
}
