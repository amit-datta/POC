package com.macys.search.bizrules.model.context;

/**
 * CustomerExperiment context attribute
 */
public enum CustomerExperiment {
    A,
    B,
    C,
    D,
    E,
    F,
    L,
    NO_EXPERIMENT,
    CONTROL
}
