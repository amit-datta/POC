package com.macys.search;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RulesPublisherApplication {
    public static void main(String[] args) {
        SpringApplication.run(RulesPublisherApplication.class, args);
    }

}
