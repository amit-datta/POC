package com.macys.search.bizrules.model.elastic.mappings;

import java.util.Map;

/**
 * Base class for all Elastic search indexes mappings to standardize them and use
 * semi-automatic mapping creation
 */
public interface ElasticSearchBaseFields {

    /**
     * @return field name in elastic index
     */
    String getFieldName();

    /**
     * @return unmodifiable map with field properties
     */
    Map<String, Object> getProperties();

}
