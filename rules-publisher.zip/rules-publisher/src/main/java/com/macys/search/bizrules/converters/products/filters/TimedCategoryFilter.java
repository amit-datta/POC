package com.macys.search.bizrules.converters.products.filters;

import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryAttribute;
import com.macys.search.bizrules.model.product.Product;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Set;

import static com.macys.search.bizrules.model.category.CategoryAttributeName.TIMED_FILTER;

@Slf4j
@Component
public class TimedCategoryFilter implements CategoryFilter {

    @Override
    public boolean pass(Category category, Product product) {
        CategoryAttribute attribute = category.getAttributes().get(TIMED_FILTER);
        if (attribute != null) {
            Set<String> values = attribute.getValues();
            if (values.size() != 1) {
                log.warn("Category {} has multiple values of TIMED_FILTER attribute: {}. " +
                        "All of them were ignored.", category.getId(), values);
            } else {
                switch (attribute.getUnaryValue()) {
                    case "New Arrivals":
                        return product.isNew();
                    case "New Markdowns":
                        return product.isNewMarkdown();
                }
            }
        }
        return true;
    }

    @Override
    public boolean isSelfBased() {
        return true;
    }

}
