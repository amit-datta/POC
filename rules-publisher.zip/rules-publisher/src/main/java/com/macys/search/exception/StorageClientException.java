package com.macys.search.exception;

public class StorageClientException extends Exception {
    public StorageClientException(String message) {
        super(message);
    }
    public StorageClientException(String message, Throwable cause) {
        super(message, cause);
    }
}
