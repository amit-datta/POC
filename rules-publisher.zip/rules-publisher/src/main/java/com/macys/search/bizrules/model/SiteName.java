package com.macys.search.bizrules.model;

public enum SiteName {
    MCOM, BCOM
}
