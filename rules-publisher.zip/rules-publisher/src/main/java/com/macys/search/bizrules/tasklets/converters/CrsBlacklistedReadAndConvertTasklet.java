package com.macys.search.bizrules.tasklets.converters;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.macys.search.analysis.PhraseAnalyzer;
import com.macys.search.analysis.PhraseAnalyzerFactory;
import com.macys.search.bizrules.model.elastic.ESIndex;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.entries.ESRule;
import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.rule.RuleType;
import com.macys.search.bizrules.model.processing.trigger.params.KeywordPatternTriggerParams;
import com.macys.search.bizrules.repository.elastic.ElasticSearchIndexer;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.utils.QueryBuildingUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import static com.macys.search.bizrules.model.elastic.ESIndex.*;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.*;
import static com.macys.search.bizrules.model.mrf.action.ESActionType.SPECIAL_INSTRUCTION;
import static com.macys.search.bizrules.model.mrf.trigger.KWPMatchType.Literal;

/**
 * Tasklet reads phrases from special file from google storage and creates literal triggered
 * SpecialInstruction actions with crs_blacklisted field with true value
 */
@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(value = "rules.publisher.reading.blacklisted-phrases.enabled", havingValue = "true")
public class CrsBlacklistedReadAndConvertTasklet implements RulesPublisherTasklet {

    private static final String CRS_BLACKLISTED = "CrsBlacklisted";

    private final PhraseAnalyzerFactory phraseAnalyzerFactory;
    private final Storage storage;

    @Value("${blacklisted-phrases.mcom.storage.object}")
    private String mcomBlacklistPhrasesObject;
    @Value("${blacklisted-phrases.bcom.storage.object}")
    private String bcomBlacklistPhrasesObject;
    @Value("${rules.storage.bucket}")
    private String bucketName;

    public void execute(ProcessingContext ctx) {
        Set<String> phrases = readPhrasesFromFile(ctx.isMCOM() ? mcomBlacklistPhrasesObject : bcomBlacklistPhrasesObject);

        ESAction esAction = generateAction(chooseFreeId(ctx.getActions()));
        ESRule esRule = generateRule(chooseFreeId(ctx.getRules()));
        List<ESTrigger> triggers = generateTrigger(chooseFreeId(ctx.getTriggers()), phrases);

        persist(ctx, esRule, esAction, triggers);
    }

    private void persist(ProcessingContext ctx, ESRule esRule, ESAction esAction, List<ESTrigger> triggers) {
        ElasticSearchIndexer rulesIndexer = ctx.getIndexers().get(RULES);
        rulesIndexer.add(esRule);
        ElasticSearchIndexer actionsIndexer = ctx.getIndexers().get(ACTIONS);
        actionsIndexer.add(esAction);
        ElasticSearchIndexer kwpTriggersIndexer = ctx.getIndexers().get(KWP_TRIGGERS);
        for (ESTrigger trigger : triggers) {
            kwpTriggersIndexer.add(trigger);
        }
        flush(ctx, RULES, ACTIONS, KWP_TRIGGERS);
    }

    private ESRule generateRule(Integer ruleId) {
        ESRule doc = new ESRule();
        doc.setFieldValue(RulesIndexFields.RULE_ID, ruleId);
        doc.setFieldValue(RulesIndexFields.RULE_NATURAL_ID, 0);
        doc.setFieldValue(RulesIndexFields.RULE_TYPE, RuleType.SEO);
        doc.setFieldValue(RulesIndexFields.RULE_NAME, CRS_BLACKLISTED);
        doc.setFieldValue(RulesIndexFields.RULE_ENABLED, true);
        doc.setFieldValue(RulesIndexFields.RULE_PRIORITY, 0);

        doc.setFieldValue(RulesIndexFields.RULE_EFFECTIVE_DATE, MIN_DATE);
        doc.setFieldValue(RulesIndexFields.RULE_EXPIRATION_DATE, MAX_DATE);
        doc.setFieldValue(RulesIndexFields.RULE_LAST_MODIFICATION_DATE, MIN_DATE_TIME);

        return doc;
    }

    private static Integer chooseFreeId(Map<Integer, ?> map) {
        for (int i = 0; i < Integer.MAX_VALUE; i++) {
            if (!map.containsKey(i)) {
                return i;
            }
        }
        throw new RuntimeException("Quite strange but there is no fee id");
    }

    private List<ESTrigger> generateTrigger(Integer triggerId, Set<String> phrases) {
        List<KeywordPatternTriggerParams.KWPNode> kwpNodes = phrases.stream()
                .map(phrase -> new KeywordPatternTriggerParams.KWPNode(
                        QueryBuildingUtils.literalQueryBuilder.apply(phrase), Set.of(phrase))
                )
                .collect(Collectors.toList());
        KeywordPatternTriggerParams params = KeywordPatternTriggerParams.builder()
                .nodes(kwpNodes)
                .operationType(BooleanOperation.OR)
                .matchType(Literal)
                .triggerId(triggerId)
                .build();
        return params.generateTriggers();
    }

    private ESAction generateAction(Integer actionId) {
        ESAction doc = new ESAction();
        doc.setFieldValue(ActionsIndexFields.ACTION_ID, actionId);
        doc.setFieldValue(ActionsIndexFields.ACTION_TYPE, SPECIAL_INSTRUCTION);
        doc.setFieldValue(ActionsIndexFields.CRS_BLACKLISTED, true);

        return doc;
    }

    private Set<String> readPhrasesFromFile(String fileName) {
        Set<String> phrases = new HashSet<>();
        log.info("RulesStorageBucketHandler: Reading blacklisted phrases from storage bucket");
        Blob blob = storage.get(BlobId.of(bucketName, fileName));
        if (blob == null) {
            throw new RuntimeException("Couldn't find " + fileName + " in Google storage");
        }
        Scanner scanner = new Scanner(new ByteArrayInputStream(blob.getContent()), StandardCharsets.UTF_8)
                .useDelimiter(",");

        PhraseAnalyzer literalPhraseAnalyzer = phraseAnalyzerFactory.createLiteralPhraseAnalyzer();
        while (scanner.hasNext()) {
            phrases.add(literalPhraseAnalyzer.analise(scanner.next()));
        }
        log.info("RulesStorageBucketHandler: Read " + phrases.size() + " phrases from " + fileName);
        return phrases;
    }

    private void flush(ProcessingContext ctx, ESIndex... indexNames) {
        for (ESIndex indexName : indexNames) {
            if (!ctx.getIndexers().get(indexName).flush()) {
                throw new RuntimeException("Exception occurred during " + indexName + " indexing. " +
                        "Check logs for additional information");
            }
        }
    }

}
