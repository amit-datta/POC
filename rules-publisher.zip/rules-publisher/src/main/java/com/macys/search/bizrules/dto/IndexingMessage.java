package com.macys.search.bizrules.dto;

import com.macys.search.bizrules.enums.PubSubProcessType;
import lombok.Data;

import java.io.Serializable;

@Data
public class IndexingMessage implements Serializable {
    private String siteName;
    private String sessionId;
    private PubSubProcessType processType;
}