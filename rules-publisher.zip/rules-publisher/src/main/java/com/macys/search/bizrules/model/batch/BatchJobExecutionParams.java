package com.macys.search.bizrules.model.batch;

import lombok.Data;

import java.sql.Date;

@Data
public class BatchJobExecutionParams {
    private Long jobExecutionId;
    private String typeCd;
    private String keyName;
    private String stringVal;
    private Date dateVal;
    private Long longVal;
    private Double doubleVal;
    private String identifying;
}