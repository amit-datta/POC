package com.macys.search.config.indexes;

import com.macys.search.bizrules.model.elastic.mappings.ProductIndexFields;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.IndexCreationProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.macys.search.bizrules.model.elastic.ESIndex.PRODUCTS;
import static com.macys.search.config.utils.ESIndicesUtils.fullAliasNameFrom;

@Configuration
public class ESProductsIndexConfiguration extends AbstractElasticIndexConfiguration {

    @Value("${rules.publisher.mcom.products.alias.name}")
    private String mcomAliasName;
    @Value("${rules.publisher.mcom.products.number-of-shards:1}")
    private int mcomShardsCount;
    @Value("${rules.publisher.mcom.products.number-of-replicas:0}")
    private int mcomReplicasCount;

    @Value("${rules.publisher.bcom.products.alias.name}")
    private String bcomAliasName;
    @Value("${rules.publisher.bcom.products.number-of-shards:1}")
    private int bcomShardsCount;
    @Value("${rules.publisher.bcom.products.number-of-replicas:0}")
    private int bcomReplicasCount;

    @Bean
    public CreateIndexTasklet createProductsIndexTasklet(ElasticSearchFacade elasticSearchFacade) {
        return new CreateIndexTasklet(elasticSearchFacade,
                mcomProductsIndexCreationProperties(), bcomProductsIndexCreationProperties(),
                mcomCommonIndexProperties, bcomCommonIndexProperties,
                indexerFactory, PRODUCTS);
    }

    private IndexCreationProperties mcomProductsIndexCreationProperties() {
        return new IndexCreationProperties(fullAliasNameFrom(mcomAliasName, indexVersion),
                mcomShardsCount, mcomReplicasCount, ProductIndexFields.class, null);
    }

    private IndexCreationProperties bcomProductsIndexCreationProperties() {
        return new IndexCreationProperties(fullAliasNameFrom(bcomAliasName, indexVersion),
                bcomShardsCount, bcomReplicasCount, ProductIndexFields.class, null);
    }

    @Bean
    public SwitchAliasProperties productsSwitchAliasProperties() {
        return SwitchAliasProperties.of(
                PRODUCTS,
                mcomAliasName, bcomAliasName,
                indexVersion,
                1
        );
    }
}
