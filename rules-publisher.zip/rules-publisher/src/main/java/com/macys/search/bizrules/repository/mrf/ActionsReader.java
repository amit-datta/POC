package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionParameter;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.processing.ProcessingAction;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

@Slf4j
public class ActionsReader extends AbstractMysqlRepository {

    private static final BiConsumer<ResultSet, Action> ACTION_CONVERTER = (rs, action) -> {
        try {
            action.setId(rs.getInt("ACTION_ID"));
            action.setLastModified(rs.getDate("LAST_MODIFIED").toLocalDate());
            action.setCreatedDate(rs.getDate("CREATED").toLocalDate());
            action.setLastModifiedByName(rs.getString("LAST_MODIFIED_BY"));
            action.setMerchActionType(ActionType.valueOf(rs.getString("ACTION_TYPE")));
        } catch (SQLException exception) {
            log.error("Error while reading action", exception);
        }
    };

    private static final BiConsumer<ResultSet, ActionParameter> ACTION_PARAMETER_CONVERTER = (rs, param) -> {
        try {
            param.setGroup(rs.getString("PARAM_GROUP"));
            param.setName(rs.getString("PARAM_NAME"));
            param.setValue(rs.getString("PARAM_VALUE"));

            param.setSequenceNumber(rs.getInt("PARAM_SEQ_NBR"));
            param.setGroupSequenceNumber(rs.getInt("PARAM_GROUP_SEQ_NBR"));
            param.setEffectiveDate(rs.getDate("EFFECTIVE_DATE").toLocalDate());
            param.setExpirationDate(rs.getDate("EXPIRATION_DATE").toLocalDate());
        } catch (SQLException exception) {
            log.error("Error while reading action param", exception);
        }
    };

    public ActionsReader(DataSource mcomDataSource, DataSource bcomDataSource, boolean isStreamMode) {
        super(mcomDataSource, bcomDataSource, isStreamMode);
    }

    public void readActions(ProcessingContext ctx, List<ActionType> actionTypes, Map<Integer, ProcessingAction> actions) {
        read(ctx.getSiteName(),
                "select * from merch_action where ACTION_TYPE in (" + paramSymbolsGenerator.apply(actionTypes.size()) + ")",
                statement -> fillStringsInStatement(statement, actionTypes),
                rs -> {
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        Action action = new Action();
                        ACTION_CONVERTER.accept(rs, action);
                        if (action.getId() != null) {
                            actions.put(action.getId(), ProcessingAction.from(action));
                        }
                    }
                });

        read(ctx.getSiteName(), "select * from merch_action_parameter order by ACTION_ID",
                rs -> {
                    ProcessingAction processingAction = null;
                    while (rs.next() && !ctx.isCurrentJobStopped()) {
                        ActionParameter param = new ActionParameter();
                        ACTION_PARAMETER_CONVERTER.accept(rs, param);
                        Integer actionId = rs.getInt("ACTION_ID");
                        if (processingAction == null || !processingAction.getId().equals(actionId)) {
                            processingAction = actions.get(actionId);
                        }
                        if (processingAction != null) {
                            processingAction.getAction().getParams().add(param);
                        }
                    }
                }
        );
    }

    public Action getActionsById(SiteName siteName, Integer actionId, List<ActionType> actionTypes) {
        Action action = new Action();
        read(siteName,
                "select * from merch_action where ACTION_ID=" + actionId + " AND ACTION_TYPE in ("
                        + paramSymbolsGenerator.apply(actionTypes.size()) + ")",
                statement -> fillStringsInStatement(statement, actionTypes),
                rs -> {
                    if (rs.next()) {
                        ACTION_CONVERTER.accept(rs, action);
                    }
                });
        if (action.getId() == null) {
            return null;
        }

        read(siteName, "select * from merch_action_parameter where ACTION_ID=" + actionId,
                rs -> {
                    while (rs.next()) {
                        ActionParameter param = new ActionParameter();
                        ACTION_PARAMETER_CONVERTER.accept(rs, param);
                        action.getParams().add(param);
                    }
                }
        );
        return action;
    }
}
