package com.macys.search.bizrules.repository.elastic;

import org.springframework.lang.NonNull;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * {@link ThreadFactory} for {@link ThreadGroup} using for
 * asynchronous bulk indexing requests into elastic search
 */
public class IndexerThreadFactory implements ThreadFactory {
    private final static String THREAD_NAME_PREFIX = "ES-INDEXING_THREAD-";
    private final ThreadGroup group = new ThreadGroup("es-indexing-group");
    private final AtomicInteger threadNumber = new AtomicInteger(1);

    public Thread newThread(@NonNull Runnable r) {
        Thread t = new Thread(group, r, THREAD_NAME_PREFIX + threadNumber.getAndIncrement(), 0);
        if (t.isDaemon()) t.setDaemon(false);
        if (t.getPriority() != Thread.NORM_PRIORITY) t.setPriority(Thread.NORM_PRIORITY);
        return t;
    }
}
