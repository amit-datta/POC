package com.macys.search.bizrules.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class IndexingStatusResponse {
    private String overallStatus;
    private String startTime;
    private Object endTime;
    private List<GetJobStatusResponse> executions;
}
