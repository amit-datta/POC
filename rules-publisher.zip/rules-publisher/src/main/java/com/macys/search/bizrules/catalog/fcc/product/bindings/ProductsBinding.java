package com.macys.search.bizrules.catalog.fcc.product.bindings;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Collection;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductsBinding {
    private Collection<ProductBinding> product;
}
