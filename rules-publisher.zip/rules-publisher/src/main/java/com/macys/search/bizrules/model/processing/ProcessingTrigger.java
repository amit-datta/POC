package com.macys.search.bizrules.model.processing;

import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.validation.ValidationResult;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import static java.util.Objects.requireNonNull;

/**
 * Model class to storing all significant information around one Trigger
 */
@Getter
@Setter
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class ProcessingTrigger {
    private Trigger trigger;
    private ValidationResult validationResult;

    private boolean isProcessed;
    private boolean isIndexed;

    private ProcessingTrigger(Trigger trigger) {
        this.trigger = requireNonNull(trigger);
    }

    public static ProcessingTrigger from(Trigger trigger) {
        return new ProcessingTrigger(trigger);
    }

    public TriggerType getTriggerType() {
        return trigger.getMerchTriggerType();
    }

    public boolean isValid() {
        return validationResult.isValid();
    }

    public Integer getId() {
        return trigger.getId();
    }

    public TriggerType getType() {
        return trigger.getMerchTriggerType();
    }
}
