package com.macys.search.bizrules.converters.actions;

import com.macys.search.bizrules.converters.ConverterUtils;
import com.macys.search.bizrules.model.elastic.entries.ESAction;
import com.macys.search.bizrules.model.elastic.mappings.ActionsIndexFields;
import com.macys.search.bizrules.model.mrf.action.Action;
import com.macys.search.bizrules.model.mrf.action.ActionType;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.model.mrf.action.ActionConstants.SHOW_MEDIA_CANVAS;
import static com.macys.search.bizrules.model.mrf.action.ActionConstants.SHOW_MEDIA_CANVAS_ID;

/**
 * {@link ActionConverter} implementation for {@link ActionType#ShowMedia} type
 */
@Slf4j
@Component
class ShowMediaConverter extends AbstractActionConverter {
    @Override
    public ActionType applicableFor() {
        return ActionType.ShowMedia;
    }

    @Override
    void enrichWithTypeSpecificProperties(Action action, ESAction doc, ProcessingContext context) {
        doc.setFieldValue(ActionsIndexFields.ACTION_TYPE, ESActionType.SHOW_MEDIA);
        String value = ConverterUtils.getUnaryValue(action, SHOW_MEDIA_CANVAS, SHOW_MEDIA_CANVAS_ID);
        doc.setFieldValue(ActionsIndexFields.CANVAS_ID, Integer.valueOf(value));
    }
}
