package com.macys.search.config;

import com.macys.search.bizrules.tasklets.InitProcessingContextTasklet;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.tasklets.SessionTrackerListener;
import com.macys.search.bizrules.tasklets.cache.UpdateCachesTasklet;
import com.macys.search.bizrules.tasklets.category.CategoryIndexingTasklet;
import com.macys.search.bizrules.tasklets.category.LoadCategoriesTasklet;
import com.macys.search.bizrules.tasklets.converters.BizControlsConverterTasklet;
import com.macys.search.bizrules.tasklets.esmanaging.CreateIndexTasklet;
import com.macys.search.bizrules.tasklets.esmanaging.RemoveIndicesTasklet;
import com.macys.search.bizrules.tasklets.esmanaging.RemoveInvalidIndices;
import com.macys.search.bizrules.tasklets.esmanaging.SwitchAliasTasklet;
import com.macys.search.bizrules.tasklets.merch.*;
import com.macys.search.bizrules.tasklets.product.ProductsProcessingTasklet;
import com.macys.search.bizrules.tasklets.warmup.ElasticCachesWarmUp;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.DuplicateJobException;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.support.ReferenceJobFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.builder.FlowJobBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.batch.BatchDataSourceInitializer;
import org.springframework.boot.autoconfigure.batch.BatchProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;

import javax.sql.DataSource;
import java.util.List;

@Slf4j
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class BatchProcessingConfiguration {
    @Value("${rules.publisher.mrf.reading.threads-count}")
    private int readMRFThreadsCount;

    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;

    private final SessionTrackerListener sessionTrackerListener;

    private final InitProcessingContextTasklet initProcessingContextTasklet;
    private final RemoveInvalidIndices removeInvalidIndices;
    // merch flow
    private final ActionsReaderTasklet actionsReaderTasklet;
    private final TriggersReaderTasklet triggersReaderTasklet;
    private final RulesReaderTasklet rulesReaderTasklet;
    private final MRFProcessingTasklet mrfProcessingTasklet;
    private final FacetsReaderTasklet facetsReaderTasklet;
    // categories flow
    private final LoadCategoriesTasklet loadCategoriesTasklet;
    private final CategoryIndexingTasklet categoryInstructionIndexingTasklet;
    // products flow
    private final ProductsProcessingTasklet productsProcessingTasklet;
    // elastic managers
    private final ElasticCachesWarmUp elasticCachesWarmUp;
    private final ClearMRFData clearMRFData;
    private final List<CreateIndexTasklet> createIndexesTasklet;

    private final SwitchAliasTasklet switchAliasTasklet;
    private final RemoveIndicesTasklet removeIndicesTasklet;
    private final BizControlsConverterTasklet bizControlsConverterTasklet;

    private final UpdateCachesTasklet updateCachesTasklet;

    @Value("${rules.publisher.reading.blacklisted-phrases.enabled:false}")
    private boolean crsBlacklistedKillSwitch;

    private final RulesPublisherTasklet crsBlacklistedProcessingTasklet;

    private final JobRegistry jobRegistry;

    @Bean
    BatchDataSourceInitializer batchDataSourceInitializer(DataSource dataSource,
                                                          ResourceLoader resourceLoader,
                                                          BatchProperties properties) {
        return new BatchDataSourceInitializer(dataSource, resourceLoader, properties);
    }

    @Bean
    BatchConfigurer configurer(DataSource dataSource) throws Exception {
        return new BizBatchConfigurer(dataSource);
    }

    private TaskExecutor taskExecutor() {
        SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor("full_reindexing_thread");
        taskExecutor.setConcurrencyLimit(readMRFThreadsCount);
        return taskExecutor;
    }

    private void addCreateIndexesSteps(FlowBuilder<FlowJobBuilder> flowBuilder) {
        for (CreateIndexTasklet t : createIndexesTasklet) {
            flowBuilder.next(step("create " + t.getIndexType().name() + " index", t));
        }
    }

    @Bean
    public Job ruleFullReindexJob() {
        FlowBuilder<FlowJobBuilder> flowBuilder = jobBuilderFactory.get("full-reindex-job")
                .incrementer(new RunIdIncrementer())
                .listener(sessionTrackerListener)
                .flow(step("Init context", initProcessingContextTasklet))
                .next(step("Remove invalid indices", removeInvalidIndices));

        addCreateIndexesSteps(flowBuilder);

        flowBuilder.next(
                concurrentFlow("Read data",
                        flow("read actions", actionsReaderTasklet),
                        flow("read triggers", triggersReaderTasklet),
                        flow("read rules", rulesReaderTasklet),
                        flow("load categories", loadCategoriesTasklet),
                        flow("load facets", facetsReaderTasklet)
                )

        );
        if (crsBlacklistedKillSwitch) {
            flowBuilder.next(flow("CRS blacklisted reading and indexing", crsBlacklistedProcessingTasklet));
        }
        Step switchAliasStep = step("Switch index aliases", switchAliasTasklet);
        flowBuilder.next(
                        concurrentFlow("Process data",
                                flow("MRF processing", mrfProcessingTasklet),
                                flow("indexing category", categoryInstructionIndexingTasklet),
                                flow("Biz controls indexing", bizControlsConverterTasklet),
                                flow("Update categories cache", updateCachesTasklet)
                        )
                )
                .next(step("warmup es cache", elasticCachesWarmUp))
                .next(step("clear MFR data", clearMRFData))

                //this step is quite hard. Let's run it alone for easy defect root cause analysis
                .next(step("load and index products", productsProcessingTasklet))

                .next(switchAliasStep)
                .from(switchAliasStep).on("FAILED").to(
                        step("Remove created indices", removeIndicesTasklet)
                )
                .build();

        Job job = flowBuilder.build().build();
        registerJob(job);
        return job;
    }

    private void registerJob(Job job) {
        ReferenceJobFactory jobFactory = new ReferenceJobFactory(job);
        try {
            jobRegistry.register(jobFactory);
        } catch (DuplicateJobException e) {
            e.printStackTrace();
        }
    }

    private Step step(String name, Tasklet tasklet) {
        return stepBuilderFactory.get(name).tasklet(tasklet).listener(sessionTrackerListener).build();
    }

    private Flow flow(String name, Tasklet tasklet) {
        return new FlowBuilder<SimpleFlow>(name + " flow")
                .start(step(name, tasklet))
                .build();
    }

    public Flow concurrentFlow(String name, Flow... flows) {
        return new FlowBuilder<Flow>(name)
                .split(taskExecutor())
                .add(flows)
                .build();
    }

}
