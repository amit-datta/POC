package com.macys.search.handler;

import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.macys.search.cache.RedisCacheUtil;
import com.macys.search.exception.StorageClientException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Component
@ConditionalOnProperty(
        value = {
                "spring.redis.enabled",
                "rules.publisher.load.rules.from.pubsub"
        },
        havingValue = "true",
        matchIfMissing = true
)
public class RulesStorageBucketHandler {

    @Value("${rules.storage.bucket}")
    private String bucket;

    @Resource
    private RedisCacheUtil redisCacheUtil;

    @Resource
    private Storage storage;

    private static final String OBJECT_FINALIZE = "OBJECT_FINALIZE";

    /**
     * Read data from the storage bucket and loads the mem-store
     *
     * @param eventType
     * @param storageObject
     * @param redisKey
     * @return
     */
    public boolean readDataFromStorageBucketIntoRedis(String eventType, String storageObject, String redisKey,String splitPattern,String message) {
        boolean isSuccess = true;
        try {
            if(eventType.equalsIgnoreCase(OBJECT_FINALIZE)) {
                Set<String> exactPhrases = new HashSet<>();
                log.info("RulesStorageBucketHandler: Reading {} from storage bucket",message);

                Blob blob = storage.get(BlobId.of(bucket, storageObject));
                if (null != blob) {
                    String blobContent = new String(blob.getContent(), StandardCharsets.UTF_8);
                    if (StringUtils.isNotBlank(blobContent)) {
                        exactPhrases = Arrays.stream(new String(blob.getContent()).split(splitPattern)).collect(Collectors.toSet());
                        if(!CollectionUtils.isEmpty(exactPhrases)) {
                            redisCacheUtil.flushAndFillStorageDataIntoCache(exactPhrases, redisKey);
                            log.info("RulesStorageBucketHandler: Loaded {} into Redis for key: {}", message,redisKey);
                        }
                    } else if(null != blobContent && blobContent.trim().equalsIgnoreCase("")) {
                        redisCacheUtil.emptyPhrasesInCache(redisKey);
                        log.info("RulesStorageBucketHandler: Emptied {} in Redis for key:{}",message,redisKey);
                    }
                }
                if(CollectionUtils.isEmpty(exactPhrases)) {
                    log.info("NO {} found for the pub-sub notification for key- {}", message,redisKey);
                }
            }
        } catch(Exception e) {
            log.error("",new StorageClientException("Exception while reading from storage/pushing "+message+" for key- "+redisKey+ " to redis mem-store-{}"+ e.getMessage(),e));
            isSuccess = false;
        }
        return isSuccess;
    }
}
