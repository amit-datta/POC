package com.macys.search.bizrules.tasklets.category;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.tasklets.statistics.FCCCategoriesStatistics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collection;

@Slf4j
@Component
@RequiredArgsConstructor
public class LoadCategoriesTasklet implements RulesPublisherTasklet {

    private final CategoryLoader categoryLoader;

    @Value("${rules.publisher.load.categories.from}")
    private String categoriesSource;

    public void execute(ProcessingContext ctx) {
        FCCCategoriesStatistics fccCategoriesStatistics = ctx.getStatistics().getFccCategoriesStatistics();
        Collection<Category> categories = categoryLoader.loadAll(ctx.getSiteName(), fccCategoriesStatistics.getWaitingTime());
        CategoryTree categoryTree = CategoryTree.from(categories);
        ctx.setCategoryTree(categoryTree);
        log.info("Loaded {} categories from {} source", categories.size(), categoriesSource);
    }
}
