package com.macys.search.bizrules.services;

import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutureCallback;
import com.google.api.core.ApiFutures;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.pubsub.v1.TopicName;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubException;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class RulesPubSubIndexingPublisher {

    @Value("${spring.projectId}")
    private String projectId;
    @Value("${rules.publisher.pubsub.notifications.topic.name}")
    private String rulePublisherMsgTopic;
    @Value("${spring.cloud.gcp.pubsub.enabled}")
    private boolean isPubSubEnabled;

    private Publisher publisher;

    @PostConstruct
    void init() throws IOException {
        if (!isPubSubEnabled) return;
        log.info("Creating pubsub publisher for rules indexing ...");
        TopicName topicName = ProjectTopicName.of(projectId, rulePublisherMsgTopic);
        publisher = Publisher.newBuilder(topicName).build();
    }

    public void publishMessage(String message) {
        if (!isPubSubEnabled) {
            log.warn("PubSub is disabled. Message=" + message + "would not be sent");
            return;
        }
        PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
                .setData(ByteString.copyFrom(message, StandardCharsets.UTF_8)).build();

        // Once published, returns a server-assigned message id (unique within the topic)
        ApiFuture<String> future = publisher.publish(pubsubMessage);

        // Add an asynchronous callback to handle success / failure
        ApiFutures.addCallback(future, new RulesIndexerPublishCallback(message, rulePublisherMsgTopic),
                MoreExecutors.directExecutor());
    }

    @PreDestroy
    void cleanup() {
        if (publisher != null) {
            // When finished with the publisher, shutdown to free up resources.
            try {
                publisher.shutdown();
                publisher.awaitTermination(1, TimeUnit.MINUTES);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static class RulesIndexerPublishCallback implements ApiFutureCallback<String> {

        private final String message;
        private final String topic;

        public RulesIndexerPublishCallback(String message, String topic) {
            this.message = message;
            this.topic = topic;
        }

        @Override
        public void onFailure(Throwable t) {
            log.error("", new PubSubException("PubSubConfig: Exception " +
                    "while sending the message to topic " + topic, t));
        }

        @Override
        public void onSuccess(String result) {
            log.info("Successfully published indexing message {} with message id {}", message, result);
        }
    }


}
