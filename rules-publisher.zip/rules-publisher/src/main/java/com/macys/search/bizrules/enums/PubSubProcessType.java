package com.macys.search.bizrules.enums;

public enum PubSubProcessType {
    START_INDEXING,
    STOP_SESSION;
}
