package com.macys.search.bizrules.tasklets.warmup;

import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.mrf.action.ESActionType;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.time.LocalDate;
import java.util.Collection;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class WarmUpRequest {
    private final String searchPhrase;
    private final Integer categoryId;
    private final LocalDate customDate;
    private final Collection<ESActionType> actionTypes;
    private final SiteName siteName;

    private final String regionCode;
}
