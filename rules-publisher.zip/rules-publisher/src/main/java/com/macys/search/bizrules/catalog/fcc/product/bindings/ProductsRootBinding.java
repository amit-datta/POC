package com.macys.search.bizrules.catalog.fcc.product.bindings;

import lombok.Data;

@Data
public class ProductsRootBinding {
    private ProductsBinding products;
}
