package com.macys.search.bizrules.catalog.fcc;

import com.google.common.base.Charsets;
import com.google.common.base.Stopwatch;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static com.macys.search.bizrules.catalog.fcc.AbstractFCCLoader.URIParams.*;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractFCCLoader<Batch, Entry> {

    private final RestTemplate restTemplate;
    private final String mcomFccURL;
    private final String bcomFccURL;
    private final int batchSize;
    private final int retryCount;
    private final int partitionsCount;
    private final Class<Batch> responseType;

    private static final ExecutorService executorService = Executors.newCachedThreadPool();

    public enum URIParams {
        OFFSET,
        LIMIT,
        PARTITION,
        PARTITIONS
    }

    public static class FCCIterator<Batch, Entry> implements Iterator<Entry> {
        private final SiteName siteName;
        private final Map<String, String> additionalParams;
        private final String entryName;
        private final int partitionsCount;
        private final AbstractFCCLoader<Batch, Entry> loader;
        private final List<Future<Boolean>> futures;

        private final BlockingQueue<Collection<Entry>> queue;
        private final AtomicInteger threadsFinished = new AtomicInteger(0);
        private Iterator<Entry> iterator = Collections.emptyIterator();
        private final TimeStatistics timeStatistics;

        public FCCIterator(SiteName siteName, Map<String, String> additionalParams, String entryName,
                           int partitionsCount, AbstractFCCLoader<Batch, Entry> loader, TimeStatistics timeStatistics) {
            this.siteName = siteName;
            this.additionalParams = additionalParams;
            this.entryName = entryName;
            this.partitionsCount = partitionsCount;
            this.queue = new LinkedBlockingQueue<>(partitionsCount);
            this.loader = loader;
            this.futures = new ArrayList<>(partitionsCount);
            this.timeStatistics = timeStatistics;
            log.info("Iterator created for {} from FCC for {}", entryName, siteName);
            startLoading();
        }

        private void startLoading() {
            for (int i = 0; i < partitionsCount; i++) {
                final int partition = i + 1;
                Future<Boolean> future = executorService.submit(() -> {
                    try {
                        int offset = 0;
                        while (offset != -1) {
                            CategoryBatchResponse<Entry> response =
                                    loader.loadBatchWithRetry(siteName, additionalParams, entryName, offset, partition,
                                            timeStatistics);
                            offset = response.offset;
                            if (!response.batch.isEmpty()) {
                                queue.put(response.batch);
                            }
                        }
                    } catch (InterruptedException e) {
                        log.error(partition + " thread for " + entryName + " loading was interrupted", e);
                        threadsFinished.addAndGet(partitionsCount);
                        throw e;
                    } catch (Exception e) {
                        log.error("Exception occurred while loading " + entryName, e);
                        threadsFinished.addAndGet(partitionsCount);
                        throw e;
                    } finally {
                        threadsFinished.incrementAndGet();
                    }
                    return true;
                });
                futures.add(future);
            }
        }

        private boolean threadsFinished() {
            boolean result = threadsFinished.get() >= partitionsCount;
            if (result) {
                for (Future<Boolean> future : futures) {
                    if (future.isDone()) {
                        try {
                            future.get();
                        } catch (InterruptedException | ExecutionException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                }
            }
            return result;
        }

        private boolean noNextElement() {
            return threadsFinished() && queue.isEmpty();
        }

        private void updateIterator() {
            if (iterator.hasNext() || noNextElement()) return;

            while (!noNextElement()) {
                try {
                    Collection<Entry> batch = queue.poll(100, TimeUnit.MILLISECONDS);
                    if (batch != null) {
                        iterator = batch.iterator();
                        return;
                    }
                } catch (InterruptedException e) {
                    log.error("FCC loading " + entryName + " was interrupted", e);
                    threadsFinished.addAndGet(partitionsCount);
                }
            }
            iterator = Collections.emptyIterator();
        }

        @Override
        public boolean hasNext() {
            updateIterator();
            return iterator.hasNext() || !noNextElement();
        }

        @Override
        public Entry next() {
            updateIterator();
            return iterator.next();
        }
    }

    protected Iterator<Entry> iterator(SiteName siteName, Map<String, String> additionalParams, String entryName, TimeStatistics timeStatistics) {
        return new FCCIterator<>(siteName, additionalParams, entryName, partitionsCount, this, timeStatistics);
    }

    protected Collection<Entry> loadAll(SiteName siteName, Map<String, String> params, String entryName, TimeStatistics timeStatistics) {
        final Collection<Entry> result = new ArrayList<>();
        Iterator<Entry> it = iterator(siteName, params, entryName, timeStatistics);
        while (it.hasNext()) {
            result.add(it.next());
        }
        return result;
    }

    @AllArgsConstructor
    private static class CategoryBatchResponse<Entry> {
        private final Collection<Entry> batch;
        private final int offset;
    }

    private CategoryBatchResponse<Entry> loadBatchWithRetry(SiteName siteName, Map<String, String> params, String entryName,
                                                            int offset, int partition, TimeStatistics timeStatistics) {
        for (int attempt = 1; attempt < retryCount; attempt++) {
            try {
                return loadBatch(siteName, params, entryName, offset, partition, timeStatistics);
            } catch (Exception ex) {
                log.warn("Exception occurred while reading {} from FCC. " +
                        "Offset={} attempt={} ex={}", entryName, offset, attempt, ex.getMessage());
            }
        }
        return loadBatch(siteName, params, entryName, offset, partition, timeStatistics);
    }

    private CategoryBatchResponse<Entry> loadBatch(SiteName siteName, Map<String, String> params, String entryName,
                                                   int offset, int partition, TimeStatistics timeStatistics) {
        log.info("Loading FCC {} entry with offset={} partition={}", entryName, offset, partition);

        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Macys-ClientId", "RulesPublisher");
        HttpEntity<?> entity = new HttpEntity<>(headers);

        LinkedHashMap<String, Object> allParams = new LinkedHashMap<>();
        allParams.put(OFFSET.name(), offset);
        allParams.put(LIMIT.name(), batchSize);
        allParams.put(PARTITION.name(), partition);
        allParams.put(PARTITIONS.name(), partitionsCount);
        allParams.putAll(params);

        Stopwatch stopwatch = Stopwatch.createStarted();
        ResponseEntity<Batch> entry = restTemplate.exchange(fccUrl(siteName) + getPathWithParams(), HttpMethod.GET,
                entity, responseType, allParams);
        Batch batch = entry.getBody();
        if (isBatchEmpty(batch)) {
            log.error("FCC sent empty response for offset={} partition={}", offset, partition);
            return new CategoryBatchResponse<>(List.of(), -1);
        }
        long responseTime = stopwatch.elapsed(TimeUnit.MILLISECONDS);
        timeStatistics.computeTime(responseTime);
        if (responseTime > 1000) {
            log.warn("FCC response time for {} {}ms", entryName, responseTime);
        }
        return new CategoryBatchResponse<>(convert(batch), parseNextOffset(entry.getHeaders()));
    }

    private static int parseNextOffset(HttpHeaders responseHeaders) {
        List<String> nextChunkLink = responseHeaders.get(HttpHeaders.LINK);
        if (nextChunkLink == null) {
            return -1;
        }
        if (nextChunkLink.size() != 1) {
            throw new RuntimeException("Count not parse Link header from FCC. Headers=" + responseHeaders);
        }
        List<NameValuePair> nameValuePairs = URLEncodedUtils.parse(nextChunkLink.get(0), Charsets.UTF_8);
        for (NameValuePair nameValuePair : nameValuePairs) {
            if (nameValuePair.getName().equals("_offset")) {
                return Integer.parseInt(nameValuePair.getValue());
            }
        }
        throw new RuntimeException("Could not parse next offset from Link header=" + nextChunkLink.get(0));
    }

    private String fccUrl(SiteName siteName) {
        return siteName == SiteName.MCOM ? mcomFccURL : bcomFccURL;
    }

    protected abstract boolean isBatchEmpty(Batch batch);

    protected abstract String getPathWithParams();

    protected abstract Collection<Entry> convert(Batch batch);
}
