package com.macys.search.bizrules.validation.trigger;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.BooleanOperation;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.KWPMatchType;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.CriteriaAttributesValidator;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import com.macys.search.bizrules.validation.model.CriteriaTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.converters.ConverterUtils.getUnaryValue;
import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.*;

/**
 * Facet refinement trigger validator
 */
@Slf4j
@Component
public class FacetRefinementTriggerValidatorStrategy implements TriggerValidationStrategy {

    @ResourceMapping("classpath:merch-validation-template/trigger/FacetRefinementTriggerMatchConfig.json")
    private ConfigTemplate matchConfigCriteriaTemplate;
    @ResourceMapping("classpath:merch-validation-template/trigger/FacetRefinementTriggerAttribute.json")
    private CriteriaTemplate criteriaAttributeTemplate;

    @Override
    public TriggerType applicableFor() {
        return TriggerType.FacetRefinement;
    }

    @Override
    public ValidationResult validate(Trigger trigger, ProcessingContext context) {
        if (trigger.isSearchable() || trigger.isResultSetRequired()) {
            return ValidationResult.failResult("Trigger with id=" + trigger.getId() +
                    " invalid. Flags isSearchable and isResultSetRequired set incorrectly");
        }

        ValidationResult result = CriteriaAttributesValidator.validateCriteriaMap(trigger.getCriteriaMap(), matchConfigCriteriaTemplate);
        if (!result.isValid()) {
            return ValidationResult.failResult("Trigger with id=" + trigger.getId() + " invalid. " +
                    result.getWarning());
        }

        Criteria matchConfig = trigger.getCriteriaMap().get(FACET_REFINEMENT_MATCH_CONFIG);
        KWPMatchType matchType = KWPMatchType.valueOf(getUnaryValue(matchConfig, FACET_REFINEMENT_MATCH_TYPE));
        BooleanOperation operationType = BooleanOperation.valueOf(getUnaryValue(matchConfig, FACET_REFINEMENT_MATCH_OPERATOR));

        if (trigger.getCriteriaMap().size() == 1) {
            if (KWPMatchType.Exact == matchType) {
                return ValidationResult.validResult();
            } else {
                return ValidationResult.failResult("Trigger with id=" + trigger.getId() +
                        " invalid. Refinements is optional only for 'exact' 'and' trigger type. Match config=" + matchConfig);
            }
        }

        for (Criteria criteria : trigger.getCriteriaMap().values()) {
            if (FACET_REFINEMENT_MATCH_CONFIG.equals(criteria.getCriteriaName())) continue;
            ValidationResult validationResult = CriteriaAttributesValidator.validateCriteriaAttributes(criteria, criteriaAttributeTemplate);
            if (!validationResult.isValid()) {
                return ValidationResult.failResult("Trigger with id=" + trigger.getId() + " invalid. " +
                        validationResult.getWarning());
            }
        }

        return ValidationResult.validResult();
    }
}
