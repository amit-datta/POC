package com.macys.search.bizrules.repository.elastic.properties;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CommonIndexProperties {
    private final int indicesToKeep;
    private final String unfinishedIndicesAliasName;
}
