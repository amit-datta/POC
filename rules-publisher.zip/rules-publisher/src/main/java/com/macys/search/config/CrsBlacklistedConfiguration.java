package com.macys.search.config;

import com.google.cloud.storage.Storage;
import com.macys.search.analysis.PhraseAnalyzerFactory;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.bizrules.tasklets.converters.CrsBlacklistedReadAndConvertTasklet;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CrsBlacklistedConfiguration {

    @Bean("crsBlacklistedProcessingTasklet")
    @ConditionalOnProperty(value = "rules.publisher.reading.blacklisted-phrases.enabled", havingValue = "true")
    public RulesPublisherTasklet realCrsProcessingTasklet(
            PhraseAnalyzerFactory phraseAnalyzerFactory,
            Storage storage) {
        return new CrsBlacklistedReadAndConvertTasklet(phraseAnalyzerFactory, storage);
    }

    @Bean("crsBlacklistedProcessingTasklet")
    @ConditionalOnProperty(value = "rules.publisher.reading.blacklisted-phrases.enabled", havingValue = "false")
    public RulesPublisherTasklet disabled() {
        return ctx -> {
        };
    }

}
