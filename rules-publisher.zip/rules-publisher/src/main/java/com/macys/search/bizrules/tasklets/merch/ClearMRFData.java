package com.macys.search.bizrules.tasklets.merch;

import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import org.springframework.stereotype.Component;

@Component
public class ClearMRFData implements RulesPublisherTasklet {

    @Override
    public void execute(ProcessingContext ctx) throws Exception {
        ctx.setTriggers(null);
        ctx.setRules(null);
        ctx.setActions(null);
        ctx.setFacets(null);
    }
}
