package com.macys.search.bizrules.model.elastic.mappings;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.KEYWORD;
import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.LONG;

/**
 * Fields for Product index
 */
@Getter
@AllArgsConstructor
public enum ProductIndexFields implements ElasticSearchBaseFields {
    SCOPE("scope", KEYWORD.getProperties()),
    PRODUCT_ID("product_id", LONG.getProperties()),

    CAT_IDS("cat_ids", LONG.getProperties()),
    CAT_PATHS("cat_paths", KEYWORD.getProperties()),

    MSR_BOOST("msr_boost", LONG.getProperties()),
    MSR_ADD("msr_add", LONG.getProperties()),
    MSR_REPLACE("msr_replace", LONG.getProperties()),
    MSR_REMOVE("msr_remove", LONG.getProperties()),
    MSR_BOOST_WITH_SEQUENCE_NUMBER("msr_boost_with_sequence_number", KEYWORD.getProperties());

    private final String fieldName;
    private final Map<String, Object> properties;
}
