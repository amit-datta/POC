package com.macys.search.bizrules.catalog.fcc.product.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Date;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PriceBinding {
    private Double originalPrice;
    private Double originalPriceHigh;
    private Double intermediatePrice;
    private Double intermediatePriceHigh;
    private Double retailPrice;
    private Double retailPriceHigh;
    private Integer priceType;
    private Double saleValue;
    private Double saleValueHigh;
    private Double intermediateSaleValue;
    private Double intermediateSaleValueHigh;
    private Date effectiveDate;
    private Date expirationDate;
    private String displayCode;
    private Integer basePriceType;
    private Boolean onSale;
    private Boolean memberProductOnSale;
    private Double percentageOff;
    private Boolean newMarkdown;
}
