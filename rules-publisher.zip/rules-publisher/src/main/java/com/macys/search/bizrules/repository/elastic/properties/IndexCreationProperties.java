package com.macys.search.bizrules.repository.elastic.properties;

import com.macys.search.bizrules.model.elastic.mappings.ElasticSearchBaseFields;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

/**
 * Contains properties required to create new Elastic search index
 */
@AllArgsConstructor
@Getter
public class IndexCreationProperties {
    private final String indexNamePrefix;
    private final int shardsCount;
    private final int replicasCount;
    private final Class<? extends ElasticSearchBaseFields> fieldsEnum;
    private final Map<String, Object> overriddenProperties;
}
