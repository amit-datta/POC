package com.macys.search.bizrules.converters;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ESParamsConvertingUtils {

    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * Serialize object to JSON
     *
     * @param obj object
     * @return serialized object
     */
    @SneakyThrows(JsonProcessingException.class)
    public static String writeAsJson(Object obj) {
        if (obj == null) return null;
        return mapper.writeValueAsString(obj);
    }

}
