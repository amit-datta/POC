package com.macys.search.bizrules.repository.mrf;

import com.macys.search.bizrules.model.SiteName;

import javax.sql.DataSource;
import java.sql.Date;
import java.time.LocalDate;

public class CustomDateReader extends AbstractMysqlRepository {

    public CustomDateReader(DataSource mcomDataSource, DataSource bcomDataSource, boolean isStreamMode) {
        super(mcomDataSource, bcomDataSource, isStreamMode);
    }

    private static class CustomDateResponse {
        private Date date;
    }

    public LocalDate getCustomDate(SiteName siteName) {
        CustomDateResponse response = new CustomDateResponse();
        read(siteName,
                "SELECT date_value FROM custom_date WHERE date_name = 'CUSTOM_DATE' AND date_visible = 'Y'",
                rs -> {
                    if (rs.next()) {
                        response.date = rs.getDate(1);
                    }
                }
        );
        return response.date != null ? response.date.toLocalDate() : null;
    }
}
