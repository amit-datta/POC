package com.macys.search.cache;

import com.macys.search.bizrules.catalog.CategoryLoader;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@RequiredArgsConstructor
@Slf4j
public class CategoriesCache implements HealthIndicator {
    private static final String STATE = "state";
    private volatile CategoryTree categoryTree;
    private final SiteName siteName;
    private final CategoryLoader categoryLoader;
    private final String categoriesSource;
    private final boolean updateOnStartup;

    private final ReentrantReadWriteLock stateLock = new ReentrantReadWriteLock();
    private final ReentrantReadWriteLock.ReadLock readLock = stateLock.readLock();
    private final ReentrantReadWriteLock.WriteLock writeLock = stateLock.writeLock();

    public void loadCache() {
        try {
            if (writeLock.tryLock()) {
                log.info("Start reloading categories cache for site={}", siteName);
                Collection<Category> categories = categoryLoader.loadAll(siteName, new TimeStatistics());
                categoryTree = CategoryTree.from(categories);
                log.info("Finished reloading categories cache for site={}, size={} from source={}", siteName, categoryTree.size(), categoriesSource);
            }
        } catch (Exception e) {
            categoryTree = null;
            log.error("Failed to reload categories cache.", e);
        } finally {
            writeLock.unlock();
        }
    }

    @EventListener(ContextRefreshedEvent.class)
    public void refreshCache() {
        if (updateOnStartup) {
            loadCache();
        }
    }

    public void updateCache(ProcessingContext context) {
        try {
            writeLock.lock();
            log.info("Start updating categories cache for site={} after indexing", siteName);
            categoryTree = context.getCategoryTree();
            log.info("Finished updating categories cache for site={}, size={}", siteName, categoryTree.size());
        } catch (Exception e) {
            categoryTree = null;
            log.error("Failed to update categories cache after indexing.", e);
        } finally {
            writeLock.unlock();
        }
    }

    public CategoryTree getCategoryTree() {
        if (categoryTree == null) {
            loadCache();
        }
        try {
            readLock.lock();
            return categoryTree;
        } finally {
            readLock.unlock();
        }
    }

    @Override
    public Health health() {
        return Health.up().withDetails(healthDetails()).build();
    }

    private Map<String, ?> healthDetails() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("categories cache: size=", categoryTree != null ? categoryTree.size() : "N/A");
        if (categoryTree != null) {
            result.put(STATE, "ready");
        } else if (stateLock.isWriteLocked()) {
            result.put(STATE, "updating");
        } else {
            result.put(STATE, "N/A");
        }
        return result;
    }

}
