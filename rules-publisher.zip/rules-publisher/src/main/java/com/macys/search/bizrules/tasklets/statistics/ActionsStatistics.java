package com.macys.search.bizrules.tasklets.statistics;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@ToString
@JsonDeserialize
public class ActionsStatistics {
    @Setter
    private int loadedActions;
    private int validActions;
    private int invalidActions;

    public void incrementValidActions() {
        validActions++;
    }

    public void incrementInvalidActions() {
        invalidActions++;
    }
}
