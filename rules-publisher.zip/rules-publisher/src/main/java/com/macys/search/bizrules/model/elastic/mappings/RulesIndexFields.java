package com.macys.search.bizrules.model.elastic.mappings;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Map;

import static com.macys.search.bizrules.model.elastic.mappings.ElasticSearchPrimitiveTypes.*;

/**
 * Fields for Rules index
 */
@AllArgsConstructor
@Getter
public enum RulesIndexFields implements ElasticSearchBaseFields {
    RULE_NAME("rule_name", KEYWORD.getProperties()),
    RULE_TYPE("rule_type", KEYWORD.getProperties()),
    RULE_ID("rule_id", LONG.getProperties()),
    RULE_NATURAL_ID("rule_natural_id", LONG.getProperties()),
    RULE_PRIORITY("rule_priority", LONG.getProperties()),
    RULE_ENABLED("rule_enabled", BOOLEAN.getProperties()),
    RULE_OWNER("rule_owner", KEYWORD.getProperties()),
    RULE_DESCRIPTION("rule_description", KEYWORD.getProperties()),
    RULE_CATEGORY_IDS("rule_category_ids", LONG.getProperties()),

    RULE_CREATED_DATE("rule_created_date", DATE_TIME.getProperties()),
    RULE_EFFECTIVE_DATE("rule_effective_date", DATE.getProperties()),
    RULE_EXPIRATION_DATE("rule_expiration_date", DATE.getProperties()),

    RULE_LAST_MODIFICATION_DATE("rule_last_modification_date", DATE_TIME.getProperties()),
    RULE_LAST_MODIFICATION_NAME("rule_last_modification_name", KEYWORD.getProperties()),

    RULE_TRIGGER_IDS("rule_trigger_ids", LONG.getProperties()),
    RULE_TRIGGER_NATURAL_IDS("rule_trigger_natural_ids", LONG.getProperties()),
    RULE_TRIGGER_OPERATOR("rule_trigger_operator", KEYWORD.getProperties());

    private final String fieldName;
    private final Map<String, Object> properties;

}
