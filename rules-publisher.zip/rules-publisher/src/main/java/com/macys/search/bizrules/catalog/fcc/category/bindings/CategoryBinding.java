package com.macys.search.bizrules.catalog.fcc.category.bindings;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Collection;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CategoryBinding {
    private Integer id;
    private String name;
    private Integer parentCategoryId;
    private Collection<AttributeBinding> attributes;
    private String externalHostUrl;
    private Collection<String> countryExclusion;
    private int sequenceNumber;
    private ContextOverridesBinding contextOverrides;
}

