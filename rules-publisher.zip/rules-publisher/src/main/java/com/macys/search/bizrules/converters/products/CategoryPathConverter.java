package com.macys.search.bizrules.converters.products;

import com.macys.search.bizrules.converters.products.filters.CategoryFilter;
import com.macys.search.bizrules.model.category.Category;
import com.macys.search.bizrules.model.category.CategoryTree;
import com.macys.search.bizrules.model.elastic.entries.ESProduct;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.model.product.ProductToCategory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class CategoryPathConverter {

    private static final String PATH_DELIMITER = " > ";

    private final Collection<CategoryFilter> filters;

    public void convert(Product product, ESProduct esProduct, CategoryTree categoryTree) {
        Set<Integer> categoryIds = new HashSet<>();
        Set<String> categoryPaths = new HashSet<>();

        List<List<Integer>> paths = new ArrayList<>();
        if (!CollectionUtils.isEmpty(product.getParentCategories())) {
            for (Integer categoryId : product.getParentCategories().stream().map(ProductToCategory::getCategoryId)
                    .collect(Collectors.toList())) {
                List<Integer> hierarchy = categoryTree.getHierarchy(categoryId);
                if (CollectionUtils.isEmpty(product.getMembers())) {
                    processHierarchy(null, product, categoryTree, hierarchy, paths);
                } else {
                    for (Product member : product.getMembers()) {
                        processHierarchy(product, member, categoryTree, hierarchy, paths);
                    }
                }
            }
        }

        for (List<Integer> path : paths) {
            categoryIds.addAll(path);
            String stringPath = path.stream().map(Objects::toString).collect(Collectors.joining(PATH_DELIMITER));
            categoryPaths.add(stringPath);
        }

        esProduct.setCatIds(categoryIds);
        esProduct.setCatPaths(categoryPaths);
    }

    private void processHierarchy(Product master, Product member, CategoryTree categoryTree, List<Integer> hierarchy,
                                  List<List<Integer>> paths) {
        List<Integer> path = new ArrayList<>(hierarchy);
        for (int i = path.size() - 1; i >= 0; i--) {
            Category category = categoryTree.get(path.get(i));
            if (category != null) {
                boolean passedFilters = true;
                for (CategoryFilter filter : filters) {
                    if (!filter.pass(category, master != null && filter.isSelfBased() ? master : member)) {
                        passedFilters = false;
                        break;
                    }
                }
                if (passedFilters) {
                    paths.add(path);
                    return;
                } else {
                    path.remove(i);
                }
            }
        }
    }

}
