package com.macys.search.bizrules.validation.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * Template for single attribute
 */
@Getter
@Setter
public class AttributeTemplate {
    private boolean uniq;
    private boolean notEmpty;
    private AttributeTypeEnum type;
    private boolean optional;
    private List<String> possibleValues;

    public boolean hasTypeValidation() {
        return type != null;
    }
}
