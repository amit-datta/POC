package com.macys.search.bizrules.tasklets.esmanaging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.macys.search.bizrules.repository.elastic.ElasticSearchFacade;
import com.macys.search.bizrules.repository.elastic.properties.CommonIndexProperties;
import com.macys.search.bizrules.repository.elastic.properties.SwitchAliasProperties;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.tasklets.RulesPublisherTasklet;
import com.macys.search.exception.bizrules.es.ElasticSearchIndexingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class SwitchAliasTasklet implements RulesPublisherTasklet {

    private final ElasticSearchFacade elasticSearchFacade;
    private final Collection<SwitchAliasProperties> switchAliasProperties;
    private final CommonIndexProperties mcomCommonIndexProperties;
    private final CommonIndexProperties bcomCommonIndexProperties;
    private final ObjectMapper mapper;

    public void execute(ProcessingContext ctx) {
        Map<String, String> indexNameToAliasMapping = new HashMap<>();
        for (SwitchAliasProperties switchAliasProperty : switchAliasProperties) {
            String indexName = ctx.getIndexName(switchAliasProperty.getIndex());
            String fullAliasName = getFullAliasName(ctx, switchAliasProperty);
            if (StringUtils.isNotBlank(indexName)) {
                indexNameToAliasMapping.put(indexName, fullAliasName);
                elasticSearchFacade.merge(indexName, switchAliasProperty.getMaxSegmentsNumber());
            } else {
                throw new ElasticSearchIndexingException(switchAliasProperty.getIndex().name(), "Index wasn't created");
            }
        }
        String unfinishedAlias = ctx.isMCOM() ? mcomCommonIndexProperties.getUnfinishedIndicesAliasName() :
                bcomCommonIndexProperties.getUnfinishedIndicesAliasName();
        elasticSearchFacade.switchAlias(indexNameToAliasMapping, Collections.singletonList(unfinishedAlias));

        List<String> indicesForDeletion = new ArrayList<>();
        switchAliasProperties.forEach(switchAliasProperties -> {
            String shortAliasName = getShortAliasName(ctx, switchAliasProperties);
            int skip = ctx.isMCOM() ? mcomCommonIndexProperties.getIndicesToKeep() :
                    bcomCommonIndexProperties.getIndicesToKeep();
            indicesForDeletion.addAll(elasticSearchFacade.getIndicesStartingWith(shortAliasName).stream()
                    .skip(skip)
                    .collect(Collectors.toList()));
        });
        elasticSearchFacade.deleteIndices(indicesForDeletion.toArray(String[]::new));
        log.info("Data was successfully inserted into indices and switched to aliases {} ",
                indexNameToAliasMapping);

        try {
            log.info(mapper.writeValueAsString(ctx.getStatistics()));
        } catch (JsonProcessingException e) {
            log.error("Could not print statistics", e);
        }
    }

    private String getFullAliasName(ProcessingContext ctx, SwitchAliasProperties properties) {
        return ctx.isMCOM() ? properties.getMcomFullAliasName() : properties.getBcomFullAliasName();
    }

    private String getShortAliasName(ProcessingContext ctx, SwitchAliasProperties properties) {
        return ctx.isMCOM() ? properties.getMcomShortAliasName() : properties.getBcomShortAliasName();
    }

}