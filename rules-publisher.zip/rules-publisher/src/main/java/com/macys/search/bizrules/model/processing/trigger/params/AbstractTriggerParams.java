package com.macys.search.bizrules.model.processing.trigger.params;

import com.macys.search.bizrules.model.elastic.entries.ESTrigger;
import com.macys.search.bizrules.model.processing.ProcessingRule;

import java.util.List;

/**
 * Base class for all trigger parameter classes
 */
public abstract class AbstractTriggerParams {

    /**
     * Generates elastic search documents from trigger params
     *
     * @return list of elastic search documents
     */
    public abstract List<ESTrigger> generateTriggers();

    /**
     * @return true if trigger params require percolator index
     */
    public boolean hasPercolator() {
        return false;
    }

    public void enrichProcessingRule(ProcessingRule processingRule) {
    }

}
