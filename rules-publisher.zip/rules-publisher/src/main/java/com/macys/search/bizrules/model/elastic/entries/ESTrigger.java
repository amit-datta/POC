package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.model.elastic.mappings.TriggerIndexFields;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import org.apache.commons.lang3.StringUtils;

import java.util.Set;

/**
 * Trigger as elastic document
 */
public class ESTrigger extends AbstractESEntry<TriggerIndexFields> {

    public ESTrigger(Integer triggerId, TriggerType triggerType, String elasticIdSuffix) {
        super(StringUtils.isBlank(elasticIdSuffix) ? triggerId.toString()
                : triggerId.toString() + "_" + elasticIdSuffix
        );
        setFieldValue(TriggerIndexFields.TRIGGER_ID, triggerId);
        setFieldValue(TriggerIndexFields.TRIGGER_TYPE, triggerType.name());
    }

    public ESTrigger(Integer triggerId, TriggerType triggerType) {
        this(triggerId, triggerType, null);
    }

    public void addRefinement(String refinementName, Set<String> values) {
        setFieldValue(refinementName, values);
    }

    public void setNaturalId(int id) {
        setFieldValue(TriggerIndexFields.TRIGGER_NATURAL_ID, id);
    }

}
