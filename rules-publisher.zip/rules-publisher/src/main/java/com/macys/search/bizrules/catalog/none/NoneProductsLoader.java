package com.macys.search.bizrules.catalog.none;

import com.macys.search.bizrules.catalog.ProductsLoader;
import com.macys.search.bizrules.model.SiteName;
import com.macys.search.bizrules.model.product.Product;
import com.macys.search.bizrules.tasklets.statistics.TimeStatistics;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

/**
 * Stub for disable category loading
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "rules.publisher.load.products.from",
        havingValue = "NONE",
        matchIfMissing = true
)
public class NoneProductsLoader implements ProductsLoader {

    @Override
    public Collection<Product> loadAll(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics) {
        return Collections.emptyList();
    }

    @Override
    public Iterator<Product> iterator(SiteName siteName, LocalDate customDate, TimeStatistics timeStatistics) {
        return Collections.emptyIterator();
    }
}
