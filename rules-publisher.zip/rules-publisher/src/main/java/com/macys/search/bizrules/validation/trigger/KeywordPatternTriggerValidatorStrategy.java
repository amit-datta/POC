package com.macys.search.bizrules.validation.trigger;

import com.macys.search.annotation.ResourceMapping;
import com.macys.search.bizrules.model.mrf.Criteria;
import com.macys.search.bizrules.model.mrf.trigger.Trigger;
import com.macys.search.bizrules.model.mrf.trigger.TriggerType;
import com.macys.search.bizrules.tasklets.ProcessingContext;
import com.macys.search.bizrules.validation.CriteriaAttributesValidator;
import com.macys.search.bizrules.validation.ValidationResult;
import com.macys.search.bizrules.validation.model.ConfigTemplate;
import com.macys.search.bizrules.validation.model.CriteriaTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import static com.macys.search.bizrules.model.mrf.trigger.TriggerConstants.KEYWORD_PATTERN_MATCH_CONFIG;

/**
 * Keyword pattern trigger validation
 */
@Slf4j
@Component
public class KeywordPatternTriggerValidatorStrategy implements TriggerValidationStrategy {

    @ResourceMapping("classpath:merch-validation-template/trigger/KeywordTriggerAttribute.json")
    private CriteriaTemplate criteriaAttributeTemplate;
    @ResourceMapping("classpath:merch-validation-template/trigger/KeywordTriggerMatchConfig.json")
    private ConfigTemplate matchConfigCriteriaTemplate;

    @Override
    public TriggerType applicableFor() {
        return TriggerType.KeywordPattern;
    }

    @Override
    public ValidationResult validate(Trigger trigger, ProcessingContext context) {
        if (!trigger.isSearchable() || trigger.isResultSetRequired()) {
            return ValidationResult.failResult("Flags isSearchable and isResultSetRequired set incorrectly");
        }
        ValidationResult result = CriteriaAttributesValidator.validateCriteriaMap(trigger.getCriteriaMap(), matchConfigCriteriaTemplate);
        if (!result.isValid()) {
            return result;
        }
        for (Criteria criteria : trigger.getCriteriaMap().values()) {
            if (KEYWORD_PATTERN_MATCH_CONFIG.equals(criteria.getCriteriaName())) continue;
            ValidationResult validationResult = CriteriaAttributesValidator.validateCriteriaAttributes(criteria, criteriaAttributeTemplate);
            if (!validationResult.isValid()) {
                return validationResult;
            }
        }
        return ValidationResult.validResult();
    }
}
