package com.macys.search.config.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ESIndicesUtils {

    /**
     * Build alias name with index version
     *
     * @param aliasName alias name
     * @param version   version
     * @return full alias name
     */
    public static String fullAliasNameFrom(String aliasName, String version) {
        return aliasName + '_' + version;
    }
}
