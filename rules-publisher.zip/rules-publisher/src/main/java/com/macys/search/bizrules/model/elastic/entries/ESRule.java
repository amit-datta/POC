package com.macys.search.bizrules.model.elastic.entries;

import com.macys.search.bizrules.model.elastic.mappings.RulesIndexFields;

/**
 * Rule as elastic document
 */
public class ESRule extends AbstractESEntry<RulesIndexFields> {
}
