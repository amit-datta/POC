package com.macys.search.config;

import com.macys.search.bizrules.repository.batch.BatchRepository;
import com.macys.search.bizrules.repository.mrf.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.autoconfigure.health.HealthEndpointProperties;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

@Configuration
@Import({
        HibernateJpaAutoConfiguration.class,
        DataSourceTransactionManagerAutoConfiguration.class
})
@RequiredArgsConstructor
public class DataSourceConfiguration {

    private final HealthEndpointProperties healthEndpointProperties;
    @Value("${rules.publisher.rules.read.merch.in.stream.mode}")
    boolean isStreamMode;

    @PostConstruct
    public void init() {
        healthEndpointProperties.getGroup().get("readiness").getInclude().add("db");
    }

    @Bean
    @ConfigurationProperties(prefix = "rules.publisher.batch.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    public BatchRepository batchRepository(DataSource dataSource) {
        return new BatchRepository(dataSource, false);
    }

    @Bean
    @ConfigurationProperties(prefix = "rules.publisher.mcom.datasource")
    public DataSource mcomDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    @ConfigurationProperties(prefix = "rules.publisher.bcom.datasource")
    public DataSource bcomDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    public ActionsReader actionsReader(DataSource mcomDataSource, DataSource bcomDataSource) {
        return new ActionsReader(mcomDataSource, bcomDataSource, isStreamMode);
    }

    @Bean
    public TriggersReader triggersReader(DataSource mcomDataSource, DataSource bcomDataSource) {
        return new TriggersReader(mcomDataSource, bcomDataSource, isStreamMode);
    }

    @Bean
    public RulesReader rulesReader(DataSource mcomDataSource, DataSource bcomDataSource) {
        return new RulesReader(mcomDataSource, bcomDataSource, isStreamMode);
    }

    @Bean
    public FacetsReader facetsReader(DataSource mcomDataSource, DataSource bcomDataSource) {
        return new FacetsReader(mcomDataSource, bcomDataSource, isStreamMode);
    }

    @Bean
    public TriggerExpressionReader triggerExpressionReader(DataSource mcomDataSource, DataSource bcomDataSource) {
        return new TriggerExpressionReader(mcomDataSource, bcomDataSource, isStreamMode);
    }

    @Bean
    public CustomDateReader customDateReader(DataSource mcomDataSource, DataSource bcomDataSource) {
        return new CustomDateReader(mcomDataSource, bcomDataSource, false);
    }

}
