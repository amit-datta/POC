# Read Me First
The following was discovered as part of building this project:

* The original package name 'com.macys.search.rules-publisher' is invalid and this project uses 'com.macys.search.rulespublisher' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.3.3.RELEASE/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.3.3.RELEASE/maven-plugin/reference/html/#build-image)

### Local environment
To start local environment you need:
* Maven
* Docker (with docker stack supported or docker-compose)

App requires ElasticSearch and MySQL.
The easiest approach to deploy ES and MySQL is to use Docker files:
* Docker stack: local_env/docker-stack-local.yml
* Docker compose: local_env/docker-compose-local.yml

In order to fill MySQL with sample data there is a script: upload_data.sh
```
cd local_env
docker ps #To get MySQL container ID
./upload_data.sh <MySQL Container ID>
```

After that App can be started as Spring Boot application.

### REST API
App API is documented at https://confluence.federated.fds/display/PDM/Business+Controls+Engine+SAD.
Using API Spring Batch Job can be started in order to index ES index from MySQL.

### 

