package com.macys.search.dynamicfacetdata.config.cache.redis.serializer;

import org.apache.commons.io.IOUtils;
import org.springframework.core.serializer.Deserializer;
import org.springframework.core.serializer.Serializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class StringSerializerDeserializer implements Serializer<Object>, Deserializer<Object> {
    private Charset charset = StandardCharsets.UTF_8;

    public StringSerializerDeserializer() {
    }

    public StringSerializerDeserializer(Charset charset) {
        this.charset = charset;
    }

    @Override
    public String deserialize(InputStream inputStream) throws IOException {
        return new String(inputStream.readAllBytes(), charset);
    }

    @Override
    public void serialize(Object object, OutputStream outputStream) throws IOException {
        if (object != null) {
            IOUtils.copy(new ByteArrayInputStream(object.toString().getBytes()), outputStream);
        }
    }
}
