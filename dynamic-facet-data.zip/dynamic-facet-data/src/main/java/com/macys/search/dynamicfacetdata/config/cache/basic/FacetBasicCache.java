package com.macys.search.dynamicfacetdata.config.cache.basic;

import com.google.common.cache.Cache;
import com.macys.search.dynamicfacetdata.config.cache.CacheManager;

import java.util.Map;
import java.util.Set;

public class FacetBasicCache implements CacheManager<String, Object> {

    private volatile Cache<String, Object> cache;

    public FacetBasicCache(Cache<String, Object> cache) {
        this.cache = cache;
    }

    @Override
    public void put(String attrName, Object value) {
        cache.put(attrName, value);
    }

    @Override
    public Object get(String attrName) {
        return cache.getIfPresent(attrName);
    }

    @Override
    public Set<String> getKeys(String pattern) {
        return cache.asMap().keySet();
    }

    @Override
    public Long deleteAllKeys() {
        return null;
    }

    @Override
    public void putMulitpleKeys(Map<String, Object> map) {
        cache.putAll(map);
    }
}
