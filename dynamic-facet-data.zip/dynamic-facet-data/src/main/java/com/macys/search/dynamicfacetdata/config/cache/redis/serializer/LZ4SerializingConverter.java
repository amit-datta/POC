package com.macys.search.dynamicfacetdata.config.cache.redis.serializer;

import net.jpountz.lz4.LZ4Compressor;
import net.jpountz.lz4.LZ4Factory;
import org.springframework.core.serializer.Serializer;
import org.springframework.core.serializer.support.SerializingConverter;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class LZ4SerializingConverter extends SerializingConverter {
    private static final int SOURCE_LENGTH_BYTES = 4;
    private static final LZ4Factory LZ4_FACTORY = LZ4Factory.fastestInstance();

    private boolean compress;

    public LZ4SerializingConverter(Serializer<Object> serializer, boolean compress) {
        super(serializer);
        this.compress = compress;
    }

    @Override
    public byte[] convert(Object source) {
        return this.compress ? compress(super.convert(source)) : super.convert(source);
    }

    private byte[] compress(byte[] input) {
        if (input == null) {
            return input;
        }
        LZ4Compressor compressor = LZ4_FACTORY.fastCompressor();
        ByteBuffer inputBuffer = ByteBuffer.wrap(input);
        int sourceLength = inputBuffer.remaining();
        int maxCompressedLength = compressor.maxCompressedLength(sourceLength);
        ByteBuffer compressedBuffer = ByteBuffer.allocate(maxCompressedLength + SOURCE_LENGTH_BYTES);

        int compressedSize = compressor.compress(inputBuffer, 0, sourceLength, compressedBuffer, SOURCE_LENGTH_BYTES, maxCompressedLength);
        compressedBuffer.putInt(sourceLength);
        compressedBuffer.limit(compressedSize + SOURCE_LENGTH_BYTES);
        compressedBuffer.position(0);

        return Arrays.copyOfRange(compressedBuffer.array(), 0, compressedBuffer.limit());
    }
}
