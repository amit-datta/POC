package com.macys.search.dynamicfacetdata.repository;

import com.macys.search.dynamicfacetdata.model.Attribute;
import com.macys.search.dynamicfacetdata.model.SizeTypeGrouping;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Transactional
//@Component
@Repository
public class SiteDBRepository {

    @PersistenceContext
    private final EntityManager entityManager;


    public List<Attribute> getAllFacets() {

       /* TypedQuery<Attribute> query = entityManager.createQuery(
                "SELECT distinct attr FROM Attribute attr JOIN FETCH attr.sizeTypeGrouping",
                Attribute.class
        );

        return query.getResultList();*/

        List<Attribute> facets = new ArrayList<>();
        Attribute attribute = null;
        SizeTypeGrouping sizeTypeGrouping = null;

       /* List<Attribute> facets = entityManager.createNamedQuery("getAllFacets", Attribute.class)
                .getResultList();*/
        String  query   =   "select facet.ATTR_NAME,facet.FACET_DISPLAY_NAME,IF(facet.COLLAPSED='Y','true','false') AS collapsed,IF(facet.ADN_ATTRIBUTE='Y','true','false') AS ADN_ATTRIBUTE," +
                "facet.FACET_TYPE from(select attr.ATTR_NAME,attr.FACET_DISPLAY_NAME,IFNULL(stg.COLLAPSED,'Y') AS COLLAPSED,attr.ADN_ATTRIBUTE,attr.FACET_TYPE "+
                "from attribute as attr left outer join size_type_grouping stg on attr.ATTR_NAME = stg.ATTR_NAME) as facet where facet.FACET_DISPLAY_NAME!=''";
        List<Object[]> facetMetaDataList =  entityManager.createNativeQuery(query).getResultList();

       for(Object[] facet:facetMetaDataList){
           attribute = new Attribute();
           attribute.setFacetName(facet[0].toString());
           attribute.setFacetDisplayName(facet[1].toString());
           sizeTypeGrouping = new SizeTypeGrouping();
           sizeTypeGrouping.setCollapsed(facet[2].toString());
           attribute.setSizeTypeGrouping(sizeTypeGrouping);
           attribute.setRobotReadable(facet[3].toString());
           attribute.setFacetType(facet[4].toString());
           sizeTypeGrouping.setAttribute(attribute);
           facets.add(attribute);
       }

        return facets;


    }

}
