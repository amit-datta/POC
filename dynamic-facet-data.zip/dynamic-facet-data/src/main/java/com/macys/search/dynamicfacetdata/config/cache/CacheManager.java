package com.macys.search.dynamicfacetdata.config.cache;

import java.util.Map;
import java.util.Set;

public interface CacheManager<K , V > {

	void put(K id, V value);
	V get(K id);
	Set<K> getKeys(K pattern);
	Long deleteAllKeys();
	void putMulitpleKeys(Map<K,V> map);
}
