package com.macys.search.dynamicfacetdata.config.cache.redis;

import com.macys.search.dynamicfacetdata.config.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Map;
import java.util.Set;

public class FacetRedisCacheImpl implements CacheManager<String, Object> {

    private RedisTemplate<String, Object> redisTemplate;

    public FacetRedisCacheImpl(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public void put(String attrName, Object value) {
        redisTemplate.opsForValue().set(attrName, value);
    }

    @Override
    public Object get(String attrName) {
        return redisTemplate.opsForValue().get(attrName);
    }

    @Override
    public Set<String> getKeys(String pattern) {
        return redisTemplate.keys("*");
    }

    @Override
    public Long deleteAllKeys() {
        return redisTemplate.delete(getKeys("*"));
    }

    @Override
    public void putMulitpleKeys(Map<String, Object> map) {
        redisTemplate.opsForValue().multiSet(map);
    }
}
