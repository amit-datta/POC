package com.macys.search.dynamicfacetdata.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.RequiredArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.JoinColumn;
import java.io.Serializable;

@Getter
@Setter
@RequiredArgsConstructor
@Entity(name = "SizeTypeGrouping")
@Table(name = "size_type_grouping")
public class SizeTypeGrouping implements Serializable {

    @Id
    @Column(name = "NODE_ID")
    private Integer nodeId;

    @Column(name = "COLLAPSED")
    private String collapsed;


    @OneToOne
    @JoinColumn(name="ATTR_NAME", referencedColumnName = "ATTR_NAME")
    private Attribute attribute;


}
