package com.macys.search.dynamicfacetdata.dto;

import lombok.Getter;
import org.springframework.batch.core.JobExecution;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Getter
public class LoadFacetMetaDataResponse {
    private final static DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    private Long executionId;
    private String startTime;

    public static LoadFacetMetaDataResponse of(JobExecution jobExecution) {
        LoadFacetMetaDataResponse result = new LoadFacetMetaDataResponse();
        result.executionId = jobExecution.getId();
        result.startTime = formatDateOrNull(jobExecution.getStartTime());
        return result;
    }


    private static String formatDateOrNull(Date date) {
        return date != null ? DATE_FORMAT.format(date) : "N/A";
    }
}