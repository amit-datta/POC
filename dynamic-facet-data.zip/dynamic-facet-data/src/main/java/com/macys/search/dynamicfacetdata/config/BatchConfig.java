package com.macys.search.dynamicfacetdata.config;


import com.macys.search.dynamicfacetdata.listener.JobCompletionListener;
import com.macys.search.dynamicfacetdata.model.Attribute;
import com.macys.search.dynamicfacetdata.model.FacetMetaData;
import com.macys.search.dynamicfacetdata.step.Processor;
import com.macys.search.dynamicfacetdata.step.Reader;
import com.macys.search.dynamicfacetdata.step.Writer;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.List;

@Configuration
public class BatchConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	private Reader reader;

	@Autowired
	private Writer writer;

	@Autowired
	private Processor processor;

	@Bean
	public TaskExecutor taskExecutor() {

		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setCorePoolSize(10);
		threadPoolTaskExecutor.setQueueCapacity(15);
		threadPoolTaskExecutor.setThreadNamePrefix("CustomThreadPool_FacetMetaData");
		return threadPoolTaskExecutor;

	}

	@Bean
	public Job processJob() {
		return jobBuilderFactory.get("processJob")
				.incrementer(new RunIdIncrementer()).listener(listener())
				.flow(orderStep1()).end().build();
	}

	@Bean
	public Step orderStep1() {

		return stepBuilderFactory.get("orderStep1").<List<Attribute>, List<FacetMetaData>> chunk(1)
				.reader(reader)
				.processor(processor)
				.writer(writer)
				.build();
	}

	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}

}
