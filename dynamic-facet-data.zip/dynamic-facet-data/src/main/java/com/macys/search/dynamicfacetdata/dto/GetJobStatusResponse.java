package com.macys.search.dynamicfacetdata.dto;


import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.springframework.batch.core.JobExecution;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.macys.search.dynamicfacetdata.utils.JobUtil.FACET_JOB_SESSION_ID;
import static com.macys.search.dynamicfacetdata.utils.JobUtil.SITE_NAME_JOB_PARAM;


@Getter
public class GetJobStatusResponse {
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    private static final String UNKNOWN = "UNKNOWN";
    private String region;
    private String siteName;
    private String sessionId;
    private Long executionId;
    private String startTime;
    private String endTime;
    private String duration;
    private String status;
    private List<StepStatusResponse> steps;
    //private IndexingStatistic statistic;

    public static GetJobStatusResponse of(JobExecution jobExecution) {
        GetJobStatusResponse result = new GetJobStatusResponse();
        result.executionId = jobExecution.getId();
        result.startTime = formatDateOrNull(jobExecution.getStartTime());
        result.endTime = formatDateOrNull(jobExecution.getEndTime());
        result.duration = formatDuration(jobExecution.getStartTime(), jobExecution.getEndTime());
        result.status = jobExecution.getStatus().name();
        result.siteName = getSite(jobExecution);
        result.sessionId = getSessionId(jobExecution);
        result.steps = jobExecution.getStepExecutions().stream()
                .map(StepStatusResponse::of)
                .collect(Collectors.toList());
       /* ProcessingContext context = ProcessingContext.getContext(jobExecution);
        result.statistic = context != null ? context.getStatistic() : null;*/
        return result;
    }

    static String formatDateOrNull(Date date) {
        return date != null ? DATE_FORMAT.format(date) : null;
    }

    static String formatDuration(final Date startTime, final Date endTime) {
        if (startTime == null || endTime == null) {
            return "N/A";
        }
        final long durationMillis = endTime.getTime() - startTime.getTime();
        return DurationFormatUtils.formatDuration(durationMillis, "H:mm:ss", true);
    }



    private static String getSite(JobExecution jobExecution) {
        if (StringUtils.isNotBlank(jobExecution.getJobParameters().getString(SITE_NAME_JOB_PARAM))) {
            return jobExecution.getJobParameters().getString(SITE_NAME_JOB_PARAM);
        }
        return UNKNOWN;
    }

    private static String getSessionId(JobExecution jobExecution) {
        if (StringUtils.isNotBlank(jobExecution.getJobParameters().getString(FACET_JOB_SESSION_ID))) {
            return jobExecution.getJobParameters().getString(FACET_JOB_SESSION_ID);
        }
        return UNKNOWN;
    }
}