package com.macys.search.dynamicfacetdata.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;


@Getter
@Setter
@RequiredArgsConstructor
@Entity(name = "Attribute")
@Table(name = "attribute")
@NamedNativeQueries({
        @NamedNativeQuery(
                name    =   "getAllFacets",
                query   =   "select facet.ATTR_NAME,facet.FACET_DISPLAY_NAME,IF(facet.COLLAPSED='Y','true','false') AS collapsed,IF(facet.ADN_ATTRIBUTE='Y','true','false') AS ADN_ATTRIBUTE," +
                        "facet.FACET_TYPE from(select attr.ATTR_NAME,attr.FACET_DISPLAY_NAME,IFNULL(stg.COLLAPSED,'Y') AS COLLAPSED,attr.ADN_ATTRIBUTE,attr.FACET_TYPE "+
                        "from attribute as attr left outer join size_type_grouping stg on attr.ATTR_NAME = stg.ATTR_NAME) as facet where facet.FACET_DISPLAY_NAME!=''",
                resultClass=Attribute.class

        )
})
public class Attribute implements Serializable {


    @Id
    @Column(name = "ATTR_NAME")
    private String facetName;

    @Column(name = "FACET_DISPLAY_NAME")
    private String facetDisplayName;

    @Column(name = "ADN_ATTRIBUTE")
    private String robotReadable;

    @Column(name = "FACET_TYPE")
    private String facetType;



    @OneToOne(mappedBy = "attribute")
    private SizeTypeGrouping sizeTypeGrouping;



}
