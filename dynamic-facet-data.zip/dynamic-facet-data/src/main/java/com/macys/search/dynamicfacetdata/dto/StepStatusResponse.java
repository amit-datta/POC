package com.macys.search.dynamicfacetdata.dto;

import lombok.Getter;
import org.springframework.batch.core.StepExecution;

import static com.macys.search.dynamicfacetdata.dto.GetJobStatusResponse.formatDateOrNull;
import static com.macys.search.dynamicfacetdata.dto.GetJobStatusResponse.formatDuration;

@Getter
public class StepStatusResponse {
    public static StepStatusResponse of(StepExecution stepExecution) {
        StepStatusResponse result = new StepStatusResponse();
        result.id = stepExecution.getId();
        result.name = stepExecution.getStepName();
        result.startTime = formatDateOrNull(stepExecution.getStartTime());
        result.endTime = formatDateOrNull(stepExecution.getEndTime());
        result.duration = formatDuration(stepExecution.getStartTime(), stepExecution.getEndTime());
        result.status = stepExecution.getStatus().name();
        return result;
    }

    private Long id;
    private String name;
    private String startTime;
    private String endTime;
    private String duration;
    private String status;
}