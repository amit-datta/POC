package com.macys.search.dynamicfacetdata.services;

public enum SiteName {
    MCOM, BCOM;
}
