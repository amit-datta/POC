package com.macys.search.dynamicfacetdata.step;

import com.macys.search.dynamicfacetdata.model.Attribute;
import com.macys.search.dynamicfacetdata.repository.SiteDBRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class Reader implements ItemReader<List<Attribute>> {

	private List<Attribute> attributeList = null;
	private SiteDBRepository siteDBRepository;
	private int count = 0;

	public Reader(SiteDBRepository siteDBRepository) {
		this.siteDBRepository = siteDBRepository;
		log.info("Start facets loading");
		attributeList = siteDBRepository.getAllFacets();
		log.info("Fetched all facets from siteDB");
	}

	@Override
	public List<Attribute> read() throws Exception, UnexpectedInputException,
			ParseException, NonTransientResourceException {
		List<Attribute> attributeListChunk = new ArrayList<>();

		if(count < attributeList.size()){

			for(int i=count; i<count+50; i++){
				if(i==attributeList.size())
					break;
				attributeListChunk.add(attributeList.get(i));
			}
			count+=50;

			return attributeListChunk;
		}
		else{
			count = 0;
			return null;
		}

	}
}