package com.macys.search.dynamicfacetdata.services;


import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

import static com.macys.search.dynamicfacetdata.utils.JobUtil.FACET_JOB_SESSION_ID;
import static com.macys.search.dynamicfacetdata.utils.JobUtil.SITE_NAME_JOB_PARAM;

@Slf4j
@Service
public class LoadFacetMetaDataService {

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job processJob;

    @Autowired
    private JobExplorer jobExplorer;


    public JobExecution startFacetMetaDataLoadJob(SiteName siteName) throws Exception {

        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis())
                .addString(SITE_NAME_JOB_PARAM, siteName.name())
                .addString(FACET_JOB_SESSION_ID, UUID.randomUUID().toString())
                .toJobParameters();
        JobExecution jobExecution = jobLauncher.run(processJob, jobParameters);

        return jobExecution;
    }

    public JobExecution getJobStatus(long executionId) {
        return jobExplorer.getJobExecution(executionId);
    }
}
