package com.macys.search.dynamicfacetdata.config.cache.redis;



import com.google.common.cache.CacheBuilder;
import com.macys.search.dynamicfacetdata.config.cache.redis.serializer.FSTSerializerDeserializer;
import com.macys.search.dynamicfacetdata.config.cache.redis.serializer.Jackson2JsonSerializerDeserializer;
import com.macys.search.dynamicfacetdata.config.cache.redis.serializer.LZ4DeserializingConverter;
import com.macys.search.dynamicfacetdata.config.cache.redis.serializer.LZ4SerializingConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;
import redis.clients.jedis.JedisPoolConfig;
import com.macys.search.dynamicfacetdata.config.cache.basic.FacetBasicCache;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;


@Configuration
public class CacheConfiguration<K, V> {

    @Value("${cache.basic.size.limit:100}")
    private int maxSize;
    @Value("${cache.basic.size.ttl:60}")
    private int timeToLiveAfterWrite;
    @Value("${spring.redis.host}")
    private String redisHost;
    @Value("${spring.redis.port}")
    private int redisPort;

    @Value("${spring.redis.facet.view.database.index}")
    private int redisDataBaseIndexForFacetData;

    @Value("${search.cache.fst.enabled}")
    boolean fstEnabled;

    @Value("${search.cache.lz4.enabled}")
    boolean lz4CompressEnabled;

    @Resource
    private JedisPoolConfig jedisConnectionFactory;

    public RedisTemplate<K, V> prepareRedisTemplate(int dbIndex) {
        final RedisTemplate<K, V> template = new RedisTemplate<>();
        RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration(
                redisHost, redisPort);
        redisStandaloneConfiguration.setDatabase(dbIndex);
        JedisClientConfiguration clientConfig = JedisClientConfiguration.builder().usePooling().poolConfig(jedisConnectionFactory).build();
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(redisStandaloneConfiguration, clientConfig);
        jedisConnectionFactory.afterPropertiesSet();
        template.setConnectionFactory(jedisConnectionFactory);
        template.setDefaultSerializer(buildSerializer());
        template.setHashKeySerializer(buildSerializer());
        template.setValueSerializer(buildSerializer());
        template.setKeySerializer(new GenericJackson2JsonRedisSerializer());
        template.afterPropertiesSet();
        return template;
    }

    private RedisSerializer<?> buildSerializer() {
        return new JdkSerializationRedisSerializer(
                new LZ4SerializingConverter(fstEnabled ? new FSTSerializerDeserializer() : new Jackson2JsonSerializerDeserializer(), lz4CompressEnabled),
                new LZ4DeserializingConverter(fstEnabled ? new FSTSerializerDeserializer() : new Jackson2JsonSerializerDeserializer(), lz4CompressEnabled));
    }

    @Bean(name = "facetValuesRedisCache")
    public FacetRedisCacheImpl facetValuesRedisCache() {
        final RedisTemplate facetRedisTemplate = prepareRedisTemplate(redisDataBaseIndexForFacetData);
        return new FacetRedisCacheImpl(facetRedisTemplate);
    }

    @Bean
    public FacetBasicCache facetValuesBasicCache() {
        return new FacetBasicCache(CacheBuilder.newBuilder()
                .expireAfterWrite(timeToLiveAfterWrite, TimeUnit.SECONDS)
                .maximumSize(maxSize)
                .recordStats()
                .build());
    }


}
