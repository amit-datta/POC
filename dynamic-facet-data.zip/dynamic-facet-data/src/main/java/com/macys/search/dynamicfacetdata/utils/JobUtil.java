package com.macys.search.dynamicfacetdata.utils;

public final class JobUtil {
    public static final String SITE_NAME_JOB_PARAM = "site-name";
    public static final String FACET_JOB_SESSION_ID = "indexing-session-id";
}
