package com.macys.search.dynamicfacetdata.config.cache.redis.serializer;

import org.apache.commons.io.IOUtils;
import org.springframework.core.serializer.Deserializer;
import org.springframework.core.serializer.Serializer;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Jackson2JsonSerializerDeserializer  implements Serializer<Object>, Deserializer<Object> {
    private final GenericJackson2JsonRedisSerializer genericJackson2JsonRedisSerializer;

    public Jackson2JsonSerializerDeserializer() {
        genericJackson2JsonRedisSerializer = new GenericJackson2JsonRedisSerializer();
    }

    @Override
    public Object deserialize(InputStream inputStream) throws IOException {
        return genericJackson2JsonRedisSerializer.deserialize(inputStream.readAllBytes());
    }

    @Override
    public void serialize(Object object, OutputStream outputStream) throws IOException {
        byte[] bytes = genericJackson2JsonRedisSerializer.serialize(object);
        if (bytes != null) {
            IOUtils.copy(new ByteArrayInputStream(bytes), outputStream);
        }
    }
}
