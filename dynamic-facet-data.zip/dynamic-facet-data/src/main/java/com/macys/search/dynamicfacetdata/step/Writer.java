package com.macys.search.dynamicfacetdata.step;

import com.google.gson.Gson;
import com.macys.search.dynamicfacetdata.config.cache.CacheProvider;
import com.macys.search.dynamicfacetdata.model.FacetMetaData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class Writer implements ItemWriter<List<FacetMetaData>> {

	@Autowired
	private CacheProvider cacheProvider;

	@Value("${mcom.facet.metadata.keyname}")
	private String mcomFacetMetadataKey;


	private static List<FacetMetaData> finalFacetMetaDataList = new ArrayList<>();
	Gson gson = new Gson();

	@Override
	public void write(List<? extends List<FacetMetaData>> list) throws Exception {

		String facetMetadata = null;
		String facetMetaDataFromRedis = null;
		List<FacetMetaData> facetMetaDataList = list.get(0);

		facetMetaDataList.forEach(facetMetaData -> {
			finalFacetMetaDataList.add(facetMetaData);

		});

		facetMetadata = gson.toJson(finalFacetMetaDataList);
		cacheProvider.putEvent(mcomFacetMetadataKey,facetMetadata);

		facetMetaDataFromRedis =  cacheProvider.getEvent(mcomFacetMetadataKey).toString();

	}
}