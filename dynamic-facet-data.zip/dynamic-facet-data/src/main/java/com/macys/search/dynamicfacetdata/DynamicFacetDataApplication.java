package com.macys.search.dynamicfacetdata;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableBatchProcessing
public class DynamicFacetDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicFacetDataApplication.class, args);
	}

}
