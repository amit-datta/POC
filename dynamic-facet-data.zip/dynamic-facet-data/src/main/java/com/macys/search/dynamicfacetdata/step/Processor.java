package com.macys.search.dynamicfacetdata.step;

import com.macys.search.dynamicfacetdata.model.Attribute;
import com.macys.search.dynamicfacetdata.model.FacetMetaData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;


import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class Processor implements ItemProcessor<List<Attribute>, List<FacetMetaData>> {
	@Override
	public List<FacetMetaData> process(List<Attribute> attributes) throws Exception {

		List<FacetMetaData> facetMetaDataList = new ArrayList<>();


		attributes.stream().forEach(attribute -> {
			FacetMetaData facetMetaData = new FacetMetaData();
			facetMetaData.setFacetKey("attributes."+attribute.getFacetName());
			facetMetaData.setFacetName(attribute.getFacetName());
			facetMetaData.setDisplayName(attribute.getFacetDisplayName());
			facetMetaData.setCollapsed(attribute.getSizeTypeGrouping().getCollapsed());
			facetMetaData.setRobotReadable(attribute.getRobotReadable());
			facetMetaData.setFacetType(attribute.getFacetType());
			facetMetaDataList.add(facetMetaData);
		});

		return facetMetaDataList;
	}

}
