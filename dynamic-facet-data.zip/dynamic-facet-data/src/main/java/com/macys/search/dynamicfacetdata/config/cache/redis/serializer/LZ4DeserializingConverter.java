package com.macys.search.dynamicfacetdata.config.cache.redis.serializer;

import net.jpountz.lz4.LZ4Factory;
import net.jpountz.lz4.LZ4FastDecompressor;
import org.springframework.core.serializer.Deserializer;
import org.springframework.core.serializer.support.DeserializingConverter;

import java.nio.ByteBuffer;


public class LZ4DeserializingConverter extends DeserializingConverter {
    private static final LZ4Factory LZ4_FACTORY = LZ4Factory.fastestInstance();

    private boolean decompress;

    public LZ4DeserializingConverter(Deserializer<Object> deserializer, boolean decompress) {
        super(deserializer);
        this.decompress = decompress;
    }

    @Override
    public Object convert(byte[] source) {
        return super.convert(decompress ? decompress(source) : source);
    }

    private byte[] decompress(byte[] input) {
        if (input == null) {
            return input;
        }
        LZ4FastDecompressor decompressor = LZ4_FACTORY.fastDecompressor();
        ByteBuffer inputBuffer = ByteBuffer.wrap(input);
        int decompressedSize = inputBuffer.getInt();

        ByteBuffer decompressedBuffer = ByteBuffer.allocate(decompressedSize);
        decompressor.decompress(inputBuffer, inputBuffer.position(), decompressedBuffer, 0, decompressedSize);

        return decompressedBuffer.array();
    }
}
