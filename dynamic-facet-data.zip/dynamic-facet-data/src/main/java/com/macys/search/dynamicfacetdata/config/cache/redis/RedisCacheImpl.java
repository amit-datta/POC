package com.macys.search.dynamicfacetdata.config.cache.redis;


import com.macys.search.dynamicfacetdata.config.cache.CacheManager;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Map;
import java.util.Set;


public class RedisCacheImpl implements CacheManager<String, Object> {

    private RedisTemplate<String, Object> redisTemplate;


    public RedisCacheImpl(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public void put(String attrName, Object obj) {
        redisTemplate.opsForValue().set(attrName, obj);
    }

    @Override
    public Object get(String attrName) {
        return redisTemplate.opsForValue().get(attrName);
    }

    @Override
    public Set<String> getKeys(String pattern) {
        return redisTemplate.keys("*");
    }

    /**
     * Verify the given attribute is exists in the cache or not
     * @param attrName
     * @return
     */
    public Boolean hasKey(String attrName) {
    	boolean noSuchKey= Boolean.FALSE;
    	if(attrName != null) {
    		return redisTemplate.hasKey(attrName);
    	}
    	return noSuchKey;
    }

    /**
     * Removes all the available keys from the cache
     * @return
     */
    public Long deleteAllKeys() {
    	return redisTemplate.delete(getKeys("*"));
    }

    @Override
    public void putMulitpleKeys(Map<String, Object> map) {
        redisTemplate.opsForValue().multiSet(map);
    }


}
