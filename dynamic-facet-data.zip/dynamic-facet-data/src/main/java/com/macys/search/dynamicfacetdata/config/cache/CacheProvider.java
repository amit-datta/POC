package com.macys.search.dynamicfacetdata.config.cache;


import com.macys.search.dynamicfacetdata.config.cache.basic.FacetBasicCache;
import com.macys.search.dynamicfacetdata.model.Attribute;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

@Configuration
@Getter
public class CacheProvider {

    @Value("${redis.cache.enabled}")
    private boolean redisCacheEnabled;

    @Resource
    private FacetBasicCache facetValuesBasicCache;

    @Autowired
    @Qualifier("facetValuesRedisCache")
    private CacheManager facetValuesRedisCache;

    @PostConstruct
    public void init(){
    }


    public CacheManager getActiveCacheImplForFacetValues() {
        if (redisCacheEnabled) {
            return facetValuesRedisCache;
        }
        return facetValuesBasicCache;

    }


    /**
     * Get the facet value from the redis cache
     *
     * @param attrName
     * @return Attribute
     */
    public Object getEvent(String attrName) {
        if (redisCacheEnabled) {
            return facetValuesRedisCache.get(attrName);
        }
        return facetValuesBasicCache.get(attrName);
    }

    /**
     * Get the event value from the redis cache with default value when null
     *
     * @param attrName
     * @param obj
     * @return Attribute
     */
    public Object getEvent(String attrName, Object obj) {
        final Object val = this.getEvent(attrName);
        return (null == val) ? obj : val;
    }

    /**
     * Put rhe event and value to the redis cache
     *
     * @param attrName
     * @return void
     */
    public void putEvent(String attrName, Object obj) {
        if (redisCacheEnabled) {
            facetValuesRedisCache.put(attrName, obj);
        } else {
            facetValuesBasicCache.put(attrName, obj);
        }
    }
}
