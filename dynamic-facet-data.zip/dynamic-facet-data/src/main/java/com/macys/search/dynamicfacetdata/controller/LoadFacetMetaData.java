package com.macys.search.dynamicfacetdata.controller;
 
import com.macys.search.dynamicfacetdata.dto.GetJobStatusResponse;
import com.macys.search.dynamicfacetdata.dto.LoadFacetMetaDataResponse;
import com.macys.search.dynamicfacetdata.services.LoadFacetMetaDataService;
import com.macys.search.dynamicfacetdata.services.SiteName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
public class LoadFacetMetaData {

    @Autowired
    private LoadFacetMetaDataService loadFacetMetaDataService;

    @PostMapping("/invokeFacetMetaDataLoadJob/job/start")
    public LoadFacetMetaDataResponse startFacetMetaDataLoadJob(@RequestParam SiteName siteName) throws Exception {

        return LoadFacetMetaDataResponse.of(loadFacetMetaDataService.startFacetMetaDataLoadJob(siteName));
    }

    @GetMapping("/invokeFacetMetaDataLoadJob/job/{executionId}/status")
    public GetJobStatusResponse getReindexingStatus(@PathVariable Long executionId) {
        return GetJobStatusResponse.of(loadFacetMetaDataService.getJobStatus(executionId));
    }
}