package com.macys.search.dynamicfacetdata.model;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;

@Slf4j
@Data
public class FacetMetaData implements Serializable {

    private String facetKey;
    private String facetName;
    private String displayName;
    private String collapsed;
    private String robotReadable;
    private String facetType;

}
