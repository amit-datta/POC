package com.macys.search.dynamicfacetdata.config.cache.redis.serializer;

import com.macys.search.dynamicfacetdata.model.Attribute;
import com.macys.search.dynamicfacetdata.model.SizeTypeGrouping;
import org.nustaq.serialization.FSTConfiguration;
import org.springframework.core.serializer.Deserializer;
import org.springframework.core.serializer.Serializer;
import org.springframework.core.serializer.support.SerializationFailedException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class FSTSerializerDeserializer implements Serializer<Object>, Deserializer<Object> {

    private final ThreadLocal<FSTConfiguration> configThreadLocal = ThreadLocal.withInitial(() -> {
        FSTConfiguration config = FSTConfiguration.createMinBinConfiguration();
        config.registerCrossPlatformClassMapping(Attribute.class.getSimpleName(), Attribute.class.getName());
        config.registerCrossPlatformClassMapping(SizeTypeGrouping.class.getSimpleName(), SizeTypeGrouping.class.getName());
        // Disables cycle detection and detection of identical objects, which may speed up performance significantly
        // The unshared mode doesn't support JDK serialization methods such as readReplace/writeObject/readObject
        config.setShareReferences(true);
        return config;
    });

    @Override
    public void serialize(Object entity, OutputStream outputStream) throws IOException {
        try {
            configThreadLocal.get().encodeToStream(outputStream, entity);
        } catch (Exception e) {
            throw new SerializationFailedException("An error occurred during serialization of an entry", e);
        }
    }

    @Override
    public Object deserialize(InputStream inputStream) throws IOException {
        try {
            return configThreadLocal.get().decodeFromStream(inputStream);
        } catch (Exception e) {
            throw new SerializationFailedException("An error occurred during deserialization of an entry", e);
        }
    }
}
