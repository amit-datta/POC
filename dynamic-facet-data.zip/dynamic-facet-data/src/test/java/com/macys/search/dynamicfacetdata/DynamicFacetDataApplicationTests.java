package com.macys.search.dynamicfacetdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicFacetDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
